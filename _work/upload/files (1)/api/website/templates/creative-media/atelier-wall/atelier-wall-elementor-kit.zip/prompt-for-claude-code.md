# Build "Atelier Wall" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #121212 · Secondary #7a7a75 · Text #1b1b1b · Accent #2547d0 · Surface #fbfaf7 · Border #e3e1da

## 2. Global Fonts
Headings: Epilogue · Body: Be Vietnam Pro
H1 130px / H2 56px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 100px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Studios (studios) — html/studios.html
- Studio: Drawing Foundations (studio) — html/studio.html
- Student wall (wall) — html/wall.html
- Before & after (progress) — html/progress.html
- Faculty (faculty) — html/faculty.html
- Tuition (tuition) — html/tuition.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
