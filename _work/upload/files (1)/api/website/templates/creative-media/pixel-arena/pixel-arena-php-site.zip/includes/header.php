<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Pixel Arena';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Pixel Arena</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<header class="nav nav-bar"><div class="wrap"><a class="logo" href="index.php">Pixel Arena</a><ul><li><a href="team.php">Team</a></li><li><a href="schedule.php">Events</a></li><li><a href="shop.php">Merch</a></li><li><a href="services.php">Arena Cafe</a></li><li class="more"><a href="#" tabindex="0">All pages ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Arena Cafe</a><a href="service.php">Single Package</a><a href="pricing.php">Memberships</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Merch Shop</a><a href="product.php">Single Item</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Roster</a><a href="projects.php">Highlights</a><a href="project.php">Single Highlight</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="schedule.php">Events</a><a href="booking.php">Book a station</a><a href="trial.php">Free first hour</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><a class="btn" href="booking.php">Book a station</a><details class="burger"><summary>Menu</summary><div class="bmenu"><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Arena Cafe</a><a href="service.php">Single Package</a><a href="pricing.php">Memberships</a><a href="contact.php">Contact</a><a href="shop.php">Merch Shop</a><a href="product.php">Single Item</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Roster</a><a href="projects.php">Highlights</a><a href="project.php">Single Highlight</a><a href="gallery.php">Gallery</a><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="schedule.php">Events</a><a href="booking.php">Book a station</a><a href="trial.php">Free first hour</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></details></div></header>
<main>
