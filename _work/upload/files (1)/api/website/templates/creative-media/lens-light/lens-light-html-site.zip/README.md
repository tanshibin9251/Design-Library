# Lens & Light

Exported from Design Library · 23 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single Service, Packages, Contact, Prints, Single Print, Cart, Checkout, Testimonials, Team, Portfolio, Single Gallery, Gallery, Journal, Single post, FAQ, Book a shoot, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
