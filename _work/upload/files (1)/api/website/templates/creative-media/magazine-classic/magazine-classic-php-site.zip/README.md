# Magazine Classic

Exported from Design Library · 25 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Subscribe, Single service, Subscribe, Contact, Shop, Single Product, Cart, Checkout, Testimonials, Team, Sections, Single Section, Gallery, Latest, Single post, FAQ, Section page, Author page, Newsletter, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
