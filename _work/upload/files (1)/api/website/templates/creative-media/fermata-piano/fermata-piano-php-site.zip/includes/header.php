<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Fermata Piano';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Fermata Piano</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Fermata Piano — sheet-music paper, tokens only */
.fp-head{background:var(--c-surface);border-bottom:1px solid var(--c-primary);position:sticky;top:0;z-index:50}
.fp-staff{position:relative;display:flex;align-items:center;gap:clamp(14px,2.6vw,40px);padding:0 clamp(16px,4vw,56px);min-height:84px;background:
 linear-gradient(var(--c-primary),var(--c-primary)) 0 calc(50% - 16px)/100% 1px no-repeat,
 linear-gradient(var(--c-primary),var(--c-primary)) 0 calc(50% - 8px)/100% 1px no-repeat,
 linear-gradient(var(--c-primary),var(--c-primary)) 0 50%/100% 1px no-repeat,
 linear-gradient(var(--c-primary),var(--c-primary)) 0 calc(50% + 8px)/100% 1px no-repeat,
 linear-gradient(var(--c-primary),var(--c-primary)) 0 calc(50% + 16px)/100% 1px no-repeat}
.fp-logo{background:var(--c-surface);padding:0 14px 0 0;display:flex;align-items:center;gap:10px;font:700 24px var(--f-head);color:var(--c-primary);text-decoration:none;letter-spacing:.01em;position:relative;z-index:1}
.fp-logo i{font:400 40px/1 var(--f-head);font-style:normal;color:var(--c-accent)}
.fp-notes{display:flex;gap:clamp(8px,2.4vw,40px);list-style:none;margin-left:auto;align-items:center}
.fp-notes a{display:flex;align-items:center;gap:9px;background:var(--c-surface);padding:0 8px;min-height:44px;text-decoration:none;font:600 14px var(--f-body);color:var(--c-text);position:relative;z-index:1}
.fp-notes a::before{content:"";width:13px;height:10px;border-radius:50%;background:var(--c-primary);transform:rotate(-20deg)}
.fp-notes a:hover::before{background:var(--c-accent)}
.fp-notes a:hover{color:var(--c-accent)}
.fp-notes .more{position:relative}
.fp-notes .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(140px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-primary);min-width:520px;z-index:60}
.fp-notes .more:hover .dd,.fp-notes .more:focus-within .dd{display:grid}
.fp-notes .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.fp-notes .dd a{padding:5px 0;min-height:0;display:block}.fp-notes .dd a::before{display:none}
.fp-m{display:none;margin-left:auto;position:relative;z-index:1;background:var(--c-surface)}
.fp-m summary{list-style:none;cursor:pointer;min-height:44px;display:flex;align-items:center;padding:0 12px;font:700 12px var(--f-body);letter-spacing:.16em;border:1px solid var(--c-primary)}
.fp-m summary::-webkit-details-marker{display:none}
.fp-m nav{position:absolute;right:0;top:100%;min-width:240px;background:var(--c-surface);border:1px solid var(--c-primary);padding:8px 18px;display:grid}
.fp-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.fp-notes{display:none}.fp-m{display:block}}

.fp-sec{padding:clamp(40px,6vw,90px) clamp(18px,5vw,80px)}
.fp-hero{display:grid;grid-template-columns:1fr 1.1fr;gap:clamp(24px,5vw,80px);align-items:center;padding:clamp(40px,6vw,90px) clamp(18px,5vw,80px)}
.fp-hero h1{font:400 clamp(44px,6.4vw,var(--h1))/1.04 var(--f-head);letter-spacing:-.01em;color:var(--c-primary)}
.fp-hero h1 em{color:var(--c-accent)}
.fp-hero .lead{font:400 18px/1.8 var(--f-body);margin:20px 0 26px;max-width:44ch}
@media(max-width:900px){.fp-hero{grid-template-columns:1fr}}
.fp-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 26px;border:1.5px solid var(--c-primary);background:var(--c-primary);color:var(--on-primary);font:600 15px var(--f-body);text-decoration:none;cursor:pointer;letter-spacing:.02em}
.fp-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.fp-btn.o{background:transparent;color:var(--c-primary)}.fp-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.fp-hd{display:flex;align-items:baseline;gap:18px;border-bottom:1.5px solid var(--c-primary);padding-bottom:10px;margin-bottom:26px}
.fp-hd h2{font:400 clamp(26px,3.4vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.fp-hd span{font:600 12px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-secondary)}

/* keyboard */
.fp-kb{position:relative;display:flex;user-select:none;touch-action:manipulation;max-width:980px;border:1.5px solid var(--c-primary);background:var(--c-primary);padding:10px 10px 0;border-radius:6px 6px 0 0}
.fp-w{flex:1;position:relative;height:clamp(150px,22vw,240px);background:var(--c-surface);border:1px solid var(--c-secondary);border-top:0;border-radius:0 0 5px 5px;cursor:pointer;display:flex;align-items:flex-end;justify-content:center;padding-bottom:8px;font:600 11px var(--f-body);color:var(--c-secondary);margin:0 1px;transition:background .08s;min-width:0}
.fp-w.on{background:color-mix(in srgb,var(--c-accent) 35%,var(--c-surface))}
.fp-b{position:absolute;top:10px;width:5.2%;height:clamp(92px,13vw,142px);margin-left:-2.6%;background:var(--c-primary);border:1px solid var(--c-text);border-top:0;border-radius:0 0 4px 4px;cursor:pointer;z-index:2;color:var(--on-primary);font:600 9px var(--f-body);display:flex;align-items:flex-end;justify-content:center;padding-bottom:6px;box-shadow:0 4px 8px color-mix(in srgb,#000 30%,transparent)}
.fp-b.on{background:var(--c-accent);color:var(--on-accent)}
.fp-read{margin:16px 0 0;display:flex;align-items:baseline;gap:16px;font:400 14px var(--f-body);color:var(--c-secondary)}
.fp-read b{font:400 clamp(36px,5vw,56px)/1 var(--f-head);color:var(--c-primary);min-width:2.3em}
.fp-sc{margin-top:12px;display:flex;gap:8px;flex-wrap:wrap}
.fp-sc button{min-height:44px;padding:0 16px;border:1px solid var(--c-primary);background:transparent;font:600 13px var(--f-body);cursor:pointer;color:var(--c-primary)}
.fp-sc button:hover{background:var(--c-primary);color:var(--on-primary)}

/* programme list */
.fp-prog{border-top:1.5px solid var(--c-primary)}
.fp-prog a{display:grid;grid-template-columns:70px minmax(0,1fr) auto auto;gap:20px;align-items:baseline;padding:22px 0;border-bottom:1px solid var(--c-border);text-decoration:none;transition:padding .15s}
.fp-prog a:hover{padding-left:12px}
.fp-prog .r{font:400 28px var(--f-head);color:var(--c-accent)}
.fp-prog h3{font:400 clamp(22px,2.6vw,32px) var(--f-head);color:var(--c-primary)}
.fp-prog p{font:400 15px var(--f-body);color:var(--c-secondary);margin-top:2px}
.fp-prog .m{font:600 13px var(--f-body);letter-spacing:.06em}
@media(max-width:700px){.fp-prog a{grid-template-columns:44px 1fr;gap:6px 12px}.fp-prog .m{grid-column:2}}

/* metronome */
.fp-metro{border:1.5px solid var(--c-primary);padding:clamp(22px,3vw,40px);max-width:560px}
.fp-bpm{font:400 clamp(60px,9vw,110px)/1 var(--f-head);color:var(--c-primary)}
.fp-bpm small{font:600 14px var(--f-body);letter-spacing:.14em;color:var(--c-secondary)}
.fp-beats{display:flex;gap:12px;margin:16px 0 22px}
.fp-beats i{flex:1;height:14px;border-radius:50%;background:var(--c-border);transition:background .05s}
.fp-beats i.on{background:var(--c-accent)}
.fp-beats i.on.f{background:var(--c-primary)}
.fp-metro input[type=range]{width:100%;accent-color:var(--c-accent);padding:0;border:0;background:none;min-height:44px}
.fp-two{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:start}
@media(max-width:860px){.fp-two{grid-template-columns:1fr}}
.fp-score{border:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 60%,#fff);padding:20px;overflow:hidden}
.fp-score svg{width:100%;height:auto;display:block}
.fp-card{border:1px solid var(--c-primary);padding:26px;display:grid;gap:10px;align-content:start}
.fp-card h3{font:400 24px var(--f-head)}
.fp-card .p{font:400 40px var(--f-head);color:var(--c-primary)}
.fp-card li{list-style:none;padding:8px 0;border-top:1px solid var(--c-border);font:400 15px var(--f-body)}
.fp-3{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
@media(max-width:860px){.fp-3{grid-template-columns:1fr}}
.fp-foot{border-top:1.5px solid var(--c-primary);margin-top:clamp(40px,6vw,80px);padding:clamp(36px,5vw,64px) clamp(18px,5vw,80px) 22px;position:relative}
.fp-foot .fine{position:absolute;right:clamp(18px,5vw,80px);top:14px;font:400 14px var(--f-head);font-style:italic;color:var(--c-secondary)}
.fp-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,6vw,100px)}
.fp-foot .big{font:700 30px var(--f-head);color:var(--c-primary)}
.fp-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.fp-foot ul{list-style:none}.fp-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 14px var(--f-body);min-height:32px}
.fp-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.fp-foot .copy{margin-top:28px;font:400 12px var(--f-body);color:var(--c-secondary)}
@media(max-width:800px){.fp-foot .top{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.fp-prog a{transition:none}}
</style><header class="fp-head"><div class="fp-staff"><a class="fp-logo" href="index.php"><i>𝄞</i>Fermata</a><ul class="fp-notes"><li><a href="courses.php">Programme</a></li><li><a href="keyboard.php">Keyboard</a></li><li><a href="lesson.php">Metronome</a></li><li><a href="teachers.php">Teachers</a></li><li><a href="pricing.php">Tuition</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Learn</h4><a href="index.php">Home</a><a href="courses.php">Programme</a><a href="course.php">Course: Piano from Zero</a><a href="lesson.php">Lesson & metronome</a><a href="keyboard.php">Keyboard</a></div><div><h4>School</h4><a href="teachers.php">Teachers</a><a href="pricing.php">Tuition</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><details class="fp-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="courses.php">Programme</a><a href="course.php">Course: Piano from Zero</a><a href="lesson.php">Lesson & metronome</a><a href="keyboard.php">Keyboard</a><a href="teachers.php">Teachers</a><a href="pricing.php">Tuition</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></div></header>
<main>
