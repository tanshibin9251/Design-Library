<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="ps-sec"><div class="ps-lab">Error 404</div><h1 class="ps-mega" style="margin:20px 0 24px">Lost<br>in translation<i>.</i></h1><a class="ps-btn" href="index.php">Back to start →</a></section>
<?php include 'includes/footer.php'; ?>
