# Build "Plainspeak English" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #111111 · Secondary #6b6b6b · Text #1a1a1a · Accent #e10600 · Surface #f4f4f0 · Border #cfcfc8

## 2. Global Fonts
Headings: Schibsted Grotesk · Body: Public Sans
H1 150px / H2 52px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 100px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Courses (courses) — html/courses.html
- Course: Everyday Conversation (course) — html/course.html
- Lesson (lesson) — html/lesson.html
- Level check (level) — html/level.html
- Method (method) — html/method.html
- Tutors (tutors) — html/tutors.html
- Pricing (pricing) — html/pricing.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
