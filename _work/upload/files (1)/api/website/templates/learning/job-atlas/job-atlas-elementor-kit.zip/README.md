# Job Atlas — Elementor kit

- global-style.json: colours, fonts, sizes
- prompt-for-claude-code.md: paste into Claude Code (with your Elementor MCP) to build the site
- html/: every page as standalone HTML — open in a browser for reference or paste into an Elementor HTML widget
- tokens.css: Additional CSS for Elementor › Site Settings

Note: this is not an Elementor .json import file. Elementor builds are best recreated with native widgets; the prompt and globals make that fast.
