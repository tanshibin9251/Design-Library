# Build "Job Atlas" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1b3a4b · Secondary #5b57a6 · Text #22303a · Accent #c98a1b · Surface #f4eee2 · Border #d9cfbd

## 2. Global Fonts
Headings: Zilla Slab · Body: Lato
H1 72px / H2 42px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 10px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home: the atlas (home) — html/home.html
- All fields (plates) (browse) — html/browse.html
- Field: Banking (domain) — html/domain.html
- Role profile: Credit Analyst (role) — html/role.html
- Search roles (search) — html/search.html
- Match me (match) — html/match.html
- Compare two roles (compare) — html/compare.html
- Switch careers (switch) — html/switch.html
- Method & sources (method) — html/method.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
