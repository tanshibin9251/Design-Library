<?php $title = 'About'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>About</b></div><h1 style="font-weight:700">About</h1></div></section><section class="kn-sec" style="padding-top:0"><div style="max-width:60ch;font:500 19px/1.8 var(--f-body)"><p>Knack Index is a small team that tests every tip before we publish it. If a tip fails, we say so. Replace this with your own story and editorial standards.</p></div></section>
<?php include 'includes/footer.php'; ?>
