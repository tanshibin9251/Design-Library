<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="kn-sec" style="text-align:center;padding-top:clamp(50px,9vw,120px)"><h1 style="font:700 clamp(60px,12vw,140px)/1 var(--f-head);color:var(--c-accent);letter-spacing:-.04em">404</h1><p style="margin:10px 0 26px;font:600 22px var(--f-body)">We don't have an answer for that page yet.</p><a class="kn-top" style="display:inline-grid;--k:#ff7f6e" href="index.php"><b>Back to the index →</b></a></section>
<?php include 'includes/footer.php'; ?>
