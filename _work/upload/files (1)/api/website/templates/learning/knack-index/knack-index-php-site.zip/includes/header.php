<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Knack Index';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Knack Index</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Knack Index — everyday know-how as an index-card search, tokens only */
.kn-head{display:flex;align-items:center;gap:clamp(12px,3vw,40px);padding:0 clamp(14px,4vw,56px);min-height:72px;background:var(--c-surface);border-bottom:2px solid var(--c-primary);position:sticky;top:0;z-index:50}
.kn-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--c-primary);font:700 22px var(--f-head);letter-spacing:-.02em}
.kn-logo i{display:grid;place-items:center;width:34px;height:34px;background:var(--c-accent);color:var(--on-accent);font:700 18px var(--f-head);font-style:normal;border-radius:8px;transform:rotate(-6deg)}
.kn-nav{display:flex;gap:4px;list-style:none;margin-left:auto;align-items:center}
.kn-nav a{display:inline-flex;align-items:center;min-height:44px;padding:0 14px;text-decoration:none;font:600 15px var(--f-body);color:var(--c-text);border-radius:8px}
.kn-nav a:hover{background:color-mix(in srgb,var(--c-accent) 20%,transparent)}
.kn-nav .more{position:relative}
.kn-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:20px 24px;background:var(--c-surface);border:2px solid var(--c-primary);border-radius:12px;min-width:560px;z-index:60}
.kn-nav .more:hover .dd,.kn-nav .more:focus-within .dd{display:grid}
.kn-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.kn-nav .dd a{display:block;min-height:0;padding:5px 0;border-radius:0}.kn-nav .dd a:hover{background:none;text-decoration:underline}
.kn-m{display:none;margin-left:auto;position:relative}
.kn-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:2px solid var(--c-primary);border-radius:8px;padding:0 14px;font:700 12px var(--f-body);letter-spacing:.12em}
.kn-m summary::-webkit-details-marker{display:none}
.kn-m nav{position:absolute;right:0;top:100%;min-width:240px;background:var(--c-surface);border:2px solid var(--c-primary);border-radius:12px;padding:8px 18px;display:grid;z-index:60}
.kn-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:860px){.kn-nav{display:none}.kn-m{display:block}}

.kn-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.kn-hero{padding:clamp(40px,7vw,100px) clamp(14px,4vw,56px) clamp(30px,4vw,56px);text-align:center}
.kn-hero h1{font:700 clamp(40px,7vw,var(--h1))/1.02 var(--f-head);letter-spacing:-.035em;color:var(--c-primary);max-width:14ch;margin:0 auto}
.kn-hero h1 em{font-style:normal;background:linear-gradient(transparent 58%,var(--c-accent) 58% 90%,transparent 90%)}
.kn-hero p{font:500 20px/1.6 var(--f-body);margin:16px auto 28px;max-width:44ch}
.kn-search{display:flex;max-width:680px;margin:0 auto;border:3px solid var(--c-primary);border-radius:16px;background:#fff;background:color-mix(in srgb,var(--c-surface) 20%,#fff);overflow:hidden;box-shadow:6px 6px 0 var(--c-primary)}
.kn-search span{display:grid;place-items:center;padding:0 16px;font:700 20px var(--f-head);color:var(--c-accent)}
.kn-search input{flex:1;min-height:60px;border:0;background:transparent;font:600 19px var(--f-body);color:var(--c-text);outline:0;padding:0 8px;box-shadow:none;border-radius:0}
.kn-chips{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:22px}
.kn-chips button{min-height:44px;padding:0 16px;border:2px solid var(--c-primary);border-radius:999px;background:transparent;color:var(--c-primary);font:700 14px var(--f-body);cursor:pointer}
.kn-chips button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.kn-chips button i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px;background:var(--k,var(--c-accent))}
.kn-res{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;align-items:start}
@media(max-width:900px){.kn-res{grid-template-columns:1fr 1fr}}@media(max-width:560px){.kn-res{grid-template-columns:1fr}}
.kn-card{background:color-mix(in srgb,var(--c-surface) 30%,#fff);border:2px solid var(--c-primary);border-radius:14px;padding:0;overflow:hidden;position:relative}
.kn-card::before{content:"";display:block;height:10px;background:var(--k,var(--c-accent));border-bottom:2px solid var(--c-primary)}
.kn-card summary{list-style:none;cursor:pointer;padding:16px 18px;display:grid;gap:6px;min-height:44px}
.kn-card summary::-webkit-details-marker{display:none}
.kn-card .k{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary)}
.kn-card h3{font:700 19px/1.25 var(--f-head);letter-spacing:-.01em;color:var(--c-primary)}
.kn-card .a{padding:0 18px 18px;font:500 15px/1.7 var(--f-body)}
.kn-card .a a{color:var(--c-accent);font-weight:700}
.kn-card[open] summary h3::after{content:" –";color:var(--c-accent)}
.kn-card.hide{display:none}
.kn-none{display:none;text-align:center;padding:30px;font:600 18px var(--f-body);color:var(--c-secondary)}
.kn-tip{display:grid;grid-template-columns:auto 1fr;gap:clamp(16px,3vw,40px);align-items:center;background:var(--c-primary);color:var(--on-primary);border-radius:20px;padding:clamp(22px,3vw,40px)}
.kn-tip .n{font:700 clamp(54px,8vw,100px)/1 var(--f-head);color:var(--c-accent);letter-spacing:-.04em}
.kn-tip h3{font:700 clamp(22px,2.6vw,32px)/1.2 var(--f-head);color:var(--on-primary);margin-bottom:6px}
.kn-tip p{font:500 17px/1.7 var(--f-body);opacity:.9}
@media(max-width:600px){.kn-tip{grid-template-columns:1fr}}
.kn-h{display:flex;align-items:baseline;justify-content:space-between;gap:14px;margin-bottom:22px;flex-wrap:wrap}
.kn-h h2{font:700 clamp(26px,3.2vw,var(--h2)) var(--f-head);letter-spacing:-.025em;color:var(--c-primary)}
.kn-h a{font:700 15px var(--f-body);color:var(--c-accent)}
.kn-tops{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.kn-top{border:2px solid var(--c-primary);border-radius:14px;padding:20px;display:grid;gap:6px;text-decoration:none;background:color-mix(in srgb,var(--c-surface) 30%,#fff);transition:transform .15s,background .15s}
.kn-top:hover{transform:translateY(-3px);background:var(--k,var(--c-accent))}
.kn-top b{font:700 22px var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}.kn-top span{font:600 14px var(--f-body);color:var(--c-text)}
.kn-top i{display:block;width:34px;height:8px;border-radius:99px;background:var(--k,var(--c-accent));border:2px solid var(--c-primary);margin-bottom:8px}
@media(max-width:900px){.kn-tops{grid-template-columns:1fr 1fr}}
.kn-az{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:26px}
.kn-az a{display:grid;place-items:center;min-width:44px;min-height:44px;border:2px solid var(--c-primary);border-radius:10px;text-decoration:none;font:700 17px var(--f-head);color:var(--c-primary)}
.kn-az a:hover{background:var(--c-accent);color:var(--on-accent)}
.kn-idx h3{font:700 36px var(--f-head);color:var(--c-accent);border-bottom:2px solid var(--c-primary);margin:30px 0 8px;padding-bottom:4px}
.kn-idx a{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px dashed var(--c-secondary);text-decoration:none;font:600 17px var(--f-body);min-height:44px;align-items:center}
.kn-idx a span{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary)}
.kn-how{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(240px,1fr);gap:clamp(20px,4vw,56px);align-items:start}
@media(max-width:860px){.kn-how{grid-template-columns:1fr}}
.kn-steps{counter-reset:s;list-style:none;display:grid;gap:14px}
.kn-steps li{counter-increment:s;display:grid;grid-template-columns:48px 1fr;gap:14px;background:color-mix(in srgb,var(--c-surface) 30%,#fff);border:2px solid var(--c-primary);border-radius:14px;padding:14px;font:500 17px/1.6 var(--f-body)}
.kn-steps li::before{content:counter(s);display:grid;place-items:center;width:48px;height:48px;background:var(--c-accent);color:var(--on-accent);border-radius:10px;font:700 24px var(--f-head);align-self:start}
.kn-box{border:2px solid var(--c-primary);border-radius:14px;padding:20px;background:color-mix(in srgb,var(--c-surface) 30%,#fff);display:grid;gap:8px}
.kn-box h3{font:700 20px var(--f-head);letter-spacing:-.01em}
.kn-box ul{list-style:disc;padding-left:20px;font:500 16px/1.8 var(--f-body)}
.kn-warn{background:color-mix(in srgb,var(--c-accent) 18%,var(--c-surface))}
.kn-ck{max-width:640px;display:grid;gap:10px}
.kn-ck label{display:flex;gap:14px;align-items:center;min-height:56px;padding:0 16px;border:2px solid var(--c-primary);border-radius:12px;background:color-mix(in srgb,var(--c-surface) 30%,#fff);font:600 17px var(--f-body);cursor:pointer}
.kn-ck input{width:24px;height:24px;accent-color:var(--c-accent);padding:0;min-height:0;flex:none}
.kn-ck input:checked+span{text-decoration:line-through;opacity:.5}
.kn-bar{height:14px;border:2px solid var(--c-primary);border-radius:99px;overflow:hidden;max-width:640px;margin-bottom:20px}
.kn-bar i{display:block;height:100%;width:var(--p,0%);background:var(--c-accent);transition:width .3s}
.kn-foot{border-top:2px solid var(--c-primary);margin-top:clamp(34px,5vw,80px);padding:clamp(30px,4vw,56px) clamp(14px,4vw,56px) 22px;background:var(--c-primary);color:var(--on-primary)}
.kn-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,6vw,90px)}
.kn-foot .big{font:700 30px var(--f-head);letter-spacing:-.02em}
.kn-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:8px}
.kn-foot ul{list-style:none}.kn-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:32px}
.kn-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.kn-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.7}
@media(max-width:800px){.kn-foot .top{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.kn-top,.kn-bar i{transition:none}}
</style><header class="kn-head"><a class="kn-logo" href="index.php"><i>?</i>knack index</a><ul class="kn-nav"><li><a href="topics.php">Topics</a></li><li><a href="atoz.php">A–Z</a></li><li><a href="checklists.php">Checklists</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Find</h4><a href="index.php">Home</a><a href="topics.php">Topics</a><a href="atoz.php">A–Z index</a></div><div><h4>Read</h4><a href="guide.php">Guide: Remove a red wine stain</a><a href="checklists.php">Checklists</a></div><div><h4>Info</h4><a href="about.php">About</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><details class="kn-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="topics.php">Topics</a><a href="atoz.php">A–Z index</a><a href="guide.php">Guide: Remove a red wine stain</a><a href="checklists.php">Checklists</a><a href="about.php">About</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header>
<main>
