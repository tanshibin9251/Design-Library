<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Commit Camp';
$dark = true;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Commit Camp</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Commit Camp — IDE-chrome coding bootcamp, tokens only */
body{font-feature-settings:"liga" 1}
.cc-shell{display:grid;grid-template-columns:250px minmax(0,1fr);min-height:100vh}
.cc-side{position:sticky;top:0;align-self:start;height:100vh;overflow:auto;border-right:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 82%,#000);display:flex;flex-direction:column}
.cc-dots{display:flex;gap:7px;padding:14px 16px}.cc-dots i{width:11px;height:11px;border-radius:50%;background:var(--c-border)}.cc-dots i:nth-child(1){background:var(--c-accent)}
.cc-logo{display:block;padding:6px 16px 18px;font:700 17px var(--f-head);color:var(--c-primary);text-decoration:none;letter-spacing:0}
.cc-logo span{color:var(--c-accent)}
.cc-tree h4{font:600 11px var(--f-head);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);padding:14px 16px 6px}
.cc-tree a{display:flex;align-items:center;gap:8px;padding:8px 16px 8px 22px;min-height:40px;text-decoration:none;font:400 13px var(--f-head);color:var(--c-text);border-left:2px solid transparent}
.cc-tree a::before{content:"▸";color:var(--c-secondary);font-size:10px}
.cc-tree a:hover{background:color-mix(in srgb,var(--c-primary) 6%,transparent)}
.cc-tree a.on{background:color-mix(in srgb,var(--c-accent) 12%,transparent);border-left-color:var(--c-accent);color:var(--c-primary)}
.cc-side .cta{margin:auto 16px 18px;display:grid;place-items:center;min-height:44px;background:var(--c-accent);color:var(--on-accent);text-decoration:none;font:700 13px var(--f-head);border-radius:6px}
.cc-main{min-width:0;display:flex;flex-direction:column}
.cc-tabs{display:flex;gap:0;border-bottom:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 82%,#000);overflow:auto}
.cc-tabs span{padding:11px 18px;font:400 12px var(--f-head);color:var(--c-secondary);border-right:1px solid var(--c-border);white-space:nowrap}
.cc-tabs span.on{color:var(--c-primary);background:var(--c-surface);box-shadow:inset 0 2px 0 var(--c-accent)}
.cc-body{flex:1;min-width:0}
.cc-m{display:none}
@media(max-width:900px){.cc-shell{grid-template-columns:1fr}.cc-side{display:none}.cc-m{display:block;position:sticky;top:0;z-index:40;background:var(--c-surface);border-bottom:1px solid var(--c-border)}
 .cc-m summary{list-style:none;cursor:pointer;min-height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;font:700 15px var(--f-head);color:var(--c-primary)}
 .cc-m summary::-webkit-details-marker{display:none}.cc-m summary b{font:400 12px var(--f-head);color:var(--c-secondary);border:1px solid var(--c-border);padding:6px 10px;border-radius:6px}
 .cc-m nav{display:grid;padding:4px 16px 16px}.cc-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:400 14px var(--f-head);min-height:44px}}

.cc-sec{padding:clamp(40px,6vw,84px) clamp(18px,4vw,64px)}
.cc-cm{font:400 13px var(--f-head);color:var(--c-secondary);margin-bottom:14px}
.cc-cm b{color:var(--c-accent);font-weight:400}
.cc-h1{font:700 clamp(34px,5.2vw,var(--h1)) var(--f-head);letter-spacing:-.02em;line-height:1.08;color:var(--c-primary)}
.cc-h1 em{font-style:normal;color:var(--c-accent)}
.cc-btn{display:inline-flex;align-items:center;gap:10px;min-height:46px;padding:0 22px;border:1px solid var(--c-accent);background:var(--c-accent);color:var(--on-accent);font:700 14px var(--f-head);text-decoration:none;border-radius:6px;cursor:pointer}
.cc-btn.o{background:transparent;color:var(--c-accent)}
.cc-btn:hover{filter:brightness(1.12)}
.cc-term{border:1px solid var(--c-border);border-radius:10px;background:color-mix(in srgb,var(--c-surface) 70%,#000);overflow:hidden;font:400 14px/1.8 var(--f-head)}
.cc-term .bar{display:flex;gap:7px;padding:10px 14px;border-bottom:1px solid var(--c-border)}.cc-term .bar i{width:10px;height:10px;border-radius:50%;background:var(--c-border)}
.cc-term pre{padding:18px 20px;white-space:pre-wrap;word-break:break-word;color:var(--c-text)}
.cc-term .p{color:var(--c-accent)}.cc-term .d{color:var(--c-secondary)}.cc-term .k{color:var(--c-primary)}
.cc-cur{display:inline-block;width:.6em;height:1.1em;background:var(--c-accent);vertical-align:-.15em;animation:ccb 1s steps(2) infinite}
@keyframes ccb{50%{opacity:0}}
.cc-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.cc-card{border:1px solid var(--c-border);border-radius:10px;background:color-mix(in srgb,var(--c-surface) 70%,#000);padding:22px;display:grid;gap:10px;align-content:start;text-decoration:none;transition:border-color .2s,transform .2s}
.cc-card:hover{border-color:var(--c-accent);transform:translateY(-2px)}
.cc-card .t{font:400 12px var(--f-head);color:var(--c-accent)}
.cc-card h3{font:700 19px var(--f-head);letter-spacing:-.01em;color:var(--c-primary)}
.cc-card p{font:400 14px/1.7 var(--f-body);color:var(--c-text);opacity:.85}
.cc-card .m{display:flex;gap:14px;font:400 12px var(--f-head);color:var(--c-secondary);margin-top:6px}
.cc-bar{height:6px;border-radius:99px;background:var(--c-border);overflow:hidden}.cc-bar i{display:block;height:100%;background:var(--c-accent);width:var(--p)}
@media(max-width:1000px){.cc-grid{grid-template-columns:1fr 1fr}}@media(max-width:640px){.cc-grid{grid-template-columns:1fr}}
.cc-log{font:400 14px/1.9 var(--f-head);display:grid;gap:0}
.cc-log a,.cc-log div{display:grid;grid-template-columns:62px 1fr auto;gap:14px;padding:6px 0;text-decoration:none;align-items:baseline}
.cc-log .g{color:var(--c-accent);white-space:pre}.cc-log .h{color:var(--c-secondary)}
.cc-log .tag{font-size:11px;border:1px solid var(--c-accent);color:var(--c-accent);padding:1px 8px;border-radius:99px}
.cc-log b{font-weight:400;color:var(--c-primary)}
.cc-play{display:grid;grid-template-columns:1fr 1fr;gap:0;border:1px solid var(--c-border);border-radius:10px;overflow:hidden;min-height:440px}
.cc-play textarea{width:100%;height:100%;min-height:440px;border:0;border-radius:0;border-right:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 70%,#000);color:var(--c-text);font:400 14px/1.7 var(--f-head);padding:18px;resize:none;outline:0;box-shadow:none}
.cc-play iframe{width:100%;height:100%;min-height:440px;border:0;background:#fff}
@media(max-width:800px){.cc-play{grid-template-columns:1fr}.cc-play textarea{border-right:0;border-bottom:1px solid var(--c-border);min-height:260px}.cc-play iframe{min-height:300px}}
.cc-player{border:1px solid var(--c-border);border-radius:10px;overflow:hidden;background:color-mix(in srgb,var(--c-surface) 70%,#000)}
.cc-vid{aspect-ratio:16/9;display:grid;place-items:center;background:repeating-linear-gradient(45deg,transparent 0 16px,color-mix(in srgb,var(--c-primary) 5%,transparent) 16px 17px);position:relative}
.cc-vid span{width:68px;height:68px;border-radius:50%;background:var(--c-accent);color:var(--on-accent);display:grid;place-items:center;font-size:22px}
.cc-vid em{position:absolute;left:14px;bottom:10px;font:400 11px var(--f-head);font-style:normal;color:var(--c-secondary)}
.cc-ctl{display:flex;justify-content:space-between;padding:12px 16px;font:400 12px var(--f-head);color:var(--c-secondary);border-top:1px solid var(--c-border)}
.cc-split{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(260px,1fr);gap:clamp(20px,3vw,40px);align-items:start}
@media(max-width:900px){.cc-split{grid-template-columns:1fr}}
.cc-list{display:grid;gap:0;border:1px solid var(--c-border);border-radius:10px;overflow:hidden}
.cc-list a{display:grid;grid-template-columns:30px 1fr auto;gap:10px;padding:13px 16px;border-bottom:1px solid var(--c-border);text-decoration:none;font:400 13px var(--f-head);min-height:44px;align-items:center}
.cc-list a:last-child{border-bottom:0}.cc-list .n{color:var(--c-secondary)}.cc-list .on{color:var(--c-accent)}
.cc-list a.cur{background:color-mix(in srgb,var(--c-accent) 12%,transparent)}
.cc-price{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.cc-price>div{border:1px solid var(--c-border);border-radius:10px;padding:26px;display:grid;gap:12px;align-content:start}
.cc-price>.hl{border-color:var(--c-accent);box-shadow:0 0 0 1px var(--c-accent)}
.cc-price .p{font:700 38px var(--f-head);color:var(--c-primary)}.cc-price .p small{font:400 14px var(--f-head);color:var(--c-secondary)}
.cc-price li{list-style:none;font:400 14px var(--f-body);padding:7px 0;border-top:1px solid var(--c-border)}.cc-price li::before{content:"✓ ";color:var(--c-accent)}
@media(max-width:900px){.cc-price{grid-template-columns:1fr}}
.cc-status{display:flex;gap:18px;flex-wrap:wrap;align-items:center;background:var(--c-accent);color:var(--on-accent);padding:0 16px;min-height:28px;font:400 12px var(--f-head);position:sticky;bottom:0;z-index:10}
.cc-status a{color:inherit;text-decoration:none}
.faq summary{font-family:var(--f-head);font-size:16px}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.cc-cur{animation:none}.cc-card{transition:none}}
</style><details class="cc-m"><summary><span>commit<span style="color:var(--c-accent)">.</span>camp</span><b>menu</b></summary><nav><a href="index.php">index.html</a><a href="courses.php">courses/</a><a href="course.php">web-dev-101.md</a><a href="lesson.php">lesson-03.js</a><a href="roadmap.php">roadmap.log</a><a href="playground.php">playground.html</a><a href="pricing.php">pricing.json</a><a href="mentors.php">mentors.yml</a><a href="faq.php">faq.md</a><a href="privacy.php">privacy.txt</a><a href="404.php">404.err</a></nav></details><div class="cc-shell"><aside class="cc-side"><div class="cc-dots"><i></i><i></i><i></i></div><a class="cc-logo" href="index.php">commit<span>.</span>camp</a><div class="cc-tree"><h4>Learn</h4><a class="" href="index.php">index.html</a><a class="" href="courses.php">courses/</a><a class="" href="course.php">web-dev-101.md</a><a class="" href="lesson.php">lesson-03.js</a><a class="" href="roadmap.php">roadmap.log</a><a class="" href="playground.php">playground.html</a></div><div class="cc-tree"><h4>Camp</h4><a class="" href="pricing.php">pricing.json</a><a class="" href="mentors.php">mentors.yml</a><a class="" href="faq.php">faq.md</a></div><div class="cc-tree"><h4>Utility</h4><a class="" href="privacy.php">privacy.txt</a><a class="" href="404.php">404.err</a></div><a class="cta" href="pricing.php">$ enroll --free-week</a></aside><div class="cc-main"><div class="cc-tabs"><span class="on">commit.camp</span><span>~/learn</span><span>main ✓</span></div><div class="cc-body">
<main>
