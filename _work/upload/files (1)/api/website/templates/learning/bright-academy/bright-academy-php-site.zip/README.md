# Bright Academy

Exported from Design Library · 20 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Courses, Single Course, Fees, Contact, Testimonials, Team, Student Work, Single Project, Gallery, Blog, Single post, FAQ, Timetable, Free trial, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
