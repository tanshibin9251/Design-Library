<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Bright Academy';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Bright Academy</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.ba-nav{display:flex;list-style:none;align-items:center;gap:4px}
.ba-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.ba-nav .more{position:relative}
.ba-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.ba-nav .more:hover .dd,.ba-nav .more:focus-within .dd{display:grid}
.ba-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.ba-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.ba-m{display:none;position:relative;margin-left:auto}
.ba-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.ba-m summary::-webkit-details-marker{display:none}
.ba-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.ba-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.ba-nav{display:none}.ba-m{display:block}}
.ba-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.ba-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ba-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.ba-foot ul{list-style:none}.ba-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.ba-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.ba-foot .top{grid-template-columns:1fr}.ba-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Bright Academy v2 — tuition centre with a build-your-own timetable, tokens only */
.ba-head{display:flex;align-items:flex-end;gap:20px;padding:14px clamp(14px,4vw,56px) 0;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:3px solid var(--c-primary)}
.ba-logo{font:700 26px var(--f-head);color:var(--c-primary);text-decoration:none;letter-spacing:-.02em;padding-bottom:12px;display:flex;align-items:baseline;gap:8px}
.ba-logo b{background:var(--c-accent);padding:0 8px;border-radius:6px 6px 0 0}
.ba-nav{margin-left:auto;align-items:flex-end;gap:2px}
.ba-nav a{padding:0 18px;min-height:46px;border:3px solid transparent;border-bottom:0;border-radius:12px 12px 0 0;font:600 15px var(--f-body);color:var(--c-text);margin-bottom:-3px}
.ba-nav a:hover{background:color-mix(in srgb,var(--c-secondary) 55%,transparent)}
.ba-cta{background:var(--c-primary);color:var(--on-primary)!important;border-color:var(--c-primary)!important}
.ba-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.ba-hero{display:grid;grid-template-columns:.85fr 1.15fr;gap:clamp(20px,4vw,60px);align-items:start;padding:clamp(28px,5vw,64px) clamp(14px,4vw,56px)}
@media(max-width:960px){.ba-hero{grid-template-columns:1fr}}
.ba-hero h1{font:700 clamp(36px,5.2vw,var(--h1))/1.04 var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.ba-hero h1 u{text-decoration:none;background:linear-gradient(transparent 58%,var(--c-accent) 58% 92%,transparent 92%)}
.ba-hero p{font:400 18px/1.7 var(--f-body);margin:16px 0 22px;max-width:36ch}
.ba-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 26px;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);text-decoration:none;border:3px solid var(--c-primary);border-radius:10px;cursor:pointer}
.ba-btn:hover{background:var(--c-accent);color:var(--on-accent)}.ba-btn.o{background:transparent;color:var(--c-primary)}
.ba-tt{border:3px solid var(--c-primary);border-radius:18px;padding:clamp(14px,2vw,24px);background:var(--c-surface);box-shadow:8px 8px 0 var(--c-accent)}
.ba-sub{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px;align-items:center}.ba-sub b{font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin-right:6px}
.ba-sub button{min-height:44px;padding:0 14px;border:2px solid var(--c-primary);border-radius:99px;background:transparent;color:var(--c-primary);font:700 14px var(--f-body);cursor:pointer}
.ba-sub button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.ba-g{display:grid;grid-template-columns:70px repeat(5,1fr);gap:4px}
.ba-g .h{font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase;text-align:center;padding:6px 0}
.ba-g .t{font:600 12px var(--f-body);display:grid;place-items:center;color:var(--c-secondary)}
.ba-g button{min-height:48px;border:2px dashed var(--c-border);border-radius:10px;background:transparent;font:700 13px var(--f-body);cursor:pointer;color:var(--c-text);padding:0}
.ba-g button:hover{border-color:var(--c-primary)}
.ba-g button[data-s]{border-style:solid;border-color:var(--c-primary);background:var(--c-accent);color:var(--on-accent)}
.ba-g button[data-s=Math]{background:var(--c-primary);color:var(--on-primary)}.ba-g button[data-s=Science]{background:var(--c-secondary);color:var(--c-primary)}.ba-g button[data-s=Chinese]{background:color-mix(in srgb,var(--c-accent) 55%,var(--c-surface))}
.ba-sum{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-top:12px;padding-top:12px;border-top:2px solid var(--c-primary);font:600 15px var(--f-body)}
.ba-sum b{font:700 30px var(--f-head);color:var(--c-primary)}
@media(max-width:560px){.ba-g{grid-template-columns:48px repeat(5,1fr);gap:3px}.ba-g button{min-height:44px;font-size:11px}}
.ba-h{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:20px;flex-wrap:wrap;gap:10px}
.ba-h h2{font:700 clamp(26px,3.2vw,var(--h2)) var(--f-head);letter-spacing:-.025em}
.ba-rp{display:grid;grid-template-columns:1fr 1fr;gap:clamp(18px,3vw,44px);align-items:center;border:3px solid var(--c-primary);border-radius:18px;padding:clamp(18px,3vw,36px)}
@media(max-width:800px){.ba-rp{grid-template-columns:1fr}}
.ba-bar{display:grid;gap:12px}.ba-bar div{display:grid;grid-template-columns:90px 1fr 56px;gap:12px;align-items:center;font:700 15px var(--f-body)}
.ba-bar i{display:block;height:16px;background:var(--c-border);border-radius:99px;overflow:hidden}.ba-bar i::after{content:"";display:block;height:100%;width:var(--p);background:var(--c-primary)}.ba-bar i.n::after{background:var(--c-accent)}
.ba-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.ba-foot .big{font:700 30px var(--f-head);letter-spacing:-.02em}
.ba .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.ba .pagehead h1{max-width:none}.ba .card,.ba .scard,.ba .qcard,.ba .pcard,.ba .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.ba .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.ba .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.ba .svc{display:block;border:2px solid var(--c-primary)}
.ba .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr) 150px 110px;gap:0;align-items:stretch;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:0}
.ba .scard:nth-child(even){background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}
.ba .scard .ph{display:none}.ba .scard .b{display:contents}
.ba .scard h3{padding:18px;font-size:19px;border-right:1px solid var(--c-border)}
.ba .scard p{padding:18px;margin:0;border-right:1px solid var(--c-border);opacity:.85;font-size:15px}
.ba .scard .m{display:contents}.ba .scard .m b{padding:18px;border-right:1px solid var(--c-border);font-size:15px}.ba .scard .m span{padding:18px;font-size:14px;opacity:.75}
@media(max-width:820px){.ba .scard{grid-template-columns:1fr 1fr}.ba .scard h3{grid-column:1/-1;border-right:0}.ba .scard p{grid-column:1/-1;border-right:0;padding-top:0}}

.ba .tgrid{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:2px solid var(--c-primary)}
.ba .person{display:grid;grid-template-columns:110px 1fr;gap:4px 18px;align-items:center;padding:20px 20px 20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;text-align:left}
.ba .person .ph{grid-row:span 2;aspect-ratio:1!important}
@media(max-width:700px){.ba .tgrid{grid-template-columns:1fr}}

.ba .qgrid{display:block;border-top:2px solid var(--c-primary)}.ba .qgrid.mt{margin-top:0}
.ba .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.ba .qcard .stars{grid-column:1}.ba .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.ba .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.ba .qcard{grid-template-columns:1fr}.ba .qcard figcaption{grid-column:1;grid-row:auto}}

.ba .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.ba .masonry .mi{margin:0}.ba .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.ba .masonry{grid-template-columns:1fr 1fr}}

.ba .articles{display:block!important}
.ba .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.ba .art .ph{display:none}.ba .art .meta{grid-row:1/span 2;align-self:start}.ba .art h3{margin:0}
.ba .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}
.ba .faq{max-width:none;columns:2 340px;column-gap:clamp(24px,5vw,72px)}.ba .faq details{break-inside:avoid}

.ba .pricing{display:block;border-top:2px solid var(--c-primary)}
.ba .pricing .card{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1.5fr) auto;gap:10px 28px;align-items:center;padding:24px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none!important;box-shadow:none;transform:none!important;color:inherit!important}
.ba .pricing .card h3,.ba .pricing .card .amt{color:var(--c-primary)!important;margin:0}
.ba .pricing .card.hl{background:color-mix(in srgb,var(--c-accent) 12%,var(--c-surface))!important}
.ba .pricing ul{margin:0;display:flex;gap:6px 16px;flex-wrap:wrap}.ba .pricing li{font-size:14px}
@media(max-width:820px){.ba .pricing .card{grid-template-columns:1fr auto}.ba .pricing ul{grid-column:1/-1}}

.ba .cinfo{display:block;border-top:2px solid var(--c-primary)}
.ba .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.ba .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.ba .cinfo .card p{margin:0}
.ba .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.ba .sec.dark h2,.ba .sec.dark p{color:var(--c-text)}
.ba .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.ba .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.ba .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.ba .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.ba .tl>div:last-child{border-right:0}
.ba .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.ba .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.ba .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.ba .vals .card:last-child{border-right:0}
@media(max-width:700px){.ba .vals{grid-template-columns:1fr}.ba .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><header class="ba-head"><a class="ba-logo" href="index.php">Bright<b>Academy</b></a><ul class="ba-nav"><li><a href="services.php">Programmes</a></li><li><a href="schedule.php">Timetable</a></li><li><a href="team.php">Teachers</a></li><li><a href="blog.php">Parents</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Courses</a><a href="service.php">Single Course</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Student Work</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Blog</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="schedule.php">Timetable</a><a href="trial.php">Free trial</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="ba-cta" href="trial.php">Free trial class</a></li></ul><details class="ba-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Courses</a><a href="service.php">Single Course</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Student Work</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a><a href="blog.php">Blog</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="schedule.php">Timetable</a><a href="trial.php">Free trial</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="ba">
<main>
