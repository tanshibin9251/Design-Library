# Build "Casa Makeover" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #6c4ad9 · Secondary #ff8fa3 · Text #2b2540 · Accent #2ec4b6 · Surface #fff9f2 · Border #e8dff5

## 2. Global Fonts
Headings: Quicksand · Body: Nunito
H1 88px / H2 48px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 24px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Packages (packages) — html/packages.html
- Budget buddy (calculator) — html/calculator.html
- Style quiz (quiz) — html/quiz.html
- Before & afters (gallery) — html/gallery.html
- Happy homes (reviews) — html/reviews.html
- How it works (how) — html/how.html
- Questions (faq) — html/faq.html
- Say hello (contact) — html/contact.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
