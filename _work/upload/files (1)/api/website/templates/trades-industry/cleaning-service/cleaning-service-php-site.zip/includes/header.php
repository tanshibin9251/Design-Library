<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Sparkle Nest';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Sparkle Nest</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Sparkle Nest — tokens only */
.cs-head{background:var(--c-surface);position:sticky;top:0;z-index:40;border-bottom:1px solid var(--c-border)}
.cs-head .in{max-width:var(--w);margin:auto;display:flex;justify-content:space-between;align-items:center;gap:14px;padding:12px 20px}
.cs-logo{font:700 24px var(--f-head);text-decoration:none;color:var(--c-primary);display:flex;gap:8px;align-items:center}
.cs-logo i{width:32px;height:32px;border-radius:10px 10px 10px 2px;background:var(--c-accent);display:grid;place-items:center;font-style:normal;color:var(--c-primary);font-size:18px}
.cs-head ul{display:flex;gap:6px;list-style:none;font:600 15px var(--f-body)}
.cs-head ul>li>a{display:block;padding:.5em .9em;border-radius:99px;text-decoration:none}.cs-head ul>li>a:hover{background:color-mix(in srgb,var(--c-accent) 25%,var(--c-surface))}
.cs-btn{background:var(--c-primary);color:var(--on-primary);padding:.8em 1.5em;border-radius:99px;font:700 15px var(--f-body);text-decoration:none;display:inline-block}
.cs-btn.o{background:none;color:var(--c-primary);box-shadow:inset 0 0 0 2px var(--c-primary)}
.cs-hero{max-width:var(--w);margin:auto;padding:clamp(30px,5vw,70px) 20px;display:grid;grid-template-columns:1.1fr 1fr;gap:34px;align-items:center}
.cs-hero h1{font-size:clamp(38px,5.8vw,var(--h1));line-height:1.06;color:var(--c-primary)}
.cs-hero p{font:500 18px/1.6 var(--f-body);max-width:42ch;margin:16px 0 22px}
.cs-chk{display:flex;gap:16px;flex-wrap:wrap;margin-top:18px;font:700 14px var(--f-body)}.cs-chk span::before{content:"✓";display:inline-grid;place-items:center;width:1.5em;height:1.5em;border-radius:50%;background:var(--c-accent);color:var(--c-primary);margin-right:6px;font-size:.8em}
.cs-q{border-radius:24px;background:var(--c-primary);color:var(--on-primary);padding:26px;box-shadow:0 30px 60px -30px color-mix(in srgb,var(--c-primary) 70%,transparent)}
.cs-q h3{font:700 22px var(--f-head);color:var(--on-primary);margin-bottom:14px}
.cs-q .row{margin-bottom:14px}.cs-q label.l{display:flex;justify-content:space-between;font:700 13px var(--f-body);margin-bottom:6px;opacity:.9}
.cs-seg{display:grid;grid-auto-flow:column;gap:6px}.cs-seg label{position:relative}.cs-seg input{position:absolute;opacity:0}
.cs-seg span{display:block;text-align:center;padding:.7em 0;border-radius:12px;background:color-mix(in srgb,var(--on-primary) 14%,transparent);font:700 14px var(--f-body);cursor:pointer}
.cs-seg input:checked+span{background:var(--c-accent);color:var(--c-primary)}.cs-seg input:focus-visible+span{outline:3px solid var(--on-primary)}
.cs-q .tot{display:flex;justify-content:space-between;align-items:baseline;border-top:1px dashed color-mix(in srgb,var(--on-primary) 40%,transparent);padding-top:14px;margin-top:6px}
.cs-q .tot b{font:700 36px var(--f-head);color:var(--c-accent)}
.cs-sec{padding:var(--pad) 20px}.cs-sec>.in{max-width:var(--w);margin:auto}
.cs-sv{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.cs-sc{border-radius:22px;background:color-mix(in srgb,var(--c-accent) 14%,var(--c-surface));padding:22px}
.cs-sc .ic{width:52px;height:52px;border-radius:16px;background:var(--c-primary);color:var(--c-accent);display:grid;place-items:center;font-size:24px;margin-bottom:12px}
.cs-sc h3{font:700 20px var(--f-head)}.cs-sc .p{font:700 15px var(--f-body);color:var(--c-primary);margin-top:8px}
.cs-list{list-style:none;padding:0;margin:12px 0 0;display:grid;gap:6px;font:500 14.5px var(--f-body)}.cs-list li::before{content:"✓ ";color:var(--c-primary);font-weight:800}
.cs-ar{display:flex;flex-wrap:wrap;gap:8px}.cs-ar span{padding:.45em 1em;border-radius:99px;border:2px solid var(--c-primary);font:700 14px var(--f-body)}.cs-ar span.s{background:var(--c-accent);border-color:var(--c-accent)}
.cs-foot{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:820px){.cs-head ul{display:none}.cs-hero,.cs-sv{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}.cs-head .more{position:relative}.cs-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:16px;}.cs-head .more:hover .dd,.cs-head .more:focus-within .dd{display:grid}.cs-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.cs-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.cs-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-text)}.cs-hero h1,.cs-logo{color:var(--c-primary)}.cs-q h3{color:var(--on-primary)}</style><header class="cs-head"><div class="in"><a class="cs-logo" href="index.php"><i>✦</i>Sparkle Nest</a><ul><li><a href="services.php">Services</a></li><li><a href="quote.php">Instant quote</a></li><li><a href="plans.php">Plans</a></li><li><a href="areas.php">Areas</a></li><li class="more" style="position:relative"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Clean</h4><a href="index.php">Home</a><a href="services.php">Services</a><a href="quote.php">Instant quote</a><a href="plans.php">Plans</a><a href="areas.php">Service areas</a><a href="how.php">How it works</a><a href="reviews.php">Reviews</a><a href="contact.php">Book</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="cs-btn" href="contact.php">Book a clean</a></div></header>
<main>
