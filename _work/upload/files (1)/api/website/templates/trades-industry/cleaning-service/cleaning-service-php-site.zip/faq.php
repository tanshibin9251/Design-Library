<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="cs-sec"><div class="in"><div class="faq"><details open><summary>Do I need to be home?</summary><p>No. Many clients use a smart lock or leave keys with the guard.</p></details><details><summary>Do you bring supplies?</summary><p>Yes, eco-friendly supplies are included.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
