<?php $title = 'Licences & safety'; include 'includes/header.php'; ?>
<div class="bp-sheet"><section class="bp-sec"><span class="bp-label">Reference B</span><h2>Licences &amp; safety</h2><div class="bp-row" style="border:1px solid var(--c-text)"><div><b>G4</b><span>CIDB grade</span></div><div><b>CCC</b><span>Electrical competent</span></div><div><b>ISO</b><span>45001 certified</span></div><div><b>RM 5m</b><span>Public liability</span></div></div></section></div>
<?php include 'includes/footer.php'; ?>
