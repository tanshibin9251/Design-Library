<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="tq-sec"><div class="in"><div class="faq"><details open><summary>Do you use genuine parts?</summary><p>Genuine or OEM-grade, your choice, shown in the quote.</p></details><details><summary>Is there a warranty?</summary><p>6 months or 10,000 km on parts and labour.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
