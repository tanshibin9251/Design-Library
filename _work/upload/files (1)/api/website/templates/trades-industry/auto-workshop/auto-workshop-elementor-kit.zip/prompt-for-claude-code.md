# Build "Torque Garage" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1f2f46 · Secondary #5b6676 · Text #14181f · Accent #ffc400 · Surface #f4f5f6 · Border #cfd3d8

## 2. Global Fonts
Headings: Rubik · Body: Roboto Condensed
H1 84px / H2 46px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 80px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Services (services) — html/services.html
- Service packages (packages) — html/packages.html
- Track your car (tracker) — html/tracker.html
- Book a slot (book) — html/book.html
- About (about) — html/about.html
- Contact (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
