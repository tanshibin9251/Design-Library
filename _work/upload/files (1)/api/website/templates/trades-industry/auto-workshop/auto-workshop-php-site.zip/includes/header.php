<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Torque Garage';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Torque Garage</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Torque Garage — tokens only */
.tq-top{background:var(--c-text);color:var(--c-surface);font:600 12.5px var(--f-body);letter-spacing:.06em;padding:8px 20px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px}
.tq-top b{color:var(--c-accent)}
.tq-head{background:var(--c-surface);border-bottom:4px solid var(--c-accent);position:sticky;top:0;z-index:40}
.tq-head .in{max-width:var(--w);margin:auto;display:flex;justify-content:space-between;align-items:center;gap:14px;padding:10px 20px}
.tq-logo{font:700 26px var(--f-head);text-decoration:none;text-transform:uppercase;letter-spacing:.02em;display:flex;align-items:center;gap:10px}
.tq-logo i{width:40px;height:40px;background:var(--c-primary);color:var(--c-accent);display:grid;place-items:center;clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);font:700 18px var(--f-head);font-style:normal}
.tq-head ul{display:flex;gap:4px;list-style:none;font:700 14px var(--f-body);text-transform:uppercase;letter-spacing:.06em}
.tq-head ul>li>a{display:block;padding:.6em 1em;text-decoration:none}.tq-head ul>li>a:hover{background:var(--c-accent)}
.tq-btn{background:var(--c-primary);color:var(--on-primary);padding:.8em 1.4em;font:700 14px var(--f-body);text-transform:uppercase;letter-spacing:.08em;text-decoration:none;display:inline-block;clip-path:polygon(0 0,calc(100% - 12px) 0,100% 50%,calc(100% - 12px) 100%,0 100%)}
.tq-btn.y{background:var(--c-accent);color:var(--c-text)}
.tq-hero{background:var(--c-primary);color:var(--on-primary);position:relative;overflow:hidden}
.tq-hero::after{content:"";position:absolute;right:-6%;top:0;bottom:0;width:36%;background:repeating-linear-gradient(115deg,var(--c-accent) 0 26px,transparent 26px 52px);opacity:.14}
.tq-hero .in{position:relative;z-index:2;max-width:var(--w);margin:auto;padding:clamp(34px,6vw,84px) 20px;display:grid;grid-template-columns:1.3fr 1fr;gap:34px;align-items:center}
.tq-hero h1{font-size:clamp(42px,7vw,var(--h1));line-height:.98;text-transform:uppercase;color:var(--on-primary);letter-spacing:-.01em}
.tq-hero h1 span{color:var(--c-accent)}
.tq-hero p{font:500 18px/1.6 var(--f-body);max-width:42ch;margin:16px 0 26px;opacity:.9}
.tq-plate{background:var(--c-surface);color:var(--c-text);border-radius:14px;padding:22px;box-shadow:0 0 0 4px var(--c-accent)}
.tq-plate h3{font:700 16px var(--f-body);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px}
.tq-plate .pl{display:flex;border:3px solid var(--c-text);border-radius:8px;overflow:hidden;background:var(--c-accent)}
.tq-plate .pl span{background:var(--c-primary);color:var(--on-primary);font:700 12px var(--f-body);padding:0 10px;display:grid;place-items:center;writing-mode:vertical-rl;letter-spacing:.2em}
.tq-plate input{flex:1;border:0;background:transparent;font:700 clamp(24px,4vw,34px) var(--f-head);letter-spacing:.2em;text-transform:uppercase;padding:10px 12px;color:var(--c-text);min-width:0}
.tq-plate p{color:var(--c-text);opacity:.7;font-size:13px;margin:10px 0 0}
.tq-sec{padding:var(--pad) 20px}.tq-sec>.in{max-width:var(--w);margin:auto}
.tq-svc{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:2px solid var(--c-text)}
.tq-svc>div{padding:24px;border-right:2px solid var(--c-text);border-bottom:2px solid var(--c-text);background:var(--c-surface)}
.tq-svc>div:nth-child(3n){border-right:0}.tq-svc>div:nth-last-child(-n+3){border-bottom:0}
.tq-svc b{font:700 13px var(--f-body);color:var(--c-primary);letter-spacing:.1em}.tq-svc h3{font:700 22px var(--f-head);text-transform:uppercase;margin:6px 0}.tq-svc .t{margin-top:10px;font:700 14px var(--f-body);opacity:.75}
.tq-size{display:inline-flex;border:2px solid var(--c-text);margin-bottom:20px}
.tq-size label{position:relative}.tq-size input{position:absolute;opacity:0}
.tq-size span{display:block;padding:.6em 1.3em;font:700 14px var(--f-body);text-transform:uppercase;letter-spacing:.06em;cursor:pointer}
.tq-size input:checked+span{background:var(--c-text);color:var(--c-surface)}.tq-size input:focus-visible+span{outline:3px solid var(--c-accent)}
.tq-pk{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.tq-pkc{border:2px solid var(--c-text);padding:24px;background:var(--c-surface)}.tq-pkc.hl{background:var(--c-accent)}
.tq-pkc h3{font:700 24px var(--f-head);text-transform:uppercase}.tq-pkc .am{font:700 40px var(--f-head);margin:6px 0 12px}
.tq-pkc ul{list-style:none;padding:0;margin:0 0 18px;display:grid;gap:6px;font:600 15px var(--f-body)}.tq-pkc li::before{content:"✓ ";font-weight:800}
.tq-job{position:relative;padding-left:30px;border-left:4px solid var(--c-border);margin-left:10px}
.tq-job li{list-style:none;position:relative;padding:0 0 22px}
.tq-job li::before{content:"";position:absolute;left:-39px;top:2px;width:18px;height:18px;border-radius:50%;background:var(--c-surface);border:4px solid var(--c-border)}
.tq-job li.done::before{background:var(--c-primary);border-color:var(--c-primary)}.tq-job li.now::before{background:var(--c-accent);border-color:var(--c-text);box-shadow:0 0 0 6px color-mix(in srgb,var(--c-accent) 40%,transparent)}
.tq-job b{display:block;font:700 18px var(--f-head);text-transform:uppercase}.tq-job small{opacity:.7}
.tq-foot{background:var(--c-text);color:var(--c-surface)}
@media(max-width:800px){.tq-head ul{display:none}.tq-hero .in,.tq-pk{grid-template-columns:1fr}.tq-svc{grid-template-columns:1fr}.tq-svc>div{border-right:0!important;border-bottom:2px solid var(--c-text)!important}.tq-svc>div:last-child{border-bottom:0!important}.tq-hero::after{display:none}}
html,body{overflow-x:clip}img,svg{max-width:100%}.tq-head .more{position:relative}.tq-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border:2px solid var(--c-text);}.tq-head .more:hover .dd,.tq-head .more:focus-within .dd{display:grid}.tq-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.tq-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.tq-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-text)}.tq-hero h1,.tq-hero h2{color:var(--on-primary)}</style><div class="tq-top"><span>Mon–Sat 8:30am–6pm · <b>Free pick-up within 5 km</b></span><span>WhatsApp 012-880 6600</span></div><header class="tq-head"><div class="in"><a class="tq-logo" href="index.php"><i>T</i>Torque Garage</a><ul><li><a href="services.php">Services</a></li><li><a href="packages.php">Packages</a></li><li><a href="tracker.php">Track my car</a></li><li><a href="about.php">About</a></li><li class="more" style="position:relative"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Garage</h4><a href="index.php">Home</a><a href="services.php">Services</a><a href="packages.php">Service packages</a><a href="tracker.php">Track your car</a></div><div><h4>Book</h4><a href="book.php">Book a slot</a><a href="about.php">About</a><a href="contact.php">Contact</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="tq-btn y" href="book.php">Book a slot</a></div></header>
<main>
