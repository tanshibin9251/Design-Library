<?php $title = 'About'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>About</b></div><h1>About</h1></div></section><section class="tq-sec"><div class="in split"><div class="ph soft" data-l="Workshop (缺图)" style="aspect-ratio:4/3"></div><div class="prose"><p class="lead">Fifteen years, three mechanics who still turn the spanners.</p><p>Replace with your workshop story, certifications and brands you service.</p></div></div></section>
<?php include 'includes/footer.php'; ?>
