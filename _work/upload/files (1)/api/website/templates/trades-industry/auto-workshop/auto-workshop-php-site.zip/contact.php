<?php $title = 'Contact'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Contact</b></div><h1>Contact</h1></div></section><section class="tq-sec"><div class="in split"><div class="ph soft" data-l="Map (缺图)" style="aspect-ratio:4/3"></div><ul class="kv"><li><span>Address</span><b>28 Jalan Cheras Perdana, Kuala Lumpur</b></li><li><span>Hours</span><b>Mon–Sat 8:30am–6pm</b></li><li><span>WhatsApp</span><b>+60 12-880 6600</b></li></ul></div></section>
<?php include 'includes/footer.php'; ?>
