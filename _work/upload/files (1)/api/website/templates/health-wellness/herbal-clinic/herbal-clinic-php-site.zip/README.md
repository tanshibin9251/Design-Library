# Baoshan Herbal Clinic

Exported from Design Library · 10 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: 首页 Home, 诊疗 Treatments, 药材 Herbs, 医师 Practitioners, 病症 Conditions, 预约 Book, 到访 Visit, FAQ, Privacy policy, 404 error.

All text and images are placeholders — replace them with your own.
