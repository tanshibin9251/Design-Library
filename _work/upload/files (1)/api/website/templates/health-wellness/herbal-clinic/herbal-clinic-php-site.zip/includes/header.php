<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Baoshan Herbal Clinic';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Baoshan Herbal Clinic</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Baoshan Herbal — tokens only */
.hb-head{background:var(--c-surface);border-bottom:1px solid var(--c-border);position:sticky;top:0;z-index:40}
.hb-head .in{max-width:var(--w);margin:auto;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:12px 20px}
.hb-logo{text-decoration:none;display:flex;align-items:center;gap:12px}
.hb-logo i{width:44px;height:44px;border:2px solid var(--c-primary);border-radius:6px;display:grid;place-items:center;font:700 24px var(--f-head);font-style:normal;color:var(--c-primary)}
.hb-logo b{font:700 20px var(--f-head);display:block;line-height:1.1}.hb-logo small{font:600 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}
.hb-head ul{display:flex;gap:6px;list-style:none;font:600 15px var(--f-body)}
.hb-head ul>li>a{display:block;padding:.5em .9em;text-decoration:none;border-radius:6px}.hb-head ul>li>a:hover{background:color-mix(in srgb,var(--c-primary) 10%,var(--c-surface))}
.hb-btn{background:var(--c-primary);color:var(--on-primary);padding:.8em 1.4em;border-radius:6px;font:700 14px var(--f-body);text-decoration:none;display:inline-block}
.hb-btn.o{background:none;color:var(--c-primary);box-shadow:inset 0 0 0 2px var(--c-primary)}
.hb-hero{max-width:var(--w);margin:auto;padding:clamp(30px,5vw,70px) 20px;display:grid;grid-template-columns:1fr 1fr;gap:36px;align-items:center}
.hb-hero h1{font-size:clamp(38px,5.6vw,var(--h1));line-height:1.12;letter-spacing:.02em}
.hb-hero h1 span{display:block;font-size:.5em;color:var(--c-secondary);letter-spacing:.2em;margin-top:10px;font-weight:600}
.hb-hero p{font:400 17px/1.8 var(--f-body);max-width:42ch;margin:18px 0 24px}
.hb-cab{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;padding:12px;background:color-mix(in srgb,var(--c-secondary) 35%,var(--c-surface));border:3px solid var(--c-secondary);border-radius:10px;box-shadow:inset 0 0 0 2px color-mix(in srgb,var(--c-secondary) 55%,#000)}
.hb-dr{aspect-ratio:1.25;background:color-mix(in srgb,var(--c-secondary) 15%,var(--c-surface));border:2px solid color-mix(in srgb,var(--c-secondary) 70%,#000);border-radius:4px;display:grid;place-items:center;font:700 clamp(14px,2.2vw,22px) var(--f-head);color:var(--c-text);position:relative;transition:translate .2s,background .2s;cursor:default}
.hb-dr::after{content:"";position:absolute;width:30%;height:3px;border-radius:3px;background:color-mix(in srgb,var(--c-secondary) 70%,#000);bottom:12%}
.hb-dr:hover{translate:0 -4px;background:var(--c-accent);color:var(--c-surface)}
.hb-sec{padding:var(--pad) 20px}.hb-sec>.in{max-width:var(--w);margin:auto}
.hb-ttl{margin-bottom:30px}.hb-ttl small{font:700 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent)}.hb-ttl h2{margin-top:6px}
.hb-flow{display:grid;grid-template-columns:repeat(4,1fr);gap:0;border:1px solid var(--c-border)}
.hb-flow>div{padding:22px;border-right:1px solid var(--c-border)}.hb-flow>div:last-child{border:0}
.hb-flow b{font:700 36px var(--f-head);color:var(--c-accent)}.hb-flow h3{font:700 18px var(--f-head);margin:4px 0}
.hb-cond{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.hb-cd{border:1px solid var(--c-border);border-radius:8px;padding:16px;background:var(--c-surface);text-decoration:none}
.hb-cd b{font:700 30px var(--f-head);color:var(--c-primary);display:block}.hb-cd span{font:600 15px var(--f-body)}
.hb-pr{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}
.hb-pr .ph{aspect-ratio:4/5;border-radius:8px}.hb-pr h3{font:700 19px var(--f-head);margin-top:10px}.hb-pr small{opacity:.7;display:block}
.hb-foot{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:820px){.hb-head ul{display:none}.hb-hero{grid-template-columns:1fr}.hb-flow,.hb-cond,.hb-pr{grid-template-columns:repeat(2,minmax(0,1fr))}.hb-flow>div{border-bottom:1px solid var(--c-border)}}
@media(prefers-reduced-motion:reduce){.hb-dr{transition:none}}
html,body{overflow-x:clip}img,svg{max-width:100%}.hb-head .more{position:relative}.hb-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:8px;}.hb-head .more:hover .dd,.hb-head .more:focus-within .dd{display:grid}.hb-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.hb-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.hb-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-text)}.hb-hero h1,.hb-ttl h2{color:var(--c-primary)}</style><header class="hb-head"><div class="in"><a class="hb-logo" href="index.php"><i>藥</i><span><b>保善堂 Baoshan</b><small>Herbal &amp; TCM Clinic</small></span></a><ul><li><a href="treatments.php">诊疗</a></li><li><a href="herbs.php">药材</a></li><li><a href="practitioners.php">医师</a></li><li><a href="conditions.php">病症</a></li><li class="more" style="position:relative"><a href="#" tabindex="0">更多 ▾</a><div class="dd"><div><h4>Clinic</h4><a href="index.php">首页 Home</a><a href="treatments.php">诊疗 Treatments</a><a href="herbs.php">药材 Herbs</a><a href="practitioners.php">医师 Practitioners</a><a href="conditions.php">病症 Conditions</a></div><div><h4>Visit</h4><a href="book.php">预约 Book</a><a href="visit.php">到访 Visit</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="hb-btn" href="book.php">预约 Book</a></div></header>
<main>
