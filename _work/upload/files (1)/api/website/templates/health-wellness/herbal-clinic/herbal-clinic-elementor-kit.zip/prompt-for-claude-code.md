# Build "Baoshan Herbal Clinic" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2f6f5e · Secondary #8b6b4a · Text #1f2a26 · Accent #b83a2a · Surface #f6f4ec · Border #d9d6c6

## 2. Global Fonts
Headings: Noto Serif SC · Body: Noto Sans SC
H1 60px / H2 38px / H3 20px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- 首页 Home (home) — html/home.html
- 诊疗 Treatments (treatments) — html/treatments.html
- 药材 Herbs (herbs) — html/herbs.html
- 医师 Practitioners (practitioners) — html/practitioners.html
- 病症 Conditions (conditions) — html/conditions.html
- 预约 Book (book) — html/book.html
- 到访 Visit (visit) — html/visit.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
