<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="sec"><div class="wrap"><div class="faq"><details open><summary>What is the 30-day run-in?</summary><p>Run in them for 30 days. If they are not right, return them for a full refund.</p></details><details><summary>When do drops go live?</summary><p>Fridays at 8pm. Sign up to get a 10-minute head start.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
