# Build "Sprint Gear" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #0d0d0d · Secondary #ff3b2f · Text #0d0d0d · Accent #d9ff1f · Surface #ffffff · Border #0d0d0d

## 2. Global Fonts
Headings: Bebas Neue · Body: Archivo
H1 120px / H2 64px / H3 28px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Shop all (shop) — html/shop.html
- Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Drops (drops) — html/drops.html
- Squad (athletes) — html/athletes.html
- Size & fit (size-guide) — html/size-guide.html
- Stores (stores) — html/stores.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
