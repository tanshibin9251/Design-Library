<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Ippon Dojo';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Ippon Dojo</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Ippon Dojo — brush ink, black and caution yellow, tokens only */
.dj-head{position:sticky;top:0;z-index:50;display:flex;align-items:stretch;justify-content:space-between;background:var(--c-primary);color:var(--on-primary);border-bottom:6px solid var(--c-accent)}
.dj-logo{display:flex;align-items:center;gap:16px;padding:10px clamp(18px,3vw,40px);text-decoration:none;color:var(--on-primary)}
.dj-logo b{font:400 38px/1 var(--f-head);letter-spacing:.1em;border-bottom:5px solid var(--c-accent);padding-bottom:2px}
.dj-logo small{font:700 11px var(--f-body);letter-spacing:.3em;text-transform:uppercase;opacity:.8}
.dj-nav{display:flex;align-items:stretch;list-style:none}
.dj-nav a{display:flex;align-items:center;padding:0 clamp(12px,1.6vw,24px);min-height:64px;text-decoration:none;color:var(--on-primary);font:700 13px var(--f-body);letter-spacing:.2em;text-transform:uppercase;border-left:1px solid color-mix(in srgb,var(--on-primary) 22%,transparent);transition:background .15s,color .15s}
.dj-nav a:hover{background:var(--c-accent);color:var(--on-accent)}
.dj-nav .more{position:relative}
.dj-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:18px 28px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:3px solid var(--c-primary);min-width:620px;z-index:60}
.dj-nav .more:hover .dd,.dj-nav .more:focus-within .dd{display:grid}
.dj-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.dj-nav .dd a{display:block;min-height:0;padding:5px 0;border:0;color:var(--c-text);text-transform:none;letter-spacing:0;font:500 14px var(--f-body)}
.dj-nav .dd a:hover{background:none;color:var(--c-primary);text-decoration:underline}
.dj-cta{background:var(--c-accent)!important;color:var(--on-accent)!important}
.dj-cta:hover{filter:brightness(1.08)}
.dj-m{display:none;align-self:center;margin-right:12px}
.dj-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:700 12px var(--f-body);letter-spacing:.2em;border:2px solid var(--on-primary);padding:0 14px}
.dj-m summary::-webkit-details-marker{display:none}
.dj-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-primary);padding:8px 20px 20px;display:grid;border-bottom:6px solid var(--c-accent)}
.dj-m nav a{padding:12px 4px;color:var(--on-primary);text-decoration:none;border-bottom:1px solid color-mix(in srgb,var(--on-primary) 25%,transparent);font:700 14px var(--f-body);letter-spacing:.12em;min-height:44px}
@media(max-width:1000px){.dj-nav{display:none}.dj-m{display:block}}

.dj-sec{padding:var(--pad) clamp(20px,5vw,80px)}
.dj-k{display:inline-block;font:700 12px var(--f-body);letter-spacing:.3em;text-transform:uppercase;background:var(--c-accent);color:var(--on-accent);padding:5px 12px;margin-bottom:18px}
.dj-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:.9em 2.2em;border:3px solid var(--c-primary);background:var(--c-accent);color:var(--on-accent);font:700 14px var(--f-body);letter-spacing:.2em;text-transform:uppercase;text-decoration:none;cursor:pointer;box-shadow:6px 6px 0 var(--c-primary);transition:transform .12s,box-shadow .12s}
.dj-btn:hover{transform:translate(3px,3px);box-shadow:3px 3px 0 var(--c-primary)}
.dj-btn.k{background:var(--c-primary);color:var(--on-primary);border-color:var(--on-primary);box-shadow:6px 6px 0 var(--c-accent)}
.dj-btn.k:hover{box-shadow:3px 3px 0 var(--c-accent)}
.dj-ph{position:relative;min-height:240px;background:repeating-linear-gradient(135deg,var(--c-primary) 0 2px,transparent 2px 14px),color-mix(in srgb,var(--c-accent) 16%,var(--c-surface));border:3px solid var(--c-primary)}
.dj-ph::after{content:attr(data-l);position:absolute;left:0;bottom:0;background:var(--c-primary);color:var(--on-primary);font:700 10px var(--f-body);letter-spacing:.18em;text-transform:uppercase;padding:5px 10px}

/* hero: brush circle and diagonal cut */
.dj-hero{position:relative;background:var(--c-primary);color:var(--on-primary);overflow:hidden;clip-path:polygon(0 0,100% 0,100% 90%,0 100%);padding:clamp(48px,7vw,110px) clamp(20px,5vw,80px) clamp(110px,12vw,190px);min-height:min(88vh,760px);display:grid;align-items:center}
.dj-enso{position:absolute;right:clamp(-120px,-4vw,0px);top:50%;width:clamp(300px,50vw,720px);aspect-ratio:1;transform:translateY(-50%) rotate(-12deg);color:var(--c-accent);opacity:.95}
.dj-enso circle{fill:none;stroke:currentColor;stroke-width:15;stroke-linecap:round;stroke-dasharray:1760;stroke-dashoffset:1760;animation:djdraw 1.9s cubic-bezier(.3,.6,.2,1) .2s forwards}
@keyframes djdraw{to{stroke-dashoffset:260}}
.dj-hero-in{position:relative;max-width:820px}
.dj-hero .en{font:700 12px var(--f-body);letter-spacing:.34em;text-transform:uppercase;color:var(--c-accent)}
.dj-hero h1{white-space:nowrap;font:400 clamp(96px,18vw,280px)/.95 var(--f-head);letter-spacing:.04em;color:var(--on-primary);margin:12px 0 20px;text-shadow:6px 6px 0 color-mix(in srgb,var(--c-accent) 70%,transparent)}
.dj-hero p{font:500 clamp(16px,1.6vw,19px)/1.9 var(--f-body);max-width:40ch;opacity:.92}
.dj-tape{background:var(--c-accent);color:var(--on-accent);border-top:4px solid var(--c-primary);border-bottom:4px solid var(--c-primary);overflow:hidden;white-space:nowrap;margin-top:-52px;transform:rotate(-1.4deg);position:relative;z-index:2}
.dj-tape span{display:inline-block;padding:12px 0;font:700 15px var(--f-body);letter-spacing:.34em;animation:djtape 30s linear infinite}
@keyframes djtape{from{transform:translateX(0)}to{transform:translateX(-50%)}}
@media(max-width:700px){.dj-enso{opacity:.35}}

/* classes slabs */
.dj-3{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(18px,2.4vw,34px)}
.dj-slab{border:3px solid var(--c-primary);background:var(--c-surface);padding:30px 26px 34px;box-shadow:8px 8px 0 var(--c-primary);display:grid;gap:12px;align-content:start;text-decoration:none;transition:transform .15s,box-shadow .15s}
.dj-slab:hover{transform:translate(4px,4px);box-shadow:4px 4px 0 var(--c-primary)}
.dj-slab .kj{font:400 78px/1 var(--f-head);color:var(--c-primary)}
.dj-slab h3{font:700 20px var(--f-body);letter-spacing:.12em;text-transform:uppercase}
.dj-slab .age{font:700 12px var(--f-body);letter-spacing:.2em;background:var(--c-primary);color:var(--on-primary);padding:4px 10px;justify-self:start}
.dj-slab p{font-size:15px;line-height:1.8}
@media(max-width:900px){.dj-3{grid-template-columns:1fr}}

/* belt ladder */
.dj-belt{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:clamp(24px,5vw,80px);align-items:start}
.dj-ladder{display:grid;gap:8px}
.dj-ladder button{display:grid;grid-template-columns:auto 1fr;gap:16px;align-items:center;text-align:left;border:3px solid var(--c-primary);background:var(--c-surface);padding:0;cursor:pointer;color:inherit;font:inherit;min-height:52px;transition:transform .12s}
.dj-ladder button:hover{transform:translateX(6px)}
.dj-ladder .bar{width:clamp(60px,var(--w),240px);align-self:stretch;min-height:50px;background:var(--bc);border-right:3px solid var(--c-primary)}
.dj-ladder .nm{font:700 14px var(--f-body);letter-spacing:.14em;text-transform:uppercase;padding-right:14px}
.dj-ladder .nm small{display:block;font:500 12px var(--f-body);letter-spacing:.1em;opacity:.7;text-transform:none}
.dj-ladder button[aria-pressed=true]{background:var(--c-accent);color:var(--on-accent);transform:translateX(14px);box-shadow:6px 6px 0 var(--c-primary)}
.dj-info{border:3px solid var(--c-primary);background:var(--c-primary);color:var(--on-primary);padding:clamp(24px,3.4vw,44px);position:sticky;top:96px}
.dj-info .big{font:400 clamp(60px,7vw,110px)/1 var(--f-head);color:var(--c-accent)}
.dj-info h3{font:700 20px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--on-primary);margin:8px 0 14px}
.dj-info ul{list-style:none;display:grid;gap:0;margin-top:18px}
.dj-info li{padding:12px 0;border-top:1px solid color-mix(in srgb,var(--on-primary) 25%,transparent);font:500 15px var(--f-body)}
@media(max-width:900px){.dj-belt{grid-template-columns:1fr}.dj-info{position:static}}

/* timetable */
.dj-chips{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:28px}
.dj-chips button{min-height:44px;padding:0 18px;border:3px solid var(--c-primary);background:var(--c-surface);font:700 13px var(--f-body);letter-spacing:.16em;text-transform:uppercase;cursor:pointer;color:var(--c-primary)}
.dj-chips button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.dj-tt{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border:3px solid var(--c-primary)}
.dj-tt>div{border-right:3px solid var(--c-primary);min-height:100px;padding:0 0 10px}
.dj-tt>div:last-child{border-right:0}
.dj-tt h4{font:700 13px var(--f-body);letter-spacing:.16em;text-transform:uppercase;background:var(--c-primary);color:var(--on-primary);padding:10px;text-align:center}
.dj-tt .c{margin:10px 8px 0;padding:8px 8px;border:2px solid var(--c-primary);background:var(--c-accent);color:var(--on-accent);font:600 12px/1.4 var(--f-body)}
.dj-tt .c b{display:block;font:700 13px var(--f-body)}
.dj-tt .c.hide{display:none}
.dj-tt .c[data-t=kids]{background:var(--c-surface);color:var(--c-text)}
.dj-tt .c[data-t=adult]{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:900px){.dj-tt{grid-template-columns:1fr 1fr}.dj-tt>div{border-bottom:3px solid var(--c-primary)}.dj-tt>div:nth-child(2n){border-right:0}}
@media(max-width:480px){.dj-tt{grid-template-columns:1fr}.dj-tt>div{border-right:0}}

.dj-pr{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(18px,2.4vw,34px)}
.dj-pr>div{border:3px solid var(--c-primary);padding:34px 28px;display:grid;gap:12px;align-content:start;background:var(--c-surface)}
.dj-pr>div.hl{background:var(--c-accent);color:var(--on-accent);box-shadow:8px 8px 0 var(--c-primary)}
.dj-pr .n{font:400 62px/1 var(--f-head)}
.dj-pr .p{font:700 28px var(--f-body)}
.dj-pr li{list-style:none;padding:9px 0;border-top:2px solid currentColor;font-size:15px}
@media(max-width:900px){.dj-pr{grid-template-columns:1fr}}
.dj-two{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:center}
.dj-two h2{font:400 clamp(34px,4.6vw,var(--h2)) var(--f-head);letter-spacing:.04em;margin-bottom:14px}
.dj-two p{line-height:1.95;max-width:48ch}
@media(max-width:800px){.dj-two{grid-template-columns:1fr}}
.dj-rules{counter-reset:r;display:grid;gap:0;border-top:3px solid var(--c-primary)}
.dj-rules li{counter-increment:r;list-style:none;display:grid;grid-template-columns:90px 1fr;gap:20px;padding:22px 0;border-bottom:3px solid var(--c-primary);align-items:baseline}
.dj-rules li::before{content:counter(r,cjk-ideographic);font:400 44px/1 var(--f-head)}
.dj-rules b{display:block;font:700 18px var(--f-body);letter-spacing:.08em;margin-bottom:4px}
.dj-news{display:grid;grid-template-columns:130px 1fr auto;gap:18px;padding:20px 0;border-top:3px solid var(--c-primary);text-decoration:none;align-items:baseline}
.dj-news:last-child{border-bottom:3px solid var(--c-primary)}
.dj-news time{font:700 13px var(--f-body);letter-spacing:.14em}
.dj-news h3{font:700 19px var(--f-body)}
.dj-news .t{font:700 11px var(--f-body);letter-spacing:.2em;background:var(--c-accent);color:var(--on-accent);padding:4px 10px;text-transform:uppercase}
@media(max-width:600px){.dj-news{grid-template-columns:1fr;gap:6px}}
.dj-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(44px,6vw,80px) clamp(20px,5vw,80px) 26px;border-top:6px solid var(--c-accent);margin-top:var(--pad)}
.dj-foot .top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(24px,6vw,100px)}
.dj-foot .big{font:400 80px/1 var(--f-head);letter-spacing:.06em}
.dj-foot h4{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.dj-foot ul{list-style:none}.dj-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font-size:14px;min-height:32px}.dj-foot li a:hover{color:var(--c-accent)}
.dj-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.dj-foot .copy{margin-top:34px;padding-top:16px;border-top:1px solid color-mix(in srgb,var(--on-primary) 30%,transparent);font:700 11px var(--f-body);letter-spacing:.2em;opacity:.7}
@media(max-width:800px){.dj-foot .top{grid-template-columns:1fr}.dj-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(max-width:700px){.dj-sec{padding-left:18px;padding-right:18px}.dj-logo small{display:none}}
@media(prefers-reduced-motion:reduce){.dj-enso circle{animation:none;stroke-dashoffset:260}.dj-tape span{animation:none}.dj-btn,.dj-slab,.dj-ladder button{transition:none}}
</style><header class="dj-head"><a class="dj-logo" href="index.php"><b>一本</b><small>Ippon Dojo<br>Karate &amp; Judo</small></a><ul class="dj-nav"><li><a href="classes.php">Classes</a></li><li><a href="timetable.php">Timetable</a></li><li><a href="ranks.php">Ranks</a></li><li><a href="pricing.php">Fees</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Dojo</h4><a href="index.php">Home</a><a href="classes.php">Classes</a><a href="timetable.php">Timetable</a><a href="ranks.php">Belt ranks</a><a href="sensei.php">Sensei</a><a href="etiquette.php">Dojo etiquette</a></div><div><h4>Join</h4><a href="trial.php">Free trial</a><a href="pricing.php">Membership</a><a href="news.php">News & events</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="dj-cta" href="trial.php">無料体験 Free trial</a></li></ul><details class="dj-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="classes.php">Classes</a><a href="timetable.php">Timetable</a><a href="ranks.php">Belt ranks</a><a href="sensei.php">Sensei</a><a href="etiquette.php">Dojo etiquette</a><a href="trial.php">Free trial</a><a href="pricing.php">Membership</a><a href="news.php">News & events</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header>
<main>
