<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="dj-sec" style="text-align:center;padding-top:clamp(60px,10vw,140px)"><span class="dj-k">Error 404</span><h1 style="font:400 clamp(110px,22vw,300px)/.9 var(--f-head);color:var(--c-primary)">一本</h1><h2 style="margin:10px 0 28px;font:700 22px var(--f-body);letter-spacing:.1em">PAGE NOT FOUND — 技あり.</h2><a class="dj-btn" href="index.php">Back to the dojo</a></section>
<?php include 'includes/footer.php'; ?>
