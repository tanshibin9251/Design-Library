# Build "Diamond Shop" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #0c0809 · Secondary #2a0a10 · Text #1a1213 · Accent #ce2128 · Surface #ffffff · Border #e3dfdb

## 2. Global Fonts
Headings: Saira · Body: Hanken Grotesk
H1 96px / H2 56px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Shop (shop) — html/shop.html
- Category (category) — html/category.html
- Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- My account (my-account) — html/my-account.html
- About (about) — html/about.html
- Contact (contact) — html/contact.html
- Shipping policy (shipping-policy) — html/shipping-policy.html
- Refund policy (refund-policy) — html/refund-policy.html
- Privacy policy (privacy) — html/privacy.html
- Terms & conditions (terms) — html/terms.html
- Cookie policy (cookie-policy) — html/cookie-policy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
