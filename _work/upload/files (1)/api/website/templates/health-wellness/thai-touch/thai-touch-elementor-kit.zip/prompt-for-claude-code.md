# Build "Thai Touch" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #5a3418 · Secondary #7b5a2e · Text #3a2614 · Accent #b8860b · Surface #fbf3e1 · Border #e6d6b3

## 2. Global Fonts
Headings: Gloock · Body: Karla
H1 84px / H2 48px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 92px vertical · Border radius 20px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Treatment menu (menu) — html/menu.html
- Treatment (treatment) — html/treatment.html
- Our therapists (therapists) — html/therapists.html
- Couple & group packages (packages) — html/packages.html
- Gift vouchers (vouchers) — html/vouchers.html
- Book a treatment (book) — html/book.html
- Our story (story) — html/story.html
- Find us (find) — html/find.html
- Before you come (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
