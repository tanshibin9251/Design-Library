# Build "Court Line" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #0b0b0c · Secondary #131416 · Text #17181a · Accent #45484f · Surface #ffffff · Border #dcdde0

## 2. Global Fonts
Headings: Bricolage Grotesque · Body: Instrument Sans
H1 112px / H2 52px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Products (products) — html/products.html
- Services (services) — html/services.html
- Contact (contact) — html/contact.html
- Privacy policy (privacy) — html/privacy.html
- Cookie policy (cookie-policy) — html/cookie-policy.html
- Terms & conditions (terms) — html/terms.html
- Sitemap (sitemap) — html/sitemap.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
