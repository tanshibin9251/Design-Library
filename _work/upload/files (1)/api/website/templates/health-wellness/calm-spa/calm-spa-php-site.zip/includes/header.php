<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Calm Spa';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Calm Spa</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<header class="nav nav-center"><div class="wrap"><a class="logo" href="index.php">Still Water</a><ul><li><a href="services.php">Treatments</a></li><li><a href="pricing.php">Packages</a></li><li><a href="about.php">About</a></li><li><a href="blog.php">Journal</a></li><li class="more"><a href="#" tabindex="0">All pages ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Treatments</a><a href="service.php">Single Treatment</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Rituals</a><a href="project.php">Single Ritual</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Booking</a><a href="gift-cards.php">Gift cards</a><a href="rooms.php">Rooms</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><details class="burger"><summary>Menu</summary><div class="bmenu"><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Treatments</a><a href="service.php">Single Treatment</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a><a href="shop.php">Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Rituals</a><a href="project.php">Single Ritual</a><a href="gallery.php">Gallery</a><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Booking</a><a href="gift-cards.php">Gift cards</a><a href="rooms.php">Rooms</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></details></div></header>
<main>
