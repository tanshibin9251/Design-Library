<?php $title = 'Access & hours'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Access & hours</b></div><h1>アクセス</h1></div></section><section class="rp-sec" style="padding-top:20px"><div class="rp-list"><div><b>住所</b><span>Level 3, 8 Jalan Kiara 3, Mont Kiara</span><span></span></div><div><b>営業</b><span>Tue–Sun, 10:00–20:00 (last entry 18:30)</span><span></span></div><div><b>予約</b><span>WhatsApp +60 12-909 0909</span><span></span></div></div></section>
<?php include 'includes/footer.php'; ?>
