<?php $title = 'Journal'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Journal</b></div><h1>ノート</h1></div></section><section class="rp-sec" style="padding-top:20px"><div class="rp-list"><div><b>11.02</b><span>Why we keep the room at 26°C</span><span>→</span></div><div><b>10.14</b><span>A short guide to tender spots</span><span>→</span></div><div><b>09.28</b><span>Tea for the second half of the day</span><span>→</span></div></div></section>
<?php include 'includes/footer.php'; ?>
