# Build "Mind Notes" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #3b4a6b · Secondary #8fa89b · Text #2d3446 · Accent #c97b63 · Surface #f4efe9 · Border #dcd5ca

## 2. Global Fonts
Headings: Vollkorn · Body: Mulish
H1 76px / H2 42px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 16px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Concept cards (concepts) — html/concepts.html
- Article: Why we keep doing what we regret (article) — html/article.html
- Stress check-in (checkin) — html/checkin.html
- Breathing space (breathe) — html/breathe.html
- Reading list (books) — html/books.html
- Getting support (support) — html/support.html
- About (about) — html/about.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
