# Quiet Grace Community

Exported from Design Library · 20 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Gatherings, Single Gathering, Giving, Contact, Testimonials, Team, Community Work, Single Outreach, Gallery, Reflections, Single post, FAQ, Plan a visit, Weekly rhythm, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
