# Build "Quiet Grace Community" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #38536b · Secondary #8aa0b3 · Text #2b3440 · Accent #e0a458 · Surface #fbf6ee · Border #e3d9c6

## 2. Global Fonts
Headings: Lora · Body: Nunito Sans
H1 68px / H2 40px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 6px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Gatherings (services) — html/services.html
- Single Gathering (service) — html/service.html
- Giving (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Community Work (projects) — html/projects.html
- Single Outreach (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Reflections (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Plan a visit (booking) — html/booking.html
- Weekly rhythm (schedule) — html/schedule.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
