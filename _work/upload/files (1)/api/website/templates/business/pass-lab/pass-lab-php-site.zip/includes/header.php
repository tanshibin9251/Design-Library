<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Pass Lab';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Pass Lab</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Pass Lab — exam & certification prep dashboard, tokens only */
.pl-bar{background:var(--c-primary);color:var(--on-primary);font:600 13px var(--f-body);display:flex;justify-content:center;gap:10px;align-items:center;padding:9px 14px;flex-wrap:wrap}
.pl-bar b{background:var(--c-accent);color:var(--on-accent);padding:2px 10px;border-radius:99px}
.pl-head{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:0 clamp(16px,4vw,56px);min-height:72px;background:var(--c-surface);border-bottom:1px solid var(--c-border);position:sticky;top:0;z-index:50}
.pl-logo{display:flex;align-items:center;gap:10px;font:800 21px var(--f-head);color:var(--c-primary);text-decoration:none;letter-spacing:-.02em}
.pl-logo i{display:grid;place-items:center;width:30px;height:30px;border-radius:8px;background:var(--c-accent);color:var(--on-accent);font:800 15px var(--f-head);font-style:normal}
.pl-nav{display:flex;gap:2px;list-style:none;align-items:center}
.pl-nav a{display:inline-flex;align-items:center;min-height:44px;padding:0 14px;border-radius:8px;text-decoration:none;font:600 14px var(--f-body);color:var(--c-text)}
.pl-nav a:hover{background:color-mix(in srgb,var(--c-primary) 7%,transparent)}
.pl-nav .cta{background:var(--c-primary);color:var(--on-primary);margin-left:8px}
.pl-nav .more{position:relative}
.pl-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:12px;box-shadow:0 20px 40px -20px color-mix(in srgb,var(--c-primary) 40%,transparent);min-width:600px;z-index:60}
.pl-nav .more:hover .dd,.pl-nav .more:focus-within .dd{display:grid}
.pl-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.pl-nav .dd a{display:block;min-height:0;padding:5px 0;border-radius:0}.pl-nav .dd a:hover{background:none;color:var(--c-primary);text-decoration:underline}
.pl-m{display:none}
.pl-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:1px solid var(--c-border);border-radius:8px;padding:0 14px;font:700 12px var(--f-body);letter-spacing:.12em}
.pl-m summary::-webkit-details-marker{display:none}
.pl-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:1px solid var(--c-border);padding:6px 16px 16px;display:grid}
.pl-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.pl-nav{display:none}.pl-m{display:block}}

.pl-sec{padding:clamp(40px,6vw,88px) clamp(16px,4vw,56px)}
.pl-hero{display:grid;grid-template-columns:1.1fr .9fr;gap:clamp(24px,5vw,72px);align-items:center;padding:clamp(36px,6vw,84px) clamp(16px,4vw,56px)}
.pl-hero h1{font:800 clamp(38px,5.4vw,var(--h1))/1.04 var(--f-head);letter-spacing:-.035em;color:var(--c-primary)}
.pl-hero h1 em{font-style:normal;background:linear-gradient(transparent 60%,color-mix(in srgb,var(--c-accent) 55%,transparent) 60% 92%,transparent 92%)}
.pl-hero .lead{font:400 18px/1.7 var(--f-body);margin:18px 0 26px;max-width:46ch}
@media(max-width:900px){.pl-hero{grid-template-columns:1fr}}
.pl-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:50px;padding:0 24px;border-radius:10px;background:var(--c-primary);color:var(--on-primary);text-decoration:none;font:700 15px var(--f-body);border:2px solid var(--c-primary);cursor:pointer}
.pl-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.pl-btn.o{background:transparent;color:var(--c-primary)}.pl-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.pl-dash{background:color-mix(in srgb,var(--c-surface) 40%,#fff);border:1px solid var(--c-border);border-radius:16px;padding:clamp(20px,2.4vw,32px);box-shadow:0 24px 50px -30px color-mix(in srgb,var(--c-primary) 50%,transparent)}
.pl-dash h3{font:700 13px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-secondary)}
.pl-gauge{position:relative;width:min(100%,300px);margin:8px auto 0}
.pl-gauge svg{width:100%;display:block}
.pl-gauge .bg{fill:none;stroke:var(--c-border);stroke-width:18;stroke-linecap:round}
.pl-gauge .fg{fill:none;stroke:var(--c-accent);stroke-width:18;stroke-linecap:round;stroke-dasharray:251;stroke-dashoffset:calc(251 - 251 * var(--v));transition:stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)}
.pl-gauge b{position:absolute;left:0;right:0;bottom:2px;text-align:center;font:800 44px/1 var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.pl-gauge small{display:block;font:600 12px var(--f-body);color:var(--c-secondary);letter-spacing:.06em;margin-top:2px}
.pl-mini{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:20px}
.pl-mini div{border:1px solid var(--c-border);border-radius:10px;padding:12px;text-align:center}
.pl-mini b{display:block;font:800 22px var(--f-head);color:var(--c-primary)}.pl-mini span{font:600 11px var(--f-body);color:var(--c-secondary);letter-spacing:.06em}

.pl-h{display:flex;justify-content:space-between;align-items:baseline;gap:16px;margin-bottom:24px;flex-wrap:wrap}
.pl-h h2{font:800 clamp(26px,3.2vw,var(--h2))/1.1 var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.pl-h a{font:700 14px var(--f-body);color:var(--c-primary)}
.pl-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.pl-card{border:1px solid var(--c-border);border-radius:14px;background:color-mix(in srgb,var(--c-surface) 40%,#fff);padding:22px;display:grid;gap:10px;align-content:start;text-decoration:none;transition:border-color .15s,transform .15s}
.pl-card:hover{border-color:var(--c-primary);transform:translateY(-3px)}
.pl-card .tag{justify-self:start;background:color-mix(in srgb,var(--c-primary) 8%,transparent);color:var(--c-primary);font:700 11px var(--f-body);letter-spacing:.1em;text-transform:uppercase;padding:3px 10px;border-radius:99px}
.pl-card h3{font:700 20px/1.2 var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.pl-card p{font:400 14px/1.6 var(--f-body);opacity:.85}
.pl-rate{display:grid;gap:5px;margin-top:6px}
.pl-rate div{display:flex;justify-content:space-between;font:700 12px var(--f-body);color:var(--c-primary)}
.pl-rate i{display:block;height:8px;border-radius:99px;background:var(--c-border);overflow:hidden}.pl-rate i::after{content:"";display:block;height:100%;width:var(--p);background:var(--c-accent)}
@media(max-width:900px){.pl-grid{grid-template-columns:1fr 1fr}}@media(max-width:560px){.pl-grid{grid-template-columns:1fr}}
.pl-stat{display:grid;grid-template-columns:repeat(4,1fr);gap:0;border:1px solid var(--c-border);border-radius:14px;overflow:hidden}
.pl-stat div{padding:24px;border-right:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 40%,#fff)}.pl-stat div:last-child{border-right:0}
.pl-stat b{display:block;font:800 clamp(30px,4vw,48px)/1 var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}.pl-stat span{font:500 14px var(--f-body);color:var(--c-secondary)}
@media(max-width:700px){.pl-stat{grid-template-columns:1fr 1fr}.pl-stat div:nth-child(2n){border-right:0}.pl-stat div:nth-child(-n+2){border-bottom:1px solid var(--c-border)}}
.pl-quiz{max-width:760px;border:1px solid var(--c-border);border-radius:16px;background:color-mix(in srgb,var(--c-surface) 40%,#fff);padding:clamp(22px,3vw,40px)}
.pl-qtop{display:flex;justify-content:space-between;font:700 13px var(--f-body);color:var(--c-secondary);margin-bottom:12px}
.pl-qtop b{color:var(--c-primary);font-variant-numeric:tabular-nums}
.pl-qbar{height:6px;background:var(--c-border);border-radius:99px;overflow:hidden;margin-bottom:22px}.pl-qbar i{display:block;height:100%;background:var(--c-accent);width:var(--p,0%);transition:width .3s}
.pl-quiz h2{font:700 clamp(20px,2.4vw,28px)/1.3 var(--f-head);letter-spacing:-.02em;margin-bottom:18px}
.pl-opts{display:grid;gap:10px}
.pl-opts button{text-align:left;min-height:52px;padding:12px 16px;border:1.5px solid var(--c-border);border-radius:10px;background:var(--c-surface);font:500 16px var(--f-body);cursor:pointer;color:var(--c-text);display:flex;gap:12px;align-items:center}
.pl-opts button b{width:26px;height:26px;border-radius:50%;border:1.5px solid var(--c-primary);display:grid;place-items:center;font:700 12px var(--f-body);flex:none}
.pl-opts button:hover{border-color:var(--c-primary)}
.pl-opts button.ok{background:color-mix(in srgb,var(--c-accent) 22%,var(--c-surface));border-color:var(--c-accent)}
.pl-opts button.no{opacity:.55}
.pl-why{margin-top:16px;padding:14px 16px;background:color-mix(in srgb,var(--c-primary) 6%,transparent);border-radius:10px;font:400 15px/1.6 var(--f-body)}
.pl-plan{display:grid;grid-template-columns:minmax(260px,380px) 1fr;gap:clamp(24px,4vw,56px);align-items:start}
@media(max-width:860px){.pl-plan{grid-template-columns:1fr}}
.pl-plan label{display:grid;gap:6px;font:700 13px var(--f-body);margin-bottom:18px}
.pl-plan input[type=range]{padding:0;border:0;background:none;accent-color:var(--c-accent);min-height:44px;width:100%}
.pl-plan output{font:800 28px var(--f-head);color:var(--c-primary)}
.pl-ph{display:grid;grid-template-columns:var(--a) var(--b) var(--c);gap:4px;margin:16px 0 8px;height:46px}
.pl-ph div{border-radius:8px;display:grid;place-items:center;font:700 12px var(--f-body);color:var(--on-primary);background:var(--c-primary)}
.pl-ph div:nth-child(2){background:var(--c-accent);color:var(--on-accent)}.pl-ph div:nth-child(3){background:var(--c-secondary)}
.pl-price{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.pl-price>div{border:1px solid var(--c-border);border-radius:14px;padding:26px;display:grid;gap:10px;align-content:start;background:color-mix(in srgb,var(--c-surface) 40%,#fff)}
.pl-price>.hl{border:2px solid var(--c-primary);box-shadow:0 20px 40px -26px color-mix(in srgb,var(--c-primary) 60%,transparent)}
.pl-price .p{font:800 38px var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.pl-price li{list-style:none;padding:8px 0;border-top:1px solid var(--c-border);font:500 15px var(--f-body)}.pl-price li::before{content:"✓ ";color:var(--c-accent);font-weight:800}
@media(max-width:900px){.pl-price{grid-template-columns:1fr}}
.pl-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(40px,5vw,70px) clamp(16px,4vw,56px) 22px;margin-top:clamp(40px,6vw,88px)}
.pl-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,6vw,100px)}
.pl-foot .big{font:800 28px var(--f-head);letter-spacing:-.02em}
.pl-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.pl-foot ul{list-style:none}.pl-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 14px var(--f-body);min-height:32px}
.pl-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.pl-foot .copy{margin-top:28px;font:500 12px var(--f-body);opacity:.7}
@media(max-width:800px){.pl-foot .top{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.pl-card,.pl-gauge .fg,.pl-qbar i{transition:none}}
</style><div class="pl-bar"><b>Next cohort</b><span>PMP · starts Monday · 14 seats left</span></div><header class="pl-head"><a class="pl-logo" href="index.php"><i>P</i>Pass Lab</a><ul class="pl-nav"><li><a href="exams.php">Exams</a></li><li><a href="practice.php">Practice test</a></li><li><a href="planner.php">Planner</a></li><li><a href="results.php">Pass stories</a></li><li><a href="pricing.php">Pricing</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Prepare</h4><a href="index.php">Home</a><a href="exams.php">Exams</a><a href="exam.php">Exam: Project Management (PMP)</a><a href="practice.php">Practice test</a><a href="planner.php">Study planner</a></div><div><h4>Prove</h4><a href="results.php">Pass stories</a><a href="pricing.php">Pricing</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="cta" href="practice.php">Free practice test</a></li></ul><details class="pl-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="exams.php">Exams</a><a href="exam.php">Exam: Project Management (PMP)</a><a href="practice.php">Practice test</a><a href="planner.php">Study planner</a><a href="results.php">Pass stories</a><a href="pricing.php">Pricing</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header>
<main>
