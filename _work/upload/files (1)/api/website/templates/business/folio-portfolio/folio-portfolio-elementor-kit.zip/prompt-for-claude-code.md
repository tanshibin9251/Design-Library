# Build "Aria Lim Portfolio" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #111111 · Secondary #6b6b64 · Text #111111 · Accent #b4ff3a · Surface #f3f1ea · Border #cfcbbf

## 2. Global Fonts
Headings: Instrument Serif · Body: Instrument Sans
H1 220px / H2 60px / H3 30px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 6px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Index (home) — html/home.html
- Work (work) — html/work.html
- Project (project) — html/project.html
- About & CV (about) — html/about.html
- Contact (contact) — html/contact.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
