</main>
<footer class="fo-foot"><span>© 2026 Aria Lim · Template demo content</span><span><a href="contact.php">hello@arialim.example</a> · Kuala Lumpur · Available from March</span></footer>
</body></html>
