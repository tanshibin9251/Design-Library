# Build "Petal Desk" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #4a2c36 · Secondary #5e7d68 · Text #3a2a30 · Accent #b8525a · Surface #f8f2eb · Border #e6d6cb

## 2. Global Fonts
Headings: Fraunces · Body: Hanken Grotesk
H1 54px / H2 32px / H3 21px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 20px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Today (dashboard) (home) — html/home.html
- Projects (projects) — html/projects.html
- Project: phases & tasks (project) — html/project.html
- Clients (clients) — html/clients.html
- Add client & project (client-new) — html/client-new.html
- Task templates (templates) — html/templates.html
- Template + how-to editor (template-edit) — html/template-edit.html
- Sign in (login) — html/login.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
