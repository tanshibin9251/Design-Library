</main>
<footer class="pd-foot"><div class="pd-in"><span>Petal Desk · a quiet place for projects, steps and due dates · template demo content</span><span>Tip: tap a coloured row to open its steps · <kbd>Esc</kbd> closes menus</span></div></footer>
</body></html>
