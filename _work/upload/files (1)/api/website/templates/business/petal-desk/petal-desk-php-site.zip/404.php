<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="pd-pg" data-nav="none"><div class="pd-in" id="pd-main"><div class="pd-lost"><svg class="" viewBox="0 0 120 170" aria-hidden="true"><use href="#pd-sprig"/></svg><span class="pd-hand">404</span><h1>This page went to seed.</h1><p>The link may have moved, or the project was archived. Let’s get you back to something that’s blooming.</p><div class="acts" style="margin-top:12px"><a class="pd-btn" href="index.php"><svg class="pd-i" aria-hidden="true"><use href="#pd-i-home"/></svg>Back to today</a><a class="pd-btn o" href="projects.php"><svg class="pd-i" aria-hidden="true"><use href="#pd-i-folder"/></svg>All projects</a></div></div></div></section>

<?php include 'includes/footer.php'; ?>
