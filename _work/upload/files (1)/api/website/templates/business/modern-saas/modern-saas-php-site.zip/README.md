# Modern SaaS

Exported from Design Library · 22 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Features, Single service, Pricing, Contact, Testimonials, Team, Customers, Single Customer Story, Gallery, Blog, Single post, FAQ, Features, Integrations, Changelog, Sign up, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
