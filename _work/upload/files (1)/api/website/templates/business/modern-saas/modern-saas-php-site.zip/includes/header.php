<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Modern SaaS';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Modern SaaS</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<header class="nav nav-bar"><div class="wrap"><a class="logo" href="index.php">Flowdesk</a><ul><li><a href="services.php">Product</a></li><li><a href="pricing.php">Pricing</a></li><li><a href="projects.php">Customers</a></li><li><a href="blog.php">Blog</a></li><li class="more"><a href="#" tabindex="0">All pages ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Features</a><a href="service.php">Single service</a><a href="pricing.php">Pricing</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customers</a><a href="project.php">Single Customer Story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Blog</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="features.php">Features</a><a href="integrations.php">Integrations</a><a href="changelog.php">Changelog</a><a href="signup.php">Sign up</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><a class="btn" href="contact.php">Start free</a><details class="burger"><summary>Menu</summary><div class="bmenu"><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Features</a><a href="service.php">Single service</a><a href="pricing.php">Pricing</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customers</a><a href="project.php">Single Customer Story</a><a href="gallery.php">Gallery</a><a href="blog.php">Blog</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="features.php">Features</a><a href="integrations.php">Integrations</a><a href="changelog.php">Changelog</a><a href="signup.php">Sign up</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></details></div></header>
<main>
