# Civic Hall

Exported from Design Library · 21 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single Service, Fees & Permits, Contact, Testimonials, Team, Community Projects, Single Project, Gallery, News & Notices, Single post, FAQ, Council meetings, Report an issue, Notices by email, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
