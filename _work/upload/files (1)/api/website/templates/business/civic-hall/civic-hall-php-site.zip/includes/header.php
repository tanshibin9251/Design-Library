<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Civic Hall';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Civic Hall</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Civic Hall v2 — municipal service directory with accessibility tools, tokens only */
.cv-util{background:var(--c-text);color:var(--c-surface);font:700 13px var(--f-body);display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;padding:0 clamp(14px,4vw,56px);min-height:44px}
.cv-tools{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.cv-tools button,.cv-tools a{min-height:36px;min-width:44px;padding:0 10px;border:2px solid var(--c-surface);background:transparent;color:var(--c-surface);font:700 13px var(--f-body);cursor:pointer;text-decoration:none;display:inline-grid;place-items:center}
.cv-tools button:hover,.cv-tools a:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.cv-head{display:flex;align-items:center;gap:clamp(14px,3vw,40px);padding:0 clamp(14px,4vw,56px);min-height:84px;background:var(--c-surface);border-bottom:8px solid var(--c-primary)}
.cv-logo{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--c-primary)}
.cv-logo i{display:grid;place-items:center;width:48px;height:48px;background:var(--c-primary);color:var(--on-primary);font:700 26px var(--f-head);font-style:normal}
.cv-logo b{display:block;font:700 22px var(--f-head);line-height:1.1}
.cv-logo small{font:700 12px var(--f-body);letter-spacing:.06em;color:var(--c-secondary)}
.cv-nav{display:flex;list-style:none;margin-left:auto;gap:2px;align-items:center}
.cv-nav a{display:inline-flex;align-items:center;min-height:48px;padding:0 14px;font:700 16px var(--f-body);color:var(--c-text);text-decoration:underline;text-decoration-color:transparent;text-underline-offset:6px;text-decoration-thickness:3px}
.cv-nav a:hover,.cv-nav a:focus-visible{text-decoration-color:var(--c-accent);background:color-mix(in srgb,var(--c-accent) 18%,transparent)}
.cv-nav .more{position:relative}
.cv-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(150px,1fr));gap:18px 28px;padding:22px 26px;background:var(--c-surface);border:3px solid var(--c-primary);min-width:680px;z-index:60}
.cv-nav .more:hover .dd,.cv-nav .more:focus-within .dd{display:grid}
.cv-nav .dd h4{font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.cv-nav .dd a{display:block;min-height:0;padding:5px 0;font-weight:600;font-size:15px}
.cv-m{display:none;margin-left:auto;position:relative}
.cv-m summary{list-style:none;cursor:pointer;min-height:48px;min-width:48px;display:grid;place-items:center;border:3px solid var(--c-primary);padding:0 14px;font:700 14px var(--f-body)}
.cv-m summary::-webkit-details-marker{display:none}
.cv-m nav{position:absolute;right:0;top:100%;min-width:260px;background:var(--c-surface);border:3px solid var(--c-primary);padding:6px 18px;display:grid;z-index:60}
.cv-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);font:700 16px var(--f-body);min-height:48px;text-decoration:none}
@media(max-width:980px){.cv-nav{display:none}.cv-m{display:block}}
.cv-hc{--c-surface:#000;--c-text:#fff;--c-primary:#ffdd00;--c-secondary:#fff;--c-border:#fff;--c-accent:#ffdd00;--on-primary:#000;--on-accent:#000;background:#000;color:#fff}
.cv-hc .cv-util{background:#fff;color:#000}.cv-hc .cv-tools button,.cv-hc .cv-tools a{color:#000;border-color:#000}

.cv-sec{padding:clamp(34px,5vw,64px) clamp(14px,4vw,56px)}
.cv-hero{background:color-mix(in srgb,var(--c-primary) 8%,var(--c-surface));padding:clamp(36px,6vw,80px) clamp(14px,4vw,56px)}
.cv-hero h1{font:700 clamp(34px,5.4vw,var(--h1))/1.1 var(--f-head);color:var(--c-primary);max-width:18ch}
.cv-hero p{font:400 20px/1.6 var(--f-body);margin:14px 0 24px;max-width:50ch}
.cv-find{display:flex;max-width:720px;border:3px solid var(--c-text);background:var(--c-surface)}
.cv-find input{flex:1;min-height:60px;border:0;font:400 20px var(--f-body);padding:0 16px;background:transparent;color:var(--c-text);outline:0;border-radius:0}
.cv-find button{min-width:120px;border:0;background:var(--c-primary);color:var(--on-primary);font:700 18px var(--f-body);cursor:pointer}
.cv-find:focus-within{outline:4px solid var(--c-accent);outline-offset:2px}
.cv-tasks{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:3px solid var(--c-text);border-left:3px solid var(--c-text);margin-top:28px;max-width:980px}
.cv-task{display:grid;gap:6px;padding:20px 20px 22px;border-right:3px solid var(--c-text);border-bottom:3px solid var(--c-text);background:var(--c-surface);text-decoration:none;color:var(--c-text);min-height:132px;align-content:space-between}
.cv-task b{font:700 24px var(--f-head);color:var(--c-primary);text-decoration:underline;text-decoration-thickness:3px;text-underline-offset:5px}
.cv-task span{font:400 16px/1.5 var(--f-body)}
.cv-task em{font:700 14px var(--f-body);font-style:normal;color:var(--c-secondary)}
.cv-task:hover{background:var(--c-accent);color:var(--on-accent)}.cv-task:hover b,.cv-task:hover em{color:var(--on-accent)}
.cv-task.hide{display:none}
@media(max-width:800px){.cv-tasks{grid-template-columns:1fr 1fr}}@media(max-width:520px){.cv-tasks{grid-template-columns:1fr}}
.cv-two{display:grid;grid-template-columns:1.4fr 1fr;gap:clamp(24px,4vw,56px);align-items:start}
@media(max-width:860px){.cv-two{grid-template-columns:1fr}}
.cv-h{font:700 clamp(24px,3vw,var(--h2)) var(--f-head);color:var(--c-text);border-bottom:4px solid var(--c-primary);padding-bottom:8px;margin-bottom:6px}
.cv-notice{display:grid;grid-template-columns:110px 1fr auto;gap:16px;align-items:baseline;padding:16px 0;border-bottom:1px solid var(--c-border);text-decoration:none;color:var(--c-text)}
.cv-notice time{font:700 14px var(--f-body);color:var(--c-secondary)}
.cv-notice b{font:700 18px/1.35 var(--f-body);text-decoration:underline;text-underline-offset:4px;color:var(--c-primary)}
.cv-notice span{font:700 12px var(--f-body);letter-spacing:.06em;text-transform:uppercase;background:var(--c-accent);color:var(--on-accent);padding:2px 8px}
@media(max-width:560px){.cv-notice{grid-template-columns:1fr;gap:4px}}
.cv-box{border:3px solid var(--c-text);padding:22px;background:var(--c-surface);display:grid;gap:12px}
.cv-box h3{font:700 22px var(--f-head);color:var(--c-primary)}
.cv-date{display:inline-grid;grid-template-columns:auto 1fr;gap:14px;align-items:center}
.cv-date i{display:grid;place-items:center;width:76px;height:76px;background:var(--c-primary);color:var(--on-primary);font:700 30px/1 var(--f-head);font-style:normal;text-align:center}
.cv-date i small{display:block;font:700 12px var(--f-body);letter-spacing:.1em}
.cv-bin{display:flex;gap:8px;flex-wrap:wrap}
.cv-bin input{flex:1;min-width:140px;min-height:52px;border:3px solid var(--c-text);padding:0 12px;font:400 18px var(--f-body);background:var(--c-surface);color:var(--c-text);border-radius:0}
.cv-bin button{min-height:52px;padding:0 20px;border:0;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);cursor:pointer}
.cv-res{font:700 18px/1.5 var(--f-body);background:color-mix(in srgb,var(--c-accent) 25%,var(--c-surface));border-left:8px solid var(--c-accent);padding:12px 14px;display:none}
.cv-res.on{display:block}
.cv-steps{counter-reset:s;list-style:none;display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.cv-steps li{counter-increment:s;border-top:6px solid var(--c-primary);padding-top:14px;font:400 17px/1.6 var(--f-body)}
.cv-steps li::before{content:"Step " counter(s);display:block;font:700 13px var(--f-body);letter-spacing:.08em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:4px}
.cv-steps b{font:700 20px var(--f-head);display:block;color:var(--c-primary)}
@media(max-width:700px){.cv-steps{grid-template-columns:1fr}}
.cv-btn{display:inline-flex;align-items:center;min-height:52px;padding:0 24px;background:var(--c-primary);color:var(--on-primary);font:700 17px var(--f-body);text-decoration:none;border:3px solid var(--c-primary);cursor:pointer}
.cv-btn:hover{background:var(--c-accent);color:var(--on-accent);border-color:var(--c-text)}
.cv-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 24px;margin-top:clamp(30px,5vw,70px)}
.cv-foot .top{display:grid;grid-template-columns:1.2fr 2.4fr;gap:clamp(24px,5vw,80px)}
.cv-foot h4{font:700 13px var(--f-body);letter-spacing:.08em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.cv-foot ul{list-style:none}.cv-foot li a{display:inline-block;padding:6px 0;font:600 16px var(--f-body);color:var(--on-primary);min-height:36px}
.cv-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.cv-foot .emg{border:3px solid var(--c-accent);padding:14px 16px;margin-top:16px;font:700 17px/1.5 var(--f-body)}
.cv-foot .copy{margin-top:26px;padding-top:16px;border-top:1px solid color-mix(in srgb,var(--on-primary) 40%,transparent);font:400 14px var(--f-body)}
@media(max-width:860px){.cv-foot .top{grid-template-columns:1fr}.cv-foot .cols{grid-template-columns:1fr 1fr}}
.cv a:focus-visible,.cv button:focus-visible,.cv input:focus-visible{outline:4px solid var(--c-accent);outline-offset:2px}
html,body{overflow-x:clip}img,svg{max-width:100%}
.cv .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.cv .pagehead h1{max-width:none}.cv .card,.cv .scard,.cv .qcard,.cv .pcard,.cv .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.cv .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.cv .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.cv .svc{display:block;border-top:2px solid var(--c-primary);counter-reset:sv}
.cv .scard{display:grid;grid-template-columns:56px minmax(0,1.1fr) minmax(0,1.7fr) auto;gap:6px 24px;align-items:baseline;padding:22px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;counter-increment:sv;transition:padding .2s}
.cv .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.cv .scard .ph{display:none}.cv .scard .b{display:contents}
.cv .scard h3{font-size:clamp(20px,2.2vw,28px)}.cv .scard p{margin:0;opacity:.8}
.cv .scard .m{display:flex;flex-direction:column;align-items:flex-end;gap:2px;font:600 13px var(--f-body);white-space:nowrap}
.cv .scard:hover{padding-left:14px}
@media(max-width:760px){.cv .scard{grid-template-columns:36px 1fr}.cv .scard p,.cv .scard .m{grid-column:2;align-items:flex-start}}

.cv .tgrid{display:block;border-top:2px solid var(--c-primary)}.cv .tgrid.mt{margin-top:0}
.cv .person{display:grid;grid-template-columns:1fr auto;gap:4px 20px;align-items:baseline;padding:18px 0;border-bottom:1px solid var(--c-border);background:none;border-radius:0;box-shadow:none;border-left:0;border-right:0;border-top:0;text-align:left}
.cv .person .ph{display:none}.cv .person h3{font-size:clamp(20px,2.2vw,28px)}.cv .person span{font:600 13px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-accent)}

.cv .qgrid{display:block;border-top:2px solid var(--c-primary)}.cv .qgrid.mt{margin-top:0}
.cv .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.cv .qcard .stars{grid-column:1}.cv .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.cv .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.cv .qcard{grid-template-columns:1fr}.cv .qcard figcaption{grid-column:1;grid-row:auto}}

.cv .masonry{display:block!important;columns:auto;border-top:2px solid var(--c-primary)}
.cv .masonry .mi{display:grid;grid-template-columns:150px 1fr auto;gap:18px;align-items:center;padding:14px 0;border-bottom:1px solid var(--c-border);margin:0}
.cv .masonry .mi .ph{aspect-ratio:3/2!important;min-height:0}
@media(max-width:600px){.cv .masonry .mi{grid-template-columns:100px 1fr}.cv .masonry .mi .muted{display:none}}

.cv .articles{display:block!important}
.cv .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.cv .art .ph{display:none}.cv .art .meta{grid-row:1/span 2;align-self:start}.cv .art h3{margin:0}
.cv .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}

.cv .faq{counter-reset:q;max-width:960px}
.cv .faq details{counter-increment:q;position:relative;padding-left:64px}
.cv .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.cv .pricing{display:block;border-top:2px solid var(--c-primary)}
.cv .pricing .card{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1.5fr) auto;gap:10px 28px;align-items:center;padding:24px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none!important;box-shadow:none;transform:none!important;color:inherit!important}
.cv .pricing .card h3,.cv .pricing .card .amt{color:var(--c-primary)!important;margin:0}
.cv .pricing .card.hl{background:color-mix(in srgb,var(--c-accent) 12%,var(--c-surface))!important}
.cv .pricing ul{margin:0;display:flex;gap:6px 16px;flex-wrap:wrap}.cv .pricing li{font-size:14px}
@media(max-width:820px){.cv .pricing .card{grid-template-columns:1fr auto}.cv .pricing ul{grid-column:1/-1}}

.cv .cinfo{display:block;border-top:2px solid var(--c-primary)}
.cv .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.cv .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.cv .cinfo .card p{margin:0}
.cv .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.cv .sec.dark h2,.cv .sec.dark p{color:var(--c-text)}
.cv .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.cv .steps>div{border:0;padding:0 0 26px;position:relative}.cv .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.cv .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.cv .tl>div{position:relative;padding:0 0 28px}.cv .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.cv .tl b{font-size:clamp(24px,3vw,36px)}

.cv .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.cv .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.cv .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.cv .vals .card h3{margin:0}.cv .vals .card p{margin:0}
@media(max-width:700px){.cv .vals .card{grid-template-columns:36px 1fr}.cv .vals .card p{grid-column:2}}

.cv-bud{display:grid;gap:10px;margin-top:12px}.cv-bud div{display:grid;grid-template-columns:150px 1fr 60px;gap:14px;align-items:center;font:700 16px var(--f-body)}
.cv-bud i{display:block;height:22px;background:var(--c-border)}.cv-bud i::after{content:"";display:block;height:100%;width:var(--p);background:var(--c-primary)}
.cv-az{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:22px}.cv-az a{display:grid;place-items:center;min-width:44px;min-height:44px;border:2px solid var(--c-text);font:700 17px var(--f-body);text-decoration:none;color:var(--c-primary)}.cv-az a:hover{background:var(--c-accent)}
.cv-dir h3{font:700 32px var(--f-head);color:var(--c-primary);border-bottom:3px solid var(--c-text);margin:26px 0 4px;padding-bottom:4px}
.cv-dir a{display:grid;grid-template-columns:1fr 150px 120px;gap:14px;padding:14px 0;border-bottom:1px solid var(--c-border);text-decoration:none;color:var(--c-text);align-items:baseline;min-height:48px}
.cv-dir a b{font:700 18px var(--f-body);color:var(--c-primary);text-decoration:underline;text-underline-offset:4px}
.cv-dir a span{font:400 15px var(--f-body)}
@media(max-width:700px){.cv-dir a{grid-template-columns:1fr}.cv-bud div{grid-template-columns:100px 1fr 44px}}</style><div class="cv-util"><span>Municipal Council of Contoh · Open Mon–Fri 08:00–17:00</span><div class="cv-tools" role="group" aria-label="Accessibility"><button type="button" data-z="0.9" aria-label="Smaller text">A−</button><button type="button" data-z="1" aria-label="Normal text">A</button><button type="button" data-z="1.15" aria-label="Larger text">A+</button><button type="button" id="cv-hc" aria-pressed="false">High contrast</button><a href="#">BM</a></div></div><header class="cv-head"><a class="cv-logo" href="index.php"><i>C</i><span><b>Civic Hall</b><small>MUNICIPAL COUNCIL</small></span></a><ul class="cv-nav"><li><a href="services.php">Services</a></li><li><a href="schedule.php">Meetings</a></li><li><a href="blog.php">News</a></li><li><a href="contact.php">Contact</a></li><li class="more"><a href="#" tabindex="0">All pages</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Fees & Permits</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Community Projects</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">News & Notices</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="schedule.php">Council meetings</a><a href="booking.php">Report an issue</a><a href="newsletter.php">Notices by email</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><details class="cv-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Fees & Permits</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Community Projects</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a><a href="blog.php">News & Notices</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="schedule.php">Council meetings</a><a href="booking.php">Report an issue</a><a href="newsletter.php">Notices by email</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="cv">
<main>
