# Build "Nexus AI" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1a1a1a · Secondary #6b6a63 · Text #1f1e1b · Accent #ff5c35 · Surface #f6f4ef · Border #dcd8cd

## 2. Global Fonts
Headings: Rethink Sans · Body: Karla
H1 84px / H2 44px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 10px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Platform (services) — html/services.html
- Single Product (service) — html/service.html
- Pricing (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Customers (projects) — html/projects.html
- Single Customer story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Developers (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Changelog (changelog) — html/changelog.html
- Sign up (signup) — html/signup.html
- Integrations (integrations) — html/integrations.html
- Features (features) — html/features.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
