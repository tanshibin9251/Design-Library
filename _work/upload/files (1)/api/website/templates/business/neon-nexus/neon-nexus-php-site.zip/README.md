# Nexus AI

Exported from Design Library · 22 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Platform, Single Product, Pricing, Contact, Testimonials, Team, Customers, Single Customer story, Gallery, Developers, Single post, FAQ, Changelog, Sign up, Integrations, Features, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
