<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Nexus AI';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Nexus AI</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Nexus AI v2 — light paper AI-lab site with a live request/response demo, tokens only */
.nx-head{display:flex;align-items:center;gap:24px;padding:0 clamp(16px,4vw,56px);min-height:72px;background:color-mix(in srgb,var(--c-surface) 92%,transparent);backdrop-filter:blur(8px);position:sticky;top:0;z-index:50;border-bottom:1px solid var(--c-border)}
.nx-logo{font:700 22px var(--f-head);letter-spacing:-.03em;color:var(--c-primary);text-decoration:none;display:flex;align-items:center;gap:10px}
.nx-logo i{width:22px;height:22px;border-radius:50%;background:conic-gradient(var(--c-accent) 0 25%,var(--c-primary) 0 50%,var(--c-accent) 0 75%,var(--c-primary) 0);display:inline-block}
.nx-nav{display:flex;gap:2px;list-style:none;margin-left:auto;align-items:center}
.nx-nav a{display:inline-flex;align-items:center;min-height:44px;padding:0 14px;font:500 15px var(--f-body);color:var(--c-text);text-decoration:none;border-radius:8px}
.nx-nav a:hover{background:color-mix(in srgb,var(--c-primary) 6%,transparent)}
.nx-nav .key{background:var(--c-primary);color:var(--on-primary);margin-left:8px;font-weight:700}
.nx-nav .more{position:relative}
.nx-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:14px;box-shadow:0 30px 60px -30px rgba(0,0,0,.3);min-width:620px;z-index:60}
.nx-nav .more:hover .dd,.nx-nav .more:focus-within .dd{display:grid}
.nx-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.nx-nav .dd a{display:block;min-height:0;padding:5px 0;border-radius:0}
.nx-m{display:none;margin-left:auto;position:relative}
.nx-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:1px solid var(--c-border);border-radius:8px;padding:0 14px;font:700 12px var(--f-body);letter-spacing:.1em}
.nx-m summary::-webkit-details-marker{display:none}
.nx-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:12px;padding:8px 18px;display:grid;z-index:60}
.nx-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:500 15px var(--f-body);min-height:44px}
@media(max-width:900px){.nx-nav{display:none}.nx-m{display:block}}
.nx-sec{padding:clamp(40px,6vw,92px) clamp(16px,4vw,56px)}
.nx-hero{padding:clamp(48px,8vw,110px) clamp(16px,4vw,56px) clamp(20px,3vw,40px);max-width:1200px;margin:0 auto}
.nx-hero .pill{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--c-border);border-radius:99px;padding:5px 14px;font:600 13px var(--f-body);color:var(--c-secondary);background:var(--c-surface)}
.nx-hero .pill b{color:var(--c-accent)}
.nx-hero h1{font:700 clamp(40px,6.6vw,var(--h1))/1.02 var(--f-head);letter-spacing:-.04em;color:var(--c-primary);margin:20px 0 18px;max-width:16ch}
.nx-hero h1 em{font-style:normal;color:var(--c-accent)}
.nx-hero p{font:400 20px/1.6 var(--f-body);max-width:48ch;margin-bottom:26px}
.nx-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 24px;border-radius:10px;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);text-decoration:none;border:1.5px solid var(--c-primary);cursor:pointer}
.nx-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.nx-btn.o{background:transparent;color:var(--c-primary)}.nx-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.nx-demo{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;border:1.5px solid var(--c-primary);border-radius:16px;overflow:hidden;background:var(--c-surface)}
@media(max-width:860px){.nx-demo{grid-template-columns:1fr}}
.nx-pane{padding:20px 22px;min-width:0}
.nx-pane+.nx-pane{border-left:1.5px solid var(--c-primary);background:color-mix(in srgb,var(--c-primary) 4%,var(--c-surface))}
@media(max-width:860px){.nx-pane+.nx-pane{border-left:0;border-top:1.5px solid var(--c-primary)}}
.nx-lab{display:flex;justify-content:space-between;align-items:center;font:700 12px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:12px}
.nx-pre{font:500 14px/1.75 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-word;min-height:240px;color:var(--c-text)}
.nx-pre .k{color:var(--c-accent)}.nx-pre .s{color:var(--c-secondary)}
.nx-run{min-height:40px;padding:0 16px;border-radius:8px;border:0;background:var(--c-accent);color:var(--on-accent);font:700 13px var(--f-body);cursor:pointer}
.nx-cur{display:inline-block;width:.55em;height:1.05em;background:var(--c-accent);vertical-align:-.15em;animation:nxb 1s steps(2) infinite}
@keyframes nxb{50%{opacity:0}}
.nx-h{max-width:1200px;margin:0 auto 26px;display:flex;justify-content:space-between;align-items:baseline;gap:14px;flex-wrap:wrap}
.nx-h h2{font:700 clamp(26px,3.4vw,var(--h2)) var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.nx-h a{font:700 15px var(--f-body);color:var(--c-accent)}
.nx-tbl{max-width:1200px;margin:0 auto;border:1.5px solid var(--c-primary);border-radius:16px;overflow:hidden;background:var(--c-surface)}
.nx-row{display:grid;grid-template-columns:1.3fr 1fr 1fr 1.4fr;gap:16px;padding:18px 22px;align-items:center;border-bottom:1px solid var(--c-border)}
.nx-row:last-child{border-bottom:0}
.nx-row.hd{font:700 12px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary);background:color-mix(in srgb,var(--c-primary) 5%,var(--c-surface))}
.nx-row b{font:700 18px var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.nx-row small{display:block;font:500 13px var(--f-body);color:var(--c-secondary)}
.nx-bar{height:8px;border-radius:99px;background:var(--c-border);overflow:hidden}.nx-bar i{display:block;height:100%;width:var(--p);background:var(--c-accent)}
@media(max-width:700px){.nx-row{grid-template-columns:1fr 1fr}.nx-row.hd{display:none}}
.nx-calc{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,56px);align-items:center}
@media(max-width:860px){.nx-calc{grid-template-columns:1fr}}
.nx-calc h2{font:700 clamp(28px,3.6vw,48px)/1.05 var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.nx-ctl{border:1.5px solid var(--c-primary);border-radius:16px;padding:24px;display:grid;gap:16px;background:var(--c-surface)}
.nx-ctl label{display:grid;gap:6px;font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-secondary)}
.nx-ctl select{min-height:48px;border:1.5px solid var(--c-border);border-radius:10px;padding:0 12px;font:600 16px var(--f-body);background:var(--c-surface);color:var(--c-text)}
.nx-ctl input[type=range]{accent-color:var(--c-accent);min-height:44px;padding:0;border:0;background:none;width:100%}
.nx-out{font:700 clamp(40px,6vw,64px)/1 var(--f-head);letter-spacing:-.04em;color:var(--c-primary)}
.nx-out small{font:600 14px var(--f-body);color:var(--c-secondary);letter-spacing:0}
.nx-log{max-width:1200px;margin:0 auto}
.nx-log a{display:grid;grid-template-columns:120px 90px 1fr;gap:20px;padding:20px 0;border-top:1px solid var(--c-border);text-decoration:none;align-items:baseline}
.nx-log a:last-child{border-bottom:1px solid var(--c-border)}
.nx-log time{font:600 14px var(--f-body);color:var(--c-secondary)}
.nx-log .t{font:700 11px var(--f-body);letter-spacing:.12em;text-transform:uppercase;border:1px solid currentColor;border-radius:99px;padding:2px 10px;justify-self:start;color:var(--c-accent)}
.nx-log b{font:600 18px var(--f-body);color:var(--c-primary)}
@media(max-width:640px){.nx-log a{grid-template-columns:1fr;gap:4px}}
.nx-foot{border-top:1px solid var(--c-border);margin-top:clamp(30px,5vw,70px);padding:clamp(30px,4vw,56px) clamp(16px,4vw,56px) 22px}
.nx-foot .top{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.nx-foot .big{font:700 24px var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.nx-foot h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:10px}
.nx-foot ul{list-style:none}.nx-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:32px}
.nx-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.nx-foot .copy{max-width:1200px;margin:24px auto 0;font:500 12px var(--f-body);color:var(--c-secondary)}
@media(max-width:860px){.nx-foot .top{grid-template-columns:1fr}.nx-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.nx-cur{animation:none}}
.nx .pagehead{background:none}.nx .card,.nx .scard,.nx .qcard,.nx .pcard,.nx .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.nx .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.nx .pagehead h1{letter-spacing:-.03em}.nx .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.nx .svc{display:block;border:2px solid var(--c-primary)}
.nx .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr) 150px 110px;gap:0;align-items:stretch;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:0}
.nx .scard:nth-child(even){background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}
.nx .scard .ph{display:none}.nx .scard .b{display:contents}
.nx .scard h3{padding:18px;font-size:19px;border-right:1px solid var(--c-border)}
.nx .scard p{padding:18px;margin:0;border-right:1px solid var(--c-border);opacity:.85;font-size:15px}
.nx .scard .m{display:contents}.nx .scard .m b{padding:18px;border-right:1px solid var(--c-border);font-size:15px}.nx .scard .m span{padding:18px;font-size:14px;opacity:.75}
@media(max-width:820px){.nx .scard{grid-template-columns:1fr 1fr}.nx .scard h3{grid-column:1/-1;border-right:0}.nx .scard p{grid-column:1/-1;border-right:0;padding-top:0}}

.nx .tgrid{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:2px solid var(--c-primary)}
.nx .person{display:grid;grid-template-columns:110px 1fr;gap:4px 18px;align-items:center;padding:20px 20px 20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;text-align:left}
.nx .person .ph{grid-row:span 2;aspect-ratio:1!important}
@media(max-width:700px){.nx .tgrid{grid-template-columns:1fr}}

.nx .qgrid{display:block;border-top:2px solid var(--c-primary)}.nx .qgrid.mt{margin-top:0}
.nx .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.nx .qcard .stars{grid-column:1}.nx .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.nx .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.nx .qcard{grid-template-columns:1fr}.nx .qcard figcaption{grid-column:1;grid-row:auto}}

.nx .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.nx .masonry .mi{margin:0}.nx .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.nx .masonry{grid-template-columns:1fr 1fr}}

.nx .split.w2{display:block}
.nx .feat{display:grid;grid-template-columns:1.3fr 1fr;gap:clamp(18px,3vw,40px);align-items:center;margin-bottom:clamp(24px,4vw,48px)}
.nx .feat h2{font-size:clamp(26px,3.6vw,48px);line-height:1.04}
.nx .articles.two{grid-template-columns:repeat(3,1fr)!important}
@media(max-width:800px){.nx .feat{grid-template-columns:1fr}.nx .articles.two{grid-template-columns:1fr!important}}
.nx .faq{max-width:none;columns:2 340px;column-gap:clamp(24px,5vw,72px)}.nx .faq details{break-inside:avoid}

.nx .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.nx .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.nx .pricing .card.hl h3,.nx .pricing .card.hl .amt{color:var(--c-primary)!important}.nx .pricing .card.hl li::before{color:var(--c-accent)!important}

.nx .cinfo{display:block;border-top:2px solid var(--c-primary)}
.nx .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.nx .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.nx .cinfo .card p{margin:0}
.nx .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.nx .sec.dark h2,.nx .sec.dark p{color:var(--c-text)}
.nx .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.nx .steps>div{border:0;padding:0 0 26px;position:relative}.nx .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.nx .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.nx .tl>div{position:relative;padding:0 0 28px}.nx .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.nx .tl b{font-size:clamp(24px,3vw,36px)}

.nx .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.nx .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.nx .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.nx .vals .card h3{margin:0}.nx .vals .card p{margin:0}
@media(max-width:700px){.nx .vals .card{grid-template-columns:36px 1fr}.nx .vals .card p{grid-column:2}}

.nx-code{border:1.5px solid var(--c-primary);border-radius:14px;background:color-mix(in srgb,var(--c-primary) 4%,var(--c-surface));padding:20px 22px;font:500 14px/1.75 ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;overflow:auto}
.nx-code .k{color:var(--c-accent)}.nx-code .s{color:var(--c-secondary)}
.nx-feat{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:1.5px solid var(--c-primary);border-radius:16px;overflow:hidden;background:var(--c-surface)}
.nx-feat>div{padding:26px;border-right:1px solid var(--c-border);display:grid;gap:8px;align-content:start}.nx-feat>div:last-child{border-right:0}
.nx-feat h3{font:700 20px var(--f-head);letter-spacing:-.02em}.nx-feat p{font:400 15px/1.7 var(--f-body)}
@media(max-width:800px){.nx-feat{grid-template-columns:1fr}.nx-feat>div{border-right:0;border-bottom:1px solid var(--c-border)}}</style><header class="nx-head"><a class="nx-logo" href="index.php"><i></i>Nexus</a><ul class="nx-nav"><li><a href="features.php">Models</a></li><li><a href="integrations.php">Integrations</a></li><li><a href="pricing.php">Pricing</a></li><li><a href="changelog.php">Changelog</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Platform</a><a href="service.php">Single Product</a><a href="pricing.php">Pricing</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customers</a><a href="project.php">Single Customer story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Developers</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="changelog.php">Changelog</a><a href="signup.php">Sign up</a><a href="integrations.php">Integrations</a><a href="features.php">Features</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="key" href="signup.php">Get API key</a></li></ul><details class="nx-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Platform</a><a href="service.php">Single Product</a><a href="pricing.php">Pricing</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customers</a><a href="project.php">Single Customer story</a><a href="gallery.php">Gallery</a><a href="blog.php">Developers</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="changelog.php">Changelog</a><a href="signup.php">Sign up</a><a href="integrations.php">Integrations</a><a href="features.php">Features</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="nx">
<main>
