# Build "Pocket App Landing" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #6d4aff · Secondary #6b7280 · Text #11121a · Accent #14c8a8 · Surface #fbfbff · Border #e6e6f2

## 2. Global Fonts
Headings: Onest · Body: Onest
H1 96px / H2 46px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 26px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Features (features) — html/features.html
- Pricing (pricing) — html/pricing.html
- Download (download) — html/download.html
- What’s new (changelog) — html/changelog.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
