<?php $title = 'Download'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Download</b></div><h1>Get Pocket</h1></div></section><section class="ap-sec"><div class="in" style="text-align:center"><p class="lead">Free on iPhone and Android.</p><p style="margin-top:22px"><a class="ap-btn" href="#">App Store</a> <a class="ap-btn" href="#">Google Play</a></p></div></section>
<?php include 'includes/footer.php'; ?>
