<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Pocket App Landing';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Pocket App Landing</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Pocket — tokens only */
.ap-head{position:sticky;top:0;z-index:40;background:color-mix(in srgb,var(--c-surface) 85%,transparent);backdrop-filter:blur(12px)}
.ap-head .in{max-width:var(--w);margin:auto;display:flex;justify-content:space-between;align-items:center;gap:14px;padding:12px 20px}
.ap-logo{font:800 22px var(--f-head);text-decoration:none;display:flex;gap:9px;align-items:center;letter-spacing:-.02em}
.ap-logo i{width:30px;height:30px;border-radius:9px;background:linear-gradient(135deg,var(--c-primary),var(--c-accent));display:block}
.ap-head ul{display:flex;gap:6px;list-style:none;font:600 14.5px var(--f-body)}.ap-head ul>li>a{display:block;padding:.5em .9em;border-radius:99px;text-decoration:none}.ap-head ul>li>a:hover{background:color-mix(in srgb,var(--c-primary) 10%,transparent)}
.ap-btn{background:var(--c-text);color:var(--c-surface);padding:.8em 1.5em;border-radius:99px;font:700 14px var(--f-body);text-decoration:none;display:inline-block}
.ap-btn.p{background:linear-gradient(135deg,var(--c-primary),var(--c-accent));color:var(--on-primary)}.ap-btn.o{background:none;color:var(--c-text);box-shadow:inset 0 0 0 2px var(--c-text)}
.ap-hero{max-width:var(--w);margin:auto;padding:clamp(34px,6vw,90px) 20px 0;text-align:center}
.ap-hero small{display:inline-block;background:color-mix(in srgb,var(--c-primary) 12%,var(--c-surface));color:var(--c-primary);padding:.35em 1em;border-radius:99px;font:700 13px var(--f-body)}
.ap-hero h1{font:800 clamp(42px,7.6vw,var(--h1));line-height:1;letter-spacing:-.04em;max-width:15ch;margin:18px auto}
.ap-hero h1 span{background:linear-gradient(90deg,var(--c-primary),var(--c-accent));-webkit-background-clip:text;background-clip:text;color:transparent}
.ap-hero p{font:500 19px/1.6 var(--f-body);max-width:46ch;margin:0 auto 26px;opacity:.85}
.ap-stage{position:relative;margin:50px auto 0;height:clamp(300px,50vw,520px);overflow:hidden}
.ap-phone{position:absolute;left:50%;top:0;translate:-50% 0;width:min(300px,64vw);aspect-ratio:9/18;border-radius:42px;background:var(--c-text);padding:10px;box-shadow:0 40px 80px -30px color-mix(in srgb,var(--c-primary) 70%,#000)}
.ap-scr{height:100%;border-radius:32px;background:linear-gradient(170deg,color-mix(in srgb,var(--c-primary) 14%,var(--c-surface)),var(--c-surface));padding:34px 16px 16px;overflow:hidden}
.ap-scr h4{font:800 20px var(--f-head);margin-bottom:12px}
.ap-scr .c{background:var(--c-surface);border-radius:16px;padding:12px;margin-bottom:10px;box-shadow:0 8px 20px -14px color-mix(in srgb,var(--c-text) 60%,transparent);display:flex;gap:10px;align-items:center;font:700 13px var(--f-body)}
.ap-scr .c i{width:36px;height:36px;border-radius:12px;background:linear-gradient(135deg,var(--c-primary),var(--c-accent));flex:none}.ap-scr .c small{display:block;font-weight:500;opacity:.6}
.ap-chip{position:absolute;background:var(--c-surface);border-radius:16px;padding:10px 14px;font:700 13px var(--f-body);box-shadow:0 18px 36px -18px color-mix(in srgb,var(--c-text) 60%,transparent);animation:ap-fl 5s ease-in-out infinite}
.ap-chip.a{left:6%;top:24%}.ap-chip.b{right:6%;top:52%;animation-delay:-2s}
@keyframes ap-fl{50%{translate:0 -10px}}
.ap-sec{padding:var(--pad) 20px}.ap-sec>.in{max-width:var(--w);margin:auto;position:relative}
.ap-ft{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.ap-fc{border-radius:26px;padding:26px;background:color-mix(in srgb,var(--c-primary) 6%,var(--c-surface));border:1px solid var(--c-border)}
.ap-fc .ic{width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,var(--c-primary),var(--c-accent));margin-bottom:14px}
.ap-fc h3{font:800 20px var(--f-head);margin-bottom:6px}
.ap-tg{display:inline-flex;border:2px solid var(--c-text);border-radius:99px;padding:3px;margin-bottom:24px}
.ap-tg label{padding:.5em 1.3em;border-radius:99px;font:700 14px var(--f-body);cursor:pointer}
#ap-mo:checked~.ap-tg label[for=ap-mo],#ap-yr:checked~.ap-tg label[for=ap-yr]{background:var(--c-text);color:var(--c-surface)}#ap-mo:focus-visible~.ap-tg label[for=ap-mo],#ap-yr:focus-visible~.ap-tg label[for=ap-yr]{outline:3px solid var(--c-primary)}
.ap-price{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.ap-pc{border:2px solid var(--c-border);border-radius:26px;padding:26px;background:var(--c-surface)}
.ap-pc.hl{border-color:transparent;background:linear-gradient(var(--c-surface),var(--c-surface)) padding-box,linear-gradient(135deg,var(--c-primary),var(--c-accent)) border-box;border:2px solid transparent}
.ap-pc h3{font:800 20px var(--f-head)}.ap-pc .am{font:800 44px var(--f-head);letter-spacing:-.03em;margin:8px 0}.ap-pc .am small{font:600 15px var(--f-body);opacity:.6}
.ap-pc .am .y{display:none}#ap-yr:checked~.ap-price .am .m{display:none}#ap-yr:checked~.ap-price .am .y{display:inline}
.ap-pc ul{list-style:none;padding:0;margin:14px 0 22px;display:grid;gap:8px;font:500 15px var(--f-body)}.ap-pc li::before{content:"✓ ";font-weight:800;color:var(--c-primary)}
.ap-log{border-left:3px solid var(--c-border);padding-left:20px;display:grid;gap:26px}
.ap-log .v b{font:800 20px var(--f-head)}.ap-log .v small{opacity:.6;margin-left:8px}.ap-log ul{margin:8px 0 0;padding-left:20px;font:500 15px/1.7 var(--f-body)}
.ap-foot{border-top:1px solid var(--c-border)}
@media(max-width:820px){.ap-head ul{display:none}.ap-ft,.ap-price{grid-template-columns:1fr}.ap-chip{display:none}}
@media(prefers-reduced-motion:reduce){.ap-chip{animation:none}}
html,body{overflow-x:clip}img,svg{max-width:100%}.ap-head .more{position:relative}.ap-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:16px;}.ap-head .more:hover .dd,.ap-head .more:focus-within .dd{display:grid}.ap-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.ap-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.ap-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-text)}</style><header class="ap-head"><div class="in"><a class="ap-logo" href="index.php"><i></i>Pocket</a><ul><li><a href="features.php">Features</a></li><li><a href="pricing.php">Pricing</a></li><li><a href="changelog.php">What’s new</a></li><li class="more" style="position:relative"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>App</h4><a href="index.php">Home</a><a href="features.php">Features</a><a href="pricing.php">Pricing</a><a href="download.php">Download</a><a href="changelog.php">What’s new</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="ap-btn" href="download.php">Get the app</a></div></header>
<main>
