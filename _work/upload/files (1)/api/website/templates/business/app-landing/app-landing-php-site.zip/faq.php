<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="ap-sec"><div class="in"><div class="faq"><details open><summary>Is my bank data safe?</summary><p>Read-only access, encrypted, never sold.</p></details><details><summary>Can I cancel anytime?</summary><p>Yes, in two taps.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
