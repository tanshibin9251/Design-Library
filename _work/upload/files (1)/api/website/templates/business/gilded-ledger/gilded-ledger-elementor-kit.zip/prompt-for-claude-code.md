# Build "Gilded Ledger" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #26282b · Secondary #8d8a82 · Text #26282b · Accent #b4683a · Surface #f4f1ea · Border #d9d4c7

## 2. Global Fonts
Headings: Cardo · Body: Albert Sans
H1 76px / H2 42px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Private Banking (services) — html/services.html
- Single Service (service) — html/service.html
- Fees (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Client Outcomes (projects) — html/projects.html
- Single Client outcome (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Insights (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Private consultation (booking) — html/booking.html
- Process (process) — html/process.html
- Client types (industries) — html/industries.html
- Resources (resources) — html/resources.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
