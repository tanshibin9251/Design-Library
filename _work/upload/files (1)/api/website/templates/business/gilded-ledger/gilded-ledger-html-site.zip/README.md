# Gilded Ledger

Exported from Design Library · 22 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Private Banking, Single Service, Fees, Contact, Testimonials, Team, Client Outcomes, Single Client outcome, Gallery, Insights, Single post, FAQ, Private consultation, Process, Client types, Resources, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
