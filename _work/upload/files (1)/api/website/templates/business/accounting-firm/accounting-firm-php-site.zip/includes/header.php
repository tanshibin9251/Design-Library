<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Verde & Co. Accountants';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Verde &amp; Co. Accountants</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Verde & Co. — tokens only */
.ac-head{background:var(--c-surface);border-bottom:1px solid var(--c-border);position:sticky;top:0;z-index:40}
.ac-head .in{max-width:var(--w);margin:auto;display:flex;justify-content:space-between;align-items:center;gap:16px;padding:14px 20px}
.ac-logo{font:600 24px var(--f-head);text-decoration:none;color:var(--c-primary)}.ac-logo small{display:block;font:600 10px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-accent);margin-top:2px}
.ac-head ul{display:flex;gap:24px;list-style:none;font:600 15px var(--f-body)}.ac-head ul a{text-decoration:none}.ac-head ul a:hover{color:var(--c-accent)}
.ac-btn{background:var(--c-primary);color:var(--on-primary);padding:.8em 1.4em;border-radius:6px;font:700 14px var(--f-body);text-decoration:none;display:inline-block}
.ac-btn.o{background:none;color:var(--c-primary);box-shadow:inset 0 0 0 2px var(--c-primary)}
.ac-hero{max-width:var(--w);margin:auto;padding:clamp(34px,6vw,84px) 20px;display:grid;grid-template-columns:1.2fr 1fr;gap:40px;align-items:center}
.ac-hero h1{font-size:clamp(38px,5.6vw,var(--h1));line-height:1.08;color:var(--c-primary)}
.ac-hero p{font:400 18px/1.7 var(--f-body);max-width:46ch;margin:18px 0 26px}
.ac-ledger{border:1px solid var(--c-border);background:var(--c-surface);border-radius:8px;box-shadow:10px 10px 0 color-mix(in srgb,var(--c-primary) 14%,transparent);font:500 15px var(--f-body)}
.ac-ledger h3{font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;padding:14px 18px;border-bottom:2px solid var(--c-primary);color:var(--c-primary)}
.ac-ledger div{display:flex;justify-content:space-between;padding:11px 18px;border-bottom:1px dashed var(--c-border)}
.ac-ledger div:last-child{border:0;background:color-mix(in srgb,var(--c-accent) 14%,var(--c-surface));font-weight:700}
.ac-ledger b{font-variant-numeric:tabular-nums}
.ac-sec{padding:var(--pad) 20px}.ac-sec>.in{max-width:var(--w);margin:auto}
.ac-svc{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.ac-sc{border-top:3px solid var(--c-primary);padding-top:16px}.ac-sc h3{font:600 22px var(--f-head);margin-bottom:6px}.ac-sc ul{margin:10px 0 0;padding:0;list-style:none;font:500 15px var(--f-body)}.ac-sc li{padding:6px 0;border-bottom:1px solid var(--c-border)}
.ac-cal{border:1px solid var(--c-border);border-radius:8px;overflow:hidden}
.ac-cal div{display:grid;grid-template-columns:110px 1fr auto;gap:16px;padding:14px 18px;border-bottom:1px solid var(--c-border);align-items:center;font:500 15px var(--f-body)}
.ac-cal div:last-child{border:0}.ac-cal .d{font:700 15px var(--f-head);color:var(--c-primary)}.ac-cal .t{font:700 11px var(--f-body);letter-spacing:.08em;text-transform:uppercase;background:color-mix(in srgb,var(--c-accent) 22%,var(--c-surface));padding:.2em .7em;border-radius:99px}
.ac-cal .t.u{background:var(--c-accent);color:var(--c-surface)}
.ac-tm{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ac-tm .ph{aspect-ratio:1;border-radius:8px}.ac-tm h3{font:600 19px var(--f-head);margin-top:10px}.ac-tm small{opacity:.7}
.ac-foot{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:800px){.ac-head ul{display:none}.ac-hero,.ac-svc{grid-template-columns:1fr}.ac-tm{grid-template-columns:1fr 1fr}.ac-cal div{grid-template-columns:90px 1fr}.ac-cal .t{grid-column:2;justify-self:start}}
html,body{overflow-x:clip}img,svg{max-width:100%}.ac-head .more{position:relative}.ac-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:8px;}.ac-head .more:hover .dd,.ac-head .more:focus-within .dd{display:grid}.ac-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.ac-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.ac-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-primary)}</style><header class="ac-head"><div class="in"><a class="ac-logo" href="index.php">Verde &amp; Co.<small>Chartered Accountants</small></a><ul><li><a href="services.php">Services</a></li><li><a href="deadlines.php">Tax calendar</a></li><li><a href="pricing.php">Fees</a></li><li><a href="team.php">Team</a></li><li class="more" style="position:relative"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Firm</h4><a href="index.php">Home</a><a href="services.php">Services</a><a href="service.php">Tax service</a><a href="pricing.php">Fees</a><a href="team.php">Team</a></div><div><h4>Resources</h4><a href="deadlines.php">Tax calendar</a><a href="resources.php">Guides</a><a href="contact.php">Free consultation</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="ac-btn" href="contact.php">Free consultation</a></div></header>
<main>
