<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="ac-sec"><div class="in"><div class="faq"><details open><summary>Do you work with sole proprietors?</summary><p>Yes, from RM 90 / month.</p></details><details><summary>Can you take over from my current accountant?</summary><p>We manage the handover and prior-year clean-up.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
