<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Enterprise Blue';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Enterprise Blue</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<header class="nav nav-bar"><div class="wrap"><a class="logo" href="index.php">Northgate Advisory</a><ul><li><a href="services.php">Services</a></li><li><a href="industries.php">Industries</a></li><li><a href="projects.php">Case studies</a></li><li><a href="about.php">About</a></li><li class="more"><a href="#" tabindex="0">All pages ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Engagements</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Case Studies</a><a href="project.php">Single Case Study</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Insights</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="industries.php">Industries</a><a href="resources.php">Resources</a><a href="book-call.php">Book a call</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><a class="btn" href="contact.php">Book a call</a><details class="burger"><summary>Menu</summary><div class="bmenu"><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Engagements</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Case Studies</a><a href="project.php">Single Case Study</a><a href="gallery.php">Gallery</a><a href="blog.php">Insights</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="industries.php">Industries</a><a href="resources.php">Resources</a><a href="book-call.php">Book a call</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></details></div></header>
<main>
