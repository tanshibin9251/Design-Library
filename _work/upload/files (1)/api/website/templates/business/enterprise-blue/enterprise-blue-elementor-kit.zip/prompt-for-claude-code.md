# Build "Enterprise Blue" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1E3A5F · Secondary #334155 · Text #1F2937 · Accent #2563EB · Surface #F9FAFB · Border #E5E7EB

## 2. Global Fonts
Headings: Source Sans 3 · Body: Source Sans 3
H1 60px / H2 40px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 6px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single service (service) — html/service.html
- Engagements (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Case Studies (projects) — html/projects.html
- Single Case Study (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Insights (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Industries (industries) — html/industries.html
- Resources (resources) — html/resources.html
- Book a call (book-call) — html/book-call.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
