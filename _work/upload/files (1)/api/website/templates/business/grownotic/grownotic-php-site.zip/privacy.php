<?php $title = 'Privacy & Cookies'; include 'includes/header.php'; ?>
<section class="gn-pg gn-d"><span class="gn-ring" aria-hidden="true"></span><div class="gn-w"><span class="gn-k">Legal</span><h1 class="gn-h">Privacy &amp; <em>cookies.</em></h1></div></section>
<section class="gn-s gn-l"><div class="gn-w"><div class="gn-legal"><p>[待你填：隐私政策与 Cookie 政策正文。上线装 GA4 前必须有 Cookie Policy。这里只是版式示范，不是法律文本。]</p><h2>What we collect</h2><p>[待你填]</p><h2>How we use it</h2><p>[待你填]</p><h2>Cookies</h2><p>[待你填]</p><h2>Contact</h2><p>[待你填]</p></div></div></section>

<?php include 'includes/footer.php'; ?>
