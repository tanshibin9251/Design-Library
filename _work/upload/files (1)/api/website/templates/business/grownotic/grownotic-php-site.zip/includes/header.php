<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Grow Notic';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Grow Notic</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Grow Notic — "Orbit": an open ring and a rising arrow, dark and light bands, tokens only */
.gn-w{max-width:var(--w,1300px);margin:0 auto;padding:0 clamp(20px,4vw,48px)}
.gn-s{padding:var(--pad) 0;position:relative;overflow:hidden}
.gn-s.sm{padding:calc(var(--pad)*.55) 0}
.gn-d{background:var(--c-primary);color:var(--on-primary)}
.gn-l{background:var(--c-surface);color:var(--c-text)}
.gn-t{background:color-mix(in srgb,var(--c-primary) 5%,var(--c-surface));color:var(--c-text)}
.gn-d h1,.gn-d h2,.gn-d h3,.gn-d h4{color:var(--on-primary)}
.gn-k{display:block;font:600 12px/1 var(--f-head);letter-spacing:.32em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:22px}
.gn-d .gn-k{color:var(--c-accent)}
.gn-h{font-family:var(--f-head);font-weight:var(--hw);letter-spacing:var(--hls);line-height:var(--hlh);color:inherit}
h1.gn-h{font-size:clamp(38px,7vw,var(--h1))}
h2.gn-h{font-size:clamp(30px,4.4vw,var(--h2))}
.gn-h em{font-style:normal;color:var(--c-secondary)}
.gn-d .gn-h em{color:var(--c-accent)}
.gn-lead{font-size:clamp(17px,1.7vw,20px);line-height:1.65;max-width:56ch;opacity:.86;margin-top:22px}
.gn-b{display:inline-flex;align-items:center;gap:12px;min-height:52px;padding:0 28px;border-radius:999px;background:var(--c-accent);color:var(--c-primary);border:2px solid var(--c-accent);font:700 14px var(--f-head);letter-spacing:.04em;text-decoration:none;cursor:pointer;transition:background .25s,color .25s,border-color .25s}
.gn-b i{font-style:normal;display:inline-block;transition:transform .25s}
.gn-b:hover i{transform:translate(4px,-4px)}
.gn-b:hover{background:var(--c-primary);color:var(--c-accent)}
.gn-d .gn-b:hover{background:transparent;color:var(--c-accent)}
.gn-b.o{background:transparent;color:inherit;border-color:currentColor}
.gn-b.o:hover{background:var(--c-accent);color:var(--c-primary);border-color:var(--c-accent)}
.gn-acts{display:flex;gap:12px;flex-wrap:wrap;margin-top:34px}
.gn-ring{position:absolute;border:1px solid color-mix(in srgb,var(--on-primary) 9%,transparent);border-radius:50%;pointer-events:none}
.gn-ph{position:relative;min-height:220px;border:1px solid color-mix(in srgb,currentColor 22%,transparent);background:repeating-linear-gradient(135deg,transparent 0 16px,color-mix(in srgb,currentColor 7%,transparent) 16px 17px);overflow:hidden}
.gn-ph::after{content:attr(data-l);position:absolute;left:14px;bottom:12px;right:14px;font:600 11px/1.4 var(--f-head);letter-spacing:.14em;text-transform:uppercase;opacity:.7}
@supports(animation-timeline:view()){.gn-rv{animation:gn-rv linear both;animation-timeline:view();animation-range:entry 0% entry 45%}@keyframes gn-rv{from{opacity:0;transform:translateY(34px)}to{opacity:1;transform:none}}}

/* header */
.gn-hd{position:sticky;top:0;z-index:50;background:color-mix(in srgb,var(--c-primary) 94%,transparent);backdrop-filter:blur(10px);color:var(--on-primary);border-bottom:1px solid color-mix(in srgb,var(--on-primary) 10%,transparent)}
.gn-hd .gn-w{display:flex;align-items:center;gap:28px;min-height:72px}
.gn-logo{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--on-primary);flex:none}
.gn-logo svg{width:38px;height:37px;display:block}
.gn-wm{font:500 15px/1 var(--f-head);letter-spacing:.34em;text-transform:uppercase}
.gn-wm b{font-weight:500;color:var(--c-accent)}
.gn-nav{display:flex;gap:4px;list-style:none;margin-left:auto}
.gn-nav a{display:flex;align-items:center;min-height:44px;padding:0 14px;border-radius:999px;font:500 14px var(--f-body);text-decoration:none;color:inherit;opacity:.82;transition:opacity .2s,background .2s}
.gn-nav a:hover{opacity:1;background:color-mix(in srgb,var(--on-primary) 10%,transparent)}
.gn-lang{display:flex;gap:2px;font:600 12px var(--f-head);letter-spacing:.1em}
.gn-lang a{min-height:44px;display:flex;align-items:center;padding:0 8px;text-decoration:none;color:inherit;opacity:.5}
.gn-lang a:first-child{opacity:1;color:var(--c-accent)}
.gn-hd .gn-b{min-height:44px;padding:0 22px;font-size:13px}
.gn-mm{display:none;margin-left:auto}
.gn-mm summary{list-style:none;cursor:pointer;min-height:44px;display:flex;align-items:center;font:700 12px var(--f-head);letter-spacing:.24em;text-transform:uppercase}
.gn-mm summary::-webkit-details-marker{display:none}
.gn-mm nav{position:absolute;left:0;right:0;top:100%;background:var(--c-primary);padding:8px clamp(20px,4vw,48px) 22px;display:grid;border-bottom:1px solid color-mix(in srgb,var(--on-primary) 14%,transparent)}
.gn-mm nav a{min-height:48px;display:flex;align-items:center;border-bottom:1px solid color-mix(in srgb,var(--on-primary) 10%,transparent);text-decoration:none;font:600 20px var(--f-head);color:inherit}
.gn-mm nav .gn-b{margin-top:18px;justify-content:center;font-size:14px}
@media(max-width:960px){.gn-nav,.gn-lang,.gn-hd>.gn-w>.gn-b{display:none}.gn-mm{display:block}}
@media(max-width:420px){.gn-wm{font-size:12px}}

/* home hero */
.gn-hero{min-height:min(92svh,860px);display:flex;align-items:center;padding:clamp(56px,9vw,120px) 0}
.gn-hero .gn-w{position:relative;z-index:2;width:100%}
.gn-hero h1{max-width:9em;font-size:clamp(38px,5.8vw,88px)}
.gn-art{position:absolute;right:-1%;top:50%;width:min(46vw,620px);aspect-ratio:225/220;transform:translateY(-50%);color:var(--on-primary);z-index:1;opacity:.95}
.gn-art svg{width:100%;height:100%;display:block;overflow:visible}
.gn-art .gn-arrow{animation:gn-up 1.4s cubic-bezier(.2,.8,.2,1) both .3s}
@keyframes gn-up{from{transform:translate(-26px,26px);opacity:0}to{transform:none;opacity:1}}
.gn-hero .gn-ring.a{width:min(88vw,1100px);aspect-ratio:1;right:calc(min(88vw,1100px)*-.3);top:50%;transform:translateY(-50%)}
.gn-hero .gn-ring.b{width:min(118vw,1500px);aspect-ratio:1;right:calc(min(118vw,1500px)*-.34);top:50%;transform:translateY(-50%)}
.gn-cue{position:absolute;left:clamp(20px,4vw,48px);bottom:28px;z-index:2;display:flex;align-items:center;gap:12px;font:600 11px var(--f-head);letter-spacing:.3em;text-transform:uppercase;opacity:.7}
.gn-cue i{font-style:normal;color:var(--c-accent);animation:gn-bob 1.8s ease-in-out infinite}
@keyframes gn-bob{50%{transform:translate(3px,-5px)}}
@media(max-width:800px){.gn-art{width:92vw;right:-34vw;top:18%;opacity:.28}.gn-hero{min-height:0;align-items:flex-start}.gn-cue{display:none}}

/* marquee */
.gn-mq{background:var(--c-primary);color:var(--on-primary);border-top:1px solid color-mix(in srgb,var(--on-primary) 12%,transparent);border-bottom:1px solid color-mix(in srgb,var(--on-primary) 12%,transparent);overflow:hidden;padding:20px 0}
.gn-mq div{display:flex;gap:44px;width:max-content;animation:gn-mq 36s linear infinite;font:600 13px var(--f-head);letter-spacing:.28em;text-transform:uppercase;white-space:nowrap}
.gn-mq span{opacity:.7}.gn-mq b{color:var(--c-accent);font-weight:600}
@keyframes gn-mq{to{transform:translateX(-50%)}}
@media(prefers-reduced-motion:reduce){.gn-mq div{animation:none}}

/* services bento */
.gn-hd2{display:grid;grid-template-columns:1fr 1fr;gap:20px 56px;align-items:end;margin-bottom:clamp(36px,5vw,64px)}
.gn-hd2 p{opacity:.8;max-width:46ch;justify-self:end}
.gn-bento{display:grid;grid-template-columns:1.25fr 1fr;grid-template-rows:auto auto;gap:20px}
.gn-card{position:relative;border:1px solid var(--c-border);border-radius:28px;padding:clamp(24px,3vw,42px);background:var(--c-surface);display:flex;flex-direction:column;gap:14px;overflow:hidden;text-decoration:none;color:inherit;transition:border-color .25s,transform .25s}
.gn-card:hover{border-color:var(--c-accent);transform:translateY(-4px)}
.gn-card .no{display:grid;place-items:center;width:46px;height:46px;border:2px solid var(--c-accent);border-radius:50%;font:700 13px var(--f-head);color:var(--c-secondary)}
.gn-card h3{font:var(--hw) clamp(24px,2.6vw,36px)/1.1 var(--f-head);letter-spacing:var(--hls);color:var(--c-primary)}
.gn-card p{opacity:.8;max-width:44ch}
.gn-card ul{list-style:none;display:grid;gap:8px;margin-top:6px;font-size:15px}
.gn-card li::before{content:"↗";color:var(--c-secondary);margin-right:10px;font-weight:700}
.gn-card .go{margin-top:auto;font:700 13px var(--f-head);letter-spacing:.06em;color:var(--c-secondary)}
.gn-card.big{grid-row:span 2;background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.gn-card.big h3{color:var(--on-primary);font-size:clamp(30px,3.6vw,52px)}
.gn-card.big .no{color:var(--c-accent)}.gn-card.big .go{color:var(--c-accent)}.gn-card.big li::before{color:var(--c-accent)}
.gn-card.big::after{content:"";position:absolute;right:-90px;bottom:-90px;width:300px;aspect-ratio:1;border:30px solid color-mix(in srgb,var(--on-primary) 9%,transparent);border-radius:50%;border-top-color:transparent}
@media(max-width:860px){.gn-hd2{grid-template-columns:1fr}.gn-hd2 p{justify-self:start}.gn-bento{grid-template-columns:1fr}.gn-card.big{grid-row:auto}}

/* work grid (dark) */
.gn-wk{display:grid;grid-template-columns:repeat(12,1fr);gap:20px}
.gn-wk a{display:grid;gap:14px;text-decoration:none;color:inherit;grid-column:span 4}
.gn-wk a:first-child{grid-column:span 7;grid-row:span 2}
.gn-wk a:nth-child(2){grid-column:span 5}.gn-wk a:nth-child(3){grid-column:span 5}
.gn-wk .gn-ph{min-height:260px;border-radius:18px;transition:border-color .25s}
.gn-wk a:first-child .gn-ph{min-height:560px}
.gn-wk a:hover .gn-ph{border-color:var(--c-accent)}
.gn-wk h3{font:var(--hw) 22px var(--f-head);color:var(--on-primary);display:flex;justify-content:space-between;gap:12px}
.gn-wk h3 i{font-style:normal;color:var(--c-accent);transition:transform .25s}
.gn-wk a:hover h3 i{transform:translate(4px,-4px)}
.gn-tag{font:600 11px var(--f-head);letter-spacing:.22em;text-transform:uppercase;opacity:.65}
@media(max-width:800px){.gn-wk a,.gn-wk a:first-child,.gn-wk a:nth-child(2),.gn-wk a:nth-child(3){grid-column:1/-1;grid-row:auto}.gn-wk a:first-child .gn-ph{min-height:300px}}

/* steps on an orbit line */
.gn-steps{display:grid;grid-template-columns:repeat(4,1fr);gap:28px;position:relative;margin-top:clamp(40px,6vw,72px)}
.gn-steps::before{content:"";position:absolute;left:0;right:34px;top:35px;height:2px;background:linear-gradient(90deg,var(--c-accent),color-mix(in srgb,var(--c-accent) 20%,transparent))}
.gn-steps::after{content:"↗";position:absolute;right:0;top:12px;font:700 28px var(--f-head);color:var(--c-accent)}
.gn-steps li{list-style:none;position:relative;display:grid;gap:12px;align-content:start}
.gn-steps .n{display:grid;place-items:center;width:70px;height:70px;border-radius:50%;background:var(--c-surface);border:2px solid var(--c-accent);font:700 18px var(--f-head);color:var(--c-primary);position:relative;z-index:1}
.gn-t .gn-steps .n{background:color-mix(in srgb,var(--c-primary) 5%,var(--c-surface))}
.gn-steps h3{font:var(--hw) 22px/1.2 var(--f-head);letter-spacing:var(--hls);color:var(--c-primary)}
.gn-steps p{opacity:.8;font-size:15px}
.gn-steps small{font:600 11px var(--f-head);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}
.gn-steps .bring{font-size:14px;border-top:1px solid var(--c-border);padding-top:10px;opacity:.9}
@media(max-width:860px){.gn-steps{grid-template-columns:1fr 1fr}.gn-steps::before,.gn-steps::after{display:none}}
@media(max-width:520px){.gn-steps{grid-template-columns:1fr}}

/* why (dark, narrow-left wide-right) */
.gn-why{display:grid;grid-template-columns:5fr 7fr;gap:clamp(32px,6vw,96px);align-items:start}
.gn-why ol{list-style:none;border-top:1px solid color-mix(in srgb,var(--on-primary) 22%,transparent)}
.gn-why li{display:grid;grid-template-columns:70px 1fr;gap:6px 18px;padding:26px 0;border-bottom:1px solid color-mix(in srgb,var(--on-primary) 22%,transparent)}
.gn-why li b{font:700 14px var(--f-head);color:var(--c-accent);grid-row:span 2;padding-top:6px}
.gn-why li h3{font:var(--hw) 26px/1.15 var(--f-head);letter-spacing:var(--hls)}
.gn-why li p{opacity:.78}
@media(max-width:860px){.gn-why{grid-template-columns:1fr}.gn-why li{grid-template-columns:44px 1fr}}

/* blog + learning duo */
.gn-duo{display:grid;grid-template-columns:1.4fr 1fr;gap:clamp(28px,5vw,72px)}
.gn-list{list-style:none;border-top:2px solid var(--c-primary)}
.gn-list a{display:grid;grid-template-columns:1fr auto;gap:4px 18px;padding:20px 0;border-bottom:1px solid var(--c-border);text-decoration:none;color:inherit}
.gn-list a:hover h3{color:var(--c-secondary)}
.gn-list h3{font:var(--hw) 21px/1.25 var(--f-head);letter-spacing:var(--hls);color:var(--c-primary)}
.gn-list small{font:600 11px var(--f-head);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}
.gn-list em{font:600 12px var(--f-head);font-style:normal;opacity:.6;align-self:end}
.gn-mini{display:grid;gap:14px}
.gn-mini a{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:20px 24px;border:1px solid var(--c-border);border-radius:999px;text-decoration:none;color:inherit;transition:background .25s,color .25s,border-color .25s}
.gn-mini a:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.gn-mini b{font:700 17px var(--f-head);display:block}.gn-mini span{font-size:13px;opacity:.7}
.gn-mini i{font-style:normal;color:var(--c-secondary);font-size:22px}.gn-mini a:hover i{color:var(--c-accent)}
@media(max-width:860px){.gn-duo{grid-template-columns:1fr}}

/* faq */
.gn-fq{display:grid;grid-template-columns:5fr 7fr;gap:clamp(28px,6vw,96px);align-items:start}
.gn-fq details{border-top:1px solid var(--c-border);padding:0}
.gn-fq details:last-child{border-bottom:1px solid var(--c-border)}
.gn-fq summary{list-style:none;cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:16px;min-height:64px;padding:12px 0;font:600 18px/1.3 var(--f-head);color:var(--c-primary)}
.gn-fq summary::-webkit-details-marker{display:none}
.gn-fq summary::after{content:"+";flex:none;display:grid;place-items:center;width:36px;height:36px;border:2px solid var(--c-accent);border-radius:50%;font:700 18px var(--f-head);transition:transform .25s,background .25s}
.gn-fq details[open] summary::after{transform:rotate(45deg);background:var(--c-accent)}
.gn-fq details p{padding:0 52px 22px 0;opacity:.82}
@media(max-width:860px){.gn-fq{grid-template-columns:1fr}.gn-fq details p{padding-right:0}}

/* footer CTA */
.gn-ft{background:var(--c-primary);color:var(--on-primary);position:relative;overflow:hidden;padding:clamp(72px,10vw,140px) 0 28px}
.gn-ft .gn-ring{width:min(70vw,820px);aspect-ratio:1;right:-14vw;top:-8vw;border-width:2px}
.gn-ft .gn-big{position:relative;z-index:2;display:block;font:var(--hw) clamp(36px,8vw,120px)/1 var(--f-head);letter-spacing:var(--hls);color:var(--on-primary)}
.gn-ft .gn-big em{font-style:normal;color:var(--c-accent)}
.gn-ft .gn-wa{position:relative;z-index:2;display:inline-flex;align-items:center;gap:18px;margin-top:34px;font:700 clamp(22px,3.6vw,48px)/1.1 var(--f-head);color:var(--on-primary);text-decoration:none;border-bottom:3px solid var(--c-accent);padding-bottom:6px;transition:color .25s}
.gn-ft .gn-wa:hover{color:var(--c-accent)}
.gn-ft .gn-wa i{font-style:normal;color:var(--c-accent)}
.gn-ft .gn-mail{position:relative;z-index:2;display:block;margin-top:18px;opacity:.75;font-size:18px}
.gn-cols{position:relative;z-index:2;display:grid;grid-template-columns:1.6fr 1fr 1fr 1fr;gap:28px;margin-top:clamp(56px,8vw,110px);padding-top:30px;border-top:1px solid color-mix(in srgb,var(--on-primary) 18%,transparent)}
.gn-cols h4{font:600 11px var(--f-head);letter-spacing:.3em;text-transform:uppercase;color:var(--c-accent);margin-bottom:14px}
.gn-cols ul{list-style:none}.gn-cols li a{display:inline-block;min-height:34px;padding:6px 0;text-decoration:none;color:inherit;opacity:.82;font-size:15px}.gn-cols li a:hover{opacity:1;color:var(--c-accent)}
.gn-cols p{opacity:.72;font-size:15px;max-width:36ch;margin-top:16px}
.gn-copy{position:relative;z-index:2;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:34px;font-size:13px;opacity:.65}
.gn-copy a{color:inherit;text-decoration:none;margin-left:6px}
@media(max-width:800px){.gn-cols{grid-template-columns:1fr 1fr}.gn-cols>:first-child{grid-column:1/-1}}

/* sub-page hero */
.gn-pg{padding:clamp(56px,8vw,110px) 0 clamp(48px,6vw,84px);position:relative;overflow:hidden}
.gn-pg .gn-ring{width:min(46vw,560px);aspect-ratio:1;right:-9vw;top:-8vw;border-width:2px}
.gn-pg .gn-w{position:relative;z-index:2}
.gn-pg h1{max-width:12em}
.gn-chips{display:flex;gap:10px;flex-wrap:wrap;margin-top:34px}
.gn-chips a{display:inline-flex;align-items:center;min-height:44px;padding:0 20px;border:1px solid color-mix(in srgb,currentColor 35%,transparent);border-radius:999px;font:600 13px var(--f-head);letter-spacing:.06em;text-decoration:none;color:inherit;transition:background .2s,color .2s,border-color .2s}
.gn-chips a:hover,.gn-chips a.on{background:var(--c-accent);border-color:var(--c-accent);color:var(--c-primary)}

/* services blocks */
.gn-sv{display:grid;grid-template-columns:5fr 7fr;gap:clamp(28px,6vw,96px);align-items:start}
.gn-sv.rv>:first-child{order:2}
.gn-sv .big{font:700 clamp(80px,12vw,180px)/.85 var(--f-head);letter-spacing:-.05em;color:transparent;-webkit-text-stroke:2px var(--c-accent);margin-bottom:18px}
.gn-sv .for{display:inline-block;margin-top:20px;padding:10px 18px;border:1px solid color-mix(in srgb,currentColor 30%,transparent);border-radius:999px;font-size:14px}
.gn-inc{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,3vw,40px)}
.gn-inc h4{font:600 11px var(--f-head);letter-spacing:.3em;text-transform:uppercase;padding-bottom:12px;border-bottom:2px solid var(--c-accent);margin-bottom:6px;color:var(--c-secondary)}
.gn-d .gn-inc h4{color:var(--c-accent)}
.gn-inc div:last-child h4{border-color:color-mix(in srgb,currentColor 35%,transparent);color:inherit;opacity:.7}
.gn-inc li{list-style:none;padding:11px 0;border-bottom:1px solid color-mix(in srgb,currentColor 14%,transparent);font-size:15px;line-height:1.5}
.gn-inc div:first-child li::before{content:"↗ ";color:var(--c-secondary);font-weight:700}
.gn-d .gn-inc div:first-child li::before{color:var(--c-accent)}
.gn-inc div:last-child li{opacity:.7}
@media(max-width:860px){.gn-sv{grid-template-columns:1fr}.gn-sv.rv>:first-child{order:0}.gn-inc{grid-template-columns:1fr}}
.gn-more{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:clamp(32px,4vw,56px)}
.gn-more>div{border:1px solid var(--c-border);border-radius:28px;padding:30px;display:grid;gap:10px;align-content:start}
.gn-more b{font:700 13px var(--f-head);color:var(--c-secondary);letter-spacing:.2em}
.gn-more h3{font:var(--hw) 26px var(--f-head);color:var(--c-primary)}.gn-more p{opacity:.8}
@media(max-width:800px){.gn-more{grid-template-columns:1fr}}

/* case page */
.gn-meta{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid color-mix(in srgb,var(--on-primary) 22%,transparent);margin-top:clamp(36px,5vw,64px)}
.gn-meta div{padding:18px 18px 0 0}.gn-meta small{display:block;font:600 11px var(--f-head);letter-spacing:.26em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.gn-meta a{color:inherit}
@media(max-width:700px){.gn-meta{grid-template-columns:1fr 1fr}}
.gn-3{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(20px,3vw,48px)}
.gn-3>div{border-top:2px solid var(--c-accent);padding-top:18px}
.gn-3 h3{font:600 11px var(--f-head);letter-spacing:.3em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:12px}
.gn-3 p{font-size:18px;line-height:1.6}
@media(max-width:800px){.gn-3{grid-template-columns:1fr}}
.gn-dev{display:grid;grid-template-columns:3fr 1fr;gap:20px;align-items:end}
.gn-dev .gn-ph{border-radius:14px}
@media(max-width:700px){.gn-dev{grid-template-columns:1fr}}
.gn-pn{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap}
.gn-pn a{font:700 clamp(20px,3vw,34px) var(--f-head);text-decoration:none;color:inherit}.gn-pn a:hover{color:var(--c-accent)}

/* blog (magazine) */
.gn-mag{display:grid;grid-template-columns:1.6fr 1fr;gap:clamp(24px,4vw,56px)}
.gn-lead-post{display:grid;gap:18px;text-decoration:none;color:inherit}
.gn-lead-post .gn-ph{min-height:400px;border-radius:22px}
.gn-lead-post h2{font:var(--hw) clamp(28px,3.6vw,48px)/1.1 var(--f-head);letter-spacing:var(--hls);color:var(--c-primary)}
.gn-lead-post:hover h2{color:var(--c-secondary)}
.gn-side{display:grid;gap:0;border-top:2px solid var(--c-primary);align-content:start}
.gn-side a{display:grid;gap:6px;padding:22px 0;border-bottom:1px solid var(--c-border);text-decoration:none;color:inherit}
.gn-side h3{font:var(--hw) 22px/1.25 var(--f-head);color:var(--c-primary)}.gn-side a:hover h3{color:var(--c-secondary)}
.gn-side small,.gn-cards small{font:600 11px var(--f-head);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}
.gn-side em,.gn-cards em{font:600 12px var(--f-head);font-style:normal;opacity:.6}
@media(max-width:860px){.gn-mag{grid-template-columns:1fr}.gn-lead-post .gn-ph{min-height:260px}}
.gn-cards{display:grid;grid-template-columns:repeat(12,1fr);gap:28px 20px}
.gn-cards a{display:grid;gap:12px;text-decoration:none;color:inherit;grid-column:span 4;align-content:start}
.gn-cards a.w{grid-column:span 8}
.gn-cards .gn-ph{min-height:200px;border-radius:16px}.gn-cards a.w .gn-ph{min-height:260px}
.gn-cards h3{font:var(--hw) 21px/1.25 var(--f-head);color:var(--c-primary)}.gn-cards a:hover h3{color:var(--c-secondary)}
@media(max-width:800px){.gn-cards a,.gn-cards a.w{grid-column:1/-1}}
.gn-sub{display:flex;gap:14px;flex-wrap:wrap;align-items:center;justify-content:space-between;border:1px solid color-mix(in srgb,var(--on-primary) 24%,transparent);border-radius:28px;padding:28px 32px}
.gn-sub form{display:flex;gap:10px;flex-wrap:wrap}
.gn-sub input{min-height:52px;border-radius:999px;border:1px solid color-mix(in srgb,var(--on-primary) 35%,transparent);background:transparent;color:inherit;padding:0 22px;font:16px var(--f-body);min-width:min(280px,100%)}

/* post */
.gn-bar{position:fixed;left:0;top:0;height:3px;width:100%;background:var(--c-accent);transform-origin:0 50%;transform:scaleX(0);z-index:90}
@supports(animation-timeline:scroll()){.gn-bar{animation:gn-bar linear both;animation-timeline:scroll(root)}@keyframes gn-bar{to{transform:scaleX(1)}}}
.gn-post{display:grid;grid-template-columns:230px minmax(0,1fr);gap:clamp(24px,5vw,80px);max-width:1080px;margin:0 auto}
.gn-toc{position:sticky;top:96px;align-self:start;display:grid;gap:8px;font-size:14px}
.gn-toc b{font:600 11px var(--f-head);letter-spacing:.3em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.gn-toc a{text-decoration:none;color:inherit;opacity:.75;padding:6px 0 6px 14px;border-left:2px solid var(--c-border)}.gn-toc a:hover{opacity:1;border-color:var(--c-accent)}
.gn-art2{max-width:68ch;font-size:19px;line-height:1.75}
.gn-art2 p{margin-bottom:1.3em;max-width:none}
.gn-art2 h2{font:var(--hw) 34px/1.15 var(--f-head);letter-spacing:var(--hls);margin:1.6em 0 .6em;color:var(--c-primary)}
.gn-art2 blockquote{margin:2em 0;padding:6px 0 6px 28px;border-left:4px solid var(--c-accent);font:var(--hw) clamp(24px,3vw,34px)/1.3 var(--f-head);color:var(--c-primary)}
.gn-au{display:grid;grid-template-columns:72px 1fr;gap:18px;align-items:center;padding:24px 0;border-top:1px solid var(--c-border);border-bottom:1px solid var(--c-border);margin:2.4em 0}
.gn-au .gn-ph{min-height:72px;border-radius:50%}
.gn-cta{border-radius:28px;background:var(--c-primary);color:var(--on-primary);padding:clamp(26px,4vw,48px);display:grid;gap:10px}
.gn-cta h3{color:var(--on-primary);font:var(--hw) clamp(24px,3vw,36px)/1.15 var(--f-head)}
@media(max-width:860px){.gn-post{grid-template-columns:1fr}.gn-toc{position:static}}

/* learning */
.gn-lc{display:grid;grid-template-columns:1fr 1fr;gap:clamp(28px,5vw,80px);align-items:center}
.gn-lc.rv>:first-child{order:2}
.gn-lc .no{display:inline-flex;align-items:center;gap:14px;font:700 13px var(--f-head);letter-spacing:.3em;color:var(--c-accent);margin-bottom:18px}
.gn-lc .no::before{content:"";width:48px;height:48px;border:2px solid var(--c-accent);border-radius:50%;border-top-color:transparent}
.gn-lc ul{list-style:none;margin:20px 0 6px;display:grid;gap:8px;font-size:16px}
.gn-lc li::before{content:"↗ ";color:var(--c-accent);font-weight:700}
.gn-lc .gn-ph{min-height:340px;border-radius:24px}
.gn-count{font:600 12px var(--f-head);letter-spacing:.14em;text-transform:uppercase;opacity:.6;margin-top:14px;display:block}
@media(max-width:860px){.gn-lc{grid-template-columns:1fr}.gn-lc.rv>:first-child{order:0}}

/* about + contact */
.gn-ab{display:grid;grid-template-columns:5fr 7fr;gap:clamp(28px,6vw,96px);align-items:center}
.gn-ab .gn-ph{min-height:560px;border-radius:200px 200px 24px 24px}
@media(max-width:860px){.gn-ab{grid-template-columns:1fr}.gn-ab .gn-ph{min-height:380px}}
.gn-prin{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:40px}
.gn-prin div{border-top:2px solid var(--c-accent);padding-top:18px}
.gn-prin b{font:700 40px var(--f-head);color:var(--c-secondary);display:block;margin-bottom:8px}
.gn-prin h3{font:var(--hw) 22px/1.2 var(--f-head);color:var(--c-primary);margin-bottom:8px}.gn-prin p{opacity:.8}
@media(max-width:800px){.gn-prin{grid-template-columns:1fr}}
.gn-tools{display:flex;gap:10px;flex-wrap:wrap;margin-top:34px}
.gn-tools span{padding:12px 22px;border:1px solid color-mix(in srgb,var(--on-primary) 30%,transparent);border-radius:999px;font:600 14px var(--f-head);letter-spacing:.04em}
.gn-ct{display:grid;grid-template-columns:5fr 7fr;gap:clamp(28px,6vw,96px);align-items:start}
.gn-wa2{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:22px 28px;border-radius:999px;background:var(--c-accent);color:var(--c-primary);text-decoration:none;font:700 clamp(18px,2vw,24px) var(--f-head);margin:26px 0 18px}
.gn-wa2:hover{background:var(--c-primary);color:var(--c-accent)}
.gn-form{display:grid;gap:18px}
.gn-form label{display:grid;gap:8px;font:600 12px var(--f-head);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}
.gn-form input,.gn-form select,.gn-form textarea{min-height:52px;border:1px solid var(--c-border);border-radius:16px;background:var(--c-surface);padding:12px 18px;font:16px var(--f-body);color:var(--c-text);width:100%;text-transform:none;letter-spacing:0}
.gn-form textarea{min-height:150px;resize:vertical}
.gn-form input:focus,.gn-form select:focus,.gn-form textarea:focus{outline:3px solid color-mix(in srgb,var(--c-accent) 55%,transparent);border-color:var(--c-accent)}
.gn-two{display:grid;grid-template-columns:1fr 1fr;gap:18px}
@media(max-width:860px){.gn-ct{grid-template-columns:1fr}.gn-two{grid-template-columns:1fr}}
.gn-legal{max-width:68ch;font-size:17px;line-height:1.75}.gn-legal h2{font:var(--hw) 26px var(--f-head);margin:1.6em 0 .5em;color:var(--c-primary)}
.gn-nf{text-align:center;min-height:70svh;display:grid;place-items:center}
.gn-nf .gn-big4{font:var(--hw) clamp(120px,26vw,360px)/.85 var(--f-head);letter-spacing:-.05em;color:var(--on-primary);display:flex;justify-content:center;align-items:center;gap:.04em}
.gn-nf .gn-big4 svg{height:.78em;width:auto;display:block}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.gn-art .gn-arrow,.gn-cue i{animation:none}.gn-card,.gn-b i{transition:none}}
</style>
<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs><linearGradient id="gn-g" gradientUnits="userSpaceOnUse" x1="236" y1="300" x2="345" y2="196"><stop offset="0" style="stop-color:var(--c-accent);stop-opacity:0"/><stop offset=".5" style="stop-color:var(--c-accent);stop-opacity:.82"/><stop offset="1" style="stop-color:var(--c-accent);stop-opacity:1"/></linearGradient><symbol id="gn-mark" viewBox="130 95 225 220"><path d="M294.8 152.3A82 82 0 1 0 246.2 285.8" fill="none" stroke="currentColor" stroke-width="20"/><polygon class="gn-arrow" points="232,213 345,195 345,275 320,305 320,236 250,302 236,298" fill="url(#gn-g)"/></symbol></defs></svg>
<header class="gn-hd"><div class="gn-w"><a class="gn-logo" href="index.php" aria-label="Grow Notic"><svg viewBox="0 0 225 220" aria-hidden="true"><use href="#gn-mark"/></svg><span class="gn-wm">Grow<b>Notic</b></span></a><ul class="gn-nav"><li><a href="services.php">Services</a></li><li><a href="portfolio.php">Portfolio</a></li><li><a href="blog.php">Blog</a></li><li><a href="learning.php">Learning</a></li><li><a href="about.php">About</a></li><li><a href="contact.php">Contact</a></li></ul><div class="gn-lang" aria-label="Language"><a href="#">EN</a><a href="#">中文</a></div><a class="gn-b" href="contact.php">Get a Quotation <i>↗</i></a><details class="gn-mm"><summary>Menu +</summary><nav><a href="services.php">Services</a><a href="portfolio.php">Portfolio</a><a href="blog.php">Blog</a><a href="learning.php">Learning</a><a href="about.php">About</a><a href="contact.php">Contact</a><a class="gn-b" href="contact.php">Get a Quotation <i>↗</i></a></nav></details></div></header>

<main>
