# Build "Grow Notic" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #141310 · Secondary #C2410C · Text #1C1A15 · Accent #F96405 · Surface #F6F5F2 · Border #DAD7CF

## 2. Global Fonts
Headings: Montserrat · Body: DM Sans
H1 112px / H2 60px / H3 26px / Body 17px

## 3. Layout
Content width 1300px · Section padding 112px vertical · Border radius 6px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Services (services) — html/services.html
- About (about) — html/about.html
- Contact (contact) — html/contact.html
- Portfolio (portfolio) — html/portfolio.html
- Case study (case) — html/case.html
- Blog (blog) — html/blog.html
- Single post (post) — html/post.html
- Learning (learning) — html/learning.html
- Privacy & Cookies (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
