<?php $title = 'Single post'; include 'includes/header.php'; ?>
<div class="gn-bar" aria-hidden="true"></div>
<section class="gn-pg gn-d"><span class="gn-ring" aria-hidden="true"></span><div class="gn-w"><span class="gn-k">WordPress</span><h1 class="gn-h" style="max-width:14em;font-size:clamp(34px,5.6vw,80px)">[示例] The article title sits here, large and <em>plain</em></h1><p class="gn-tag" style="margin-top:26px">DATE · 6 MIN READ · BY GROW NOTIC · EN [占位]</p></div></section>

<section class="gn-s gn-l"><div class="gn-w"><div class="gn-post"><aside class="gn-toc"><b>On this page</b><a href="#p1">1. The problem</a><a href="#p2">2. What I tried</a><a href="#p3">3. What worked</a><a href="#p4">4. Summary</a></aside>
<article class="gn-art2"><p>[示例正文] 正文宽度控制在约 68 个字符，每行不会太长，读起来不累。这里是第一段。 [占位]</p><h2 id="p1">The problem</h2><p>[示例] 第二段。段落之间留足空白，标题用大号。 [占位]</p><blockquote>One pull quote per article, large, with the orange rule. [占位]</blockquote><h2 id="p2">What I tried</h2><p>[示例] 过程描述。 [占位]</p><h2 id="p3">What worked</h2><p>[示例] 结尾段落。 [占位]</p><h2 id="p4">Summary</h2><p>[示例] 总结。 [占位]</p>
<div class="gn-au"><div class="gn-ph" data-l="缺图"></div><div><b style="font-family:var(--f-head)">Grow Notic</b><p style="margin:0;opacity:.8;font-size:16px">一句话作者介绍 [待你填]</p></div></div>
<div class="gn-cta"><span class="gn-k" style="color:var(--c-accent);margin:0">Need this done for you?</span><h3>Let us talk about your site.</h3><p style="opacity:.8">A short, related call-to-action sits here, tied to the article topic.</p><div class="gn-acts" style="margin-top:12px"><a class="gn-b" href="contact.php">Get a Quotation <i>↗</i></a></div></div></article></div></div></section>

<section class="gn-s gn-t"><div class="gn-w"><span class="gn-k">Keep reading</span><div class="gn-cards"><a href="post.php"><div class="gn-ph" data-l="缺图"></div><small>SEO</small><h3>[示例] Related post</h3><p style="opacity:.8">[占位]</p></a><a href="post.php"><div class="gn-ph" data-l="缺图"></div><small>WordPress</small><h3>[示例] Related post</h3><p style="opacity:.8">[占位]</p></a><a href="post.php"><div class="gn-ph" data-l="缺图"></div><small>WordPress</small><h3>[示例] Related post</h3><p style="opacity:.8">[占位]</p></a></div></div></section>

<?php include 'includes/footer.php'; ?>
