# Boutique Rose

Exported from Design Library · 24 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single service, Gift Cards, Contact, Shop, Single product, Cart, Checkout, Testimonials, Team, Lookbook, Single Look, Gallery, Journal, Single post, FAQ, Lookbook, Size guide, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
