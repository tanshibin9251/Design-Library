<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Boutique Rose';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Boutique Rose</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.br-nav{display:flex;list-style:none;align-items:center;gap:4px}
.br-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.br-nav .more{position:relative}
.br-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.br-nav .more:hover .dd,.br-nav .more:focus-within .dd{display:grid}
.br-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.br-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.br-m{display:none;position:relative;margin-left:auto}
.br-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.br-m summary::-webkit-details-marker{display:none}
.br-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.br-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.br-nav{display:none}.br-m{display:block}}
.br-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.br-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.br-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.br-foot ul{list-style:none}.br-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.br-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.br-foot .top{grid-template-columns:1fr}.br-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Maison Rosée v2 — fashion lookbook that adds a whole outfit to the bag, tokens only */
.br-head{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:82px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:1px solid var(--c-text)}
.br-logo{font:500 clamp(24px,3vw,34px) var(--f-head);letter-spacing:.14em;text-transform:uppercase;color:var(--c-primary);text-decoration:none;text-align:center;grid-column:2}
.br-nav{grid-column:1;grid-row:1;justify-self:start;gap:2px}.br-nav a{padding:0 12px;font:500 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-text)}.br-nav a:hover{color:var(--c-accent)}
.br-cta{grid-column:3;grid-row:1;justify-self:end;border-bottom:2px solid var(--c-accent);font:600 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;text-decoration:none;color:var(--c-primary);min-height:44px;display:inline-flex;align-items:center}
.br-m{grid-column:1;grid-row:1;justify-self:start;margin-left:0}
.br-tick{background:var(--c-primary);color:var(--on-primary);font:500 12px var(--f-body);letter-spacing:.24em;text-transform:uppercase;text-align:center;padding:9px 10px}
.br-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.br-hd{display:flex;justify-content:space-between;align-items:end;gap:14px;margin-bottom:22px;flex-wrap:wrap}
.br-hd h1,.br-hd h2{font:500 clamp(34px,5.4vw,var(--h1))/1 var(--f-head);color:var(--c-primary);letter-spacing:-.01em}
.br-hd p{font:400 16px/1.7 var(--f-body);max-width:36ch}
.br-sc{display:flex;gap:clamp(12px,1.6vw,22px);overflow-x:auto;scroll-snap-type:x mandatory;padding:4px 4px 20px;-webkit-overflow-scrolling:touch}
.br-lk{flex:0 0 clamp(240px,26vw,340px);scroll-snap-align:start;border:0;background:none;padding:0;cursor:pointer;text-align:left;font-family:var(--f-body);color:var(--c-text)}
.br-lk .im{aspect-ratio:3/4.4;background:linear-gradient(175deg,var(--a),var(--b));position:relative;display:block;transition:transform .3s}
.br-lk:hover .im{transform:translateY(-4px)}
.br-lk .im::after{content:"缺图";position:absolute;right:10px;top:10px;font:500 10px var(--f-body);letter-spacing:.16em;background:var(--c-surface);padding:2px 8px}
.br-lk .n{font:500 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-accent);display:block;margin-top:10px}
.br-lk b{font:500 22px var(--f-head);color:var(--c-primary);display:block}
.br-lk[aria-pressed=true] .im{outline:3px solid var(--c-accent);outline-offset:3px}
.br-bag{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,60px);border-top:1px solid var(--c-text);padding-top:clamp(20px,3vw,36px)}
@media(max-width:800px){.br-bag{grid-template-columns:1fr}}
.br-bag h2{font:500 clamp(28px,3.6vw,46px)/1.05 var(--f-head);color:var(--c-primary)}
.br-bag p{font:400 17px/1.8 var(--f-body);margin-top:10px;max-width:38ch}
.br-it{display:grid;grid-template-columns:30px 1fr auto;gap:12px;align-items:center;padding:14px 0;border-bottom:1px solid var(--c-border);cursor:pointer;min-height:56px}
.br-it input{width:22px;height:22px;accent-color:var(--c-accent);padding:0;min-height:0}
.br-it span{font:500 16px var(--f-body)}.br-it b{font:500 17px var(--f-head);color:var(--c-primary)}
.br-sz{display:flex;gap:6px;margin:16px 0 8px;flex-wrap:wrap}.br-sz button{min-width:48px;min-height:48px;border:1px solid var(--c-primary);background:transparent;font:500 14px var(--f-body);cursor:pointer;color:var(--c-primary)}
.br-sz button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.br-tot{display:flex;justify-content:space-between;align-items:baseline;margin-top:6px}.br-tot b{font:500 30px var(--f-head);color:var(--c-primary)}
.br-btn{display:inline-flex;align-items:center;justify-content:center;min-height:54px;padding:0 34px;background:var(--c-primary);color:var(--on-primary);font:500 13px var(--f-body);letter-spacing:.24em;text-transform:uppercase;text-decoration:none;border:1px solid var(--c-primary);cursor:pointer;margin-top:12px}
.br-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.br-fa{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:1px solid var(--c-text)}.br-fa>div{padding:24px 22px;border-right:1px solid var(--c-border)}.br-fa>div:last-child{border-right:0}
.br-fa b{font:500 22px var(--f-head);color:var(--c-primary);display:block;margin-bottom:6px}.br-fa span{font:400 15px/1.7 var(--f-body)}
@media(max-width:800px){.br-fa{grid-template-columns:1fr}.br-fa>div{border-right:0;border-bottom:1px solid var(--c-border)}}
.br-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.br-foot .big{font:500 32px var(--f-head);letter-spacing:.14em;text-transform:uppercase}
.br .pagehead{text-align:center;background:none}.br .pagehead .crumbs{justify-content:center}.br .pagehead h1,.br .pagehead .lead{margin-left:auto;margin-right:auto}.br .card,.br .scard,.br .qcard,.br .pcard,.br .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.br .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.br .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.br .svc{display:block;border-top:2px solid var(--c-primary);counter-reset:sv}
.br .scard{display:grid;grid-template-columns:56px minmax(0,1.1fr) minmax(0,1.7fr) auto;gap:6px 24px;align-items:baseline;padding:22px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;counter-increment:sv;transition:padding .2s}
.br .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.br .scard .ph{display:none}.br .scard .b{display:contents}
.br .scard h3{font-size:clamp(20px,2.2vw,28px)}.br .scard p{margin:0;opacity:.8}
.br .scard .m{display:flex;flex-direction:column;align-items:flex-end;gap:2px;font:600 13px var(--f-body);white-space:nowrap}
.br .scard:hover{padding-left:14px}
@media(max-width:760px){.br .scard{grid-template-columns:36px 1fr}.br .scard p,.br .scard .m{grid-column:2;align-items:flex-start}}

.br .tgrid{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:14px}
.br .person{flex:0 0 min(240px,70vw);scroll-snap-align:start}

.br .qgrid{display:block}.br .qgrid.mt{margin-top:0}
.br .qcard{max-width:900px;margin:0 auto;padding:clamp(24px,4vw,48px) 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.br .qcard blockquote{font-size:clamp(22px,3vw,36px);line-height:1.3;margin:10px 0 18px}

.br .masonry{display:flex!important;gap:12px;overflow-x:auto;scroll-snap-type:x mandatory;columns:auto;padding-bottom:14px}
.br .masonry .mi{flex:0 0 min(340px,76vw);margin:0;scroll-snap-align:start}.br .masonry .mi .ph{aspect-ratio:3/4!important}

.br .art .ph,.br .feat .ph{display:none}
.br .art,.br .feat{border-left:4px solid var(--c-accent);padding:4px 0 4px 20px;margin-bottom:22px}
.br .faq summary{font-size:clamp(20px,2.4vw,30px);padding:10px 0}.br .faq details{padding:14px 0}.br .faq p{font-size:18px;max-width:60ch}

.br .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.br .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.br .pricing .card.hl h3,.br .pricing .card.hl .amt{color:var(--c-primary)!important}.br .pricing .card.hl li::before{color:var(--c-accent)!important}
.br .split{display:block;max-width:760px;margin:0 auto}.br .cinfo{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:34px}
.br .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.br .sec.dark h2,.br .sec.dark p{color:var(--c-text)}
.br .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.br .steps>div{border:0;padding:0 0 26px;position:relative}.br .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.br .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.br .tl>div{position:relative;padding:0 0 28px}.br .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.br .tl b{font-size:clamp(24px,3vw,36px)}

.br .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.br .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.br .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.br .vals .card h3{margin:0}.br .vals .card p{margin:0}
@media(max-width:700px){.br .vals .card{grid-template-columns:36px 1fr}.br .vals .card p{grid-column:2}}
</style><div class="br-tick">Autumn / Winter 2026 · Free alterations on every dress</div><header class="br-head"><a class="br-logo" href="index.php">Maison Rosée</a><ul class="br-nav"><li><a href="shop.php">Shop</a></li><li><a href="lookbook.php">Lookbook</a></li><li><a href="size-guide.php">Sizes</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Gift Cards</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Shop</a><a href="product.php">Single product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Lookbook</a><a href="project.php">Single Look</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="lookbook.php">Lookbook</a><a href="size-guide.php">Size guide</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="br-cta" href="cart.php">Bag (0)</a></li></ul><details class="br-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Gift Cards</a><a href="contact.php">Contact</a><a href="shop.php">Shop</a><a href="product.php">Single product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Lookbook</a><a href="project.php">Single Look</a><a href="gallery.php">Gallery</a><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="lookbook.php">Lookbook</a><a href="size-guide.php">Size guide</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="br">
<main>
