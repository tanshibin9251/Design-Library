# Build "Pawsh Pet Boutique" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1f3d36 · Secondary #6b7b73 · Text #16211e · Accent #f59e5b · Surface #fbf8f3 · Border #e4ddd2

## 2. Global Fonts
Headings: Familjen Grotesk · Body: Hind
H1 92px / H2 46px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 20px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Shop (shop) — html/shop.html
- Product (product) — html/product.html
- Grooming (grooming) — html/grooming.html
- Membership (membership) — html/membership.html
- Journal (journal) — html/journal.html
- Visit (visit) — html/visit.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
