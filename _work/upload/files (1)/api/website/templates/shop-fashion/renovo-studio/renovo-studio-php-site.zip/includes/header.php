<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Renovo Studio';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Renovo Studio</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Renovo Studio — editorial, tokens only */
.rv-head{position:sticky;top:0;z-index:40;background:var(--c-surface);border-bottom:1px solid var(--c-text)}
.rv-head .in{max-width:var(--w);margin:auto;display:flex;justify-content:space-between;align-items:baseline;padding:16px 20px}
.rv-logo{font:italic 500 28px var(--f-head);text-decoration:none;letter-spacing:-.01em}
.rv-logo sup{font:600 10px var(--f-body);letter-spacing:.2em;text-transform:uppercase;margin-left:8px;color:var(--c-accent);font-style:normal}
.rv-head ul{display:flex;gap:30px;list-style:none;font:500 13px var(--f-body);letter-spacing:.14em;text-transform:uppercase}
.rv-head ul a{text-decoration:none}.rv-head ul a:hover{color:var(--c-accent)}
.rv-mast{max-width:var(--w);margin:auto;padding:0 20px}
.rv-hero{padding:clamp(30px,5vw,70px) 0 0;display:grid;grid-template-columns:1fr;gap:20px}
.rv-hero .kick{display:flex;justify-content:space-between;font:500 12px var(--f-body);letter-spacing:.22em;text-transform:uppercase;border-bottom:1px solid var(--c-text);padding-bottom:10px}
.rv-hero h1{font-size:clamp(54px,11.5vw,var(--h1));font-weight:500;line-height:.9;letter-spacing:-.03em;max-width:12ch}
.rv-hero h1 em{color:var(--c-accent)}
.rv-collage{display:grid;grid-template-columns:repeat(12,1fr);gap:14px;margin-top:16px}
.rv-collage .ph{border-radius:0}
.rv-c1{grid-column:1/8;aspect-ratio:4/3}.rv-c2{grid-column:8/13;aspect-ratio:4/5;margin-top:60px}.rv-c3{grid-column:1/5;aspect-ratio:1}
.rv-intro{grid-column:5/13;align-self:center;padding:0 0 0 30px;font:400 clamp(20px,2.2vw,28px)/1.35 var(--f-head)}
.rv-intro span{display:block;font:500 12px var(--f-body);letter-spacing:.18em;text-transform:uppercase;margin-bottom:12px;color:var(--c-accent)}
.rv-idx{display:grid;grid-template-columns:220px 1fr;gap:40px;padding:var(--pad) 0 0}
.rv-idx aside{position:sticky;top:90px;align-self:start}
.rv-idx aside h2{font-size:clamp(34px,4vw,56px);font-weight:500;line-height:1}
.rv-idx aside p{font:500 13px var(--f-body);margin-top:14px;opacity:.7}
.rv-case{display:grid;grid-template-columns:1.4fr 1fr;gap:26px;padding:28px 0;border-top:1px solid var(--c-text);text-decoration:none}
.rv-case:hover h3{color:var(--c-accent)}
.rv-case .n{font:italic 500 18px var(--f-head);color:var(--c-accent)}
.rv-case h3{font-size:clamp(28px,3.4vw,50px);font-weight:500;line-height:1;margin:8px 0 12px;transition:color .2s}
.rv-case dl{display:grid;grid-template-columns:auto 1fr;gap:4px 18px;font:500 13px var(--f-body)}
.rv-case dt{opacity:.55;text-transform:uppercase;letter-spacing:.14em;font-size:11px;padding-top:2px}
.rv-ba{position:relative;aspect-ratio:3/2;overflow:hidden;--p:50%}
.rv-ba .ph{position:absolute;inset:0;border-radius:0;height:100%}
.rv-ba .af{clip-path:inset(0 0 0 var(--p))}
.rv-ba input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:ew-resize;margin:0}
.rv-ba .ln{position:absolute;top:0;bottom:0;left:var(--p);width:2px;background:var(--c-surface)}
.rv-ba .ln::after{content:"↔";position:absolute;top:50%;left:50%;translate:-50% -50%;width:42px;height:42px;border-radius:50%;background:var(--c-surface);display:grid;place-items:center;font-weight:700}
.rv-ba .tg{position:absolute;bottom:12px;background:var(--c-surface);padding:.2em .8em;font:600 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase}
.rv-quote{padding:var(--pad) 0;text-align:center;max-width:900px;margin:auto}
.rv-quote blockquote{font:italic 400 clamp(28px,4vw,52px)/1.2 var(--f-head)}
.rv-quote cite{display:block;margin-top:20px;font:500 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;font-style:normal}
.rv-fee{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--c-text)}
.rv-fee>div{padding:30px;border-right:1px solid var(--c-text)}.rv-fee>div:last-child{border:0}
.rv-fee .big{font:500 clamp(36px,4vw,56px)/1 var(--f-head);margin:14px 0}
.rv-fee small{font:600 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-accent)}
.rv-foot{background:var(--c-primary);color:var(--on-primary);margin-top:60px}
.rv-foot .big{font:italic 500 clamp(60px,15vw,240px)/.85 var(--f-head);padding:50px 0 0;opacity:.9}
@media(max-width:900px){.rv-head ul{display:none}.rv-idx,.rv-case,.rv-fee{grid-template-columns:1fr}.rv-fee>div{border-right:0;border-bottom:1px solid var(--c-text)}.rv-idx aside{position:static}.rv-c1,.rv-c2,.rv-c3,.rv-intro{grid-column:1/13;margin:0;padding:0}}
.rv-head .more{position:relative}.rv-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:0;}.rv-head .more:hover .dd,.rv-head .more:focus-within .dd{display:grid}.rv-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.rv-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.rv-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3,h4{color:var(--c-text)}/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.rv-hero h1{font-size:clamp(40px,12.5vw,64px)}.rv-collage{gap:10px}.rv-c2{margin-top:0}.rv-intro{font-size:19px}.rv-case h3{font-size:28px}.rv-foot .big{font-size:20vw}}</style><header class="rv-head"><div class="in"><a class="rv-logo" href="index.php">Renovo<sup>Studio</sup></a><ul><li><a href="projects.php">Projects</a></li><li><a href="services.php">Services</a></li><li><a href="investment.php">Investment</a></li><li><a href="about.php">Studio</a></li><li class="more"><a href="#" tabindex="0">Index</a><div class="dd"><div><h4>Studio</h4><a href="index.php">Home</a><a href="projects.php">Projects</a><a href="project.php">Case study</a><a href="services.php">Services</a><a href="process.php">How we work</a><a href="investment.php">Investment guide</a><a href="about.php">The studio</a></div><div><h4>Contact</h4><a href="visit.php">Book a site visit</a><a href="journal.php">Notes</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a href="visit.php" style="color:var(--c-accent)">Book a visit →</a></li></ul></div></header>
<main>
