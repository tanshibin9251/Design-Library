# Renovo Studio

Exported from Design Library · 12 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, Projects, Case study, Services, How we work, Investment guide, The studio, Book a site visit, Notes, FAQ, Privacy policy, 404 error.

All text and images are placeholders — replace them with your own.
