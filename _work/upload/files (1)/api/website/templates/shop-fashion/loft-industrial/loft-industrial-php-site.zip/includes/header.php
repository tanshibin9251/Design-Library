<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Loft Industrial';
$dark = true;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Loft Industrial</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Loft Industrial — tokens only */
.lf-top{border-bottom:1px solid var(--c-border);background:var(--c-surface);position:sticky;top:0;z-index:30}
.lf-top .in{max-width:var(--w);margin:auto;display:grid;grid-template-columns:auto 1fr auto;align-items:stretch;padding:0 20px}
.lf-logo{font:800 26px var(--f-head);letter-spacing:.06em;text-transform:uppercase;text-decoration:none;padding:16px 28px 16px 0;border-right:1px solid var(--c-border);display:flex;align-items:center;gap:10px}
.lf-logo i{width:14px;height:14px;background:var(--c-accent);display:inline-block}
.lf-menu{display:flex;list-style:none;font:500 12px/1 'IBM Plex Mono',ui-monospace,monospace;letter-spacing:.12em;text-transform:uppercase}
.lf-menu>li>a{display:flex;align-items:center;height:100%;padding:0 20px;text-decoration:none;border-right:1px solid var(--c-border)}
.lf-menu>li>a:hover{background:var(--c-accent);color:var(--c-surface)}
.lf-menu .more{position:relative}
.lf-cart{display:flex;align-items:center;gap:10px;font:600 12px 'IBM Plex Mono',monospace;letter-spacing:.1em;text-transform:uppercase;text-decoration:none;padding:0 0 0 22px;border-left:1px solid var(--c-border)}
.lf-cart b{background:var(--c-accent);color:var(--c-surface);padding:2px 8px}
.mono{font:500 12px/1.5 'IBM Plex Mono',ui-monospace,monospace;letter-spacing:.08em;text-transform:uppercase;opacity:.75}
.lf-bento{display:grid;grid-template-columns:repeat(12,1fr);grid-auto-rows:minmax(120px,auto);gap:10px;padding:10px;max-width:var(--w);margin:auto}
.lf-t{border:1px solid var(--c-border);padding:clamp(16px,2vw,28px);position:relative;overflow:hidden;display:flex;flex-direction:column;justify-content:space-between;gap:16px}
.lf-t.big{grid-column:span 7;grid-row:span 3;background:var(--c-primary)}
.lf-t.big h1{font-size:clamp(54px,9vw,var(--h1));line-height:.88;text-transform:uppercase;letter-spacing:-.005em}
.lf-t.img{grid-column:span 5;grid-row:span 2;padding:0}.lf-t.img .ph{height:100%;border-radius:0;min-height:260px}
.lf-t.s3{grid-column:span 3}.lf-t.s2{grid-column:span 2}
.lf-t.acc{background:var(--c-accent);color:var(--c-surface);border-color:var(--c-accent)}
.lf-t .big-n{font:800 clamp(52px,6vw,88px)/.9 var(--f-head)}
.lf-t a.go{text-decoration:none;font:600 12px 'IBM Plex Mono',monospace;letter-spacing:.12em;text-transform:uppercase;border-top:1px solid currentColor;padding-top:10px;display:flex;justify-content:space-between}
.lf-t.mat{display:grid;grid-template-columns:repeat(4,1fr);gap:0;padding:0}
.lf-t.mat i{display:block;background:var(--s);min-height:90px}
.lf-strip{display:flex;gap:10px;overflow-x:auto;scroll-snap-type:x mandatory;padding:10px;max-width:var(--w);margin:auto;scrollbar-width:thin}
.lf-card{flex:0 0 min(380px,78vw);scroll-snap-align:start;border:1px solid var(--c-border);text-decoration:none;display:block}
.lf-card .ph{border-radius:0;aspect-ratio:1/1}
.lf-card div.m{padding:16px;display:grid;gap:4px;border-top:1px solid var(--c-border)}
.lf-card h3{font-size:26px;text-transform:uppercase}
.lf-card .row{display:flex;justify-content:space-between;align-items:baseline}
.lf-tick{overflow:hidden;border-block:1px solid var(--c-border);background:var(--c-accent);color:var(--c-surface)}
.lf-tick div{display:flex;gap:48px;white-space:nowrap;width:max-content;animation:lf-t 28s linear infinite;padding:14px 0;font:800 clamp(22px,3vw,38px) var(--f-head);text-transform:uppercase;letter-spacing:.04em}
@keyframes lf-t{to{transform:translateX(-50%)}}
.lf-list{border-top:1px solid var(--c-border)}
.lf-row{display:grid;grid-template-columns:140px 2fr 1.2fr 1.2fr 120px;gap:20px;align-items:center;padding:16px 0;border-bottom:1px solid var(--c-border);text-decoration:none}
.lf-row:hover{background:color-mix(in srgb,var(--c-accent) 10%,var(--c-surface))}
.lf-row .ph{border-radius:0;aspect-ratio:1/1;min-height:0}
.lf-row h3{font-size:28px;text-transform:uppercase}
.lf-row.h{font:500 11px 'IBM Plex Mono',monospace;letter-spacing:.14em;text-transform:uppercase;opacity:.6;padding:10px 0}.lf-row.h:hover{background:none}
.lf-sheet{display:grid;grid-template-columns:1.3fr 1fr;gap:0;border:1px solid var(--c-border)}
.lf-sheet>div{padding:clamp(20px,3vw,40px)}
.lf-sheet>div+div{border-left:1px solid var(--c-border)}
.lf-spec{width:100%;border-collapse:collapse;font:500 13px 'IBM Plex Mono',monospace}
.lf-spec td{padding:11px 0;border-bottom:1px dashed var(--c-border)}.lf-spec td:last-child{text-align:right}
.lf-opt{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0 22px}
.lf-opt button{background:none;color:inherit;border:1px solid var(--c-border);padding:.7em 1em;font:600 12px 'IBM Plex Mono',monospace;letter-spacing:.08em;text-transform:uppercase;cursor:pointer}
.lf-opt button[aria-pressed=true]{background:var(--c-accent);color:var(--c-surface);border-color:var(--c-accent)}
.lf-giant{font:800 clamp(70px,19vw,320px)/.8 var(--f-head);text-transform:uppercase;letter-spacing:-.01em;color:color-mix(in srgb,var(--c-text) 14%,var(--c-surface));padding:40px 0 0;white-space:nowrap;overflow:hidden}
@media(max-width:960px){.lf-top .in{grid-template-columns:1fr auto}.lf-menu{display:none}.lf-t.big,.lf-t.img,.lf-t.s3,.lf-t.s2{grid-column:span 12}.lf-row{grid-template-columns:90px 1fr 90px}.lf-row>:nth-child(3),.lf-row>:nth-child(4){display:none}.lf-sheet{grid-template-columns:1fr}.lf-sheet>div+div{border-left:0;border-top:1px solid var(--c-border)}}
@media(prefers-reduced-motion:reduce){.lf-tick div{animation:none}}
.lf-top .more{position:relative}.lf-top .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:22px 34px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:50;text-align:left;text-transform:none;letter-spacing:0;font-family:var(--f-body)}.lf-top .more:hover .dd,.lf-top .more:focus-within .dd{display:grid}.lf-top .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.lf-top .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none}.lf-top .dd a:hover{color:var(--c-accent);background:none;opacity:1}
h1,h2,h3,h4{color:var(--c-text)}
/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.lf-bento{padding:8px;gap:8px}.lf-t.big h1{font-size:clamp(44px,14vw,72px)}.lf-t.s4{grid-column:span 12}.lf-row{grid-template-columns:72px 1fr auto;gap:12px}.lf-giant{font-size:21vw}.lf-card{flex-basis:78vw}}</style><header class="lf-top"><div class="in"><a class="lf-logo" href="index.php"><i></i>Ironwood &amp; Hide</a><ul class="lf-menu"><li><a href="collection.php">Seating</a></li><li><a href="collection.php">Tables</a></li><li><a href="collection.php">Storage</a></li><li><a href="trade.php">Trade</a></li><li><a href="projects.php">Installed</a></li><li class="more"><a href="#" tabindex="0">Index ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="trade.php">Trade & fit-outs</a><a href="projects.php">Installed</a><a href="materials.php">Steel & leather</a><a href="contact.php">Workshop</a></div><div><h4>Shop</h4><a href="collection.php">Collection</a><a href="product.php">Spec sheet</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Support</h4><a href="faq.php">FAQ</a><a href="journal.php">Field notes</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="lf-cart" href="cart.php">Cart <b>2</b></a></div></header>
<main>
