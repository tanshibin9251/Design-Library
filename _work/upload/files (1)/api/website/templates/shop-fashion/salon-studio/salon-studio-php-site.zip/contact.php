<?php $title = 'Visit us'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Visit us</b></div><h1>Visit us</h1></div></section><section class="sl-sec"><div class="in split"><div class="ph soft" data-l="Map (缺图)" style="aspect-ratio:4/3"></div><ul class="kv"><li><span>Address</span><b>21 Jalan SS 2/67, Petaling Jaya</b></li><li><span>Hours</span><b>Tue–Sun 10am–8pm</b></li><li><span>WhatsApp</span><b>+60 12-777 2020</b></li></ul></div></section>
<?php include 'includes/footer.php'; ?>
