<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Maison Verde';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Maison Verde</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Maison Verde — tokens only */
.sl-head{position:absolute;left:0;right:0;top:0;z-index:40;padding:18px 24px;display:flex;justify-content:space-between;align-items:center;max-width:var(--w);margin:auto}
.sl-logo{font:700 26px var(--f-head);text-decoration:none;letter-spacing:.02em;text-transform:uppercase}
.sl-logo b{color:var(--c-accent)}
.sl-head ul{display:flex;gap:26px;list-style:none;font:600 14px var(--f-body);letter-spacing:.1em;text-transform:uppercase}
.sl-head ul a{text-decoration:none;border-bottom:2px solid transparent;padding-bottom:3px}.sl-head ul a:hover{border-color:var(--c-accent)}
.sl-pill{background:var(--c-primary);color:var(--on-primary);padding:.8em 1.5em;border-radius:99px;font:700 13px var(--f-body);letter-spacing:.1em;text-transform:uppercase;text-decoration:none;display:inline-block}
.sl-pill.o{background:none;color:var(--c-primary);box-shadow:inset 0 0 0 2px var(--c-primary)}
.sl-hero{position:relative;padding:130px 24px 60px;max-width:var(--w);margin:auto;display:grid;grid-template-columns:1fr 1.1fr;gap:30px;align-items:center}
.sl-hero h1{font-size:clamp(46px,8.4vw,var(--h1));line-height:.92;text-transform:uppercase;letter-spacing:-.02em;color:var(--c-primary)}
.sl-hero h1 span{display:block;color:transparent;-webkit-text-stroke:2px var(--c-primary)}
.sl-hero p{font:500 18px/1.6 var(--f-body);max-width:38ch;margin:18px 0 26px}
.sl-collage{position:relative;aspect-ratio:1/1.05}
.sl-collage .ph{position:absolute;border-radius:200px 200px 16px 16px}
.sl-collage .a{left:0;top:6%;width:56%;height:70%}.sl-collage .b{right:0;top:0;width:46%;height:48%;border-radius:16px 16px 100px 16px}.sl-collage .c{right:6%;bottom:0;width:50%;height:46%;border-radius:100px 16px 16px 16px}
.sl-blob{position:absolute;left:38%;top:36%;width:30%;aspect-ratio:1;border-radius:50%;background:var(--c-accent);z-index:2;display:grid;place-items:center;text-align:center;font:700 14px/1.15 var(--f-body);color:var(--c-primary);text-transform:uppercase;rotate:-10deg}
.sl-sec{padding:var(--pad) 24px}.sl-sec>.in{max-width:var(--w);margin:auto}
.sl-sv{border-top:2px solid var(--c-primary)}
.sl-sv details{border-bottom:1px solid var(--c-border)}
.sl-sv summary{list-style:none;cursor:pointer;display:grid;grid-template-columns:1fr auto auto;gap:20px;align-items:center;padding:22px 0;font:700 clamp(20px,2.4vw,30px) var(--f-head);text-transform:uppercase}
.sl-sv summary::-webkit-details-marker{display:none}
.sl-sv summary small{font:500 14px var(--f-body);opacity:.65;text-transform:none}
.sl-sv summary b{font:700 18px var(--f-body);color:var(--c-accent)}
.sl-sv details[open] summary{color:var(--c-accent)}
.sl-sv .rows{padding:0 0 22px;display:grid;gap:8px;font:500 16px var(--f-body)}
.sl-sv .rows div{display:flex;justify-content:space-between;border-bottom:1px dashed var(--c-border);padding:6px 0}
.sl-st{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.sl-stc{text-decoration:none;display:block}
.sl-stc .ph{aspect-ratio:3/4;border-radius:140px 140px 14px 14px}
.sl-stc h3{font:700 22px var(--f-head);margin-top:12px;text-transform:uppercase}.sl-stc small{display:block;opacity:.7}
.sl-stc em{display:inline-block;font-style:normal;background:color-mix(in srgb,var(--c-accent) 35%,var(--c-surface));padding:.15em .7em;border-radius:99px;font:700 12px var(--f-body);margin-top:6px}
.sl-ba{position:relative;aspect-ratio:4/3;overflow:hidden;border-radius:16px;--p:50%}
.sl-ba .ph{position:absolute;inset:0;border-radius:0;height:100%}.sl-ba .af{clip-path:inset(0 0 0 var(--p))}
.sl-ba input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:ew-resize;margin:0}
.sl-ba .ln{position:absolute;top:0;bottom:0;left:var(--p);width:3px;background:var(--c-surface)}
.sl-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}
.sl-time{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:10px 0 20px}
.sl-time label{position:relative}.sl-time input{position:absolute;opacity:0}
.sl-time span{display:block;text-align:center;padding:.65em 0;border:1.5px solid var(--c-primary);border-radius:12px;font:700 14px var(--f-body);cursor:pointer}
.sl-time input:checked+span{background:var(--c-primary);color:var(--on-primary)}.sl-time input:disabled+span{opacity:.3;text-decoration:line-through;cursor:not-allowed}.sl-time input:focus-visible+span{outline:3px solid var(--c-accent)}
.sl-foot{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:800px){.sl-head ul{display:none}.sl-hero{grid-template-columns:1fr;padding-top:96px}.sl-st{grid-template-columns:repeat(2,minmax(0,1fr))}.sl-time{grid-template-columns:repeat(3,1fr)}.sl-sv summary{grid-template-columns:1fr auto}.sl-sv summary small{display:none}}
html,body{overflow-x:clip}img,svg{max-width:100%}.sl-head .more{position:relative}.sl-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:18px;}.sl-head .more:hover .dd,.sl-head .more:focus-within .dd{display:grid}.sl-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.sl-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.sl-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-primary)}</style><header class="sl-head"><a class="sl-logo" href="index.php">Maison <b>Verde</b></a><ul><li><a href="services.php">Services</a></li><li><a href="stylists.php">Stylists</a></li><li><a href="gallery.php">Gallery</a></li><li><a href="packages.php">Packages</a></li><li class="more" style="position:relative"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Salon</h4><a href="index.php">Home</a><a href="services.php">Services & prices</a><a href="stylists.php">Stylists</a><a href="stylist.php">Stylist profile</a><a href="gallery.php">Gallery</a><a href="packages.php">Packages</a></div><div><h4>Visit</h4><a href="book.php">Book</a><a href="contact.php">Visit us</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="sl-pill" href="book.php">Book now</a></header>
<main>
