<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="sec loose center404"><div class="wrap"><span class="eyebrow">Error 404</span><h1 style="font-size:clamp(80px,16vw,220px)">404</h1><h2>This piece is not in the catalogue.</h2><p style="margin:14px auto 28px">The page may have moved or sold out.</p><div class="actions" style="justify-content:center"><a class="btn" href="shop.php">Shop all furniture</a><a class="btn ghost" href="index.php">Back home</a></div></div></section>
<?php include 'includes/footer.php'; ?>
