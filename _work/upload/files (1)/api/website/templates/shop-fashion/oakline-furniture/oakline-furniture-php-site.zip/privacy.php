<?php $title = 'Privacy policy'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Privacy policy</b></div><h1>Privacy policy</h1></div></section><section class="sec"><div class="wrap prose"><p>Replace with your privacy policy. Describe what you collect at checkout, how long you keep delivery details and how customers can request deletion.</p></div></section>
<?php include 'includes/footer.php'; ?>
