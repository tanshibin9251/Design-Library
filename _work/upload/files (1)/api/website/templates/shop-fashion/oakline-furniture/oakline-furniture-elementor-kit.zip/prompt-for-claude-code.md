# Build "Oakline Furniture" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #6b4a2f · Secondary #2f3b34 · Text #2b231c · Accent #b85c2e · Surface #f5efe4 · Border #dccfb9

## 2. Global Fonts
Headings: Young Serif · Body: Figtree
H1 88px / H2 48px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 104px vertical · Border radius 6px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Shop all (shop) — html/shop.html
- Single product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Our workshop (about) — html/about.html
- Woods & finishes (materials) — html/materials.html
- Delivery & assembly (delivery) — html/delivery.html
- Showroom (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Journal (blog) — html/blog.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
