# Build "Happy Paws" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2f4b7c · Secondary #8ad0c7 · Text #26334d · Accent #ff8a5b · Surface #f4f9ff · Border #d5e3f2

## 2. Global Fonts
Headings: Sniglet · Body: Varela Round
H1 84px / H2 44px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 26px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Vet Care (services) — html/services.html
- Single Service (service) — html/service.html
- Grooming Prices (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Pet Shop (shop) — html/shop.html
- Single Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Pet Gallery (projects) — html/projects.html
- Single Pet story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Pet Tips (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book a visit (booking) — html/booking.html
- Grooming day (process) — html/process.html
- Pet taxi areas (service-areas) — html/service-areas.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
