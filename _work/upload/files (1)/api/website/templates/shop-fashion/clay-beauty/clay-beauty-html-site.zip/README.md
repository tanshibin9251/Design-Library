# Clay Beauty Studio

Exported from Design Library · 25 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single Service, Packages, Contact, Shop, Single Product, Cart, Checkout, Testimonials, Team, Before & After, Single Transformation, Gallery, Journal, Single post, FAQ, Book an appointment, Gift cards, Style gallery, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
