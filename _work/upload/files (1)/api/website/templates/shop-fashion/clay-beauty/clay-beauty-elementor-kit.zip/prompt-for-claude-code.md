# Build "Clay Beauty Studio" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #5c3b3b · Secondary #f0cdbf · Text #3b2626 · Accent #c4745a · Surface #fdf6f1 · Border #ecd5c8

## 2. Global Fonts
Headings: Prata · Body: Jost
H1 80px / H2 46px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 24px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single Service (service) — html/service.html
- Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Shop (shop) — html/shop.html
- Single Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Before & After (projects) — html/projects.html
- Single Transformation (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book an appointment (booking) — html/booking.html
- Gift cards (gift-cards) — html/gift-cards.html
- Style gallery (lookbook) — html/lookbook.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
