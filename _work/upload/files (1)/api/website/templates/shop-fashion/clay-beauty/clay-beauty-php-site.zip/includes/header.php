<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Clay Beauty Studio';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Clay Beauty Studio</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.cb-nav{display:flex;list-style:none;align-items:center;gap:4px}
.cb-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.cb-nav .more{position:relative}
.cb-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.cb-nav .more:hover .dd,.cb-nav .more:focus-within .dd{display:grid}
.cb-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.cb-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.cb-m{display:none;position:relative;margin-left:auto}
.cb-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.cb-m summary::-webkit-details-marker{display:none}
.cb-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.cb-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.cb-nav{display:none}.cb-m{display:block}}
.cb-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.cb-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.cb-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.cb-foot ul{list-style:none}.cb-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.cb-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.cb-foot .top{grid-template-columns:1fr}.cb-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Clay Beauty v2 — skin-first brand with a shade finder, tokens only */
.cb-ann{background:var(--c-primary);color:var(--on-primary);text-align:center;font:500 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;padding:9px 12px}
.cb-head{display:flex;align-items:center;gap:22px;padding:0 clamp(14px,4vw,56px);min-height:78px;background:var(--c-surface);position:sticky;top:0;z-index:50}
.cb-logo{font:400 28px var(--f-head);color:var(--c-primary);text-decoration:none;letter-spacing:.02em}
.cb-nav{margin-left:auto;gap:2px}.cb-nav a{padding:0 14px;font:400 14px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-text)}.cb-nav a:hover{color:var(--c-accent)}
.cb-cta{border:1px solid var(--c-primary);border-radius:999px;margin-left:8px;color:var(--c-primary)!important;padding:0 20px!important}.cb-cta:hover{background:var(--c-primary);color:var(--on-primary)!important}
.cb-sec{padding:clamp(40px,6vw,90px) clamp(14px,4vw,56px)}
.cb-hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:center;padding:clamp(28px,5vw,70px) clamp(14px,4vw,56px)}
@media(max-width:900px){.cb-hero{grid-template-columns:1fr}}
.cb-hero h1{font:400 clamp(42px,6vw,var(--h1))/1.04 var(--f-head);color:var(--c-primary)}
.cb-hero h1 em{color:var(--c-accent);font-style:italic}
.cb-hero p{font:300 18px/1.85 var(--f-body);margin:16px 0 24px;max-width:38ch}
.cb-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 30px;border-radius:999px;background:var(--c-primary);color:var(--on-primary);font:400 13px var(--f-body);letter-spacing:.2em;text-transform:uppercase;text-decoration:none;border:1px solid var(--c-primary);cursor:pointer}
.cb-btn:hover{background:var(--c-accent);border-color:var(--c-accent)}.cb-btn.o{background:transparent;color:var(--c-primary)}.cb-btn.o:hover{background:var(--c-primary);color:var(--on-primary)}
.cb-fn{background:color-mix(in srgb,var(--c-secondary) 45%,var(--c-surface));border-radius:200px 200px 24px 24px;padding:clamp(24px,3vw,44px) clamp(18px,3vw,40px) clamp(20px,3vw,34px);text-align:center}
.cb-fn h2{font:400 28px var(--f-head);color:var(--c-primary);margin-bottom:4px}.cb-fn .k{font:400 12px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-text);opacity:.7}
.cb-sw{width:clamp(120px,16vw,180px);aspect-ratio:1;border-radius:50%;margin:20px auto;background:var(--sh,#e8c4a8);box-shadow:0 18px 34px -16px rgba(0,0,0,.4),inset 0 0 0 6px rgba(255,255,255,.35);transition:background .25s}
.cb-un{display:flex;gap:6px;justify-content:center;margin-bottom:14px}.cb-un button{min-height:44px;padding:0 18px;border-radius:999px;border:1px solid var(--c-primary);background:transparent;font:400 14px var(--f-body);cursor:pointer;color:var(--c-primary)}
.cb-un button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.cb-rng{width:min(100%,320px);accent-color:var(--c-accent);padding:0;border:0;background:none;min-height:44px}
.cb-dp{display:flex;justify-content:space-between;max-width:320px;margin:0 auto;font:400 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase}
.cb-res{margin-top:16px;font:400 18px var(--f-head);color:var(--c-primary)}.cb-res small{display:block;font:300 15px var(--f-body);color:var(--c-text);margin-top:4px}
.cb-h{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:24px;flex-wrap:wrap}
.cb-h h2{font:400 clamp(28px,4vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.cb-pd{display:grid;grid-template-columns:repeat(4,1fr);gap:clamp(14px,2vw,28px)}@media(max-width:900px){.cb-pd{grid-template-columns:1fr 1fr}}
.cb-p{display:grid;gap:8px;text-decoration:none;color:var(--c-text)}.cb-p .im{aspect-ratio:3/4;border-radius:200px 200px 10px 10px;background:linear-gradient(170deg,var(--a),var(--b));position:relative}
.cb-p .im::after{content:"缺图";position:absolute;left:50%;bottom:10px;transform:translateX(-50%);font:400 10px var(--f-body);letter-spacing:.14em;background:var(--c-surface);padding:2px 8px;border-radius:99px}
.cb-p b{font:400 20px var(--f-head);color:var(--c-primary)}.cb-p span{font:300 15px var(--f-body)}.cb-p:hover .im{filter:saturate(1.2)}
.cb-sk{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:1px solid var(--c-primary)}
.cb-sk>div{padding:26px 24px;border-right:1px solid var(--c-border)}.cb-sk>div:last-child{border-right:0}
.cb-sk b{font:400 22px var(--f-head);color:var(--c-primary);display:block;margin-bottom:6px}.cb-sk span{font:300 16px/1.75 var(--f-body)}
@media(max-width:800px){.cb-sk{grid-template-columns:1fr}.cb-sk>div{border-right:0;border-bottom:1px solid var(--c-border)}}
.cb-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.cb-foot .big{font:400 32px var(--f-head)}
.cb .pagehead{text-align:center;background:none}.cb .pagehead .crumbs{justify-content:center}.cb .pagehead h1,.cb .pagehead .lead{margin-left:auto;margin-right:auto}.cb .card,.cb .scard,.cb .qcard,.cb .pcard,.cb .person{background:color-mix(in srgb,var(--c-secondary) 14%,var(--c-surface));border:0;box-shadow:none}.cb .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.cb .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.cb .svc{display:grid;grid-template-columns:1fr;gap:clamp(18px,3vw,36px)}
.cb .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:0;align-items:stretch}
.cb .scard:nth-child(even) .ph{order:2}
.cb .scard .ph{aspect-ratio:auto!important;min-height:220px;height:100%;border-radius:inherit}
.cb .scard .b{padding:clamp(20px,3vw,40px);align-self:center}
@media(max-width:760px){.cb .scard{grid-template-columns:1fr}.cb .scard:nth-child(even) .ph{order:0}}

.cb .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:30px 20px}
.cb .person{text-align:center;background:none;border:0;box-shadow:none;padding:0}
.cb .person .ph{aspect-ratio:1!important;border-radius:50%!important;margin:0 auto 12px;max-width:190px}

.cb .qgrid{display:block}.cb .qgrid.mt{margin-top:0}
.cb .qcard{max-width:900px;margin:0 auto;padding:clamp(24px,4vw,48px) 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.cb .qcard blockquote{font-size:clamp(22px,3vw,36px);line-height:1.3;margin:10px 0 18px}

.cb .masonry{display:grid!important;grid-template-columns:repeat(4,1fr);grid-auto-rows:150px;gap:8px;columns:auto}
.cb .masonry .mi{margin:0;overflow:hidden}.cb .masonry .mi .ph{aspect-ratio:auto!important;height:100%}
.cb .masonry .mi:nth-child(5n+1){grid-column:span 2;grid-row:span 2}.cb .masonry .mi:nth-child(7n+3){grid-row:span 2}
.cb .masonry .mi h3,.cb .masonry .mi .muted{display:none}
@media(max-width:700px){.cb .masonry{grid-template-columns:1fr 1fr}}

.cb .split.w2{display:block}
.cb .feat{display:grid;grid-template-columns:1.3fr 1fr;gap:clamp(18px,3vw,40px);align-items:center;margin-bottom:clamp(24px,4vw,48px)}
.cb .feat h2{font-size:clamp(26px,3.6vw,48px);line-height:1.04}
.cb .articles.two{grid-template-columns:repeat(3,1fr)!important}
@media(max-width:800px){.cb .feat{grid-template-columns:1fr}.cb .articles.two{grid-template-columns:1fr!important}}

.cb .faq{display:grid;gap:10px}
.cb .faq details{border:1px solid var(--c-primary);padding:6px 18px;background:var(--c-surface)}.cb .faq details[open]{background:color-mix(in srgb,var(--c-accent) 10%,var(--c-surface))}

.cb .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.cb .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.cb .pricing .card.hl h3,.cb .pricing .card.hl .amt{color:var(--c-primary)!important}.cb .pricing .card.hl li::before{color:var(--c-accent)!important}
.cb .split{display:block;max-width:760px;margin:0 auto}.cb .cinfo{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:34px}
.cb .ctaband{display:block;text-align:center}.cb .ctaband h2{max-width:22ch;margin:0 auto}.cb .ctaband .btn{margin-top:22px}
.cb .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.cb .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.cb .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.cb .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.cb .tl>div:last-child{border-right:0}
.cb .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.cb .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.cb .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.cb .vals .card:last-child{border-right:0}
@media(max-width:700px){.cb .vals{grid-template-columns:1fr}.cb .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><div class="cb-ann">Free shade matching · Complimentary samples with every order</div><header class="cb-head"><a class="cb-logo" href="index.php">Clay Beauty</a><ul class="cb-nav"><li><a href="shop.php">Shop</a></li><li><a href="lookbook.php">Looks</a></li><li><a href="booking.php">Studio</a></li><li><a href="gift-cards.php">Gifts</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Before & After</a><a href="project.php">Single Transformation</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Book an appointment</a><a href="gift-cards.php">Gift cards</a><a href="lookbook.php">Style gallery</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="cb-cta" href="shop.php">Find my shade</a></li></ul><details class="cb-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a><a href="shop.php">Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Before & After</a><a href="project.php">Single Transformation</a><a href="gallery.php">Gallery</a><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Book an appointment</a><a href="gift-cards.php">Gift cards</a><a href="lookbook.php">Style gallery</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="cb">
<main>
