# Build "Sugar & Crumb" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #8a3b55 · Secondary #f7c6c7 · Text #4a2c35 · Accent #f2b84b · Surface #fff8f2 · Border #f1d6cf

## 2. Global Fonts
Headings: Grandstander · Body: Mulish
H1 88px / H2 44px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 28px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- All bakes (recipes) — html/recipes.html
- Recipe: Vanilla sponge (recipe) — html/recipe.html
- Pan converter (pans) — html/pans.html
- Cups, grams & oven temps (conversions) — html/conversions.html
- Why did it sink? (troubleshoot) — html/troubleshoot.html
- About (about) — html/about.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
