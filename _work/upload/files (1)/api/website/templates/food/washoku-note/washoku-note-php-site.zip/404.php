<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="wn-sec" style="text-align:center;padding-top:clamp(50px,9vw,120px)"><div class="wn-note" style="max-width:520px;margin:0 auto"><span class="jp">404</span><h1 style="font:600 clamp(36px,6vw,64px) var(--f-head);margin:10px 0">ページがありません</h1><p style="font:500 16px/1.9 var(--f-body);margin-bottom:20px">This page was torn out of the notebook.</p><a class="wn-btn" href="index.php">ノートへ戻る</a></div></section>
<?php include 'includes/footer.php'; ?>
