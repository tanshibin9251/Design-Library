# Build "Sunny's Diner" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #c8102e · Secondary #00a3a1 · Text #14213d · Accent #14213d · Surface #fff4e0 · Border #14213d

## 2. Global Fonts
Headings: Bungee · Body: Manrope
H1 80px / H2 40px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Specials (services) — html/services.html
- Single Special (service) — html/service.html
- Party Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Order Online (shop) — html/shop.html
- Single Dish (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Gallery (projects) — html/projects.html
- Single Photo (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- News (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Menu (menu) — html/menu.html
- Book a table (reservations) — html/reservations.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
