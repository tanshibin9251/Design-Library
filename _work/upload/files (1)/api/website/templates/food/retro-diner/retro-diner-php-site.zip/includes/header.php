<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Sunny\'s Diner';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Sunny's Diner</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.rd-nav{display:flex;list-style:none;align-items:center;gap:4px}
.rd-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.rd-nav .more{position:relative}
.rd-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.rd-nav .more:hover .dd,.rd-nav .more:focus-within .dd{display:grid}
.rd-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.rd-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.rd-m{display:none;position:relative;margin-left:auto}
.rd-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.rd-m summary::-webkit-details-marker{display:none}
.rd-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.rd-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.rd-nav{display:none}.rd-m{display:block}}
.rd-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.rd-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.rd-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.rd-foot ul{list-style:none}.rd-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.rd-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.rd-foot .top{grid-template-columns:1fr}.rd-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Sunny's Diner v2 — chequerboard counter with a printed-receipt order pad */
.rd-chk{height:22px;background:repeating-conic-gradient(var(--c-text) 0 25%,var(--c-surface) 0 50%) 0 0/44px 44px}
.rd-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:84px;background:var(--c-primary);color:var(--on-primary);position:sticky;top:0;z-index:50;border-bottom:6px solid var(--c-text)}
.rd-logo{font:400 30px var(--f-head);letter-spacing:.02em;color:var(--on-primary);text-decoration:none;text-transform:uppercase;text-shadow:3px 3px 0 var(--c-text)}
.rd-logo small{display:block;font:700 11px var(--f-body);letter-spacing:.3em;text-shadow:none;color:var(--c-surface)}
.rd-nav{margin-left:auto}.rd-nav a{padding:0 14px;font:400 15px var(--f-head);text-transform:uppercase;color:var(--on-primary);letter-spacing:.02em}.rd-nav a:hover{background:var(--c-text);color:var(--c-surface)}
.rd-cta{background:var(--c-surface);color:var(--c-text)!important;border:3px solid var(--c-text);margin-left:8px;box-shadow:3px 3px 0 var(--c-text)}
.rd-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.rd-hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,60px);align-items:start;padding:clamp(28px,5vw,64px) clamp(14px,4vw,56px)}
@media(max-width:900px){.rd-hero{grid-template-columns:1fr}}
.rd-hero h1{font:400 clamp(36px,6vw,var(--h1))/1.02 var(--f-head);text-transform:uppercase;color:var(--c-primary);text-shadow:4px 4px 0 var(--c-text)}
.rd-hero p{font:600 19px/1.7 var(--f-body);margin:18px 0 22px;max-width:38ch}
.rd-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 24px;background:var(--c-primary);color:var(--on-primary);font:400 16px var(--f-head);text-transform:uppercase;text-decoration:none;border:3px solid var(--c-text);box-shadow:4px 4px 0 var(--c-text);cursor:pointer;transition:transform .1s,box-shadow .1s}
.rd-btn:hover{transform:translate(2px,2px);box-shadow:2px 2px 0 var(--c-text)}
.rd-btn.t{background:var(--c-secondary)}
.rd-pad{display:grid;grid-template-columns:1fr 1fr;gap:20px}@media(max-width:560px){.rd-pad{grid-template-columns:1fr}}
.rd-opts{display:grid;gap:8px;align-content:start}
.rd-opts button{display:flex;justify-content:space-between;align-items:center;min-height:50px;padding:0 14px;border:3px solid var(--c-text);background:var(--c-surface);color:var(--c-text);font:700 15px var(--f-body);cursor:pointer;text-align:left}
.rd-opts button:hover{background:var(--c-secondary);color:var(--on-secondary,#fff)}
.rd-opts button b{font:400 14px var(--f-head);color:var(--c-primary)}
.rd-rc{background:#fff;color:#111;font:500 14px/1.6 ui-monospace,Menlo,Consolas,monospace;padding:18px 18px 28px;position:relative;box-shadow:0 14px 24px -14px rgba(0,0,0,.5);min-height:300px;clip-path:polygon(0 0,100% 0,100% calc(100% - 12px),95% 100%,90% calc(100% - 12px),85% 100%,80% calc(100% - 12px),75% 100%,70% calc(100% - 12px),65% 100%,60% calc(100% - 12px),55% 100%,50% calc(100% - 12px),45% 100%,40% calc(100% - 12px),35% 100%,30% calc(100% - 12px),25% 100%,20% calc(100% - 12px),15% 100%,10% calc(100% - 12px),5% 100%,0 calc(100% - 12px))}
.rd-rc h3{text-align:center;font:400 18px var(--f-head);text-transform:uppercase}.rd-rc .no{text-align:center;color:#666;margin-bottom:10px}
.rd-rc .ln{display:flex;justify-content:space-between;gap:8px;border-bottom:1px dashed #bbb;padding:5px 0}
.rd-rc .ln button{border:0;background:none;color:#c00;cursor:pointer;font:700 14px ui-monospace,monospace;min-width:28px;min-height:28px}
.rd-rc .tt{display:flex;justify-content:space-between;margin-top:8px;font-weight:700}.rd-rc .em{color:#888;text-align:center;padding:30px 0}
.rd-h{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:20px;flex-wrap:wrap}
.rd-h h2{font:400 clamp(24px,3.4vw,var(--h2)) var(--f-head);text-transform:uppercase;color:var(--c-text)}
.rd-sh{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.rd-sh>div{border:3px solid var(--c-text);background:var(--c-surface);padding:20px;box-shadow:6px 6px 0 var(--c-secondary)}
.rd-sh h3{font:400 20px var(--f-head);text-transform:uppercase;color:var(--c-primary)}.rd-sh p{font:600 15px/1.6 var(--f-body)}.rd-sh b{font:400 18px var(--f-head);color:var(--c-text)}
@media(max-width:800px){.rd-sh{grid-template-columns:1fr}}
.rd-foot{background:var(--c-text);color:var(--c-surface);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px;border-top:6px solid var(--c-primary)}
.rd-foot .big{font:400 32px var(--f-head);text-transform:uppercase;color:var(--c-primary)}.rd-foot li a,.rd-foot h4{color:var(--c-surface)}
.rd .pagehead{background:var(--c-primary);color:var(--on-primary)}.rd .pagehead h1,.rd .pagehead .lead,.rd .pagehead .crumbs,.rd .pagehead .eyebrow{color:var(--on-primary)}.rd .card,.rd .scard,.rd .qcard,.rd .pcard,.rd .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.rd .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.rd .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.rd .svc{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:3px solid var(--c-primary)}
.rd .scard{display:block;padding:clamp(22px,3vw,40px);border:0;border-bottom:1px solid var(--c-primary);border-right:1px solid var(--c-primary);border-radius:0;background:none;box-shadow:none;min-height:240px;transition:background .2s}
.rd .scard:nth-child(2n){border-right:0}
.rd .scard .ph{display:none}
.rd .scard h3{font-size:clamp(28px,3.6vw,50px);line-height:1.02;margin-bottom:12px;letter-spacing:-.02em}
.rd .scard p{max-width:34ch;opacity:.85}.rd .scard .m{margin-top:16px;display:flex;gap:14px;font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent)}
.rd .scard:hover{background:color-mix(in srgb,var(--c-accent) 14%,var(--c-surface))}
@media(max-width:760px){.rd .svc{grid-template-columns:1fr}.rd .scard{border-right:0;min-height:0}}

.rd .tgrid{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:14px}
.rd .person{flex:0 0 min(240px,70vw);scroll-snap-align:start}

.rd .qgrid{display:block;border-top:2px solid var(--c-primary)}.rd .qgrid.mt{margin-top:0}
.rd .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.rd .qcard .stars{grid-column:1}.rd .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.rd .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.rd .qcard{grid-template-columns:1fr}.rd .qcard figcaption{grid-column:1;grid-row:auto}}

.rd .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.rd .masonry .mi{margin:0}.rd .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.rd .masonry{grid-template-columns:1fr 1fr}}

.rd .articles{display:block!important}
.rd .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.rd .art .ph{display:none}.rd .art .meta{grid-row:1/span 2;align-self:start}.rd .art h3{margin:0}
.rd .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}

.rd .faq{counter-reset:q;max-width:960px}
.rd .faq details{counter-increment:q;position:relative;padding-left:64px}
.rd .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.rd .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.rd .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.rd .pricing .card.hl h3,.rd .pricing .card.hl .amt{color:var(--c-primary)!important}.rd .pricing .card.hl li::before{color:var(--c-accent)!important}
.rd .split{display:flex;flex-direction:column-reverse;gap:30px}.rd .cinfo{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}@media(max-width:800px){.rd .cinfo{grid-template-columns:1fr 1fr}}
.rd .sec.dark{background:var(--c-accent);color:var(--on-accent)}.rd .sec.dark h2,.rd .sec.dark p{color:var(--on-accent)}.rd .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.rd .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.rd .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.rd .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.rd .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.rd .tl>div:last-child{border-right:0}
.rd .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.rd .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.rd .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.rd .vals .card:last-child{border-right:0}
@media(max-width:700px){.rd .vals{grid-template-columns:1fr}.rd .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><div class="rd-chk"></div><header class="rd-head"><a class="rd-logo" href="index.php">Sunny&#x27;s Diner<small>OPEN LATE · SINCE 1958</small></a><ul class="rd-nav"><li><a href="menu.php">Menu</a></li><li><a href="reservations.php">Booths</a></li><li><a href="gallery.php">Gallery</a></li><li><a href="about.php">About</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Specials</a><a href="service.php">Single Special</a><a href="pricing.php">Party Packages</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Order Online</a><a href="product.php">Single Dish</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Gallery</a><a href="project.php">Single Photo</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="menu.php">Menu</a><a href="reservations.php">Book a table</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="rd-cta" href="shop.php">Order</a></li></ul><details class="rd-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Specials</a><a href="service.php">Single Special</a><a href="pricing.php">Party Packages</a><a href="contact.php">Contact</a><a href="shop.php">Order Online</a><a href="product.php">Single Dish</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Gallery</a><a href="project.php">Single Photo</a><a href="gallery.php">Gallery</a><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="menu.php">Menu</a><a href="reservations.php">Book a table</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="rd">
<main>
