<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Kissa Maruyo';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Kissa Maruyo</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Kissa Maruyo — Showa-era coffee house, tokens only */
.ks-awning{height:30px;background:repeating-linear-gradient(90deg,var(--c-accent) 0 48px,var(--c-surface) 48px 96px);position:relative;border-bottom:3px solid var(--c-primary)}
.ks-awning::after{content:"";position:absolute;left:0;right:0;top:100%;height:24px;background:
 radial-gradient(circle at 24px 0,var(--c-accent) 23px,transparent 24px) 0 0/96px 24px,
 radial-gradient(circle at 72px 0,var(--c-surface) 23px,var(--c-primary) 23px 26px,transparent 26px) 0 0/96px 24px;z-index:2;pointer-events:none}
.ks-head{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:34px clamp(18px,4vw,60px) 14px;position:relative}
.ks-plate{display:flex;align-items:center;gap:14px;text-decoration:none;color:var(--c-primary);border:3px double var(--c-primary);padding:8px 20px;border-radius:14px;background:var(--c-surface)}
.ks-plate b{font:400 30px var(--f-head);letter-spacing:.1em;line-height:1}
.ks-plate small{display:block;font:500 10px var(--f-body);letter-spacing:.3em;color:var(--c-secondary);margin-top:4px}
.ks-tabs{display:flex;gap:6px;list-style:none;flex-wrap:wrap;justify-content:center}
.ks-tabs a{display:inline-flex;align-items:center;min-height:44px;padding:0 18px;border:2px solid var(--c-primary);border-radius:999px;text-decoration:none;font:500 14px var(--f-body);letter-spacing:.06em;color:var(--c-primary);background:var(--c-surface);transition:background .2s,color .2s}
.ks-tabs a:hover{background:var(--c-primary);color:var(--on-primary)}
.ks-tabs .more{position:relative}
.ks-tabs .dd{position:absolute;right:0;top:calc(100% + 8px);display:none;grid-template-columns:repeat(4,minmax(120px,1fr));gap:18px 28px;padding:22px 26px;background:var(--c-surface);border:3px double var(--c-primary);border-radius:14px;min-width:600px;z-index:60}
.ks-tabs .more:hover .dd,.ks-tabs .more:focus-within .dd{display:grid}
.ks-tabs .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.ks-tabs .dd a{display:block;border:0;border-radius:0;min-height:0;padding:5px 0;background:none;color:var(--c-text)}
.ks-tabs .dd a:hover{background:none;color:var(--c-accent)}
.ks-sign{display:grid;place-items:center;min-width:92px;min-height:44px;padding:0 14px;border-radius:8px;background:var(--c-primary);color:var(--on-primary);font:400 18px var(--f-head);letter-spacing:.12em}
.ks-sign.off{background:transparent;color:var(--c-secondary);border:2px dashed var(--c-secondary)}
.ks-m{display:none}.ks-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:600 12px var(--f-body);letter-spacing:.18em;border:2px solid var(--c-primary);border-radius:999px;padding:0 16px}
.ks-m summary::-webkit-details-marker{display:none}
.ks-m nav{position:absolute;left:12px;right:12px;top:100%;background:var(--c-surface);border:3px double var(--c-primary);border-radius:14px;padding:10px 18px;display:grid;z-index:60}
.ks-m nav a{padding:12px 4px;border-bottom:1px dotted var(--c-secondary);text-decoration:none;font:500 15px var(--f-body);min-height:44px}
@media(max-width:960px){.ks-head{flex-wrap:wrap}.ks-tabs{display:none}.ks-m{display:block;margin-left:auto}.ks-sign{order:3}}

.ks-sec{padding:var(--pad) clamp(20px,5vw,80px)}
.ks-hd{display:flex;align-items:center;gap:16px;margin-bottom:30px}
.ks-hd h2{font:400 clamp(26px,3.4vw,40px) var(--f-head);letter-spacing:.1em;color:var(--c-primary)}
.ks-hd::before,.ks-hd::after{content:"";flex:1;height:0;border-top:3px double var(--c-primary)}
.ks-hd::before{max-width:60px}
.ks-btn{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:.8em 2em;border-radius:999px;border:3px solid var(--c-primary);background:var(--c-primary);color:var(--on-primary);font:600 15px var(--f-body);letter-spacing:.1em;text-decoration:none;cursor:pointer;box-shadow:4px 4px 0 var(--c-accent);transition:transform .15s,box-shadow .15s}
.ks-btn:hover{transform:translate(2px,2px);box-shadow:2px 2px 0 var(--c-accent)}
.ks-btn.o{background:var(--c-surface);color:var(--c-primary)}
.ks-ph{position:relative;min-height:240px;border:3px solid var(--c-primary);border-radius:12px;background:
 radial-gradient(circle at 30% 30%,color-mix(in srgb,var(--c-surface) 55%,transparent) 0 10%,transparent 11%),
 repeating-linear-gradient(135deg,color-mix(in srgb,var(--c-secondary) 22%,var(--c-surface)) 0 12px,color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface)) 12px 24px)}
.ks-ph::after{content:attr(data-l);position:absolute;left:12px;bottom:10px;font:600 10px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-primary);background:var(--c-surface);padding:2px 8px;border-radius:999px}

.ks-hero{display:grid;grid-template-columns:1.05fr .95fr;gap:clamp(24px,5vw,80px);padding:clamp(30px,5vw,64px) clamp(20px,5vw,80px) var(--pad);align-items:center}
.ks-board{background:var(--c-surface);border:4px double var(--c-primary);border-radius:18px;padding:clamp(22px,3.4vw,44px);position:relative;box-shadow:8px 8px 0 color-mix(in srgb,var(--c-primary) 18%,transparent)}
.ks-board h1{font:400 clamp(34px,5vw,var(--h1)) var(--f-head);letter-spacing:.08em;line-height:1.25;color:var(--c-primary);margin-bottom:6px}
.ks-board .sub{font:500 13px var(--f-body);letter-spacing:.24em;color:var(--c-secondary);margin-bottom:24px;display:block}
.ks-it{display:flex;align-items:baseline;gap:10px;padding:9px 0;font:500 17px var(--f-body)}
.ks-it i{flex:1;border-bottom:3px dotted var(--c-secondary);transform:translateY(-4px);min-width:20px}
.ks-it b{font:600 17px var(--f-body);color:var(--c-primary);white-space:nowrap}
.ks-it small{display:block;font:400 12px var(--f-body);color:var(--c-secondary);letter-spacing:.06em}
.ks-stick{position:absolute;right:-18px;top:-26px;width:104px;height:104px;border-radius:50%;background:var(--c-accent);color:var(--on-accent);display:grid;place-items:center;text-align:center;font:400 15px/1.3 var(--f-head);letter-spacing:.06em;transform:rotate(12deg);border:3px solid var(--c-primary)}
.ks-today{margin-top:22px;border:2px dashed var(--c-primary);border-radius:12px;padding:14px 18px;display:grid;grid-template-columns:auto 1fr;gap:6px 16px;align-items:center;background:color-mix(in srgb,var(--c-accent) 10%,var(--c-surface))}
.ks-today span{font:600 11px var(--f-body);letter-spacing:.24em;color:var(--c-accent)}
.ks-today b{font:400 22px var(--f-head);letter-spacing:.08em;color:var(--c-primary)}
.ks-today em{grid-column:1/-1;font:400 14px var(--f-body);font-style:normal;color:var(--c-text);opacity:.85}
.ks-hero .ks-ph{aspect-ratio:4/5;min-height:300px;transform:rotate(1.4deg);box-shadow:8px 8px 0 var(--c-primary)}
@media(max-width:900px){.ks-hero{grid-template-columns:1fr}.ks-stick{right:10px;top:-30px}.ks-hero .ks-ph{aspect-ratio:16/10;transform:none}}

.ks-3{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(16px,2.4vw,30px)}
.ks-card{border:3px solid var(--c-primary);border-radius:16px;background:var(--c-surface);padding:26px 24px;display:grid;gap:10px;align-content:start;position:relative}
.ks-card h3{font:400 24px var(--f-head);letter-spacing:.08em;color:var(--c-primary)}
.ks-card .pr{font:700 20px var(--f-body);color:var(--c-accent)}
.ks-card p{font-size:15px;line-height:1.8;opacity:.85}
.ks-card .tag{position:absolute;right:16px;top:-14px;background:var(--c-accent);color:var(--on-accent);border:2px solid var(--c-primary);border-radius:999px;padding:2px 14px;font:700 12px var(--f-body);letter-spacing:.14em}
@media(max-width:800px){.ks-3{grid-template-columns:1fr}}
.ks-menu{display:grid;grid-template-columns:1fr 1fr;gap:0 clamp(30px,6vw,90px)}
.ks-menu h3{font:400 26px var(--f-head);letter-spacing:.14em;color:var(--c-primary);margin:30px 0 8px;padding-bottom:8px;border-bottom:3px solid var(--c-primary)}
@media(max-width:800px){.ks-menu{grid-template-columns:1fr}}
.ks-split{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:center}
.ks-split h2{font:400 clamp(28px,3.6vw,var(--h2)) var(--f-head);letter-spacing:.08em;color:var(--c-primary);margin-bottom:14px}
.ks-split p{line-height:2;max-width:46ch}
@media(max-width:800px){.ks-split{grid-template-columns:1fr}}
.ks-hours{width:100%;border-collapse:collapse;font:500 16px var(--f-body)}
.ks-hours td,.ks-hours th{padding:14px 8px;border-bottom:2px dotted var(--c-secondary);text-align:left}
.ks-hours th{font:400 18px var(--f-head);letter-spacing:.12em;color:var(--c-primary)}
.ks-hours tr.off td{color:var(--c-secondary)}
.ks-gal{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.ks-gal .ks-ph{min-height:0;aspect-ratio:1}.ks-gal .w{grid-column:span 2}
@media(max-width:700px){.ks-gal{grid-template-columns:1fr 1fr}}
.ks-note{display:grid;grid-template-columns:130px 1fr;gap:20px;padding:20px 0;border-bottom:2px dotted var(--c-secondary);text-decoration:none;align-items:baseline}
.ks-note time{font:600 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.ks-note h3{font:400 20px var(--f-head);letter-spacing:.06em}
@media(max-width:600px){.ks-note{grid-template-columns:1fr;gap:4px}}
.ks-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(40px,5vw,70px) clamp(20px,5vw,80px) 26px;margin-top:var(--pad)}
.ks-foot .top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(24px,6vw,100px)}
.ks-foot .big{font:400 32px var(--f-head);letter-spacing:.14em}
.ks-foot h4{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;opacity:.7;margin-bottom:10px;color:var(--on-primary)}
.ks-foot ul{list-style:none}.ks-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font-size:14px;opacity:.9;min-height:32px}
.ks-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ks-foot .copy{margin-top:34px;padding-top:16px;border-top:2px dotted color-mix(in srgb,var(--on-primary) 40%,transparent);font-size:12px;letter-spacing:.14em;opacity:.75}
@media(max-width:800px){.ks-foot .top{grid-template-columns:1fr}.ks-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(max-width:700px){.ks-sec{padding-left:18px;padding-right:18px}}
@media(prefers-reduced-motion:reduce){.ks-btn{transition:none}}
</style><div class="ks-awning"></div><header class="ks-head"><a class="ks-plate" href="index.php"><b>喫茶 まるよ</b><span><small>KISSA MARUYO</small></span></a><ul class="ks-tabs"><li><a href="menu.php">お品書き Menu</a></li><li><a href="morning.php">モーニング</a></li><li><a href="beans.php">珈琲豆 Beans</a></li><li><a href="access.php">場所 Access</a></li><li class="more"><a href="#" tabindex="0">他 More</a><div class="dd"><div><h4>Café</h4><a href="index.php">Home</a><a href="menu.php">Menu</a><a href="morning.php">Morning set</a><a href="beans.php">Roasted beans</a></div><div><h4>Shop</h4><a href="story.php">Our story</a><a href="gallery.php">Gallery</a><a href="news.php">Notice board</a></div><div><h4>Visit</h4><a href="access.php">Access & hours</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><span class="ks-sign" id="ks-sign">営業中</span><details class="ks-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="menu.php">Menu</a><a href="morning.php">Morning set</a><a href="beans.php">Roasted beans</a><a href="story.php">Our story</a><a href="gallery.php">Gallery</a><a href="news.php">Notice board</a><a href="access.php">Access & hours</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header>
<main>
