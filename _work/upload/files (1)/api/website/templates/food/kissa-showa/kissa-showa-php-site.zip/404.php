<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="ks-sec" style="text-align:center;padding-top:clamp(60px,10vw,140px)"><div class="ks-sign" style="display:inline-grid;margin-bottom:20px">準備中</div><h1 style="font:400 clamp(70px,14vw,180px) var(--f-head)">404</h1><h2 style="margin:8px 0 26px;font:400 28px var(--f-head);letter-spacing:.1em">そのページは売り切れです。</h2><a class="ks-btn" href="index.php">TOPへ戻る</a></section>
<?php include 'includes/footer.php'; ?>
