# Daily Table

Exported from Design Library · 10 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, All recipes, Recipe: Sheet-pan chicken, Weekly planner, Shopping list, Pantry staples, About, FAQ, Privacy policy, 404 error.

All text and images are placeholders — replace them with your own.
