<?php $title = 'About'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>About</b></div><h1 style="font-weight:700">About</h1></div></section><section class="dt-sec" style="padding-top:0"><div style="max-width:60ch;font:400 20px/1.8 var(--f-body)"><p>Daily Table started as a spreadsheet on a fridge. Replace this with your own story.</p></div></section>
<?php include 'includes/footer.php'; ?>
