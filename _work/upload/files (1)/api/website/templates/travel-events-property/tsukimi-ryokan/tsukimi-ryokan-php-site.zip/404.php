<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="ts-sec" style="text-align:center;padding-top:clamp(80px,12vw,180px)"><div class="ts-k" style="justify-content:center">Error 404</div><h1 style="font-size:clamp(70px,14vw,200px);font-weight:400;letter-spacing:.2em">404</h1><h2 style="margin:10px 0 28px;font-weight:400;letter-spacing:.14em">この道は、月に隠れました。</h2><a class="ts-btn f" href="index.php">Back to the inn</a></section>
<?php include 'includes/footer.php'; ?>
