<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="sec loose center404"><div class="wrap"><span class="eyebrow">Error 404</span><h1 style="font-size:clamp(80px,16vw,220px)">404</h1><h2>This page has gone for a walk.</h2><p style="margin:14px auto 28px">The page you are looking for may have moved or no longer exists.</p><div class="actions" style="justify-content:center"><a class="btn" href="index.php">Back home</a><a class="btn ghost" href="contact.php">Contact us</a></div></div></section>
<?php include 'includes/footer.php'; ?>
