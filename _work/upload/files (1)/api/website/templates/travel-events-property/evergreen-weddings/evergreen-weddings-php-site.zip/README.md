# Evergreen Weddings

Exported from Design Library · 23 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Wedding Services, Single Service, Packages, Contact, Venues, Single Venue, Cart, Checkout, Testimonials, Team, Real Weddings, Single Wedding, Gallery, Journal, Single post, FAQ, Enquire, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
