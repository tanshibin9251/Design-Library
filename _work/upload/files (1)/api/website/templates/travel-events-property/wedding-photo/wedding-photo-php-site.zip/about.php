<?php $title = 'About us'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>About us</b></div><h1>About us</h1></div></section><section class="wp-sec"><div class="in split"><div class="ph soft" data-l="Photographers (缺图)" style="aspect-ratio:4/5;border-radius:0"></div><div class="prose"><p class="lead">Two photographers, one film-maker, and a thermos of kopi.</p><p>Replace with your story and style.</p></div></div></section>
<?php include 'includes/footer.php'; ?>
