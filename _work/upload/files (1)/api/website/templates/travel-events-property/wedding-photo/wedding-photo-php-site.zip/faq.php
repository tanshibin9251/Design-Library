<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="wp-sec"><div class="in"><div class="faq"><details open><summary>How far ahead should we book?</summary><p>9–12 months for peak weekends.</p></details><details><summary>Do you travel?</summary><p>Yes, travel is quoted at cost.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
