<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Frame & Vow';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Frame &amp; Vow</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Frame & Vow — tokens only */
.wp-head{position:absolute;left:0;right:0;top:0;z-index:40;display:flex;justify-content:space-between;align-items:center;padding:20px clamp(16px,3vw,40px);color:var(--on-primary)}
.wp-head a{text-decoration:none;color:inherit}
.wp-logo{font:400 30px var(--f-head);letter-spacing:.14em;text-transform:uppercase}.wp-logo small{display:block;font:400 10px var(--f-body);letter-spacing:.5em;margin-top:2px;opacity:.8}
.wp-head ul{display:flex;gap:28px;list-style:none;font:400 13px var(--f-body);letter-spacing:.24em;text-transform:uppercase}
.wp-head .more{position:relative}
.wp-hero{position:relative;min-height:100vh;display:grid;place-items:center;text-align:center;color:var(--on-primary);background:var(--c-primary);overflow:hidden}
.wp-hero .ph{position:absolute;inset:0;border-radius:0;height:100%;opacity:.55}
.wp-hero::after{content:"";position:absolute;inset:0;background:radial-gradient(ellipse at center,transparent 30%,var(--c-primary) 100%)}
.wp-hero .in{position:relative;z-index:2;padding:0 20px}
.wp-hero small{font:400 12px var(--f-body);letter-spacing:.5em;text-transform:uppercase;opacity:.85}
.wp-hero h1{font:400 clamp(44px,9vw,var(--h1));line-height:1;letter-spacing:.04em;color:var(--on-primary);margin:20px 0}
.wp-hero p{font:300 18px/1.8 var(--f-body);max-width:46ch;margin:0 auto 30px;opacity:.9}
.wp-btn{display:inline-block;border:1px solid currentColor;padding:1em 2.4em;font:400 12px var(--f-body);letter-spacing:.3em;text-transform:uppercase;text-decoration:none}
.wp-btn:hover,.wp-btn.f{background:var(--c-accent);border-color:var(--c-accent);color:var(--c-primary)}
.wp-sec{padding:var(--pad) clamp(16px,3vw,40px)}.wp-sec>.in{max-width:var(--w);margin:auto}
.wp-strip{display:flex;gap:6px;overflow-x:auto;scroll-snap-type:x mandatory;padding:18px 0;background:var(--c-primary)}
.wp-strip .fr{flex:0 0 min(260px,62vw);scroll-snap-align:center;background:var(--c-surface);padding:10px 10px 36px;position:relative;rotate:var(--r,0deg);box-shadow:0 14px 28px -12px color-mix(in srgb,#000 60%,transparent)}
.wp-strip .fr .ph{aspect-ratio:3/4;border-radius:0}
.wp-strip .fr::after{content:attr(data-c);position:absolute;left:12px;bottom:10px;font:400 18px var(--f-head);letter-spacing:.06em}
.wp-strip::before,.wp-strip::after{content:"";flex:0 0 12vw}
.wp-sto{display:grid;grid-template-columns:1fr 1fr;gap:0}
.wp-sto a{position:relative;aspect-ratio:4/5;display:block;text-decoration:none;color:var(--on-primary);overflow:hidden}
.wp-sto .ph{position:absolute;inset:0;border-radius:0;height:100%;transition:transform .6s}.wp-sto a:hover .ph{transform:scale(1.04)}
.wp-sto a::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,color-mix(in srgb,var(--c-primary) 85%,transparent),transparent 55%)}
.wp-sto div{position:absolute;left:24px;bottom:22px;z-index:2}.wp-sto h3{font:400 30px var(--f-head);letter-spacing:.06em;color:var(--on-primary)}.wp-sto small{letter-spacing:.3em;text-transform:uppercase;font-size:11px}
.wp-pk{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:1px solid var(--c-border)}
.wp-pk>div{padding:36px 28px;border-right:1px solid var(--c-border);text-align:center}.wp-pk>div:last-child{border:0}
.wp-pk h3{font:400 26px var(--f-head);letter-spacing:.08em;text-transform:uppercase}.wp-pk .am{font:400 40px var(--f-head);color:var(--c-accent);margin:10px 0}
.wp-pk ul{list-style:none;padding:0;margin:0 0 22px;font:300 16px/2 var(--f-body)}
.wp-foot{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:800px){.wp-head ul{display:none}.wp-pk,.wp-sto{grid-template-columns:1fr}.wp-pk>div{border-right:0;border-bottom:1px solid var(--c-border)}.wp-logo{font-size:24px}}
@media(prefers-reduced-motion:reduce){.wp-sto .ph{transition:none}}
html,body{overflow-x:clip}img,svg{max-width:100%}.wp-head .more{position:relative}.wp-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:0;}.wp-head .more:hover .dd,.wp-head .more:focus-within .dd{display:grid}.wp-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.wp-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.wp-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-text)}.wp-hero h1,.wp-sto h3{color:var(--on-primary)}</style><header class="wp-head"><a class="wp-logo" href="index.php">Frame &amp; Vow<small>Wedding Photography</small></a><ul><li><a href="stories.php">Stories</a></li><li><a href="packages.php">Packages</a></li><li><a href="about.php">About</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd" style="color:var(--c-text)"><div><h4>Studio</h4><a href="index.php">Home</a><a href="stories.php">Love stories</a><a href="story.php">A love story</a><a href="packages.php">Packages</a><a href="about.php">About us</a></div><div><h4>Enquire</h4><a href="enquire.php">Check your date</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a href="enquire.php">Enquire</a></li></ul></header>
<main>
