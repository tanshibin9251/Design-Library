# Estate Prime

Exported from Design Library · 24 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single service, Fees, Contact, Properties, Single Property, Cart, Checkout, Testimonials, Team, Sold, Single Sold property, Gallery, Blog, Single post, FAQ, Book a viewing, Valuation, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
