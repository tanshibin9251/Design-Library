<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Estate Prime';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Estate Prime</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.ep-nav{display:flex;list-style:none;align-items:center;gap:4px}
.ep-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.ep-nav .more{position:relative}
.ep-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.ep-nav .more:hover .dd,.ep-nav .more:focus-within .dd{display:grid}
.ep-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.ep-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.ep-m{display:none;position:relative;margin-left:auto}
.ep-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.ep-m summary::-webkit-details-marker{display:none}
.ep-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.ep-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.ep-nav{display:none}.ep-m{display:block}}
.ep-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.ep-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ep-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.ep-foot ul{list-style:none}.ep-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.ep-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.ep-foot .top{grid-template-columns:1fr}.ep-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Prime Estates v2 — listings-first agency with a live mortgage panel, tokens only */
.ep-head{display:flex;align-items:center;gap:18px;padding:0 clamp(14px,4vw,56px);min-height:76px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:1px solid var(--c-border)}
.ep-logo{font:700 24px var(--f-head);color:var(--c-primary);text-decoration:none;display:flex;align-items:center;gap:10px}
.ep-logo i{width:26px;height:26px;background:var(--c-accent);clip-path:polygon(50% 0,100% 45%,100% 100%,0 100%,0 45%);display:inline-block}
.ep-nav{margin-left:auto}.ep-nav a{padding:0 14px;font:600 15px var(--f-body);color:var(--c-text)}.ep-nav a:hover{color:var(--c-accent)}
.ep-cta{background:var(--c-primary);color:var(--on-primary)!important;margin-left:8px;padding:0 20px!important;border-radius:6px}
.ep-sec{padding:clamp(30px,4vw,64px) clamp(14px,4vw,56px)}
.ep-top{background:linear-gradient(180deg,color-mix(in srgb,var(--c-secondary) 28%,var(--c-surface)),var(--c-surface));padding:clamp(28px,4vw,56px) clamp(14px,4vw,56px) 18px}
.ep-top h1{font:700 clamp(32px,4.6vw,var(--h1))/1.1 var(--f-head);color:var(--c-primary);max-width:20ch}
.ep-sr{margin-top:20px;background:var(--c-surface);border:2px solid var(--c-primary);border-radius:14px;padding:12px;display:grid;grid-template-columns:auto 1.4fr 1fr 1fr auto;gap:10px;align-items:end;box-shadow:0 20px 40px -26px rgba(0,0,0,.4)}
@media(max-width:900px){.ep-sr{grid-template-columns:1fr 1fr}}@media(max-width:520px){.ep-sr{grid-template-columns:1fr}}
.ep-tab{display:flex;border:2px solid var(--c-primary);border-radius:10px;overflow:hidden}.ep-tab button{min-height:50px;padding:0 18px;border:0;background:transparent;font:700 15px var(--f-body);cursor:pointer;color:var(--c-primary)}
.ep-tab button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.ep-sr label{display:grid;gap:4px;font:700 11px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary)}
.ep-sr select,.ep-sr input{min-height:50px;border:1px solid var(--c-border);border-radius:10px;padding:0 12px;font:600 16px var(--f-body);background:var(--c-surface);color:var(--c-text);width:100%}
.ep-go{min-height:50px;padding:0 24px;border:0;border-radius:10px;background:var(--c-accent);color:var(--on-accent);font:700 16px var(--f-body);cursor:pointer}
.ep-grid{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(280px,1fr);gap:clamp(20px,3vw,44px);align-items:start}
@media(max-width:960px){.ep-grid{grid-template-columns:1fr}}
.ep-count{font:700 15px var(--f-body);color:var(--c-secondary);margin-bottom:14px}
.ep-l{display:grid;grid-template-columns:200px 1fr;gap:18px;border:1px solid var(--c-border);border-radius:14px;overflow:hidden;background:color-mix(in srgb,var(--c-surface) 40%,#fff);margin-bottom:14px;text-decoration:none;color:var(--c-text);transition:box-shadow .2s}
.ep-l:hover{box-shadow:0 18px 34px -24px rgba(0,0,0,.5)}
.ep-l.hide{display:none}
.ep-l .im{background:linear-gradient(160deg,var(--a),var(--b));min-height:170px;position:relative}.ep-l .im::after{content:"缺图";position:absolute;left:8px;bottom:8px;font:700 10px var(--f-body);letter-spacing:.12em;background:var(--c-surface);padding:2px 8px;border-radius:99px}
.ep-l .b{padding:16px 18px 16px 0;display:grid;gap:4px;align-content:center}
.ep-l .p{font:700 24px var(--f-head);color:var(--c-primary)}.ep-l .a{font:600 15px var(--f-body)}
.ep-l .sp{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px}.ep-l .sp span{font:700 12px var(--f-body);padding:3px 10px;border-radius:99px;background:color-mix(in srgb,var(--c-secondary) 28%,var(--c-surface))}
@media(max-width:560px){.ep-l{grid-template-columns:1fr}.ep-l .b{padding:0 16px 16px}.ep-l .im{min-height:140px}}
.ep-mc{background:var(--c-primary);color:var(--on-primary);border-radius:16px;padding:clamp(18px,2.4vw,28px);position:sticky;top:96px;display:grid;gap:14px}
.ep-mc h2{font:700 24px var(--f-head);color:var(--on-primary)}
.ep-mc label{display:grid;gap:4px;font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase}
.ep-mc label span{font:700 18px var(--f-head);text-transform:none;letter-spacing:0;color:var(--c-accent)}
.ep-mc input[type=range]{accent-color:var(--c-accent);padding:0;border:0;background:none;min-height:44px;width:100%}
.ep-mo{background:var(--c-surface);color:var(--c-text);border-radius:12px;padding:16px;text-align:center}.ep-mo b{display:block;font:700 34px var(--f-head);color:var(--c-primary)}.ep-mo small{font:600 13px var(--f-body);color:var(--c-secondary)}
@media(max-width:960px){.ep-mc{position:static}}
.ep-ag{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.ep-ag>div{border:1px solid var(--c-border);border-radius:14px;padding:20px;display:grid;gap:4px}
.ep-ag b{font:700 20px var(--f-head);color:var(--c-primary)}.ep-ag span{font:500 15px var(--f-body)}@media(max-width:800px){.ep-ag{grid-template-columns:1fr}}
.ep-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.ep-foot .big{font:700 30px var(--f-head)}
.ep .pagehead{background:color-mix(in srgb,var(--c-secondary) 14%,var(--c-surface));border-left:10px solid var(--c-accent)}.ep .pagehead .wrap{padding-left:clamp(20px,3vw,40px)}.ep .card,.ep .scard,.ep .qcard,.ep .pcard,.ep .person{background:#fff;background:color-mix(in srgb,var(--c-surface) 30%,#fff);border:0;box-shadow:0 14px 34px -20px color-mix(in srgb,var(--c-primary) 55%,transparent)}.ep .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.ep .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.ep .svc{display:block;border:2px solid var(--c-primary)}
.ep .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr) 150px 110px;gap:0;align-items:stretch;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:0}
.ep .scard:nth-child(even){background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}
.ep .scard .ph{display:none}.ep .scard .b{display:contents}
.ep .scard h3{padding:18px;font-size:19px;border-right:1px solid var(--c-border)}
.ep .scard p{padding:18px;margin:0;border-right:1px solid var(--c-border);opacity:.85;font-size:15px}
.ep .scard .m{display:contents}.ep .scard .m b{padding:18px;border-right:1px solid var(--c-border);font-size:15px}.ep .scard .m span{padding:18px;font-size:14px;opacity:.75}
@media(max-width:820px){.ep .scard{grid-template-columns:1fr 1fr}.ep .scard h3{grid-column:1/-1;border-right:0}.ep .scard p{grid-column:1/-1;border-right:0;padding-top:0}}

.ep .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:30px 20px}
.ep .person{text-align:center;background:none;border:0;box-shadow:none;padding:0}
.ep .person .ph{aspect-ratio:1!important;border-radius:50%!important;margin:0 auto 12px;max-width:190px}

.ep .qgrid{display:block;columns:2 300px;column-gap:20px}.ep .qgrid.mt{margin-top:20px}
.ep .qcard{break-inside:avoid;margin-bottom:20px}

.ep .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.ep .masonry .mi{margin:0}.ep .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.ep .masonry{grid-template-columns:1fr 1fr}}

.ep .articles{display:block!important}
.ep .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.ep .art .ph{display:none}.ep .art .meta{grid-row:1/span 2;align-self:start}.ep .art h3{margin:0}
.ep .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}

.ep .faq{display:grid;gap:10px}
.ep .faq details{border:1px solid var(--c-primary);padding:6px 18px;background:var(--c-surface)}.ep .faq details[open]{background:color-mix(in srgb,var(--c-accent) 10%,var(--c-surface))}

.ep .pricing{display:grid;grid-template-columns:1fr;max-width:760px;gap:14px}
.ep .pricing .card{transform:none!important}
.ep .split{display:flex;flex-direction:column-reverse;gap:30px}.ep .cinfo{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}@media(max-width:800px){.ep .cinfo{grid-template-columns:1fr 1fr}}
.ep .sec.dark{background:var(--c-accent);color:var(--on-accent)}.ep .sec.dark h2,.ep .sec.dark p{color:var(--on-accent)}.ep .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.ep .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.ep .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.ep .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.ep .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.ep .tl>div:last-child{border-right:0}
.ep .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.ep .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.ep .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.ep .vals .card:last-child{border-right:0}
@media(max-width:700px){.ep .vals{grid-template-columns:1fr}.ep .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><header class="ep-head"><a class="ep-logo" href="index.php"><i></i>Prime Estates</a><ul class="ep-nav"><li><a href="shop.php">Buy</a></li><li><a href="shop.php">Rent</a></li><li><a href="valuation.php">Valuation</a></li><li><a href="team.php">Agents</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Properties</a><a href="product.php">Single Property</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Sold</a><a href="project.php">Single Sold property</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Blog</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Book a viewing</a><a href="valuation.php">Valuation</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="ep-cta" href="booking.php">Book a viewing</a></li></ul><details class="ep-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a><a href="shop.php">Properties</a><a href="product.php">Single Property</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Sold</a><a href="project.php">Single Sold property</a><a href="gallery.php">Gallery</a><a href="blog.php">Blog</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Book a viewing</a><a href="valuation.php">Valuation</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="ep">
<main>
