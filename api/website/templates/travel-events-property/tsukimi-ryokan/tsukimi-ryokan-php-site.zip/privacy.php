<?php $title = 'Privacy policy'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Privacy policy</b></div><h1 style="letter-spacing:.14em;font-weight:400">Privacy policy</h1></div></section><section class="ts-sec" style="padding-top:20px"><div class="prose"><p>Replace with your privacy policy: what you collect, why, how long you keep it and how guests can ask for deletion.</p></div></section></div>
<?php include 'includes/footer.php'; ?>
