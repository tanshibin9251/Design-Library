<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Tsukimi Ryokan';
$dark = true;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Tsukimi Ryokan</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="tsukimi-ryokan" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Tsukimi Ryokan — japanese night inn, tokens only */
.ts-head{position:sticky;top:0;z-index:50;display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:24px;padding:0 clamp(18px,4vw,56px);min-height:76px;background:color-mix(in srgb,var(--c-surface) 90%,transparent);backdrop-filter:blur(10px);border-bottom:1px solid var(--c-border)}
.ts-logo{display:flex;align-items:center;gap:14px;text-decoration:none;color:var(--c-primary);font:400 20px var(--f-head);letter-spacing:.3em}
.ts-logo i{width:18px;height:18px;border-radius:50%;background:var(--c-primary);box-shadow:inset -6px -2px 0 var(--c-surface)}
.ts-logo small{display:block;font:300 10px var(--f-body);letter-spacing:.34em;color:var(--c-secondary);margin-top:5px}
.ts-nav{display:flex;justify-content:center;gap:clamp(14px,2.4vw,40px);list-style:none}
.ts-nav a{display:flex;align-items:baseline;gap:8px;text-decoration:none;font:300 13px var(--f-body);letter-spacing:.22em;text-transform:uppercase;padding:14px 4px;min-height:44px;color:var(--c-text)}
.ts-nav a b{font:400 14px var(--f-head);color:var(--c-accent);letter-spacing:0}
.ts-nav a:hover{color:var(--c-primary)}
.ts-nav .more{position:relative}
.ts-nav .dd{position:absolute;right:-60px;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:20px 30px;padding:24px 28px;background:var(--c-surface);border:1px solid var(--c-border);min-width:640px;z-index:60}
.ts-nav .more:hover .dd,.ts-nav .more:focus-within .dd{display:grid}
.ts-nav .dd h4{font:600 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:8px}
.ts-nav .dd a{padding:5px 0;min-height:0;font-size:14px;letter-spacing:.04em;text-transform:none;display:block}
.ts-key{display:grid;place-items:center;min-height:44px;padding:0 24px;background:var(--c-accent);color:var(--on-accent);text-decoration:none;font:400 14px var(--f-head);letter-spacing:.3em}
.ts-key:hover{filter:brightness(1.12)}
.ts-m{display:none}
.ts-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:300 12px var(--f-body);letter-spacing:.22em}
.ts-m summary::-webkit-details-marker{display:none}
.ts-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:1px solid var(--c-border);padding:12px 20px 22px;display:grid}
.ts-m nav a{padding:12px 4px;border-bottom:1px solid var(--c-border);text-decoration:none;font:300 15px var(--f-body);letter-spacing:.1em;min-height:44px}
@media(max-width:960px){.ts-head{grid-template-columns:auto 1fr auto auto}.ts-nav{display:none}.ts-m{display:block;justify-self:end}}

.ts-sec{padding:var(--pad) clamp(20px,6vw,100px)}
.ts-k{display:flex;align-items:center;gap:16px;margin-bottom:34px;font:300 12px var(--f-body);letter-spacing:.34em;text-transform:uppercase;color:var(--c-secondary)}
.ts-k b{font:400 20px var(--f-head);color:var(--c-accent);letter-spacing:0}
.ts-k::after{content:"";flex:1;height:1px;background:var(--c-border)}
.ts-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:.9em 2.4em;border:1px solid var(--c-primary);color:var(--c-primary);text-decoration:none;font:300 13px var(--f-body);letter-spacing:.32em;text-transform:uppercase;background:none;cursor:pointer;transition:background .3s,color .3s}
.ts-btn:hover{background:var(--c-primary);color:var(--c-surface)}
.ts-btn.f{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}.ts-btn.f:hover{filter:brightness(1.12);background:var(--c-accent);color:var(--on-accent)}
.ts-ph{position:relative;min-height:220px;background:
 repeating-linear-gradient(90deg,transparent 0 59px,color-mix(in srgb,var(--c-primary) 10%,transparent) 59px 60px),
 repeating-linear-gradient(0deg,transparent 0 59px,color-mix(in srgb,var(--c-primary) 10%,transparent) 59px 60px),
 linear-gradient(160deg,color-mix(in srgb,var(--c-primary) 12%,var(--c-surface)),color-mix(in srgb,var(--c-accent) 14%,var(--c-surface)))}
.ts-ph::after{content:attr(data-l);position:absolute;left:14px;bottom:12px;font:400 10px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}

/* hero: moon behind shoji lattice */
.ts-hero{position:relative;min-height:min(100vh,880px);display:grid;align-items:end;overflow:hidden;padding:clamp(80px,12vw,160px) clamp(20px,6vw,100px) clamp(36px,5vw,70px)}
.ts-lattice{position:absolute;inset:0;pointer-events:none;background:
 repeating-linear-gradient(90deg,transparent 0 calc(12.5% - 1px),color-mix(in srgb,var(--c-primary) 20%,transparent) calc(12.5% - 1px) 12.5%),
 repeating-linear-gradient(0deg,transparent 0 calc(16.666% - 1px),color-mix(in srgb,var(--c-primary) 20%,transparent) calc(16.666% - 1px) 16.666%);
 -webkit-mask-image:linear-gradient(180deg,#000 0,#000 55%,transparent 100%);mask-image:linear-gradient(180deg,#000 0,#000 55%,transparent 100%)}
.ts-moon{position:absolute;right:clamp(20px,9vw,150px);top:clamp(90px,12vw,150px);width:clamp(170px,26vw,380px);aspect-ratio:1;filter:drop-shadow(0 0 40px color-mix(in srgb,var(--c-primary) 35%,transparent))}
.ts-moon svg{width:100%;height:100%;display:block}
.ts-hero-in{position:relative;max-width:760px}
.ts-hero h1{font-size:clamp(46px,8vw,var(--h1));letter-spacing:.16em;color:var(--c-primary);font-weight:400;margin:14px 0 22px;line-height:1.25}
.ts-hero .en{font:300 12px var(--f-body);letter-spacing:.38em;text-transform:uppercase;color:var(--c-secondary)}
.ts-hero p.lead{font:300 17px/2 var(--f-body);max-width:46ch}
.ts-tonight{position:absolute;right:clamp(20px,6vw,100px);bottom:clamp(36px,5vw,70px);text-align:right;font:300 12px var(--f-body);letter-spacing:.3em;text-transform:uppercase;color:var(--c-secondary)}
.ts-tonight b{display:block;font:400 clamp(24px,3vw,36px) var(--f-head);letter-spacing:.2em;color:var(--c-primary);text-transform:none;margin-top:8px}
@media(max-width:800px){.ts-tonight{position:static;text-align:left;margin-top:36px}.ts-moon{opacity:.55}}

/* rooms: fusuma accordion */
.ts-rooms{display:flex;gap:0;height:min(70vh,560px);min-height:420px;border:1px solid var(--c-border)}
.ts-room{position:relative;flex:1;overflow:hidden;text-decoration:none;border-right:1px solid var(--c-border);transition:flex .7s cubic-bezier(.2,.8,.2,1);display:flex;flex-direction:column;justify-content:space-between;padding:26px 24px;min-width:0;background:var(--c-surface)}
.ts-room:last-child{border-right:0}
.ts-room.on{flex:3.4;background:color-mix(in srgb,var(--c-primary) 6%,var(--c-surface))}
.ts-room .n{font:400 clamp(30px,3vw,44px) var(--f-head);color:var(--c-accent)}
.ts-room h3{font:400 22px var(--f-head);letter-spacing:.2em;color:var(--c-primary);white-space:nowrap}
.ts-room .d{font:300 15px/1.9 var(--f-body);max-width:34ch;opacity:0;transform:translateY(10px);transition:opacity .5s .15s,transform .5s .15s;margin-top:10px}
.ts-room.on .d{opacity:1;transform:none}
.ts-room .pr{font:300 12px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-secondary);margin-top:12px;opacity:0;transition:opacity .5s .2s}
.ts-room.on .pr{opacity:1}
@media(max-width:800px){.ts-rooms{flex-direction:column;height:auto}.ts-room,.ts-room.on{flex:none;border-right:0;border-bottom:1px solid var(--c-border);min-height:150px}.ts-room .d,.ts-room .pr{opacity:1;transform:none}}

/* seasons */
.ts-seasons{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid var(--c-border);border-bottom:1px solid var(--c-border)}
.ts-seasons>div{padding:34px 24px 38px;border-right:1px solid var(--c-border);display:grid;gap:10px;align-content:start}
.ts-seasons>div:last-child{border-right:0}
.ts-seasons .k{font:400 clamp(70px,9vw,130px)/1 var(--f-head);color:transparent;-webkit-text-stroke:1px var(--c-primary);transition:color .5s}
.ts-seasons>div:hover .k{color:color-mix(in srgb,var(--c-primary) 22%,transparent)}
.ts-seasons h3{font:400 17px var(--f-head);letter-spacing:.24em}
.ts-seasons p{font:300 14px/1.9 var(--f-body);opacity:.85}
@media(max-width:800px){.ts-seasons{grid-template-columns:1fr 1fr}.ts-seasons>div:nth-child(2n){border-right:0}.ts-seasons>div{border-bottom:1px solid var(--c-border)}}

/* kaiseki timeline */
.ts-course{position:relative;margin-left:8px}
.ts-course::before{content:"";position:absolute;left:78px;top:6px;bottom:6px;width:1px;background:var(--c-border)}
.ts-course li{list-style:none;display:grid;grid-template-columns:70px 1fr;gap:0 52px;padding:22px 0;position:relative}
.ts-course li::before{content:"";position:absolute;left:73px;top:34px;width:11px;height:11px;border-radius:50%;background:var(--c-surface);border:1px solid var(--c-primary)}
.ts-course .jp{font:400 28px var(--f-head);color:var(--c-primary);letter-spacing:.1em;text-align:right}
.ts-course h3{font:400 19px var(--f-head);letter-spacing:.14em;margin-bottom:4px;padding-left:40px}
.ts-course p{font:300 15px/1.9 var(--f-body);padding-left:40px;opacity:.85;max-width:52ch}
@media(max-width:600px){.ts-course::before{left:46px}.ts-course li{grid-template-columns:40px 1fr;gap:0 26px}.ts-course li::before{left:41px}.ts-course h3,.ts-course p{padding-left:14px}.ts-course .jp{font-size:20px}}

/* tables & cards */
.ts-tbl{width:100%;border-collapse:collapse;font:300 15px var(--f-body)}
.ts-tbl th,.ts-tbl td{padding:18px 12px;border-top:1px solid var(--c-border);text-align:left}
.ts-tbl th{font:400 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-secondary)}
.ts-tbl tr:last-child td{border-bottom:1px solid var(--c-border)}
.ts-plans{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:1px solid var(--c-border)}
.ts-plans>div{padding:40px 30px;border-right:1px solid var(--c-border);display:grid;gap:12px;align-content:start}
.ts-plans>div:last-child{border-right:0}
.ts-plans .jp{font:400 38px var(--f-head);color:var(--c-accent)}
.ts-plans h3{font:400 20px var(--f-head);letter-spacing:.18em}
.ts-plans .pr{font:400 28px var(--f-head);letter-spacing:.06em;margin-top:6px}
.ts-plans li{list-style:none;font:300 14px/1.8 var(--f-body);padding:8px 0;border-top:1px solid var(--c-border)}
@media(max-width:800px){.ts-plans{grid-template-columns:1fr}.ts-plans>div{border-right:0;border-bottom:1px solid var(--c-border)}}
.ts-two{display:grid;grid-template-columns:1fr 1fr;gap:clamp(30px,6vw,100px);align-items:center}
.ts-two h2{font-weight:400;letter-spacing:.14em;margin-bottom:18px}
.ts-two p{font:300 16px/2 var(--f-body);max-width:46ch}
@media(max-width:800px){.ts-two{grid-template-columns:1fr}}
.ts-gal{display:grid;grid-template-columns:repeat(6,1fr);grid-auto-rows:150px;gap:10px}
.ts-gal .a{grid-column:span 3;grid-row:span 2}.ts-gal .b{grid-column:span 2;grid-row:span 1}.ts-gal .c{grid-column:span 1;grid-row:span 2}.ts-gal .d{grid-column:span 2;grid-row:span 2}
.ts-gal .ts-ph{min-height:0;height:100%}
@media(max-width:700px){.ts-gal{grid-template-columns:1fr 1fr;grid-auto-rows:130px}.ts-gal .a,.ts-gal .b,.ts-gal .c,.ts-gal .d{grid-column:span 1;grid-row:span 1}.ts-gal .a{grid-column:span 2}}
.ts-est{border:1px solid var(--c-border);padding:30px;display:grid;gap:12px}
.ts-est div{display:flex;justify-content:space-between;font:300 15px var(--f-body)}
.ts-est .t{border-top:1px solid var(--c-border);padding-top:16px;font:400 24px var(--f-head);letter-spacing:.06em;color:var(--c-primary)}
.ts-kv{display:grid;grid-template-columns:150px 1fr;gap:0}
.ts-kv dt,.ts-kv dd{padding:18px 0;border-top:1px solid var(--c-border)}
.ts-kv dt{font:400 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-secondary);padding-top:22px}
.ts-kv dd{font:300 16px/1.8 var(--f-body)}
@media(max-width:600px){.ts-kv{grid-template-columns:1fr}.ts-kv dt{border-top:1px solid var(--c-border);padding-bottom:0}.ts-kv dd{border-top:0;padding-top:4px}}

/* footer */
.ts-foot{border-top:1px solid var(--c-border);padding:clamp(48px,6vw,90px) clamp(20px,6vw,100px) 30px}
.ts-foot-top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(30px,6vw,100px)}
.ts-foot .big{font:400 30px var(--f-head);letter-spacing:.34em;color:var(--c-primary)}
.ts-foot h4{font:400 11px var(--f-body);letter-spacing:.26em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:12px}
.ts-foot ul{list-style:none}.ts-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:300 14px var(--f-body);min-height:32px}.ts-foot li a:hover{color:var(--c-primary)}
.ts-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:24px}
.ts-foot .copy{margin-top:46px;padding-top:18px;border-top:1px solid var(--c-border);font:300 12px var(--f-body);letter-spacing:.2em;color:var(--c-secondary);display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap}
@media(max-width:800px){.ts-foot-top{grid-template-columns:1fr}.ts-foot .cols{grid-template-columns:1fr 1fr}}
.faq summary{letter-spacing:.1em}
html,body{overflow-x:clip}img,video,svg{max-width:100%}
@media(max-width:700px){.ts-sec{padding-left:18px;padding-right:18px}.ts-hero{padding-left:18px;padding-right:18px}}
@media(prefers-reduced-motion:reduce){.ts-room,.ts-room .d,.ts-room .pr{transition:none}}
</style>
<header class="ts-head">
<a class="ts-logo" href="index.php"><i></i><span>月見荘<small>TSUKIMI INN</small></span></a>
<ul class="ts-nav"><li><a href="rooms.php"><b>一</b>Rooms</a></li><li><a href="kaiseki.php"><b>二</b>Dinner</a></li><li><a href="onsen.php"><b>三</b>Onsen</a></li><li><a href="seasons.php"><b>四</b>Seasons</a></li><li class="more"><a href="#" tabindex="0"><b>他</b>More</a><div class="dd"><div><h4>Stay</h4><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="room.php">Room: Tsuki</a><a href="plans.php">Plans & rates</a><a href="reserve.php">Reserve</a></div><div><h4>Experience</h4><a href="kaiseki.php">Kaiseki dinner</a><a href="onsen.php">Onsen</a><a href="seasons.php">Four seasons</a><a href="gallery.php">Gallery</a></div><div><h4>Visit</h4><a href="access.php">Access</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul>
<details class="ts-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="room.php">Room: Tsuki</a><a href="plans.php">Plans & rates</a><a href="reserve.php">Reserve</a><a href="kaiseki.php">Kaiseki dinner</a><a href="onsen.php">Onsen</a><a href="seasons.php">Four seasons</a><a href="gallery.php">Gallery</a><a href="access.php">Access</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details>
<a class="ts-key" href="reserve.php">予約</a>
</header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
