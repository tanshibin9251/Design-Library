# Build "Tsukimi Ryokan" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #efe6d0 · Secondary #a79d88 · Text #e2dac8 · Accent #c8442f · Surface #14120f · Border #322e27

## 2. Global Fonts
Headings: Yuji Syuku · Body: Noto Sans JP
H1 84px / H2 42px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 120px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Rooms (rooms) — html/rooms.html
- Room: Tsuki (room) — html/room.html
- Plans & rates (plans) — html/plans.html
- Reserve (reserve) — html/reserve.html
- Kaiseki dinner (kaiseki) — html/kaiseki.html
- Onsen (onsen) — html/onsen.html
- Four seasons (seasons) — html/seasons.html
- Gallery (gallery) — html/gallery.html
- Access (access) — html/access.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
