# Tsukimi Ryokan

Exported from Design Library · 13 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, Rooms, Room: Tsuki, Plans & rates, Reserve, Kaiseki dinner, Onsen, Four seasons, Gallery, Access, FAQ, Privacy policy, 404 error.

All text and images are placeholders — replace them with your own.
