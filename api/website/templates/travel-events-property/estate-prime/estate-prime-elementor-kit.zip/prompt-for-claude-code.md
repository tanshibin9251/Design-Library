# Build "Estate Prime" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #243b53 · Secondary #81b29a · Text #243b53 · Accent #e07a5f · Surface #f4f1de · Border #dcd6bd

## 2. Global Fonts
Headings: Libre Caslon Text · Body: Mulish
H1 68px / H2 40px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 12px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single service (service) — html/service.html
- Fees (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Properties (shop) — html/shop.html
- Single Property (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Sold (projects) — html/projects.html
- Single Sold property (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Blog (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book a viewing (booking) — html/booking.html
- Valuation (valuation) — html/valuation.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
