# Build "Wanderlust" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #b5502d · Secondary #2a6f8f · Text #2b2118 · Accent #f2b134 · Surface #fbf3e4 · Border #e8d9bd

## 2. Global Fonts
Headings: Abril Fatface · Body: DM Sans
H1 92px / H2 48px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 80px vertical · Border radius 18px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Destinations (services) — html/services.html
- Single Destination (service) — html/service.html
- Trip Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Trips (shop) — html/shop.html
- Single Trip (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Traveller Stories (projects) — html/projects.html
- Single Story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Plan a trip (booking) — html/booking.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
