# Build "Rumah Singgah" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #4d7c0f · Secondary #8a6d3b · Text #24231b · Accent #f59e0b · Surface #faf6ea · Border #e6dec7

## 2. Global Fonts
Headings: Spectral · Body: Be Vietnam Pro
H1 76px / H2 40px / H3 20px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 14px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- All stays (stays) — html/stays.html
- Stay detail (stay) — html/stay.html
- Availability (availability) — html/availability.html
- Experiences (experiences) — html/experiences.html
- Local guide (guide) — html/guide.html
- Contact host (contact) — html/contact.html
- Booking FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
