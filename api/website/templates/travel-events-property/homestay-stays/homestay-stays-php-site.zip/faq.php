<?php $title = 'Booking FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Booking FAQ</b></div><h1>Booking FAQ</h1></div></section><section class="hs-sec"><div class="in"><div class="faq"><details open><summary>What time is check-in?</summary><p>From 3pm; earlier if the house is ready.</p></details><details><summary>Do you accept pets?</summary><p>At selected stays, RM 50 per stay.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
