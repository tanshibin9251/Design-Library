# Build "Blue Hour" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #f3ecdf · Secondary #9a93d0 · Text #e9e6f3 · Accent #f2b84b · Surface #0e0c22 · Border #2a2650

## 2. Global Fonts
Headings: Josefin Sans · Body: Source Serif 4
H1 104px / H2 58px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 112px vertical · Border radius 14px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home: the blue hour (home) — html/home.html
- Departures (list + filter) (expeditions) — html/expeditions.html
- Expedition: Lofoten in winter (expedition) — html/expedition.html
- Field journal (journal) — html/journal.html
- Story: Eleven minutes of blue (story) — html/story.html
- Prints (liquid distort) (prints) — html/prints.html
- The studio (about) — html/about.html
- Enquire (contact) — html/contact.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
