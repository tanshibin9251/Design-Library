<?php $title = '404 error'; include 'includes/header.php'; ?>
<section data-nav="" class="bh-nf"><div class="bh-in"><p class="big">404</p><h1 data-sc>Lost in the blue hour</h1><p class="bh-lead" style="margin:16px auto 28px">This page is somewhere between day and night. Head back and we will find you a better view.</p><div class="bh-actions" style="justify-content:center"><a class="pf pf-solid" href="index.php">Back to the start</a><a class="pf" href="expeditions.php">See departures</a></div></div></section>
<?php include 'includes/footer.php'; ?>
