<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="mt-sec" style="text-align:center;padding-top:clamp(60px,10vw,140px)"><span class="mt-k">Error 404</span><h1 style="font:400 clamp(90px,18vw,240px)/1 var(--f-head);color:var(--c-accent);-webkit-text-stroke:3px var(--c-primary);paint-order:stroke fill">404</h1><h2 style="margin:10px 0 28px;font:400 28px var(--f-head);letter-spacing:.1em">花火は、もう終わりました。</h2><a class="mt-btn" href="index.php">TOPへ戻る</a></section>
<?php include 'includes/footer.php'; ?>
