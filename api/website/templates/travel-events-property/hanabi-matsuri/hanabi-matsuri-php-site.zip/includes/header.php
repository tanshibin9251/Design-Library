<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Hanabi Matsuri';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Hanabi Matsuri</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="hanabi-matsuri" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Hanabi Matsuri — night festival, lantern nav, tokens only */
.mt-top{background:var(--c-primary);color:var(--on-primary);text-align:center;font:500 12px var(--f-body);letter-spacing:.24em;padding:9px 12px}
.mt-head{position:relative;padding:0 clamp(16px,4vw,60px);background:linear-gradient(180deg,var(--c-primary) 0 54%,var(--c-surface) 54%)}
.mt-rope{height:3px;background:repeating-linear-gradient(90deg,var(--c-secondary) 0 10px,var(--c-primary) 10px 14px);position:absolute;left:0;right:0;top:30px}
.mt-row{position:relative;display:flex;justify-content:center;align-items:flex-start;gap:clamp(8px,2.4vw,34px);padding-top:30px;list-style:none;flex-wrap:wrap}
.mt-lan{display:flex;flex-direction:column;align-items:center;text-decoration:none;color:var(--c-text);transform-origin:50% 0;animation:mtsway 5s ease-in-out infinite;animation-delay:var(--d,0s)}
.mt-lan::before{content:"";width:2px;height:22px;background:var(--c-primary)}
.mt-lan .cap{width:46px;height:9px;background:var(--c-primary);border-radius:2px}
.mt-lan .body{width:84px;height:112px;border-radius:50%/42%;background:radial-gradient(ellipse at 50% 35%,color-mix(in srgb,var(--c-accent) 70%,#fff) 0,var(--c-accent) 55%,color-mix(in srgb,var(--c-accent) 70%,#000) 100%);display:grid;place-items:center;position:relative;box-shadow:0 6px 18px color-mix(in srgb,var(--c-accent) 45%,transparent);transition:transform .25s}
.mt-lan .body::before,.mt-lan .body::after{content:"";position:absolute;left:6%;right:6%;height:2px;background:color-mix(in srgb,var(--c-primary) 45%,transparent);border-radius:50%}
.mt-lan .body::before{top:12%}.mt-lan .body::after{bottom:12%}
.mt-lan .jp{writing-mode:vertical-rl;font:400 27px var(--f-head);color:var(--on-accent);letter-spacing:.08em;line-height:1.05}
.mt-lan .en{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;margin-top:8px;color:var(--c-primary)}
.mt-lan:hover .body,.mt-lan:focus-visible .body{transform:scale(1.08)}
.mt-lan.k .body{background:radial-gradient(ellipse at 50% 35%,color-mix(in srgb,var(--c-secondary) 70%,#fff) 0,var(--c-secondary) 60%,color-mix(in srgb,var(--c-secondary) 70%,#000) 100%);box-shadow:0 6px 18px color-mix(in srgb,var(--c-secondary) 45%,transparent)}
.mt-lan.k .jp{color:var(--c-primary)}
@keyframes mtsway{0%,100%{transform:rotate(-2deg)}50%{transform:rotate(2deg)}}
.mt-logo{position:absolute;left:clamp(16px,4vw,60px);top:44px;font:400 22px var(--f-head);letter-spacing:.1em;color:var(--on-primary);text-decoration:none;z-index:2}
.mt-more{position:relative}
.mt-more .dd{position:absolute;right:-30px;top:100%;display:none;grid-template-columns:repeat(4,minmax(120px,1fr));gap:16px 26px;padding:20px 24px;background:var(--c-surface);border:3px solid var(--c-primary);min-width:600px;z-index:60;text-align:left}
.mt-more:hover .dd,.mt-more:focus-within .dd{display:grid}
.mt-more .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.mt-more .dd a{display:block;padding:5px 0;text-decoration:none;font:500 14px var(--f-body)}
.mt-more .dd a:hover{color:var(--c-accent)}
.mt-m{display:none}
.mt-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:700 12px var(--f-body);letter-spacing:.18em;color:var(--on-primary);border:2px solid var(--on-primary);padding:0 14px}
.mt-m summary::-webkit-details-marker{display:none}
.mt-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:3px solid var(--c-primary);padding:8px 20px 20px;display:grid;z-index:60}
.mt-m nav a{padding:12px 4px;border-bottom:2px dotted var(--c-border);text-decoration:none;font:700 14px var(--f-body);min-height:44px}
@media(max-width:820px){.mt-head{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--c-primary);position:relative}.mt-rope,.mt-row{display:none}.mt-logo{position:static;font-size:20px}.mt-m{display:block}}
@media(prefers-reduced-motion:reduce){.mt-lan{animation:none}}

.mt-sec{padding:var(--pad) clamp(20px,5vw,80px)}
.mt-k{display:inline-block;font:700 12px var(--f-body);letter-spacing:.26em;text-transform:uppercase;background:var(--c-primary);color:var(--on-primary);padding:5px 14px;margin-bottom:18px;transform:rotate(-1.5deg)}
.mt-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:.8em 2em;border:3px solid var(--c-primary);background:var(--c-accent);color:var(--on-accent);font:400 18px var(--f-head);letter-spacing:.14em;text-decoration:none;cursor:pointer;border-radius:999px;box-shadow:0 5px 0 var(--c-primary);transition:transform .12s,box-shadow .12s}
.mt-btn:hover{transform:translateY(3px);box-shadow:0 2px 0 var(--c-primary)}
.mt-btn.y{background:var(--c-secondary);color:var(--c-primary)}
.mt-ph{position:relative;min-height:220px;border:3px solid var(--c-primary);background:radial-gradient(circle,var(--c-primary) 0 2px,transparent 3px) 0 0/18px 18px,color-mix(in srgb,var(--c-secondary) 25%,var(--c-surface))}
.mt-ph::after{content:attr(data-l);position:absolute;left:10px;bottom:8px;background:var(--c-surface);border:2px solid var(--c-primary);font:700 10px var(--f-body);letter-spacing:.14em;text-transform:uppercase;padding:3px 9px}

/* hero: night sky + fireworks + countdown */
.mt-hero{position:relative;background:var(--c-primary);color:var(--on-primary);overflow:hidden;padding:clamp(50px,7vw,110px) clamp(20px,5vw,80px) clamp(120px,12vw,180px);text-align:center;clip-path:polygon(0 0,100% 0,100% 100%,50% calc(100% - 40px),0 100%)}
.mt-fw{position:absolute;width:6px;height:6px;border-radius:50%;opacity:0;animation:mtburst 4.2s ease-out infinite;animation-delay:var(--d)}
@keyframes mtburst{0%{opacity:0;transform:scale(.2)}8%{opacity:1}60%{opacity:.9;transform:scale(1)}100%{opacity:0;transform:scale(1.25)}}
.mt-hero-in{position:relative;z-index:1}
.mt-hero .en{font:700 13px var(--f-body);letter-spacing:.36em;text-transform:uppercase;color:var(--c-secondary)}
.mt-hero h1{font:400 clamp(70px,16vw,230px)/1 var(--f-head);color:var(--c-secondary);margin:12px 0 10px;-webkit-text-stroke:3px var(--c-accent);paint-order:stroke fill;text-shadow:8px 8px 0 var(--c-accent);letter-spacing:.06em}
.mt-hero p.d{font:700 clamp(16px,2vw,24px) var(--f-body);letter-spacing:.14em}
.mt-cd{display:inline-grid;grid-template-columns:repeat(4,auto);gap:clamp(10px,2vw,26px);margin:30px 0 34px;padding:16px clamp(16px,3vw,36px);border:3px solid var(--c-secondary);border-radius:18px;background:color-mix(in srgb,var(--c-primary) 85%,#000)}
.mt-cd div{text-align:center}
.mt-cd b{display:block;font:400 clamp(34px,5vw,64px)/1 var(--f-head);color:var(--c-secondary)}
.mt-cd span{font:700 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;opacity:.8}
@media(prefers-reduced-motion:reduce){.mt-fw{animation:none;opacity:.7}}

/* tickets */
.mt-tks{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(18px,2.4vw,34px)}
.mt-tk{position:relative;background:var(--c-surface);border:3px solid var(--c-primary);padding:30px 26px 26px;display:grid;gap:10px;align-content:start}
.mt-tk::before,.mt-tk::after{content:"";position:absolute;top:calc(100% - 78px);width:26px;height:26px;border-radius:50%;background:var(--c-surface);border:3px solid var(--c-primary)}
.mt-tk::before{left:-15px;clip-path:inset(0 0 0 50%)}.mt-tk::after{right:-15px;clip-path:inset(0 50% 0 0)}
.mt-tk .n{font:400 64px/1 var(--f-head);color:var(--c-accent)}
.mt-tk h3{font:400 24px var(--f-head);letter-spacing:.08em}
.mt-tk .pr{font:700 26px var(--f-body)}
.mt-tk .st{border-top:3px dashed var(--c-primary);margin-top:18px;padding-top:14px;font:700 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;display:flex;justify-content:space-between}
.mt-tk.hl{background:var(--c-secondary)}
@media(max-width:900px){.mt-tks{grid-template-columns:1fr}}

/* program timeline */
.mt-prog{display:grid;gap:0;border-top:3px solid var(--c-primary)}
.mt-prog>div{display:grid;grid-template-columns:130px 40px 1fr;gap:0 18px;padding:20px 0;border-bottom:3px solid var(--c-primary);align-items:baseline}
.mt-prog time{font:400 34px/1 var(--f-head);color:var(--c-accent)}
.mt-prog i{width:18px;height:18px;border-radius:50%;background:var(--c-secondary);border:3px solid var(--c-primary);align-self:center}
.mt-prog h3{font:400 24px var(--f-head);letter-spacing:.06em}
.mt-prog p{font-size:15px;opacity:.85;margin-top:4px}
@media(max-width:600px){.mt-prog>div{grid-template-columns:90px 26px 1fr;gap:0 8px}.mt-prog time{font-size:26px}}

/* stall map */
.mt-map{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:clamp(24px,5vw,70px);align-items:start}
.mt-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:8px;padding:14px;border:3px solid var(--c-primary);background:color-mix(in srgb,var(--c-secondary) 18%,var(--c-surface))}
.mt-grid button{aspect-ratio:1;border:3px solid var(--c-primary);background:var(--c-surface);cursor:pointer;font:400 18px var(--f-head);color:var(--c-primary);min-height:44px;position:relative;transition:transform .12s}
.mt-grid button:hover{transform:translateY(-3px)}
.mt-grid button[data-k=food]{background:var(--c-accent);color:var(--on-accent)}
.mt-grid button[data-k=game]{background:var(--c-secondary)}
.mt-grid button[data-k=shop]{background:var(--c-primary);color:var(--on-primary)}
.mt-grid button[aria-pressed=true]{outline:4px solid var(--c-accent);outline-offset:2px;transform:scale(1.06)}
.mt-grid .path{grid-column:1/-1;height:34px;display:grid;place-items:center;font:700 11px var(--f-body);letter-spacing:.5em;color:var(--c-primary)}
.mt-leg{display:flex;gap:16px;flex-wrap:wrap;margin-top:14px;font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase}
.mt-leg i{display:inline-block;width:16px;height:16px;border:2px solid var(--c-primary);vertical-align:-3px;margin-right:6px}
.mt-card{border:3px solid var(--c-primary);padding:30px;background:var(--c-surface);box-shadow:8px 8px 0 var(--c-accent);position:sticky;top:24px}
.mt-card .id{font:400 70px/1 var(--f-head);color:var(--c-accent)}
.mt-card h3{font:400 26px var(--f-head);letter-spacing:.08em;margin:6px 0 10px}
@media(max-width:900px){.mt-map{grid-template-columns:1fr}.mt-card{position:static}}
.mt-two{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:center}
.mt-two h2{font:400 clamp(30px,4.4vw,var(--h2)) var(--f-head);letter-spacing:.06em;margin-bottom:14px}
.mt-two p{line-height:1.95;max-width:46ch}
@media(max-width:800px){.mt-two{grid-template-columns:1fr}}
.mt-news{display:grid;grid-template-columns:130px 1fr auto;gap:18px;padding:18px 0;border-top:3px solid var(--c-primary);text-decoration:none;align-items:baseline}
.mt-news:last-child{border-bottom:3px solid var(--c-primary)}
.mt-news time{font:700 13px var(--f-body);letter-spacing:.14em}
.mt-news h3{font:700 18px var(--f-body)}
.mt-news .t{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;background:var(--c-accent);color:var(--on-accent);padding:3px 10px}
@media(max-width:600px){.mt-news{grid-template-columns:1fr;gap:4px}}
.mt-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(44px,6vw,80px) clamp(20px,5vw,80px) 26px;margin-top:var(--pad);position:relative}
.mt-foot::before{content:"";position:absolute;left:0;right:0;top:-18px;height:18px;background:radial-gradient(circle at 18px 18px,var(--c-primary) 17px,transparent 18px) 0 0/36px 18px}
.mt-foot .top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(24px,6vw,100px)}
.mt-foot .big{font:400 44px var(--f-head);letter-spacing:.1em;color:var(--c-secondary)}
.mt-foot h4{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:10px}
.mt-foot ul{list-style:none}.mt-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font-size:14px;min-height:32px}
.mt-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.mt-foot .copy{margin-top:34px;padding-top:16px;border-top:2px dotted color-mix(in srgb,var(--on-primary) 40%,transparent);font:700 11px var(--f-body);letter-spacing:.2em;opacity:.8}
@media(max-width:800px){.mt-foot .top{grid-template-columns:1fr}.mt-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(max-width:700px){.mt-sec{padding-left:18px;padding-right:18px}}
@media(prefers-reduced-motion:reduce){.mt-btn,.mt-grid button{transition:none}}
</style><div class="mt-top">8.15 SAT · 17:00 – 21:30 · 花火 20:00 · 雨天決行 RAIN OR SHINE</div><header class="mt-head"><div class="mt-rope"></div><a class="mt-logo" href="index.php">花火祭</a><ul class="mt-row"><li><a class="mt-lan" href="program.php" style="--d:0s"><span class="cap"></span><span class="body"><span class="jp">番組</span></span><span class="en">Program</span></a></li><li><a class="mt-lan" href="stalls.php" style="--d:0.7s"><span class="cap"></span><span class="body"><span class="jp">屋台</span></span><span class="en">Stalls</span></a></li><li><a class="mt-lan" href="fireworks.php" style="--d:1.4s"><span class="cap"></span><span class="body"><span class="jp">花火</span></span><span class="en">Fireworks</span></a></li><li><a class="mt-lan" href="tickets.php" style="--d:2.1s"><span class="cap"></span><span class="body"><span class="jp">切符</span></span><span class="en">Tickets</span></a></li><li><a class="mt-lan k" href="access.php" style="--d:2.8s"><span class="cap"></span><span class="body"><span class="jp">道順</span></span><span class="en">Access</span></a></li><li class="mt-more"><a class="mt-lan k" href="#" tabindex="0" style="--d:3.5s"><span class="cap"></span><span class="body"><span class="jp">他</span></span><span class="en">More</span></a><div class="dd"><div><h4>Festival</h4><a href="index.php">Home</a><a href="program.php">Program</a><a href="stalls.php">Stall map</a><a href="fireworks.php">Fireworks</a></div><div><h4>Plan</h4><a href="tickets.php">Tickets</a><a href="access.php">Access</a><a href="volunteer.php">Volunteer</a></div><div><h4>Info</h4><a href="news.php">News</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><details class="mt-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="program.php">Program</a><a href="stalls.php">Stall map</a><a href="fireworks.php">Fireworks</a><a href="tickets.php">Tickets</a><a href="access.php">Access</a><a href="volunteer.php">Volunteer</a><a href="news.php">News</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
