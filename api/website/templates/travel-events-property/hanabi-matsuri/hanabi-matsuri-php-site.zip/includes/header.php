<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Hanabi Matsuri';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Hanabi Matsuri</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Hanabi Matsuri — night festival, lantern nav, tokens only */
.mt-top{background:var(--c-primary);color:var(--on-primary);text-align:center;font:500 12px var(--f-body);letter-spacing:.24em;padding:9px 12px}
.mt-head{position:relative;padding:0 clamp(16px,4vw,60px);background:linear-gradient(180deg,var(--c-primary) 0 54%,var(--c-surface) 54%)}
.mt-rope{height:3px;background:repeating-linear-gradient(90deg,var(--c-secondary) 0 10px,var(--c-primary) 10px 14px);position:absolute;left:0;right:0;top:30px}
.mt-row{position:relative;display:flex;justify-content:center;align-items:flex-start;gap:clamp(8px,2.4vw,34px);padding-top:30px;list-style:none;flex-wrap:wrap}
.mt-lan{display:flex;flex-direction:column;align-items:center;text-decoration:none;color:var(--c-text);transform-origin:50% 0;animation:mtsway 5s ease-in-out infinite;animation-delay:var(--d,0s)}
.mt-lan::before{content:"";width:2px;height:22px;background:var(--c-primary)}
.mt-lan .cap{width:46px;height:9px;background:var(--c-primary);border-radius:2px}
.mt-lan .body{width:84px;height:112px;border-radius:50%/42%;background:radial-gradient(ellipse at 50% 35%,color-mix(in srgb,var(--c-accent) 70%,#fff) 0,var(--c-accent) 55%,color-mix(in srgb,var(--c-accent) 70%,#000) 100%);display:grid;place-items:center;position:relative;box-shadow:0 6px 18px color-mix(in srgb,var(--c-accent) 45%,transparent);transition:transform .25s}
.mt-lan .body::before,.mt-lan .body::after{content:"";position:absolute;left:6%;right:6%;height:2px;background:color-mix(in srgb,var(--c-primary) 45%,transparent);border-radius:50%}
.mt-lan .body::before{top:12%}.mt-lan .body::after{bottom:12%}
.mt-lan .jp{writing-mode:vertical-rl;font:400 27px var(--f-head);color:var(--on-accent);letter-spacing:.08em;line-height:1.05}
.mt-lan .en{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;margin-top:8px;color:var(--c-primary)}
.mt-lan:hover .body,.mt-lan:focus-visible .body{transform:scale(1.08)}
.mt-lan.k .body{background:radial-gradient(ellipse at 50% 35%,color-mix(in srgb,var(--c-secondary) 70%,#fff) 0,var(--c-secondary) 60%,color-mix(in srgb,var(--c-secondary) 70%,#000) 100%);box-shadow:0 6px 18px color-mix(in srgb,var(--c-secondary) 45%,transparent)}
.mt-lan.k .jp{color:var(--c-primary)}
@keyframes mtsway{0%,100%{transform:rotate(-2deg)}50%{transform:rotate(2deg)}}
.mt-logo{position:absolute;left:clamp(16px,4vw,60px);top:44px;font:400 22px var(--f-head);letter-spacing:.1em;color:var(--on-primary);text-decoration:none;z-index:2}
.mt-more{position:relative}
.mt-more .dd{position:absolute;right:-30px;top:100%;display:none;grid-template-columns:repeat(4,minmax(120px,1fr));gap:16px 26px;padding:20px 24px;background:var(--c-surface);border:3px solid var(--c-primary);min-width:600px;z-index:60;text-align:left}
.mt-more:hover .dd,.mt-more:focus-within .dd{display:grid}
.mt-more .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.mt-more .dd a{display:block;padding:5px 0;text-decoration:none;font:500 14px var(--f-body)}
.mt-more .dd a:hover{color:var(--c-accent)}
.mt-m{display:none}
.mt-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:700 12px var(--f-body);letter-spacing:.18em;color:var(--on-primary);border:2px solid var(--on-primary);padding:0 14px}
.mt-m summary::-webkit-details-marker{display:none}
.mt-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:3px solid var(--c-primary);padding:8px 20px 20px;display:grid;z-index:60}
.mt-m nav a{padding:12px 4px;border-bottom:2px dotted var(--c-border);text-decoration:none;font:700 14px var(--f-body);min-height:44px}
@media(max-width:820px){.mt-head{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--c-primary);position:relative}.mt-rope,.mt-row{display:none}.mt-logo{position:static;font-size:20px}.mt-m{display:block}}
@media(prefers-reduced-motion:reduce){.mt-lan{animation:none}}

.mt-sec{padding:var(--pad) clamp(20px,5vw,80px)}
.mt-k{display:inline-block;font:700 12px var(--f-body);letter-spacing:.26em;text-transform:uppercase;background:var(--c-primary);color:var(--on-primary);padding:5px 14px;margin-bottom:18px;transform:rotate(-1.5deg)}
.mt-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:.8em 2em;border:3px solid var(--c-primary);background:var(--c-accent);color:var(--on-accent);font:400 18px var(--f-head);letter-spacing:.14em;text-decoration:none;cursor:pointer;border-radius:999px;box-shadow:0 5px 0 var(--c-primary);transition:transform .12s,box-shadow .12s}
.mt-btn:hover{transform:translateY(3px);box-shadow:0 2px 0 var(--c-primary)}
.mt-btn.y{background:var(--c-secondary);color:var(--c-primary)}
.mt-ph{position:relative;min-height:220px;border:3px solid var(--c-primary);background:radial-gradient(circle,var(--c-primary) 0 2px,transparent 3px) 0 0/18px 18px,color-mix(in srgb,var(--c-secondary) 25%,var(--c-surface))}
.mt-ph::after{content:attr(data-l);position:absolute;left:10px;bottom:8px;background:var(--c-surface);border:2px solid var(--c-primary);font:700 10px var(--f-body);letter-spacing:.14em;text-transform:uppercase;padding:3px 9px}

/* hero: night sky + fireworks + countdown */
.mt-hero{position:relative;background:var(--c-primary);color:var(--on-primary);overflow:hidden;padding:clamp(50px,7vw,110px) clamp(20px,5vw,80px) clamp(120px,12vw,180px);text-align:center;clip-path:polygon(0 0,100% 0,100% 100%,50% calc(100% - 40px),0 100%)}
.mt-fw{position:absolute;width:6px;height:6px;border-radius:50%;opacity:0;animation:mtburst 4.2s ease-out infinite;animation-delay:var(--d)}
@keyframes mtburst{0%{opacity:0;transform:scale(.2)}8%{opacity:1}60%{opacity:.9;transform:scale(1)}100%{opacity:0;transform:scale(1.25)}}
.mt-hero-in{position:relative;z-index:1}
.mt-hero .en{font:700 13px var(--f-body);letter-spacing:.36em;text-transform:uppercase;color:var(--c-secondary)}
.mt-hero h1{font:400 clamp(70px,16vw,230px)/1 var(--f-head);color:var(--c-secondary);margin:12px 0 10px;-webkit-text-stroke:3px var(--c-accent);paint-order:stroke fill;text-shadow:8px 8px 0 var(--c-accent);letter-spacing:.06em}
.mt-hero p.d{font:700 clamp(16px,2vw,24px) var(--f-body);letter-spacing:.14em}
.mt-cd{display:inline-grid;grid-template-columns:repeat(4,auto);gap:clamp(10px,2vw,26px);margin:30px 0 34px;padding:16px clamp(16px,3vw,36px);border:3px solid var(--c-secondary);border-radius:18px;background:color-mix(in srgb,var(--c-primary) 85%,#000)}
.mt-cd div{text-align:center}
.mt-cd b{display:block;font:400 clamp(34px,5vw,64px)/1 var(--f-head);color:var(--c-secondary)}
.mt-cd span{font:700 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;opacity:.8}
@media(prefers-reduced-motion:reduce){.mt-fw{animation:none;opacity:.7}}

/* tickets */
.mt-tks{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(18px,2.4vw,34px)}
.mt-tk{position:relative;background:var(--c-surface);border:3px solid var(--c-primary);padding:30px 26px 26px;display:grid;gap:10px;align-content:start}
.mt-tk::before,.mt-tk::after{content:"";position:absolute;top:calc(100% - 78px);width:26px;height:26px;border-radius:50%;background:var(--c-surface);border:3px solid var(--c-primary)}
.mt-tk::before{left:-15px;clip-path:inset(0 0 0 50%)}.mt-tk::after{right:-15px;clip-path:inset(0 50% 0 0)}
.mt-tk .n{font:400 64px/1 var(--f-head);color:var(--c-accent)}
.mt-tk h3{font:400 24px var(--f-head);letter-spacing:.08em}
.mt-tk .pr{font:700 26px var(--f-body)}
.mt-tk .st{border-top:3px dashed var(--c-primary);margin-top:18px;padding-top:14px;font:700 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;display:flex;justify-content:space-between}
.mt-tk.hl{background:var(--c-secondary)}
@media(max-width:900px){.mt-tks{grid-template-columns:1fr}}

/* program timeline */
.mt-prog{display:grid;gap:0;border-top:3px solid var(--c-primary)}
.mt-prog>div{display:grid;grid-template-columns:130px 40px 1fr;gap:0 18px;padding:20px 0;border-bottom:3px solid var(--c-primary);align-items:baseline}
.mt-prog time{font:400 34px/1 var(--f-head);color:var(--c-accent)}
.mt-prog i{width:18px;height:18px;border-radius:50%;background:var(--c-secondary);border:3px solid var(--c-primary);align-self:center}
.mt-prog h3{font:400 24px var(--f-head);letter-spacing:.06em}
.mt-prog p{font-size:15px;opacity:.85;margin-top:4px}
@media(max-width:600px){.mt-prog>div{grid-template-columns:90px 26px 1fr;gap:0 8px}.mt-prog time{font-size:26px}}

/* stall map */
.mt-map{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:clamp(24px,5vw,70px);align-items:start}
.mt-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:8px;padding:14px;border:3px solid var(--c-primary);background:color-mix(in srgb,var(--c-secondary) 18%,var(--c-surface))}
.mt-grid button{aspect-ratio:1;border:3px solid var(--c-primary);background:var(--c-surface);cursor:pointer;font:400 18px var(--f-head);color:var(--c-primary);min-height:44px;position:relative;transition:transform .12s}
.mt-grid button:hover{transform:translateY(-3px)}
.mt-grid button[data-k=food]{background:var(--c-accent);color:var(--on-accent)}
.mt-grid button[data-k=game]{background:var(--c-secondary)}
.mt-grid button[data-k=shop]{background:var(--c-primary);color:var(--on-primary)}
.mt-grid button[aria-pressed=true]{outline:4px solid var(--c-accent);outline-offset:2px;transform:scale(1.06)}
.mt-grid .path{grid-column:1/-1;height:34px;display:grid;place-items:center;font:700 11px var(--f-body);letter-spacing:.5em;color:var(--c-primary)}
.mt-leg{display:flex;gap:16px;flex-wrap:wrap;margin-top:14px;font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase}
.mt-leg i{display:inline-block;width:16px;height:16px;border:2px solid var(--c-primary);vertical-align:-3px;margin-right:6px}
.mt-card{border:3px solid var(--c-primary);padding:30px;background:var(--c-surface);box-shadow:8px 8px 0 var(--c-accent);position:sticky;top:24px}
.mt-card .id{font:400 70px/1 var(--f-head);color:var(--c-accent)}
.mt-card h3{font:400 26px var(--f-head);letter-spacing:.08em;margin:6px 0 10px}
@media(max-width:900px){.mt-map{grid-template-columns:1fr}.mt-card{position:static}}
.mt-two{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:center}
.mt-two h2{font:400 clamp(30px,4.4vw,var(--h2)) var(--f-head);letter-spacing:.06em;margin-bottom:14px}
.mt-two p{line-height:1.95;max-width:46ch}
@media(max-width:800px){.mt-two{grid-template-columns:1fr}}
.mt-news{display:grid;grid-template-columns:130px 1fr auto;gap:18px;padding:18px 0;border-top:3px solid var(--c-primary);text-decoration:none;align-items:baseline}
.mt-news:last-child{border-bottom:3px solid var(--c-primary)}
.mt-news time{font:700 13px var(--f-body);letter-spacing:.14em}
.mt-news h3{font:700 18px var(--f-body)}
.mt-news .t{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;background:var(--c-accent);color:var(--on-accent);padding:3px 10px}
@media(max-width:600px){.mt-news{grid-template-columns:1fr;gap:4px}}
.mt-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(44px,6vw,80px) clamp(20px,5vw,80px) 26px;margin-top:var(--pad);position:relative}
.mt-foot::before{content:"";position:absolute;left:0;right:0;top:-18px;height:18px;background:radial-gradient(circle at 18px 18px,var(--c-primary) 17px,transparent 18px) 0 0/36px 18px}
.mt-foot .top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(24px,6vw,100px)}
.mt-foot .big{font:400 44px var(--f-head);letter-spacing:.1em;color:var(--c-secondary)}
.mt-foot h4{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:10px}
.mt-foot ul{list-style:none}.mt-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font-size:14px;min-height:32px}
.mt-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.mt-foot .copy{margin-top:34px;padding-top:16px;border-top:2px dotted color-mix(in srgb,var(--on-primary) 40%,transparent);font:700 11px var(--f-body);letter-spacing:.2em;opacity:.8}
@media(max-width:800px){.mt-foot .top{grid-template-columns:1fr}.mt-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(max-width:700px){.mt-sec{padding-left:18px;padding-right:18px}}
@media(prefers-reduced-motion:reduce){.mt-btn,.mt-grid button{transition:none}}
</style><div class="mt-top">8.15 SAT · 17:00 – 21:30 · 花火 20:00 · 雨天決行 RAIN OR SHINE</div><header class="mt-head"><div class="mt-rope"></div><a class="mt-logo" href="index.php">花火祭</a><ul class="mt-row"><li><a class="mt-lan" href="program.php" style="--d:0s"><span class="cap"></span><span class="body"><span class="jp">番組</span></span><span class="en">Program</span></a></li><li><a class="mt-lan" href="stalls.php" style="--d:0.7s"><span class="cap"></span><span class="body"><span class="jp">屋台</span></span><span class="en">Stalls</span></a></li><li><a class="mt-lan" href="fireworks.php" style="--d:1.4s"><span class="cap"></span><span class="body"><span class="jp">花火</span></span><span class="en">Fireworks</span></a></li><li><a class="mt-lan" href="tickets.php" style="--d:2.1s"><span class="cap"></span><span class="body"><span class="jp">切符</span></span><span class="en">Tickets</span></a></li><li><a class="mt-lan k" href="access.php" style="--d:2.8s"><span class="cap"></span><span class="body"><span class="jp">道順</span></span><span class="en">Access</span></a></li><li class="mt-more"><a class="mt-lan k" href="#" tabindex="0" style="--d:3.5s"><span class="cap"></span><span class="body"><span class="jp">他</span></span><span class="en">More</span></a><div class="dd"><div><h4>Festival</h4><a href="index.php">Home</a><a href="program.php">Program</a><a href="stalls.php">Stall map</a><a href="fireworks.php">Fireworks</a></div><div><h4>Plan</h4><a href="tickets.php">Tickets</a><a href="access.php">Access</a><a href="volunteer.php">Volunteer</a></div><div><h4>Info</h4><a href="news.php">News</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><details class="mt-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="program.php">Program</a><a href="stalls.php">Stall map</a><a href="fireworks.php">Fireworks</a><a href="tickets.php">Tickets</a><a href="access.php">Access</a><a href="volunteer.php">Volunteer</a><a href="news.php">News</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header>
<main>
