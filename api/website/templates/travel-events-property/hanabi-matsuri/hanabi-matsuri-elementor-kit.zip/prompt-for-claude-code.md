# Build "Hanabi Matsuri" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2a1b3d · Secondary #f5b623 · Text #2a1b3d · Accent #e0312f · Surface #fff6e2 · Border #2a1b3d

## 2. Global Fonts
Headings: Dela Gothic One · Body: Kiwi Maru
H1 120px / H2 52px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Program (program) — html/program.html
- Stall map (stalls) — html/stalls.html
- Fireworks (fireworks) — html/fireworks.html
- Tickets (tickets) — html/tickets.html
- Access (access) — html/access.html
- Volunteer (volunteer) — html/volunteer.html
- News (news) — html/news.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
