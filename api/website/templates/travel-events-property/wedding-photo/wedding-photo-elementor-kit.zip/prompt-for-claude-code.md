# Build "Frame & Vow" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #14182b · Secondary #8a8576 · Text #22232b · Accent #c8a978 · Surface #faf7f2 · Border #ddd6c8

## 2. Global Fonts
Headings: Italiana · Body: Raleway
H1 96px / H2 46px / H3 28px / Body 16px

## 3. Layout
Content width 1300px · Section padding 104px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Love stories (stories) — html/stories.html
- A love story (story) — html/story.html
- Packages (packages) — html/packages.html
- About us (about) — html/about.html
- Check your date (enquire) — html/enquire.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
