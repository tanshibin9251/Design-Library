<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="ex-sec"><div class="in"><div class="faq"><details open><summary>Can I transfer my ticket?</summary><p>Yes, up to 7 days before the event.</p></details><details><summary>Will sessions be recorded?</summary><p>Main stage talks, yes. Workshops, no.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
