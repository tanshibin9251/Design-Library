<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Nexus Summit';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Nexus Summit</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Nexus Summit — tokens only */
.ex-head{position:sticky;top:0;z-index:40;background:color-mix(in srgb,var(--c-surface) 88%,transparent);backdrop-filter:blur(10px);border-bottom:1px solid var(--c-border)}
.ex-head .in{max-width:var(--w);margin:auto;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:12px 20px}
.ex-logo{font:900 22px var(--f-head);letter-spacing:-.02em;text-decoration:none;display:flex;align-items:center;gap:8px}
.ex-logo i{width:14px;height:14px;border-radius:50%;background:linear-gradient(135deg,var(--c-accent),var(--c-primary))}
.ex-head ul{display:flex;gap:22px;list-style:none;font:700 14px var(--f-body)}.ex-head ul a{text-decoration:none}.ex-head ul a:hover{color:var(--c-primary)}
.ex-btn{background:linear-gradient(135deg,var(--c-primary),var(--c-accent));color:var(--on-primary);padding:.8em 1.5em;border-radius:99px;font:800 14px var(--f-body);text-decoration:none;display:inline-block}
.ex-btn.o{background:none;color:var(--c-text);box-shadow:inset 0 0 0 2px var(--c-text)}
.ex-hero{position:relative;overflow:hidden;text-align:center;padding:clamp(40px,7vw,100px) 20px;background:radial-gradient(circle at 20% 20%,color-mix(in srgb,var(--c-accent) 35%,transparent),transparent 45%),radial-gradient(circle at 85% 30%,color-mix(in srgb,var(--c-primary) 35%,transparent),transparent 50%),var(--c-surface)}
.ex-hero small{font:800 13px var(--f-body);letter-spacing:.2em;text-transform:uppercase}
.ex-hero h1{font:900 clamp(48px,11vw,var(--h1));line-height:.92;letter-spacing:-.04em;margin:14px 0;color:var(--c-text)}
.ex-hero h1 span{background:linear-gradient(90deg,var(--c-primary),var(--c-accent));-webkit-background-clip:text;background-clip:text;color:transparent}
.ex-hero p{font:500 19px/1.6 var(--f-body);max-width:50ch;margin:0 auto 24px}
.ex-cd{display:inline-grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:8px 0 26px}
.ex-cd div{background:var(--c-surface);border:1px solid var(--c-border);border-radius:16px;padding:14px 18px;min-width:76px;box-shadow:0 10px 26px -14px color-mix(in srgb,var(--c-text) 40%,transparent)}
.ex-cd b{display:block;font:900 clamp(28px,5vw,44px)/1 var(--f-head);font-variant-numeric:tabular-nums}.ex-cd span{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;opacity:.6}
.ex-meta{display:flex;gap:14px;flex-wrap:wrap;justify-content:center;font:700 14px var(--f-body)}.ex-meta span{background:var(--c-surface);border:1px solid var(--c-border);padding:.4em 1em;border-radius:99px}
.ex-sec{padding:var(--pad) 20px}.ex-sec>.in{max-width:var(--w);margin:auto}
.ex-tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;position:relative}
.ex-tabs input{position:absolute;opacity:0}.ex-tabs label{padding:.6em 1.3em;border-radius:99px;border:2px solid var(--c-text);font:800 14px var(--f-body);cursor:pointer}
.ex-tabs input:checked+label{background:var(--c-text);color:var(--c-surface)}.ex-tabs input:focus-visible+label{outline:3px solid var(--c-primary)}
.ex-day{display:none}#ex-d1:checked~.d1,#ex-d2:checked~.d2{display:block}
.ex-s{display:grid;grid-template-columns:110px 1fr auto;gap:16px;padding:16px 0;border-bottom:1px solid var(--c-border);align-items:center}
.ex-s .t{font:900 18px var(--f-head);font-variant-numeric:tabular-nums}.ex-s h3{font:800 19px var(--f-head);margin-bottom:2px}.ex-s small{opacity:.7}
.ex-s .tag{font:800 11px var(--f-body);letter-spacing:.08em;text-transform:uppercase;padding:.25em .8em;border-radius:99px;background:color-mix(in srgb,var(--c-accent) 22%,var(--c-surface))}
.ex-sp{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}
.ex-sp .ph{aspect-ratio:1;border-radius:22px}.ex-sp h3{font:800 18px var(--f-head);margin-top:10px}.ex-sp small{opacity:.7;display:block}
.ex-tk{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.ex-tc{border:2px solid var(--c-text);border-radius:22px;padding:26px;background:var(--c-surface);position:relative}
.ex-tc.hl{background:linear-gradient(160deg,var(--c-primary),var(--c-accent));color:var(--on-primary);border-color:transparent}.ex-tc.hl h3,.ex-tc.hl .am{color:inherit}
.ex-tc h3{font:900 22px var(--f-head)}.ex-tc .am{font:900 40px var(--f-head);margin:8px 0}.ex-tc .left{font:800 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase;opacity:.75}
.ex-tc ul{list-style:none;padding:0;margin:14px 0 20px;display:grid;gap:6px;font:600 15px var(--f-body)}
.ex-foot{background:var(--c-text);color:var(--c-surface)}
@media(max-width:820px){.ex-head ul{display:none}.ex-sp{grid-template-columns:1fr 1fr}.ex-tk{grid-template-columns:1fr}.ex-s{grid-template-columns:78px 1fr}.ex-s .tag{grid-column:2;justify-self:start}}
html,body{overflow-x:clip}img,svg{max-width:100%}.ex-head .more{position:relative}.ex-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:16px;}.ex-head .more:hover .dd,.ex-head .more:focus-within .dd{display:grid}.ex-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.ex-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.ex-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-text)}.ex-tc.hl h3{color:var(--on-primary)}</style><header class="ex-head"><div class="in"><a class="ex-logo" href="index.php"><i></i>Nexus Summit</a><ul><li><a href="agenda.php">Agenda</a></li><li><a href="speakers.php">Speakers</a></li><li><a href="venue.php">Venue</a></li><li><a href="sponsors.php">Sponsors</a></li><li class="more" style="position:relative"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Event</h4><a href="index.php">Home</a><a href="agenda.php">Agenda</a><a href="speakers.php">Speakers</a><a href="tickets.php">Tickets</a><a href="venue.php">Venue & travel</a><a href="sponsors.php">Sponsors</a><a href="faq.php">FAQ</a><a href="contact.php">Contact</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="ex-btn" href="tickets.php">Get tickets</a></div></header>
<main>
