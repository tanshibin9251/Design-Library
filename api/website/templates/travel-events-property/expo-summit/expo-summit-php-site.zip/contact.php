<?php $title = 'Contact'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Contact</b></div><h1>Contact</h1></div></section><section class="ex-sec"><div class="in" style="max-width:640px"><form class="form"><div class="fld"><label>Name</label><input></div><div class="fld"><label>Email</label><input></div><div class="fld"><label>Message</label><textarea rows="3"></textarea></div><a class="ex-btn" href="#">Send</a></form></div></section>
<?php include 'includes/footer.php'; ?>
