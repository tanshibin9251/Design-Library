# Build "Nexus Summit" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #6d28d9 · Secondary #4b5563 · Text #0b0b12 · Accent #06b6d4 · Surface #ffffff · Border #e5e7eb

## 2. Global Fonts
Headings: Red Hat Display · Body: Red Hat Text
H1 124px / H2 54px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 22px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Agenda (agenda) — html/agenda.html
- Speakers (speakers) — html/speakers.html
- Tickets (tickets) — html/tickets.html
- Venue & travel (venue) — html/venue.html
- Sponsors (sponsors) — html/sponsors.html
- FAQ (faq) — html/faq.html
- Contact (contact) — html/contact.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
