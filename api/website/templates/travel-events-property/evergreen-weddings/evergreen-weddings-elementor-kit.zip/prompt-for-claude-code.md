# Build "Evergreen Weddings" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #4b5d52 · Secondary #d9c7b8 · Text #34403a · Accent #c7826b · Surface #fbf8f3 · Border #e4dacd

## 2. Global Fonts
Headings: Gilda Display · Body: Questrial
H1 84px / H2 46px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Wedding Services (services) — html/services.html
- Single Service (service) — html/service.html
- Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Venues (shop) — html/shop.html
- Single Venue (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Real Weddings (projects) — html/projects.html
- Single Wedding (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Enquire (booking) — html/booking.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
