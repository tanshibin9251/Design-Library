# Build "Wok & Steam" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2b1d16 · Secondary #4f7f6f · Text #2b1d16 · Accent #c8372d · Surface #f9f3e6 · Border #e2d4b8

## 2. Global Fonts
Headings: ZCOOL XiaoWei · Body: Noto Sans SC
H1 96px / H2 44px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 18px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- All recipes (recipes) — html/recipes.html
- Recipe: Mapo tofu (recipe) — html/recipe.html
- What to eat today (picker) — html/picker.html
- Techniques (techniques) — html/techniques.html
- The pantry (pantry) — html/pantry.html
- About (about) — html/about.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
