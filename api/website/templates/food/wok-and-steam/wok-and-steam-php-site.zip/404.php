<?php $title = '404 error'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="wk-sec" style="text-align:center;padding-top:clamp(60px,10vw,140px)"><div class="wk-plate" style="width:min(70%,260px)"><div class="ring"></div></div><h1 style="font:400 clamp(60px,12vw,130px)/1 var(--f-head);color:var(--c-accent);margin-top:18px">404</h1><p style="margin:10px 0 26px;font:400 22px var(--f-head)">这盘菜已经吃完了。</p><a class="wk-btn" href="index.php">Back to the kitchen</a></section></div>
<?php include 'includes/footer.php'; ?>
