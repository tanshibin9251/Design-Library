<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Wok & Steam';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Wok &amp; Steam</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="wok-and-steam" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Wok & Steam — Chinese home-cooking recipe site, tokens only */
.wk-head{background:var(--c-surface);border-bottom:2px solid var(--c-primary);position:sticky;top:0;z-index:50}
.wk-in{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:20px;padding:0 clamp(16px,4vw,56px);min-height:76px}
.wk-logo{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--c-primary)}
.wk-seal{display:grid;place-items:center;width:44px;height:44px;background:var(--c-accent);color:var(--on-accent);font:400 26px var(--f-head);border-radius:6px;transform:rotate(-4deg)}
.wk-logo b{font:400 22px var(--f-head);letter-spacing:.06em}
.wk-logo small{display:block;font:500 10px var(--f-body);letter-spacing:.3em;color:var(--c-secondary);text-transform:uppercase}
.wk-nav{display:flex;justify-content:center;gap:clamp(6px,1.4vw,22px);list-style:none}
.wk-nav a{display:flex;flex-direction:column;align-items:center;min-height:44px;justify-content:center;text-decoration:none;font:500 14px var(--f-body);padding:0 8px;line-height:1.1;color:var(--c-text)}
.wk-nav a span{font:400 12px var(--f-head);color:var(--c-secondary);letter-spacing:.2em}
.wk-nav a:hover{color:var(--c-accent)}
.wk-nav .more{position:relative}
.wk-nav .dd{position:absolute;left:50%;transform:translateX(-50%);top:100%;display:none;grid-template-columns:repeat(4,minmax(120px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:2px solid var(--c-primary);min-width:560px;z-index:60;text-align:left}
.wk-nav .more:hover .dd,.wk-nav .more:focus-within .dd{display:grid}
.wk-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.wk-nav .dd a{display:block;min-height:0;padding:5px 0;text-align:left}
.wk-find{display:flex;align-items:center;gap:8px;min-height:44px;border:2px solid var(--c-primary);padding:0 14px;border-radius:999px;text-decoration:none;font:500 14px var(--f-body);color:var(--c-primary)}
.wk-m{display:none}
.wk-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:2px solid var(--c-primary);border-radius:999px;padding:0 14px;font:700 12px var(--f-body);letter-spacing:.14em}
.wk-m summary::-webkit-details-marker{display:none}
.wk-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:2px solid var(--c-primary);padding:6px 18px 16px;display:grid}
.wk-m nav a{padding:12px 0;border-bottom:1px dashed var(--c-border);text-decoration:none;font:500 15px var(--f-body);min-height:44px}
@media(max-width:940px){.wk-nav,.wk-find{display:none}.wk-in{grid-template-columns:1fr auto}.wk-m{display:block}}

.wk-sec{padding:clamp(40px,6vw,88px) clamp(16px,4vw,56px)}
.wk-hero{position:relative;display:grid;grid-template-columns:1.1fr .9fr;gap:clamp(24px,5vw,80px);align-items:center;padding:clamp(36px,6vw,84px) clamp(16px,4vw,56px)}
.wk-hero h1{font:400 clamp(44px,7vw,var(--h1))/1.08 var(--f-head);color:var(--c-primary);letter-spacing:.02em}
.wk-hero h1 em{font-style:normal;color:var(--c-accent)}
.wk-hero .sub{font:500 13px var(--f-body);letter-spacing:.3em;color:var(--c-secondary);text-transform:uppercase;display:block;margin-bottom:16px}
.wk-hero p.lead{font:400 18px/1.8 var(--f-body);margin:20px 0 26px;max-width:42ch}
@media(max-width:900px){.wk-hero{grid-template-columns:1fr}}
.wk-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 28px;border-radius:999px;background:var(--c-accent);color:var(--on-accent);text-decoration:none;font:700 15px var(--f-body);border:2px solid var(--c-accent);cursor:pointer;transition:transform .15s}
.wk-btn:hover{transform:scale(1.04)}
.wk-btn.o{background:transparent;color:var(--c-primary);border-color:var(--c-primary)}
/* the plate */
.wk-plate{position:relative;width:min(100%,460px);aspect-ratio:1;margin:0 auto}
.wk-plate .ring{position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle at 50% 50%,var(--c-surface) 0 52%,var(--c-border) 52.5% 54%,var(--c-surface) 54.5% 70%,var(--c-secondary) 70.5% 72%,var(--c-surface) 72.5%);box-shadow:0 30px 50px -30px color-mix(in srgb,var(--c-primary) 55%,transparent),inset 0 0 0 10px var(--c-surface)}
.wk-plate .dish{position:absolute;inset:20%;border-radius:50%;background:
 radial-gradient(circle at 30% 30%,color-mix(in srgb,var(--c-accent) 70%,#fff) 0 7%,transparent 8%),
 radial-gradient(circle at 62% 38%,var(--c-primary) 0 5%,transparent 6%),radial-gradient(circle at 48% 66%,var(--c-secondary) 0 9%,transparent 10%),radial-gradient(circle at 70% 70%,var(--c-accent) 0 6%,transparent 7%),
 color-mix(in srgb,var(--c-accent) 38%,var(--c-surface))}
.wk-steam{position:absolute;left:50%;top:-4%;width:50%;height:30%;transform:translateX(-50%);display:flex;justify-content:space-around;pointer-events:none}
.wk-steam i{width:10px;height:100%;border-radius:50%;border-left:3px solid color-mix(in srgb,var(--c-secondary) 60%,transparent);animation:wksteam 3.2s ease-in-out infinite;animation-delay:var(--d)}
@keyframes wksteam{0%{transform:translateY(20px) scaleY(.6);opacity:0}30%{opacity:.9}100%{transform:translateY(-24px) scaleY(1.2);opacity:0}}
.wk-plate .tag{position:absolute;right:2%;bottom:6%;background:var(--c-primary);color:var(--on-primary);font:400 20px var(--f-head);padding:10px 14px;border-radius:6px;transform:rotate(4deg);letter-spacing:.1em}

.wk-h{display:flex;align-items:baseline;gap:14px;margin-bottom:26px;flex-wrap:wrap}
.wk-h h2{font:400 clamp(26px,3.4vw,var(--h2)) var(--f-head);color:var(--c-primary);letter-spacing:.04em}
.wk-h span{font:500 12px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-secondary)}
.wk-h::after{content:"";flex:1;min-width:30px;border-top:2px dotted var(--c-secondary);align-self:center}
.wk-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:clamp(14px,2vw,28px)}
.wk-card{display:grid;gap:6px;text-decoration:none;align-content:start;text-align:center}
.wk-card .pic{aspect-ratio:1;border-radius:50%;border:3px solid var(--c-primary);background:radial-gradient(circle at var(--x,35%) var(--y,35%),var(--c1,var(--c-accent)) 0 14%,transparent 15%),radial-gradient(circle at 62% 66%,var(--c2,var(--c-secondary)) 0 20%,transparent 21%),color-mix(in srgb,var(--c-accent) 14%,var(--c-surface));position:relative;transition:transform .3s}
.wk-card:hover .pic{transform:rotate(8deg) scale(1.03)}
.wk-card .pic::after{content:"缺图";position:absolute;left:50%;bottom:10%;transform:translateX(-50%);font:600 10px var(--f-body);letter-spacing:.14em;background:var(--c-surface);padding:2px 8px;border-radius:99px}
.wk-card h3{font:400 22px var(--f-head);color:var(--c-primary);letter-spacing:.04em;margin-top:10px}
.wk-card .m{font:500 13px var(--f-body);color:var(--c-secondary)}
.wk-card .zh{font:400 14px var(--f-head);color:var(--c-accent);letter-spacing:.2em}
@media(max-width:900px){.wk-grid{grid-template-columns:repeat(2,1fr)}}
.wk-chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:28px}
.wk-chips button{min-height:44px;padding:0 18px;border-radius:999px;border:2px solid var(--c-primary);background:transparent;color:var(--c-primary);font:600 14px var(--f-body);cursor:pointer}
.wk-chips button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.wk-card.hide{display:none}

/* recipe */
.wk-rec{display:grid;grid-template-columns:minmax(260px,380px) 1fr;gap:clamp(24px,5vw,72px);align-items:start}
@media(max-width:860px){.wk-rec{grid-template-columns:1fr}}
.wk-ing{border:2px solid var(--c-primary);border-radius:18px;padding:clamp(20px,2.4vw,30px);background:color-mix(in srgb,var(--c-surface) 50%,#fff);position:sticky;top:96px}
.wk-ing h3{font:400 24px var(--f-head);letter-spacing:.06em}
.wk-serv{display:flex;align-items:center;gap:10px;margin:14px 0 18px}
.wk-serv button{width:44px;height:44px;border-radius:50%;border:2px solid var(--c-primary);background:transparent;font:700 20px var(--f-body);cursor:pointer;color:var(--c-primary)}
.wk-serv output{font:400 26px var(--f-head);min-width:3ch;text-align:center}
.wk-ing ul{list-style:none}
.wk-ing li{display:flex;gap:10px;align-items:flex-start;padding:9px 0;border-top:1px dotted var(--c-secondary);font:500 15px/1.5 var(--f-body)}
.wk-ing li input{width:20px;height:20px;accent-color:var(--c-accent);flex:none;margin-top:2px;padding:0;min-height:0}
.wk-ing li label{display:flex;justify-content:space-between;gap:12px;flex:1;cursor:pointer}
.wk-ing li input:checked+label{opacity:.45;text-decoration:line-through}
.wk-ing .q{font-weight:700;white-space:nowrap}
@media(max-width:860px){.wk-ing{position:static}}
.wk-steps{counter-reset:s;list-style:none;display:grid;gap:22px}
.wk-steps li{counter-increment:s;display:grid;grid-template-columns:54px 1fr;gap:16px;align-items:start}
.wk-steps li::before{content:counter(s,cjk-ideographic);display:grid;place-items:center;width:54px;height:54px;border-radius:50%;background:var(--c-primary);color:var(--on-primary);font:400 24px var(--f-head)}
.wk-steps h3{font:400 22px var(--f-head);letter-spacing:.04em;margin-bottom:4px}
.wk-steps p{font:400 16px/1.8 var(--f-body)}
.wk-heat{display:inline-flex;gap:3px;vertical-align:middle;margin-left:8px}.wk-heat i{width:10px;height:14px;background:var(--c-border);border-radius:3px}.wk-heat i.on{background:var(--c-accent)}
.wk-meta{display:flex;gap:26px;flex-wrap:wrap;margin:20px 0 30px;padding:16px 0;border-top:2px solid var(--c-primary);border-bottom:2px solid var(--c-primary)}
.wk-meta div b{display:block;font:400 26px var(--f-head);color:var(--c-primary)}.wk-meta div span{font:600 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary)}
/* picker */
.wk-pick{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,72px);align-items:center}
@media(max-width:860px){.wk-pick{grid-template-columns:1fr}}
.wk-roll{border:3px solid var(--c-primary);border-radius:24px;padding:clamp(24px,3vw,44px);text-align:center;background:color-mix(in srgb,var(--c-surface) 50%,#fff);min-height:300px;display:grid;place-items:center;align-content:center;gap:10px}
.wk-roll .zh{font:400 clamp(46px,7vw,84px)/1.1 var(--f-head);color:var(--c-accent)}
.wk-roll .en{font:400 clamp(22px,3vw,32px) var(--f-head);color:var(--c-primary)}
.wk-roll p{font:500 15px var(--f-body);color:var(--c-secondary)}
.wk-tech{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.wk-tech>div{border:2px solid var(--c-primary);border-radius:18px;padding:24px;display:grid;gap:8px;align-content:start}
.wk-tech .zh{font:400 40px var(--f-head);color:var(--c-accent)}.wk-tech h3{font:400 22px var(--f-head)}.wk-tech p{font:400 15px/1.7 var(--f-body)}
@media(max-width:860px){.wk-tech{grid-template-columns:1fr}}
.wk-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(40px,6vw,88px);padding:clamp(36px,5vw,64px) clamp(16px,4vw,56px) 22px}
.wk-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,6vw,100px)}
.wk-foot .big{font:400 36px var(--f-head);letter-spacing:.08em}
.wk-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.wk-foot ul{list-style:none}.wk-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 14px var(--f-body);min-height:32px}
.wk-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.wk-foot .copy{margin-top:28px;font:500 12px var(--f-body);opacity:.7}
@media(max-width:800px){.wk-foot .top{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.wk-steam i{animation:none;opacity:.5}.wk-card .pic,.wk-btn{transition:none}}
</style><header class="wk-head"><div class="wk-in"><a class="wk-logo" href="index.php"><span class="wk-seal">家</span><span><b>Wok &amp; Steam</b><small>Chinese home cooking</small></span></a><ul class="wk-nav"><li><a href="recipes.php">Recipes<span>菜谱</span></a></li><li><a href="picker.php">Tonight<span>今天</span></a></li><li><a href="techniques.php">Techniques<span>技法</span></a></li><li><a href="pantry.php">Pantry<span>调料</span></a></li><li class="more"><a href="#" tabindex="0">More<span>更多</span></a><div class="dd"><div><h4>Cook</h4><a href="index.php">Home</a><a href="recipes.php">All recipes</a><a href="recipe.php">Recipe: Mapo tofu</a><a href="picker.php">What to eat today</a></div><div><h4>Learn</h4><a href="techniques.php">Techniques</a><a href="pantry.php">The pantry</a></div><div><h4>Kitchen</h4><a href="about.php">About</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="wk-find" href="picker.php">今天吃什么 →</a><details class="wk-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="recipes.php">All recipes</a><a href="recipe.php">Recipe: Mapo tofu</a><a href="picker.php">What to eat today</a><a href="techniques.php">Techniques</a><a href="pantry.php">The pantry</a><a href="about.php">About</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></div></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
