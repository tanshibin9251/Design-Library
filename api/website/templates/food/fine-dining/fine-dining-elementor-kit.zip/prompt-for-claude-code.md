# Build "Fine Dining" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1C1917 · Secondary #44403C · Text #292524 · Accent #A16207 · Surface #FAFAF9 · Border #E7E5E4

## 2. Global Fonts
Headings: Cormorant Garamond · Body: EB Garamond
H1 76px / H2 48px / H3 28px / Body 16px

## 3. Layout
Content width 1300px · Section padding 104px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Experiences (services) — html/services.html
- Single service (service) — html/service.html
- Gift Vouchers (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Cellar Shop (shop) — html/shop.html
- Single Bottle (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Press (projects) — html/projects.html
- Single Feature (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Menu (menu) — html/menu.html
- Wine list (wine) — html/wine.html
- Private dining (private-dining) — html/private-dining.html
- Reservations (reservations) — html/reservations.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
