# Fine Dining

Exported from Design Library · 26 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Experiences, Single service, Gift Vouchers, Contact, Cellar Shop, Single Bottle, Cart, Checkout, Testimonials, Team, Press, Single Feature, Gallery, Journal, Single post, FAQ, Menu, Wine list, Private dining, Reservations, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
