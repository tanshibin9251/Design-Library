# Build "Restaurant Warm" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #a31f2e · Secondary #5c7a3a · Text #2d1a12 · Accent #f4b942 · Surface #fff7e6 · Border #ecd9b0

## 2. Global Fonts
Headings: Bree Serif · Body: Mukta
H1 84px / H2 44px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 22px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Catering (services) — html/services.html
- Single service (service) — html/service.html
- Catering Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Order Online (shop) — html/shop.html
- Single Dish (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Our Dishes (projects) — html/projects.html
- Dish story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Stories (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Menu (menu) — html/menu.html
- Book a table (reservations) — html/reservations.html
- Catering (catering) — html/catering.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
