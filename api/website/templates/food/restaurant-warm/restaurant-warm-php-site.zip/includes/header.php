<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Restaurant Warm';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Restaurant Warm</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.rw-nav{display:flex;list-style:none;align-items:center;gap:4px}
.rw-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.rw-nav .more{position:relative}
.rw-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.rw-nav .more:hover .dd,.rw-nav .more:focus-within .dd{display:grid}
.rw-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.rw-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.rw-m{display:none;position:relative;margin-left:auto}
.rw-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.rw-m summary::-webkit-details-marker{display:none}
.rw-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.rw-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.rw-nav{display:none}.rw-m{display:block}}
.rw-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.rw-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.rw-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.rw-foot ul{list-style:none}.rw-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.rw-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.rw-foot .top{grid-template-columns:1fr}.rw-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Kopi & Kaya v2 — family kitchen with an order-your-rice-set builder */
.rw-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:80px;background:var(--c-surface);border-bottom:3px dotted var(--c-primary);position:sticky;top:0;z-index:50}
.rw-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--c-primary);font:400 28px var(--f-head)}
.rw-logo i{width:34px;height:34px;border-radius:50%;background:radial-gradient(circle at 35% 35%,var(--c-accent) 0 40%,var(--c-secondary) 41%);border:3px solid var(--c-primary);display:inline-block}
.rw-nav{margin-left:auto}.rw-nav a{padding:0 14px;font:600 16px var(--f-body);color:var(--c-text)}.rw-nav a:hover{color:var(--c-primary);text-decoration:underline wavy var(--c-accent)}
.rw-cta{background:var(--c-primary);color:var(--on-primary)!important;border-radius:999px;margin-left:8px}
.rw-open{font:700 13px var(--f-body);background:var(--c-secondary);color:var(--on-secondary,#fff);padding:6px 14px;border-radius:99px;white-space:nowrap}
.rw-open.off{background:var(--c-border);color:var(--c-text)}
@media(max-width:900px){.rw-open{display:none}}
.rw-sec{padding:clamp(36px,5vw,76px) clamp(14px,4vw,56px)}
.rw-hero{display:grid;grid-template-columns:1fr 1.05fr;gap:clamp(20px,4vw,64px);align-items:center;padding:clamp(30px,5vw,72px) clamp(14px,4vw,56px)}
@media(max-width:900px){.rw-hero{grid-template-columns:1fr}}
.rw-hero h1{font:400 clamp(42px,6.2vw,var(--h1))/1.05 var(--f-head);color:var(--c-primary)}
.rw-hero p{font:500 19px/1.7 var(--f-body);margin:16px 0 24px;max-width:38ch}
.rw-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 26px;border-radius:999px;background:var(--c-accent);color:var(--on-accent);font:700 16px var(--f-body);text-decoration:none;border:3px solid var(--c-primary);cursor:pointer}
.rw-btn:hover{background:var(--c-primary);color:var(--on-primary)}
.rw-btn.o{background:transparent;color:var(--c-primary)}
.rw-b{background:var(--c-surface);border:3px solid var(--c-primary);border-radius:28px;padding:clamp(18px,2.4vw,30px);box-shadow:8px 8px 0 var(--c-accent)}
.rw-b h2{font:400 26px var(--f-head);color:var(--c-primary);margin-bottom:12px}
.rw-st{margin-bottom:14px}.rw-st b{display:block;font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.rw-op{display:flex;gap:6px;flex-wrap:wrap}
.rw-op button{min-height:44px;padding:0 14px;border-radius:999px;border:2px solid var(--c-primary);background:transparent;color:var(--c-primary);font:700 14px var(--f-body);cursor:pointer}
.rw-op button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.rw-tot{display:flex;justify-content:space-between;align-items:baseline;gap:10px;margin-top:8px;padding-top:12px;border-top:3px dotted var(--c-primary)}
.rw-tot b{font:400 34px var(--f-head);color:var(--c-primary)}.rw-tot span{font:700 15px var(--f-body)}
.rw-h{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:22px;flex-wrap:wrap;gap:12px}
.rw-h h2{font:400 clamp(28px,3.6vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.rw-m{display:grid;grid-template-columns:1fr 1fr;gap:0 clamp(24px,5vw,70px)}@media(max-width:800px){.rw-m{grid-template-columns:1fr}}
.rw-it{display:grid;grid-template-columns:1fr auto;gap:2px 14px;padding:16px 0;border-bottom:2px dotted var(--c-border)}
.rw-it h3{font:400 22px var(--f-head);color:var(--c-primary)}.rw-it b{font:700 18px var(--f-body);color:var(--c-primary)}.rw-it p{grid-column:1/-1;font:500 15px/1.6 var(--f-body)}
.rw-it .hot{display:inline-flex;gap:3px;margin-left:8px;vertical-align:middle}.rw-it .hot i{width:9px;height:9px;border-radius:50%;background:var(--c-border)}.rw-it .hot i.on{background:var(--c-primary)}
.rw-w{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.rw-w>div{border:3px solid var(--c-primary);border-radius:26px;padding:22px;background:var(--c-surface)}.rw-w h3{font:400 24px var(--f-head);color:var(--c-primary)}.rw-w p{font:500 15px/1.7 var(--f-body)}
@media(max-width:800px){.rw-w{grid-template-columns:1fr}}
.rw-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.rw-foot .big{font:400 34px var(--f-head)}
.rw .pagehead{background:color-mix(in srgb,var(--c-secondary) 14%,var(--c-surface));border-left:10px solid var(--c-accent)}.rw .pagehead .wrap{padding-left:clamp(20px,3vw,40px)}.rw .card,.rw .scard,.rw .qcard,.rw .pcard,.rw .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.rw .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.rw .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.rw .svc{display:grid;grid-template-columns:repeat(3,1fr);gap:0;counter-reset:sv}
.rw .scard{display:flex;flex-direction:column;justify-content:space-between;aspect-ratio:1;padding:clamp(18px,2.4vw,32px);border:0;border-radius:0;box-shadow:none;background:color-mix(in srgb,var(--c-primary) 92%,var(--c-surface));color:var(--on-primary);counter-increment:sv}
.rw .scard:nth-child(3n+2){background:var(--c-accent);color:var(--on-accent)}
.rw .scard:nth-child(3n){background:color-mix(in srgb,var(--c-secondary) 55%,var(--c-surface));color:var(--c-text)}
.rw .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.16em;opacity:.8}
.rw .scard .ph{display:none}.rw .scard h3{color:inherit;font-size:clamp(22px,2.4vw,32px)}.rw .scard p{color:inherit;opacity:.85}.rw .scard .m{color:inherit;display:flex;gap:12px;font-size:13px}
@media(max-width:800px){.rw .svc{grid-template-columns:1fr 1fr}.rw .scard{aspect-ratio:auto;min-height:200px}}@media(max-width:520px){.rw .svc{grid-template-columns:1fr}}

.rw .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:30px}
.rw .person{background:color-mix(in srgb,var(--c-surface) 20%,#fff);padding:12px 12px 18px;box-shadow:0 16px 26px -18px rgba(0,0,0,.45);border:0;transform:rotate(-1.4deg);transition:transform .2s}
.rw .person:nth-child(2n){transform:rotate(1.2deg)}.rw .person:nth-child(3n){transform:rotate(-.5deg)}
.rw .person:hover{transform:rotate(0) translateY(-4px)}

.rw .qgrid{display:block;columns:2 300px;column-gap:20px}.rw .qgrid.mt{margin-top:20px}
.rw .qcard{break-inside:avoid;margin-bottom:20px}

.rw .masonry{display:grid!important;grid-template-columns:repeat(4,1fr);grid-auto-rows:150px;gap:8px;columns:auto}
.rw .masonry .mi{margin:0;overflow:hidden}.rw .masonry .mi .ph{aspect-ratio:auto!important;height:100%}
.rw .masonry .mi:nth-child(5n+1){grid-column:span 2;grid-row:span 2}.rw .masonry .mi:nth-child(7n+3){grid-row:span 2}
.rw .masonry .mi h3,.rw .masonry .mi .muted{display:none}
@media(max-width:700px){.rw .masonry{grid-template-columns:1fr 1fr}}

.rw .split.w2{display:block}
.rw .feat{display:grid;grid-template-columns:1.3fr 1fr;gap:clamp(18px,3vw,40px);align-items:center;margin-bottom:clamp(24px,4vw,48px)}
.rw .feat h2{font-size:clamp(26px,3.6vw,48px);line-height:1.04}
.rw .articles.two{grid-template-columns:repeat(3,1fr)!important}
@media(max-width:800px){.rw .feat{grid-template-columns:1fr}.rw .articles.two{grid-template-columns:1fr!important}}
.rw .faq{max-width:none;columns:2 340px;column-gap:clamp(24px,5vw,72px)}.rw .faq details{break-inside:avoid}

.rw .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.rw .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.rw .pricing .card.hl h3,.rw .pricing .card.hl .amt{color:var(--c-primary)!important}.rw .pricing .card.hl li::before{color:var(--c-accent)!important}

.rw .cinfo{display:block;border-top:2px solid var(--c-primary)}
.rw .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.rw .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.rw .cinfo .card p{margin:0}
.rw .sec.dark{background:var(--c-accent);color:var(--on-accent)}.rw .sec.dark h2,.rw .sec.dark p{color:var(--on-accent)}.rw .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.rw .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.rw .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.rw .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.rw .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.rw .tl>div:last-child{border-right:0}
.rw .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.rw .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.rw .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.rw .vals .card:last-child{border-right:0}
@media(max-width:700px){.rw .vals{grid-template-columns:1fr}.rw .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><header class="rw-head"><a class="rw-logo" href="index.php"><i></i>Kopi &amp; Kaya</a><span class="rw-open" id="rw-o" style="margin-left:auto">Open</span><ul class="rw-nav" style="margin-left:0"><li><a href="menu.php">Menu</a></li><li><a href="catering.php">Catering</a></li><li><a href="reservations.php">Book a table</a></li><li><a href="about.php">Our story</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Catering</a><a href="service.php">Single service</a><a href="pricing.php">Catering Packages</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Order Online</a><a href="product.php">Single Dish</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Our Dishes</a><a href="project.php">Single Dish</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Stories</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="menu.php">Menu</a><a href="reservations.php">Book a table</a><a href="catering.php">Catering</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="rw-cta" href="shop.php">Order online</a></li></ul><details class="rw-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Catering</a><a href="service.php">Single service</a><a href="pricing.php">Catering Packages</a><a href="contact.php">Contact</a><a href="shop.php">Order Online</a><a href="product.php">Single Dish</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Our Dishes</a><a href="project.php">Single Dish</a><a href="gallery.php">Gallery</a><a href="blog.php">Stories</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="menu.php">Menu</a><a href="reservations.php">Book a table</a><a href="catering.php">Catering</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><script>(function(){var h=new Date().getHours(),e=document.getElementById("rw-o");if(e){var o=h>=7&&h<22;e.textContent=o?"Open · until 10 pm":"Closed · opens 7 am";e.className="rw-open"+(o?"":" off")}})();</script><div class="rw">
<main>
