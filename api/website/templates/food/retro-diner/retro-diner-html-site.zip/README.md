# Sunny's Diner

Exported from Design Library · 24 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Specials, Single Special, Party Packages, Contact, Order Online, Single Dish, Cart, Checkout, Testimonials, Team, Gallery, Single Photo, Gallery, News, Single post, FAQ, Menu, Book a table, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
