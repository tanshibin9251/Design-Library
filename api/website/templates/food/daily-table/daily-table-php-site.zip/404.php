<?php $title = '404 error'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="dt-sec" style="text-align:center;padding-top:clamp(50px,9vw,120px)"><h1 style="font:700 clamp(60px,12vw,140px)/1 var(--f-head);color:var(--c-accent)">404</h1><p style="margin:10px 0 26px;font:400 22px var(--f-body)">Nothing planned for this page.</p><a class="dt-btn" href="index.php">Back to the table</a></section></div>
<?php include 'includes/footer.php'; ?>
