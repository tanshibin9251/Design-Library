# Build "Daily Table" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #3a2745 · Secondary #7a5a8a · Text #2e2433 · Accent #d8472b · Surface #fffaf0 · Border #e6dccb

## 2. Global Fonts
Headings: Alegreya · Body: Alegreya Sans
H1 88px / H2 44px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 80px vertical · Border radius 14px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- All recipes (recipes) — html/recipes.html
- Recipe: Sheet-pan chicken (recipe) — html/recipe.html
- Weekly planner (planner) — html/planner.html
- Shopping list (shopping) — html/shopping.html
- Pantry staples (staples) — html/staples.html
- About (about) — html/about.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
