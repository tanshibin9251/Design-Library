<?php $title = 'About'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>About</b></div><h1 style="font-family:var(--f-head);font-weight:800">About</h1></div></section><section class="sc-sec" style="padding-top:0"><div class="sc-box" style="max-width:640px"><p style="font:600 17px/2 var(--f-body)">Sugar &amp; Crumb is one baker, one oven and a lot of sunk cakes. Replace this with your story and a photo of your kitchen.</p></div></section>
<?php include 'includes/footer.php'; ?>
