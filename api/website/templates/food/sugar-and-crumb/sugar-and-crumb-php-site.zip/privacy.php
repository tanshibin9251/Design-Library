<?php $title = 'Privacy policy'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Privacy policy</b></div><h1 style="">Privacy policy</h1></div></section><section class="sc-sec" style="padding-top:20px"><div class="prose"><p>Replace with your privacy policy: what you collect, why, how long you keep it and how customers can ask for deletion.</p></div></section>
<?php include 'includes/footer.php'; ?>
