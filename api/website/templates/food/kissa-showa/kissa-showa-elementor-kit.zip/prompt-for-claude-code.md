# Build "Kissa Maruyo" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #4a2a1a · Secondary #b8873a · Text #3a2418 · Accent #2f8f78 · Surface #f7eed8 · Border #dcc9a0

## 2. Global Fonts
Headings: Kaisei Decol · Body: M PLUS Rounded 1c
H1 72px / H2 40px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 12px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Menu (menu) — html/menu.html
- Morning set (morning) — html/morning.html
- Roasted beans (beans) — html/beans.html
- Our story (story) — html/story.html
- Gallery (gallery) — html/gallery.html
- Notice board (news) — html/news.html
- Access & hours (access) — html/access.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
