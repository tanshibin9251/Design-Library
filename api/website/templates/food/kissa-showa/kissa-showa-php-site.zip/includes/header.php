<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Kissa Maruyo';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Kissa Maruyo</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="kissa-showa" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Kissa Maruyo — Showa-era coffee house, tokens only */
.ks-awning{height:30px;background:repeating-linear-gradient(90deg,var(--c-accent) 0 48px,var(--c-surface) 48px 96px);position:relative;border-bottom:3px solid var(--c-primary)}
.ks-awning::after{content:"";position:absolute;left:0;right:0;top:100%;height:24px;background:
 radial-gradient(circle at 24px 0,var(--c-accent) 23px,transparent 24px) 0 0/96px 24px,
 radial-gradient(circle at 72px 0,var(--c-surface) 23px,var(--c-primary) 23px 26px,transparent 26px) 0 0/96px 24px;z-index:2;pointer-events:none}
.ks-head{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:34px clamp(18px,4vw,60px) 14px;position:relative}
.ks-plate{display:flex;align-items:center;gap:14px;text-decoration:none;color:var(--c-primary);border:3px double var(--c-primary);padding:8px 20px;border-radius:14px;background:var(--c-surface)}
.ks-plate b{font:400 30px var(--f-head);letter-spacing:.1em;line-height:1}
.ks-plate small{display:block;font:500 10px var(--f-body);letter-spacing:.3em;color:var(--c-secondary);margin-top:4px}
.ks-tabs{display:flex;gap:6px;list-style:none;flex-wrap:wrap;justify-content:center}
.ks-tabs a{display:inline-flex;align-items:center;min-height:44px;padding:0 18px;border:2px solid var(--c-primary);border-radius:999px;text-decoration:none;font:500 14px var(--f-body);letter-spacing:.06em;color:var(--c-primary);background:var(--c-surface);transition:background .2s,color .2s}
.ks-tabs a:hover{background:var(--c-primary);color:var(--on-primary)}
.ks-tabs .more{position:relative}
.ks-tabs .dd{position:absolute;right:0;top:calc(100% + 8px);display:none;grid-template-columns:repeat(4,minmax(120px,1fr));gap:18px 28px;padding:22px 26px;background:var(--c-surface);border:3px double var(--c-primary);border-radius:14px;min-width:600px;z-index:60}
.ks-tabs .more:hover .dd,.ks-tabs .more:focus-within .dd{display:grid}
.ks-tabs .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.ks-tabs .dd a{display:block;border:0;border-radius:0;min-height:0;padding:5px 0;background:none;color:var(--c-text)}
.ks-tabs .dd a:hover{background:none;color:var(--c-accent)}
.ks-sign{display:grid;place-items:center;min-width:92px;min-height:44px;padding:0 14px;border-radius:8px;background:var(--c-primary);color:var(--on-primary);font:400 18px var(--f-head);letter-spacing:.12em}
.ks-sign.off{background:transparent;color:var(--c-secondary);border:2px dashed var(--c-secondary)}
.ks-m{display:none}.ks-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:600 12px var(--f-body);letter-spacing:.18em;border:2px solid var(--c-primary);border-radius:999px;padding:0 16px}
.ks-m summary::-webkit-details-marker{display:none}
.ks-m nav{position:absolute;left:12px;right:12px;top:100%;background:var(--c-surface);border:3px double var(--c-primary);border-radius:14px;padding:10px 18px;display:grid;z-index:60}
.ks-m nav a{padding:12px 4px;border-bottom:1px dotted var(--c-secondary);text-decoration:none;font:500 15px var(--f-body);min-height:44px}
@media(max-width:960px){.ks-head{flex-wrap:wrap}.ks-tabs{display:none}.ks-m{display:block;margin-left:auto}.ks-sign{order:3}}

.ks-sec{padding:var(--pad) clamp(20px,5vw,80px)}
.ks-hd{display:flex;align-items:center;gap:16px;margin-bottom:30px}
.ks-hd h2{font:400 clamp(26px,3.4vw,40px) var(--f-head);letter-spacing:.1em;color:var(--c-primary)}
.ks-hd::before,.ks-hd::after{content:"";flex:1;height:0;border-top:3px double var(--c-primary)}
.ks-hd::before{max-width:60px}
.ks-btn{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:.8em 2em;border-radius:999px;border:3px solid var(--c-primary);background:var(--c-primary);color:var(--on-primary);font:600 15px var(--f-body);letter-spacing:.1em;text-decoration:none;cursor:pointer;box-shadow:4px 4px 0 var(--c-accent);transition:transform .15s,box-shadow .15s}
.ks-btn:hover{transform:translate(2px,2px);box-shadow:2px 2px 0 var(--c-accent)}
.ks-btn.o{background:var(--c-surface);color:var(--c-primary)}
.ks-ph{position:relative;min-height:240px;border:3px solid var(--c-primary);border-radius:12px;background:
 radial-gradient(circle at 30% 30%,color-mix(in srgb,var(--c-surface) 55%,transparent) 0 10%,transparent 11%),
 repeating-linear-gradient(135deg,color-mix(in srgb,var(--c-secondary) 22%,var(--c-surface)) 0 12px,color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface)) 12px 24px)}
.ks-ph::after{content:attr(data-l);position:absolute;left:12px;bottom:10px;font:600 10px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-primary);background:var(--c-surface);padding:2px 8px;border-radius:999px}

.ks-hero{display:grid;grid-template-columns:1.05fr .95fr;gap:clamp(24px,5vw,80px);padding:clamp(30px,5vw,64px) clamp(20px,5vw,80px) var(--pad);align-items:center}
.ks-board{background:var(--c-surface);border:4px double var(--c-primary);border-radius:18px;padding:clamp(22px,3.4vw,44px);position:relative;box-shadow:8px 8px 0 color-mix(in srgb,var(--c-primary) 18%,transparent)}
.ks-board h1{font:400 clamp(34px,5vw,var(--h1)) var(--f-head);letter-spacing:.08em;line-height:1.25;color:var(--c-primary);margin-bottom:6px}
.ks-board .sub{font:500 13px var(--f-body);letter-spacing:.24em;color:var(--c-secondary);margin-bottom:24px;display:block}
.ks-it{display:flex;align-items:baseline;gap:10px;padding:9px 0;font:500 17px var(--f-body)}
.ks-it i{flex:1;border-bottom:3px dotted var(--c-secondary);transform:translateY(-4px);min-width:20px}
.ks-it b{font:600 17px var(--f-body);color:var(--c-primary);white-space:nowrap}
.ks-it small{display:block;font:400 12px var(--f-body);color:var(--c-secondary);letter-spacing:.06em}
.ks-stick{position:absolute;right:-18px;top:-26px;width:104px;height:104px;border-radius:50%;background:var(--c-accent);color:var(--on-accent);display:grid;place-items:center;text-align:center;font:400 15px/1.3 var(--f-head);letter-spacing:.06em;transform:rotate(12deg);border:3px solid var(--c-primary)}
.ks-today{margin-top:22px;border:2px dashed var(--c-primary);border-radius:12px;padding:14px 18px;display:grid;grid-template-columns:auto 1fr;gap:6px 16px;align-items:center;background:color-mix(in srgb,var(--c-accent) 10%,var(--c-surface))}
.ks-today span{font:600 11px var(--f-body);letter-spacing:.24em;color:var(--c-accent)}
.ks-today b{font:400 22px var(--f-head);letter-spacing:.08em;color:var(--c-primary)}
.ks-today em{grid-column:1/-1;font:400 14px var(--f-body);font-style:normal;color:var(--c-text);opacity:.85}
.ks-hero .ks-ph{aspect-ratio:4/5;min-height:300px;transform:rotate(1.4deg);box-shadow:8px 8px 0 var(--c-primary)}
@media(max-width:900px){.ks-hero{grid-template-columns:1fr}.ks-stick{right:10px;top:-30px}.ks-hero .ks-ph{aspect-ratio:16/10;transform:none}}

.ks-3{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(16px,2.4vw,30px)}
.ks-card{border:3px solid var(--c-primary);border-radius:16px;background:var(--c-surface);padding:26px 24px;display:grid;gap:10px;align-content:start;position:relative}
.ks-card h3{font:400 24px var(--f-head);letter-spacing:.08em;color:var(--c-primary)}
.ks-card .pr{font:700 20px var(--f-body);color:var(--c-accent)}
.ks-card p{font-size:15px;line-height:1.8;opacity:.85}
.ks-card .tag{position:absolute;right:16px;top:-14px;background:var(--c-accent);color:var(--on-accent);border:2px solid var(--c-primary);border-radius:999px;padding:2px 14px;font:700 12px var(--f-body);letter-spacing:.14em}
@media(max-width:800px){.ks-3{grid-template-columns:1fr}}
.ks-menu{display:grid;grid-template-columns:1fr 1fr;gap:0 clamp(30px,6vw,90px)}
.ks-menu h3{font:400 26px var(--f-head);letter-spacing:.14em;color:var(--c-primary);margin:30px 0 8px;padding-bottom:8px;border-bottom:3px solid var(--c-primary)}
@media(max-width:800px){.ks-menu{grid-template-columns:1fr}}
.ks-split{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:center}
.ks-split h2{font:400 clamp(28px,3.6vw,var(--h2)) var(--f-head);letter-spacing:.08em;color:var(--c-primary);margin-bottom:14px}
.ks-split p{line-height:2;max-width:46ch}
@media(max-width:800px){.ks-split{grid-template-columns:1fr}}
.ks-hours{width:100%;border-collapse:collapse;font:500 16px var(--f-body)}
.ks-hours td,.ks-hours th{padding:14px 8px;border-bottom:2px dotted var(--c-secondary);text-align:left}
.ks-hours th{font:400 18px var(--f-head);letter-spacing:.12em;color:var(--c-primary)}
.ks-hours tr.off td{color:var(--c-secondary)}
.ks-gal{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.ks-gal .ks-ph{min-height:0;aspect-ratio:1}.ks-gal .w{grid-column:span 2}
@media(max-width:700px){.ks-gal{grid-template-columns:1fr 1fr}}
.ks-note{display:grid;grid-template-columns:130px 1fr;gap:20px;padding:20px 0;border-bottom:2px dotted var(--c-secondary);text-decoration:none;align-items:baseline}
.ks-note time{font:600 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.ks-note h3{font:400 20px var(--f-head);letter-spacing:.06em}
@media(max-width:600px){.ks-note{grid-template-columns:1fr;gap:4px}}
.ks-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(40px,5vw,70px) clamp(20px,5vw,80px) 26px;margin-top:var(--pad)}
.ks-foot .top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(24px,6vw,100px)}
.ks-foot .big{font:400 32px var(--f-head);letter-spacing:.14em}
.ks-foot h4{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;opacity:.7;margin-bottom:10px;color:var(--on-primary)}
.ks-foot ul{list-style:none}.ks-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font-size:14px;opacity:.9;min-height:32px}
.ks-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ks-foot .copy{margin-top:34px;padding-top:16px;border-top:2px dotted color-mix(in srgb,var(--on-primary) 40%,transparent);font-size:12px;letter-spacing:.14em;opacity:.75}
@media(max-width:800px){.ks-foot .top{grid-template-columns:1fr}.ks-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(max-width:700px){.ks-sec{padding-left:18px;padding-right:18px}}
@media(prefers-reduced-motion:reduce){.ks-btn{transition:none}}
</style><div class="ks-awning"></div><header class="ks-head"><a class="ks-plate" href="index.php"><b>喫茶 まるよ</b><span><small>KISSA MARUYO</small></span></a><ul class="ks-tabs"><li><a href="menu.php">お品書き Menu</a></li><li><a href="morning.php">モーニング</a></li><li><a href="beans.php">珈琲豆 Beans</a></li><li><a href="access.php">場所 Access</a></li><li class="more"><a href="#" tabindex="0">他 More</a><div class="dd"><div><h4>Café</h4><a href="index.php">Home</a><a href="menu.php">Menu</a><a href="morning.php">Morning set</a><a href="beans.php">Roasted beans</a></div><div><h4>Shop</h4><a href="story.php">Our story</a><a href="gallery.php">Gallery</a><a href="news.php">Notice board</a></div><div><h4>Visit</h4><a href="access.php">Access & hours</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><span class="ks-sign" id="ks-sign">営業中</span><details class="ks-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="menu.php">Menu</a><a href="morning.php">Morning set</a><a href="beans.php">Roasted beans</a><a href="story.php">Our story</a><a href="gallery.php">Gallery</a><a href="news.php">Notice board</a><a href="access.php">Access & hours</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header>
<style>/* Export mobile sizing: let grid items shrink within their tracks. */@media(max-width:820px){.ks-hero>*{min-width:0}.ks-board{max-width:100%}.ks-hero p{overflow-wrap:break-word}}</style>
<script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
