# Build "Washoku Note" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #3f5a3a · Secondary #a3b18a · Text #2e2a25 · Accent #e0763a · Surface #fbf8ef · Border #d9d3c0

## 2. Global Fonts
Headings: Klee One · Body: Zen Maru Gothic
H1 76px / H2 40px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 4px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Recipes (recipes) — html/recipes.html
- Recipe: Teriyaki chicken (recipe) — html/recipe.html
- Miso soup builder (soup) — html/soup.html
- Basics: dashi & rice (basics) — html/basics.html
- Seasonal ingredients (seasonal) — html/seasonal.html
- About the notebook (about) — html/about.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
