<?php $title = 'Find us'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Find us</b></div><h1>Find us</h1></div></section><section class="cb-sec"><div class="in split"><div class="ph soft" data-l="Map (缺图)" style="aspect-ratio:4/3"></div><ul class="kv"><li><span>Address</span><b>12 Jalan Telawi 2, Bangsar</b></li><li><span>Hours</span><b>Daily 7am–5pm</b></li><li><span>WhatsApp</span><b>+60 12-300 4455</b></li></ul></div></section>
<?php include 'includes/footer.php'; ?>
