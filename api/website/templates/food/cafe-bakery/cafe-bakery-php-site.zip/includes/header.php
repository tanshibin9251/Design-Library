<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Crumb & Co';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Crumb &amp; Co</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Crumb & Co — tokens only */
.cb-strip{background:var(--c-primary);color:var(--on-primary);font:500 13px var(--f-body);text-align:center;padding:8px;letter-spacing:.04em}
.cb-head{background:var(--c-surface);border-bottom:2px dashed color-mix(in srgb,var(--c-primary) 40%,transparent);position:sticky;top:0;z-index:40}
.cb-head .in{max-width:var(--w);margin:auto;display:flex;align-items:center;justify-content:space-between;padding:12px 20px;gap:16px}
.cb-logo{font:400 30px var(--f-head);text-decoration:none;color:var(--c-primary);display:flex;align-items:center;gap:10px}
.cb-logo i{width:38px;height:38px;border-radius:50%;background:var(--c-accent);display:grid;place-items:center;color:var(--c-surface);font:400 18px var(--f-head);font-style:normal;rotate:-8deg}
.cb-head ul{display:flex;gap:6px;list-style:none;font:600 15px var(--f-body)}
.cb-head ul>li>a{display:block;padding:.5em .9em;border-radius:99px;text-decoration:none}
.cb-head ul>li>a:hover{background:color-mix(in srgb,var(--c-accent) 18%,var(--c-surface))}
.cb-btn{display:inline-block;background:var(--c-accent);color:var(--c-surface);padding:.8em 1.5em;border-radius:99px;font:700 15px var(--f-body);text-decoration:none;border:2px solid var(--c-primary);box-shadow:3px 3px 0 var(--c-primary)}
.cb-btn:hover{translate:1px 1px;box-shadow:2px 2px 0 var(--c-primary)}.cb-btn.o{background:var(--c-surface);color:var(--c-primary)}
.cb-hero{max-width:var(--w);margin:auto;padding:clamp(28px,5vw,64px) 20px;display:grid;grid-template-columns:1.1fr 1fr;gap:34px;align-items:center}
.cb-hero h1{font-size:clamp(46px,7.4vw,var(--h1));line-height:.98;color:var(--c-primary)}
.cb-hero h1 em{font-style:normal;color:var(--c-accent);display:inline-block;rotate:-2deg}
.cb-hero p{font:500 19px/1.55 var(--f-body);max-width:38ch;margin:18px 0 26px}
.cb-board{background:color-mix(in srgb,var(--c-text) 92%,var(--c-primary));color:var(--c-surface);border-radius:16px;border:10px solid color-mix(in srgb,var(--c-primary) 60%,var(--c-text));padding:22px 24px;transform:rotate(1.5deg);box-shadow:8px 10px 0 color-mix(in srgb,var(--c-primary) 30%,transparent)}
.cb-board h3{font:400 28px var(--f-head);color:var(--c-surface);border-bottom:2px dashed color-mix(in srgb,var(--c-surface) 40%,transparent);padding-bottom:8px;margin-bottom:10px}
.cb-board li{list-style:none;display:flex;justify-content:space-between;gap:12px;padding:7px 0;font:500 17px var(--f-body)}
.cb-board li s{opacity:.45}.cb-board li b{color:color-mix(in srgb,var(--c-accent) 60%,#fff)}
.cb-board small{display:block;opacity:.6;margin-top:8px;font-size:13px}
.cb-sec{padding:var(--pad) 20px}.cb-sec>.in{max-width:var(--w);margin:auto}
.cb-ttl{text-align:center;margin-bottom:36px}.cb-ttl small{font:700 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent)}.cb-ttl h2{margin-top:6px}
.cb-tags{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.cb-tag{background:var(--c-surface);border:2px solid var(--c-primary);border-radius:6px 6px 18px 18px;padding:0 0 16px;text-align:center;position:relative;margin-top:14px}
.cb-tag::before{content:"";position:absolute;left:50%;top:-14px;width:16px;height:16px;border-radius:50%;background:var(--c-surface);border:2px solid var(--c-primary);translate:-50% 0}
.cb-tag .ph{aspect-ratio:1;border-radius:4px 4px 0 0;border:0;border-bottom:2px solid var(--c-primary)}
.cb-tag h3{font:400 22px var(--f-head);margin:12px 8px 2px;color:var(--c-primary)}.cb-tag p{font-size:14px;opacity:.75;padding:0 12px}
.cb-tag .pr{display:inline-block;margin-top:8px;background:var(--c-accent);color:var(--c-surface);padding:.1em .8em;border-radius:99px;font:700 15px var(--f-body)}
.cb-menu{display:grid;grid-template-columns:1fr 1fr;gap:10px 56px}
.cb-it{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:baseline;padding:10px 0}
.cb-it b{font:400 21px var(--f-head);color:var(--c-primary)}.cb-it i{border-bottom:2px dotted color-mix(in srgb,var(--c-primary) 45%,transparent)}.cb-it span{font:700 17px var(--f-body)}
.cb-it p{grid-column:1/-1;margin:-4px 0 0;opacity:.7;font-size:14px}
.cb-slot{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 18px}
.cb-slot label{position:relative}.cb-slot input{position:absolute;opacity:0}
.cb-slot span{display:inline-block;padding:.55em 1em;border:2px solid var(--c-primary);border-radius:99px;font:700 14px var(--f-body);cursor:pointer}
.cb-slot input:checked+span{background:var(--c-primary);color:var(--on-primary)}.cb-slot input:focus-visible+span{outline:3px solid var(--c-accent)}
.cb-foot{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:800px){.cb-head ul{display:none}.cb-hero{grid-template-columns:1fr}.cb-tags{grid-template-columns:repeat(2,minmax(0,1fr))}.cb-menu{grid-template-columns:1fr}.cb-board{transform:none}}
html,body{overflow-x:clip}img,svg{max-width:100%}.cb-head .more{position:relative}.cb-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:18px;border:2px solid var(--c-primary);}.cb-head .more:hover .dd,.cb-head .more:focus-within .dd{display:grid}.cb-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.cb-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.cb-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3{color:var(--c-primary)}/* Crumb & Co photography edition — all photographs remain remote. */
.cb-photo{position:relative;isolation:isolate;overflow:hidden;margin:0;background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface));aspect-ratio:4/3}
.cb-photo img{position:relative;z-index:1;display:block;width:100%;height:100%;object-fit:cover}.cb-photo img[hidden]{display:none}
.cb-photo-fallback{position:absolute;inset:0;display:grid;place-content:center;padding:24px;text-align:center;color:var(--c-text);font:500 15px var(--f-body)}
.cb-photo-hero{padding-top:48px;padding-bottom:80px;gap:clamp(30px,5vw,80px);grid-template-columns:1fr 1fr}
.cb-photo-hero .eyebrow{color:var(--c-accent);font-weight:700;letter-spacing:.12em;font-size:12px}
.cb-photo-hero h1{max-width:10.5ch;font-size:clamp(48px,5.6vw,80px)}
.cb-actions{display:flex;flex-wrap:wrap;gap:12px}.cb-actions .cb-btn{min-height:48px;display:inline-flex;align-items:center;justify-content:center}
.cb-hero-note{border-top:1px dashed var(--c-border);margin-top:38px;padding-top:20px;max-width:360px}
.cb-hero-note>span{font:600 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-primary)}
.cb-hero-note p{font:400 16px/1.6 var(--f-body);margin:8px 0 0;color:var(--c-text)}
.cb-hero-visual{position:relative;min-width:0;padding-bottom:56px}.cb-hero-image{aspect-ratio:4/5;border-radius:48% 48% 14px 14px;max-height:660px}
.cb-hero-image img{object-position:50% 52%}.cb-photo-stamp{position:absolute;right:-10px;top:18px;z-index:3;border-radius:50%;width:112px;height:112px;display:grid;place-content:center;text-align:center;background:var(--c-accent);color:var(--on-accent);font:400 19px/1.2 var(--f-head);rotate:10deg;border:2px dashed var(--c-surface)}
.cb-hero-board{position:absolute;bottom:0;left:-24px;z-index:3;width:min(330px,84%);padding:16px 20px;border-width:6px;transform:rotate(-3deg);box-shadow:5px 6px 0 color-mix(in srgb,var(--c-primary) 20%,transparent)}
.cb-hero-board h3{font-size:22px}.cb-hero-board li{font-size:14px;padding:5px 0}.cb-hero-board a{display:inline-flex;align-items:center;min-height:44px;color:var(--c-surface);font:600 13px var(--f-body);text-underline-offset:4px}
.cb-tag .cb-photo{aspect-ratio:1;border-bottom:2px solid var(--c-primary);border-radius:4px 4px 0 0}.cb-tag::before{z-index:3}.cb-tag p{min-height:2.5em}
.cb-photo-hero+.cb-sec{background:color-mix(in srgb,var(--c-secondary) 7%,var(--c-surface))!important}
.cb-story-row{display:grid;grid-template-columns:1.2fr 1fr;align-items:center;gap:clamp(28px,6vw,90px)}.cb-story-image{aspect-ratio:4/3;border-radius:12px;box-shadow:10px 10px 0 color-mix(in srgb,var(--c-primary) 18%,var(--c-surface))}.cb-story-copy{max-width:460px}.cb-story-copy h2{font-size:clamp(36px,4.6vw,64px);margin:12px 0 20px}.cb-story-copy p{font-size:18px;line-height:1.7}.cb-story-copy small{display:block;font-size:12px;margin-top:16px;color:var(--c-text)}
.cb-text-link{display:inline-flex;align-items:center;min-height:44px;font:600 14px var(--f-body);color:var(--c-primary);text-underline-offset:5px}
.cb-btn:focus-visible,.cb-text-link:focus-visible{outline:3px solid var(--c-accent);outline-offset:5px}
.cb-photo-cta{position:relative;isolation:isolate;padding:clamp(40px,7vw,100px) 24px;min-height:480px;display:grid;place-items:center}.cb-cta-background{position:absolute;inset:0;z-index:-1;aspect-ratio:auto}.cb-cta-background img{object-position:50% 56%}.cb-cta-paper{padding:36px 42px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);box-shadow:7px 7px 0 var(--c-primary);text-align:center;max-width:480px;rotate:-2deg}.cb-cta-paper h2{font-size:clamp(38px,5vw,60px);margin:12px 0}.cb-cta-paper p{margin:14px 0 24px}
.cb-wide-photo{aspect-ratio:16/9;border-radius:12px;margin-bottom:32px}.cb-photo-pair{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:36px}.cb-photo-pair .cb-photo{aspect-ratio:4/3;border-radius:12px}
.cb-caption{font:400 12px/1.6 var(--f-body);color:var(--c-text);margin:12px 0 0}.cb-demo-note{padding:14px 18px;border:1px dashed var(--c-primary);font-size:14px;line-height:1.6;margin:20px 0;color:var(--c-text)}
.cb-order-layout{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:start}.cb-order-layout input,.cb-order-layout textarea{width:100%;min-height:44px}.cb-order-layout .fld{display:block;margin-bottom:18px}.cb-order-layout .fld>span{display:block;margin-bottom:6px}.cb-order-layout output{display:block;margin-top:20px;color:var(--c-primary);font-weight:600}.cb-order-layout output:empty{display:none}.cb-order-layout legend{margin-bottom:12px}.cb-order-layout fieldset{padding:0;border:0;min-width:0}.cb-order-layout .cb-slot input{width:1px;height:1px;min-height:0}.cb-order-layout .cb-slot label{position:relative;min-height:44px}.cb-order-layout .cb-slot span{min-height:44px;display:flex;align-items:center}
.cb-mobile-nav{display:none;position:relative}.cb-mobile-nav summary{list-style:none;cursor:pointer;border:1px solid var(--c-primary);border-radius:99px;padding:10px 16px;min-height:44px;font:600 14px var(--f-body);color:var(--c-primary)}.cb-mobile-nav summary::-webkit-details-marker{display:none}.cb-mobile-nav nav{position:absolute;right:0;top:calc(100% + 12px);width:min(290px,calc(100vw - 32px));padding:12px 20px;background:var(--c-surface);border:2px solid var(--c-primary);border-radius:16px;box-shadow:4px 4px 0 var(--c-primary)}.cb-mobile-nav nav a{display:flex;align-items:center;min-height:44px;border-bottom:1px dashed var(--c-border);color:var(--c-text);font:500 16px var(--f-body);text-decoration:none}
.cb-credits{margin-top:24px;border-top:1px solid currentColor;padding-top:14px;font:400 13px/1.7 var(--f-body)}.cb-credits summary{min-height:44px;cursor:pointer;display:list-item}.cb-credits a{color:inherit;text-underline-offset:3px}.cb-credits ul{display:flex;flex-wrap:wrap;gap:8px 20px;margin-top:12px}.cb-credits p{max-width:80ch}
@media(max-width:800px){.cb-mobile-nav{display:block}.cb-head .in>.cb-btn{display:none}.cb-head .in{gap:10px}.cb-photo-hero{grid-template-columns:1fr;padding-top:30px;padding-bottom:48px}.cb-photo-hero h1{max-width:none;font-size:clamp(42px,10.4vw,64px)}.cb-hero-note{display:none}.cb-hero-visual{max-width:560px;width:100%;margin:auto;padding:0 0 48px 12px}.cb-hero-image{max-height:580px}.cb-hero-board{left:0;width:min(300px,85%)}.cb-photo-stamp{right:0;width:96px;height:96px;font-size:17px}.cb-tag h3{font-size:20px}.cb-tag p{font-size:14px;min-height:3em}.cb-story-row,.cb-order-layout{grid-template-columns:1fr}.cb-cta-paper{padding:26px 24px;rotate:0}.cb-photo-cta{min-height:440px}.cb-foot .cols{grid-template-columns:1fr 1fr!important;gap:28px}.cb-foot .cols>div:first-child{grid-column:1/-1}.cb-strip{font-size:12px}.cb-sec{padding-top:52px;padding-bottom:52px}.cb-photo-pair{gap:12px}}
@media(prefers-reduced-motion:reduce){.cb-btn:hover{translate:none}}


/* Footer: explicit grid and text colors; independent of shared .foot styles. */
.cb-foot{background:var(--c-primary);color:var(--on-primary);padding:0;border-top:1px solid color-mix(in srgb,var(--on-primary) 16%,transparent)}
.cb-footer-inner{max-width:var(--w);margin:0 auto;padding:clamp(40px,5vw,72px) 24px 18px;box-sizing:border-box}
.cb-footer-grid{display:grid;grid-template-columns:minmax(0,1.8fr) repeat(2,minmax(0,1fr));gap:clamp(28px,5vw,80px);align-items:start;padding-bottom:40px}
.cb-footer-brand{max-width:360px;min-width:0}.cb-footer-logo{display:inline-flex;align-items:center;gap:10px;color:var(--on-primary);font:400 30px/1.15 var(--f-head);text-decoration:none;min-height:44px}
.cb-footer-logo>span{display:grid;place-items:center;flex:none;width:38px;height:38px;border-radius:50%;background:var(--c-accent);color:var(--on-accent);font:400 18px var(--f-head);rotate:-8deg}
.cb-foot .cb-footer-message{font:400 25px/1.3 var(--f-head);color:var(--on-primary);margin:22px 0 12px;letter-spacing:-.02em}
.cb-foot .cb-footer-description,.cb-foot .cb-footer-address{font:400 15px/1.7 var(--f-body);color:var(--on-primary);margin:0;opacity:.85}.cb-foot .cb-footer-address{margin-top:16px;font-size:13px;opacity:.72}
.cb-foot .cb-footer-nav h2{font:600 12px/1.4 var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--on-primary);margin:12px 0 20px}
.cb-foot .cb-footer-nav ul{display:grid;gap:0;list-style:none;margin:0;padding:0}.cb-foot .cb-footer-nav li{list-style:none;margin:0;padding:0}
.cb-foot .cb-footer-nav a{display:inline-flex;align-items:center;min-height:44px;color:var(--on-primary);font:400 16px/1.5 var(--f-body);text-decoration:none;text-underline-offset:5px}
.cb-foot .cb-footer-nav a:hover,.cb-foot .cb-footer-bottom>a:hover{text-decoration:underline}.cb-foot a:focus-visible,.cb-foot summary:focus-visible{outline:2px solid var(--on-primary);outline-offset:4px;border-radius:3px}
.cb-footer-bottom{display:flex;align-items:center;justify-content:space-between;gap:16px;border-top:1px dashed color-mix(in srgb,var(--on-primary) 35%,transparent);padding:15px 0 0}
.cb-foot .cb-footer-bottom p{font:400 12px/1.7 var(--f-body);margin:0;color:var(--on-primary)}.cb-footer-bottom p>span{opacity:.7}.cb-footer-bottom>a{display:inline-flex;align-items:center;min-height:44px;color:var(--on-primary);font:400 13px var(--f-body);text-decoration:none}
.cb-foot .cb-credits{margin:0;padding:0;border:0;color:var(--on-primary);font-size:12px}.cb-foot .cb-credits summary{padding:6px 0;min-height:44px;box-sizing:border-box;align-content:center;opacity:.75}.cb-foot .cb-credits p{color:var(--on-primary);margin:10px 0;max-width:85ch}.cb-foot .cb-credits ul{list-style:none;padding:0;gap:4px 20px}.cb-foot .cb-credits li{list-style:none}.cb-foot .cb-credits a{display:inline-flex;align-items:center;min-height:44px}
@media(max-width:800px){.cb-footer-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:28px 24px;padding-bottom:28px}.cb-footer-brand{grid-column:1/-1;max-width:none}.cb-foot .cb-footer-message{margin-top:18px;font-size:24px}.cb-foot .cb-footer-nav h2{margin:0 0 12px}.cb-footer-inner{padding:40px 20px 12px}.cb-footer-logo{font-size:28px}.cb-foot .cb-footer-nav a{font-size:15px}.cb-footer-bottom{flex-wrap:wrap;gap:2px 16px}.cb-footer-bottom p{flex:1 1 200px}}
</style><div class="cb-strip">Fresh from the oven at 6:30am · Sold out? Order ahead and never miss your loaf</div><header class="cb-head"><div class="in"><a class="cb-logo" href="index.php"><i>C</i>Crumb &amp; Co</a><ul><li><a href="menu.php">Menu</a></li><li><a href="bakes.php">Today’s bakes</a></li><li><a href="catering.php">Catering</a></li><li><a href="story.php">Story</a></li><li class="more"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Café</h4><a href="index.php">Home</a><a href="menu.php">Menu</a><a href="bakes.php">Today’s bakes</a><a href="order.php">Order ahead</a><a href="catering.php">Catering</a></div><div><h4>Visit</h4><a href="story.php">Our story</a><a href="visit.php">Find us</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="cb-btn" href="order.php">Order ahead</a><details class="cb-mobile-nav"><summary>Menu</summary><nav aria-label="Café navigation"><a href="index.php">Home</a><a href="menu.php">Food &amp; coffee</a><a href="bakes.php">Today’s bakes</a><a href="order.php">Order ahead</a><a href="catering.php">Catering</a><a href="story.php">Our story</a><a href="visit.php">Find us</a><a href="faq.php">FAQ</a></nav></details></div></header>

<main>
