</main>
<footer class="cb-foot">
  <div class="cb-footer-inner">
    <div class="cb-footer-grid">
      <div class="cb-footer-brand">
        <a class="cb-footer-logo" href="index.php" aria-label="Crumb and Co, home"><span aria-hidden="true">C</span>Crumb &amp; Co</a>
        <p class="cb-footer-message">A good morning.<br>A little slower.</p>
        <p class="cb-footer-description">Sourdough, buttery croissants<br>and a proper cup of coffee.</p>
        <p class="cb-footer-address">12 Jalan Telawi, Bangsar<br>Sample café location</p>
      </div>
      <nav class="cb-footer-nav" aria-label="Café links">
        <h2>At the café</h2>
        <ul>
          <li><a href="menu.php">Food &amp; coffee</a></li>
          <li><a href="bakes.php">Today’s bakes</a></li>
          <li><a href="order.php">Order ahead</a></li>
          <li><a href="catering.php">Catering</a></li>
        </ul>
      </nav>
      <nav class="cb-footer-nav" aria-label="Visit links">
        <h2>Come say hello</h2>
        <ul>
          <li><a href="story.php">Our story</a></li>
          <li><a href="visit.php">Find us</a></li>
          <li><a href="faq.php">Questions &amp; answers</a></li>
        </ul>
      </nav>
    </div>
    <div class="cb-footer-bottom"><p>© 2026 Crumb &amp; Co. <span>Template demo.</span></p><a href="privacy.php">Privacy policy</a></div>
    <details class="cb-credits"><summary>Illustrative photography &amp; credits</summary><p>Stock images illustrate the layout, not the actual café, staff or exact products. Photos remain hosted remotely and need an internet connection. Replace with your own photography for a real business.</p><ul><li><a href="https://unsplash.com/photos/latte-croissant-and-book-on-cafe-table-1k7TnX5GAww" target="_blank" rel="noopener noreferrer">Rizky Subagja</a></li><li><a href="https://unsplash.com/photos/a-stack-of-four-pieces-of-bread-sitting-on-top-of-a-table-U9-0JVdjCVo" target="_blank" rel="noopener noreferrer">Caramel</a></li><li><a href="https://unsplash.com/photos/a-close-up-of-a-croissant-on-a-white-surface-VgsizSk7py0" target="_blank" rel="noopener noreferrer">Olga Petnyunene</a></li><li><a href="https://unsplash.com/photos/croissants-on-display-TG77ANwm3MQ" target="_blank" rel="noopener noreferrer">Mimi Thian</a></li><li><a href="https://unsplash.com/photos/cup-of-cappuccino-2y4tsj5iouQ" target="_blank" rel="noopener noreferrer">Joe Hepburn</a></li><li><a href="https://unsplash.com/photos/a-bakery-and-coffee-shops-interior-is-shown-iTD5w0VxnpQ" target="_blank" rel="noopener noreferrer">Firda Faradiba</a></li><li><a href="https://unsplash.com/photos/baker-scoring-dough-with-a-razor-blade-t51-WQwU2z4" target="_blank" rel="noopener noreferrer">Diego Arenas de Rodrigo</a></li><li><a href="https://unsplash.com/photos/a-decadent-chocolate-cake-with-slices-on-plates-cAy6uai7l5U" target="_blank" rel="noopener noreferrer">Just Capturing It</a></li></ul><p>Free collection photographs used under the <a href="https://unsplash.com/license" target="_blank" rel="noopener noreferrer">Unsplash License</a>. No original photo files are included in downloads.</p></details>
  </div>
</footer>

</body></html>
