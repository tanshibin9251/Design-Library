<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="cb-sec"><div class="in"><div class="faq"><details open><summary>Do you do gluten-free?</summary><p>One loaf a day, baked separately. Reserve it.</p></details><details><summary>Can I bring my dog?</summary><p>On the patio, yes.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
