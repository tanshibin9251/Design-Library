<?php $title = 'Our story'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Our story</b></div><h1>Our story</h1></div></section><section class="cb-sec"><div class="in split"><div class="ph soft" data-l="Bakers (缺图)" style="aspect-ratio:4/3"></div><div class="prose"><p class="lead">Two friends, one oven, and a starter named Gerald.</p><p>Replace with your story.</p></div></div></section>
<?php include 'includes/footer.php'; ?>
