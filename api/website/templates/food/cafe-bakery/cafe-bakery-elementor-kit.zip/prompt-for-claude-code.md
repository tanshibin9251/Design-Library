# Build "Crumb & Co" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #5c6b1e · Secondary #8a5a2b · Text #2a2418 · Accent #d9482b · Surface #fbf4df · Border #d8cfa9

## 2. Global Fonts
Headings: Caprasimo · Body: Outfit
H1 86px / H2 46px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 14px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Menu (menu) — html/menu.html
- Today’s bakes (bakes) — html/bakes.html
- Order ahead (order) — html/order.html
- Catering (catering) — html/catering.html
- Our story (story) — html/story.html
- Find us (visit) — html/visit.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
