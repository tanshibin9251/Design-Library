# Hope Foundation

Exported from Design Library · 18 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, What We Do, Single Programme, Donate, Contact, Testimonials, Team, Impact, Single Impact story, Gallery, Stories, Single post, FAQ, Get Involved, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
