<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Hope Foundation';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Hope Foundation</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.hf-nav{display:flex;list-style:none;align-items:center;gap:4px}
.hf-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.hf-nav .more{position:relative}
.hf-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.hf-nav .more:hover .dd,.hf-nav .more:focus-within .dd{display:grid}
.hf-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.hf-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.hf-m{display:none;position:relative;margin-left:auto}
.hf-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.hf-m summary::-webkit-details-marker{display:none}
.hf-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.hf-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.hf-nav{display:none}.hf-m{display:block}}
.hf-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.hf-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.hf-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.hf-foot ul{list-style:none}.hf-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.hf-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.hf-foot .top{grid-template-columns:1fr}.hf-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Hope Foundation v2 — charity site with a 'what your gift does' picker and a campaign thermometer */
.hf-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:80px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:1px solid var(--c-border)}
.hf-logo{font:700 26px var(--f-head);color:var(--c-primary);text-decoration:none;display:flex;align-items:center;gap:10px}
.hf-logo i{width:12px;height:12px;border-radius:50%;background:var(--c-accent);box-shadow:-9px 7px 0 var(--c-secondary),9px 7px 0 var(--c-primary);display:inline-block;margin:0 10px}
.hf-nav{margin-left:auto}.hf-nav a{padding:0 14px;font:600 16px var(--f-body);color:var(--c-text)}.hf-nav a:hover{color:var(--c-accent)}
.hf-cta{background:var(--c-accent);color:var(--on-accent)!important;border-radius:6px;padding:0 20px!important;margin-left:8px;font-weight:700!important}
.hf-sec{padding:clamp(36px,5vw,76px) clamp(14px,4vw,56px)}
.hf-hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,5vw,72px);align-items:center;padding:clamp(30px,5vw,72px) clamp(14px,4vw,56px)}
@media(max-width:900px){.hf-hero{grid-template-columns:1fr}}
.hf-hero h1{font:700 clamp(38px,5.4vw,var(--h1))/1.1 var(--f-head);color:var(--c-primary)}
.hf-hero h1 em{font-style:italic;color:var(--c-accent)}
.hf-hero p{font:400 19px/1.75 var(--f-body);margin:16px 0 0;max-width:40ch}
.hf-give{background:var(--c-primary);color:var(--on-primary);border-radius:12px;padding:clamp(20px,2.6vw,34px)}
.hf-give h2{font:700 26px var(--f-head);color:var(--on-primary);margin-bottom:14px}
.hf-amt{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px}
.hf-amt button{min-height:52px;border:2px solid var(--on-primary);background:transparent;color:var(--on-primary);font:700 17px var(--f-body);cursor:pointer;border-radius:6px}
.hf-amt button[aria-pressed=true]{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.hf-tg{display:flex;gap:6px;margin-bottom:14px}.hf-tg button{flex:1;min-height:44px;border:0;background:color-mix(in srgb,var(--on-primary) 16%,transparent);color:var(--on-primary);font:700 14px var(--f-body);cursor:pointer}
.hf-tg button[aria-pressed=true]{background:var(--on-primary);color:var(--c-primary)}
.hf-out{background:var(--c-surface);color:var(--c-text);border-radius:8px;padding:16px 18px;font:500 17px/1.6 var(--f-body);min-height:92px}
.hf-out b{font:700 24px var(--f-head);color:var(--c-primary)}
.hf-go{display:inline-flex;margin-top:14px;min-height:52px;padding:0 28px;align-items:center;background:var(--c-accent);color:var(--on-accent);font:700 17px var(--f-body);text-decoration:none;border-radius:6px}
.hf-th{border:1px solid var(--c-border);border-radius:12px;padding:clamp(20px,3vw,36px);display:grid;gap:16px}
.hf-th .bar{height:26px;background:var(--c-border);border-radius:99px;overflow:hidden}.hf-th .bar i{display:block;height:100%;width:var(--p);background:linear-gradient(90deg,var(--c-secondary),var(--c-accent))}
.hf-th .n{display:flex;justify-content:space-between;font:700 15px var(--f-body)}.hf-th .n b{font:700 32px var(--f-head);color:var(--c-primary)}
.hf-st{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.hf-st>div{border-top:4px solid var(--c-accent);padding-top:16px}
.hf-st b{font:700 clamp(32px,4vw,52px)/1 var(--f-head);color:var(--c-primary);display:block}.hf-st span{font:500 16px/1.6 var(--f-body)}
@media(max-width:800px){.hf-st{grid-template-columns:1fr}}
.hf-h{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:22px;flex-wrap:wrap;gap:12px}
.hf-h h2{font:700 clamp(26px,3.4vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.hf-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.hf-foot .big{font:700 30px var(--f-head)}
.hf .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.hf .pagehead h1{max-width:none}.hf .card,.hf .scard,.hf .qcard,.hf .pcard,.hf .person{background:color-mix(in srgb,var(--c-secondary) 14%,var(--c-surface));border:0;box-shadow:none}.hf .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.hf .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.hf .svc{display:block;border-top:2px solid var(--c-primary);counter-reset:sv}
.hf .scard{display:grid;grid-template-columns:56px minmax(0,1.1fr) minmax(0,1.7fr) auto;gap:6px 24px;align-items:baseline;padding:22px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;counter-increment:sv;transition:padding .2s}
.hf .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.hf .scard .ph{display:none}.hf .scard .b{display:contents}
.hf .scard h3{font-size:clamp(20px,2.2vw,28px)}.hf .scard p{margin:0;opacity:.8}
.hf .scard .m{display:flex;flex-direction:column;align-items:flex-end;gap:2px;font:600 13px var(--f-body);white-space:nowrap}
.hf .scard:hover{padding-left:14px}
@media(max-width:760px){.hf .scard{grid-template-columns:36px 1fr}.hf .scard p,.hf .scard .m{grid-column:2;align-items:flex-start}}

.hf .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:30px 20px}
.hf .person{text-align:center;background:none;border:0;box-shadow:none;padding:0}
.hf .person .ph{aspect-ratio:1!important;border-radius:50%!important;margin:0 auto 12px;max-width:190px}

.hf .qgrid{display:block}.hf .qgrid.mt{margin-top:0}
.hf .qcard{max-width:900px;margin:0 auto;padding:clamp(24px,4vw,48px) 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.hf .qcard blockquote{font-size:clamp(22px,3vw,36px);line-height:1.3;margin:10px 0 18px}

.hf .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.hf .masonry .mi{margin:0}.hf .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.hf .masonry{grid-template-columns:1fr 1fr}}

.hf .art .ph,.hf .feat .ph{display:none}
.hf .art,.hf .feat{border-left:4px solid var(--c-accent);padding:4px 0 4px 20px;margin-bottom:22px}
.hf .faq summary{font-size:clamp(20px,2.4vw,30px);padding:10px 0}.hf .faq details{padding:14px 0}.hf .faq p{font-size:18px;max-width:60ch}

.hf .pricing{display:grid;grid-template-columns:1fr;max-width:760px;gap:14px}
.hf .pricing .card{transform:none!important}
.hf .split{display:block;max-width:760px;margin:0 auto}.hf .cinfo{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:34px}
.hf .sec.dark{background:var(--c-accent);color:var(--on-accent)}.hf .sec.dark h2,.hf .sec.dark p{color:var(--on-accent)}.hf .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.hf .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.hf .steps>div{border:0;padding:0 0 26px;position:relative}.hf .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.hf .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.hf .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.hf .tl>div:last-child{border-right:0}
.hf .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.hf .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.hf .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.hf .vals .card:last-child{border-right:0}
@media(max-width:700px){.hf .vals{grid-template-columns:1fr}.hf .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><header class="hf-head"><a class="hf-logo" href="index.php"><i></i>Hope Foundation</a><ul class="hf-nav"><li><a href="projects.php">Our work</a></li><li><a href="blog.php">Stories</a></li><li><a href="team.php">People</a></li><li><a href="faq.php">Questions</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">What We Do</a><a href="service.php">Single Programme</a><a href="pricing.php">Donate</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Impact</a><a href="project.php">Single Impact story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Stories</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="careers.php">Get Involved</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="hf-cta" href="contact.php">Give today</a></li></ul><details class="hf-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">What We Do</a><a href="service.php">Single Programme</a><a href="pricing.php">Donate</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Impact</a><a href="project.php">Single Impact story</a><a href="gallery.php">Gallery</a><a href="blog.php">Stories</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="careers.php">Get Involved</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="hf">
<main>
