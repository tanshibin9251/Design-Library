# Build "Hope Foundation" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2b2f6e · Secondary #f7d6c4 · Text #2a2a3a · Accent #ef7b45 · Surface #fffaf5 · Border #eadfd6

## 2. Global Fonts
Headings: Crimson Text · Body: Cabin
H1 72px / H2 42px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- What We Do (services) — html/services.html
- Single Programme (service) — html/service.html
- Donate (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Impact (projects) — html/projects.html
- Single Impact story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Stories (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Get Involved (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
