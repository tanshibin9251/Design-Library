# Build "Green Acre Farm" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #3d2b1f · Secondary #ffb703 · Text #3d2b1f · Accent #8ac926 · Surface #faf6ea · Border #e4dcc0

## 2. Global Fonts
Headings: Rokkitt · Body: Catamaran
H1 88px / H2 46px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 6px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Farm Boxes (services) — html/services.html
- Single Box (service) — html/service.html
- Farm Box Plans (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Farm Shop (shop) — html/shop.html
- Single Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- From the Farm (projects) — html/projects.html
- Single Farm story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Delivery days (schedule) — html/schedule.html
- Visit the farm (booking) — html/booking.html
- Delivery areas (service-areas) — html/service-areas.html
- Gift a box (gift-cards) — html/gift-cards.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
