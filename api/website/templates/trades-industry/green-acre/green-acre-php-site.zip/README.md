# Green Acre Farm

Exported from Design Library · 26 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Farm Boxes, Single Box, Farm Box Plans, Contact, Farm Shop, Single Product, Cart, Checkout, Testimonials, Team, From the Farm, Single Farm story, Gallery, Journal, Single post, FAQ, Delivery days, Visit the farm, Delivery areas, Gift a box, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
