<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Green Acre Farm';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Green Acre Farm</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.ga-nav{display:flex;list-style:none;align-items:center;gap:4px}
.ga-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.ga-nav .more{position:relative}
.ga-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.ga-nav .more:hover .dd,.ga-nav .more:focus-within .dd{display:grid}
.ga-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.ga-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.ga-m{display:none;position:relative;margin-left:auto}
.ga-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.ga-m summary::-webkit-details-marker{display:none}
.ga-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.ga-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.ga-nav{display:none}.ga-m{display:block}}
.ga-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.ga-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ga-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.ga-foot ul{list-style:none}.ga-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.ga-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.ga-foot .top{grid-template-columns:1fr}.ga-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Green Acre Farm v2 — farm shop with a seasonal box builder and harvest calendar, tokens only */
.ga-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:80px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:4px double var(--c-primary)}
.ga-logo{font:700 30px var(--f-head);color:var(--c-primary);text-decoration:none;display:flex;align-items:center;gap:10px;letter-spacing:.01em}
.ga-logo i{width:34px;height:34px;border-radius:50% 4px 50% 4px;background:var(--c-accent);border:3px solid var(--c-primary);transform:rotate(-12deg);display:inline-block}
.ga-nav{margin-left:auto}.ga-nav a{padding:0 14px;font:600 17px var(--f-body);color:var(--c-text)}.ga-nav a:hover{color:var(--c-primary);text-decoration:underline;text-decoration-color:var(--c-accent);text-decoration-thickness:4px;text-underline-offset:6px}
.ga-cta{background:var(--c-accent);color:var(--on-accent)!important;border-radius:6px;margin-left:8px;padding:0 20px!important;font-weight:700!important}
.ga-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.ga-hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,60px);align-items:start;padding:clamp(28px,5vw,64px) clamp(14px,4vw,56px)}
@media(max-width:900px){.ga-hero{grid-template-columns:1fr}}
.ga-hero h1{font:700 clamp(40px,6.4vw,var(--h1))/1.02 var(--f-head);color:var(--c-primary)}
.ga-hero h1 em{font-style:normal;background:linear-gradient(transparent 60%,var(--c-accent) 60% 90%,transparent 90%)}
.ga-hero p{font:500 19px/1.7 var(--f-body);margin:16px 0 22px;max-width:38ch}
.ga-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 26px;border-radius:6px;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);text-decoration:none;border:3px solid var(--c-primary);cursor:pointer}
.ga-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}.ga-btn.o{background:transparent;color:var(--c-primary)}
.ga-bx{border:4px solid var(--c-primary);background:var(--c-surface);padding:clamp(16px,2.2vw,28px);position:relative;box-shadow:inset 0 0 0 4px var(--c-surface),inset 0 0 0 6px var(--c-primary)}
.ga-bx h2{font:700 26px var(--f-head);color:var(--c-primary);margin-bottom:10px}
.ga-st{margin-bottom:14px}.ga-st b{display:block;font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px;filter:brightness(.7)}
.ga-op{display:flex;gap:6px;flex-wrap:wrap}
.ga-op button{min-height:46px;padding:0 16px;border:3px solid var(--c-primary);border-radius:6px;background:transparent;color:var(--c-primary);font:700 15px var(--f-body);cursor:pointer}
.ga-op button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.ga-in{border:3px dashed var(--c-primary);padding:12px 14px;margin:10px 0;font:600 15px/1.7 var(--f-body);min-height:90px}
.ga-in b{font:700 13px var(--f-body);letter-spacing:.12em;text-transform:uppercase;display:block;margin-bottom:2px}
.ga-tot{display:flex;justify-content:space-between;align-items:baseline;gap:10px;flex-wrap:wrap}.ga-tot b{font:700 36px var(--f-head);color:var(--c-primary)}
.ga-h{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:20px;flex-wrap:wrap;gap:10px;border-bottom:4px double var(--c-primary);padding-bottom:6px}
.ga-h h2{font:700 clamp(28px,3.8vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.ga-cal{display:grid;gap:0;border:3px solid var(--c-primary);background:var(--c-surface);overflow:auto}
.ga-cr{display:grid;grid-template-columns:130px repeat(12,minmax(34px,1fr));min-width:560px;align-items:stretch;border-bottom:1px solid var(--c-border)}
.ga-cr:last-child{border-bottom:0}
.ga-cr>span{display:grid;place-items:center;min-height:42px;font:700 12px var(--f-body)}.ga-cr>b{padding:10px 12px;font:700 15px var(--f-head);display:flex;align-items:center}
.ga-cr.hd>span{background:var(--c-primary);color:var(--on-primary);font-size:11px;letter-spacing:.06em}.ga-cr.hd>span.now{background:var(--c-accent);color:var(--on-accent)}
.ga-cr>span.on{background:var(--c-secondary);border-left:1px solid var(--c-surface)}.ga-cr>span.now.on{background:var(--c-accent)}
.ga-cr>span.now{box-shadow:inset 3px 0 0 var(--c-primary),inset -3px 0 0 var(--c-primary)}
.ga-vl{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.ga-vl>div{border-top:6px solid var(--c-accent);padding-top:14px}
.ga-vl b{font:700 24px var(--f-head);color:var(--c-primary);display:block}.ga-vl span{font:500 16px/1.7 var(--f-body)}
@media(max-width:800px){.ga-vl{grid-template-columns:1fr}}
.ga-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.ga-foot .big{font:700 34px var(--f-head)}
.ga .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.ga .pagehead h1{max-width:none}.ga .card,.ga .scard,.ga .qcard,.ga .pcard,.ga .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.ga .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.ga .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.ga .svc{display:grid;grid-template-columns:1fr;gap:clamp(18px,3vw,36px)}
.ga .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:0;align-items:stretch}
.ga .scard:nth-child(even) .ph{order:2}
.ga .scard .ph{aspect-ratio:auto!important;min-height:220px;height:100%;border-radius:inherit}
.ga .scard .b{padding:clamp(20px,3vw,40px);align-self:center}
@media(max-width:760px){.ga .scard{grid-template-columns:1fr}.ga .scard:nth-child(even) .ph{order:0}}

.ga .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:30px 20px}
.ga .person{text-align:center;background:none;border:0;box-shadow:none;padding:0}
.ga .person .ph{aspect-ratio:1!important;border-radius:50%!important;margin:0 auto 12px;max-width:190px}

.ga .qgrid{display:block}.ga .qgrid.mt{margin-top:0}
.ga .qcard{max-width:900px;margin:0 auto;padding:clamp(24px,4vw,48px) 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.ga .qcard blockquote{font-size:clamp(22px,3vw,36px);line-height:1.3;margin:10px 0 18px}

.ga .masonry{display:grid!important;grid-template-columns:repeat(4,1fr);grid-auto-rows:150px;gap:8px;columns:auto}
.ga .masonry .mi{margin:0;overflow:hidden}.ga .masonry .mi .ph{aspect-ratio:auto!important;height:100%}
.ga .masonry .mi:nth-child(5n+1){grid-column:span 2;grid-row:span 2}.ga .masonry .mi:nth-child(7n+3){grid-row:span 2}
.ga .masonry .mi h3,.ga .masonry .mi .muted{display:none}
@media(max-width:700px){.ga .masonry{grid-template-columns:1fr 1fr}}

.ga .art .ph,.ga .feat .ph{display:none}
.ga .art,.ga .feat{border-left:4px solid var(--c-accent);padding:4px 0 4px 20px;margin-bottom:22px}
.ga .faq{max-width:none;columns:2 340px;column-gap:clamp(24px,5vw,72px)}.ga .faq details{break-inside:avoid}

.ga .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.ga .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.ga .pricing .card.hl h3,.ga .pricing .card.hl .amt{color:var(--c-primary)!important}.ga .pricing .card.hl li::before{color:var(--c-accent)!important}

.ga .cinfo{display:block;border-top:2px solid var(--c-primary)}
.ga .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.ga .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.ga .cinfo .card p{margin:0}
.ga .sec.dark{background:var(--c-accent);color:var(--on-accent)}.ga .sec.dark h2,.ga .sec.dark p{color:var(--on-accent)}.ga .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.ga .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.ga .steps>div{border:0;padding:0 0 26px;position:relative}.ga .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.ga .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.ga .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.ga .tl>div:last-child{border-right:0}
.ga .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.ga .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.ga .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.ga .vals .card:last-child{border-right:0}
@media(max-width:700px){.ga .vals{grid-template-columns:1fr}.ga .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><header class="ga-head"><a class="ga-logo" href="index.php"><i></i>Green Acre Farm</a><ul class="ga-nav"><li><a href="shop.php">Veg boxes</a></li><li><a href="schedule.php">Harvest</a></li><li><a href="service-areas.php">Delivery</a></li><li><a href="gift-cards.php">Gifts</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Farm Boxes</a><a href="service.php">Single Box</a><a href="pricing.php">Farm Box Plans</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Farm Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">From the Farm</a><a href="project.php">Single Farm story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="schedule.php">Delivery days</a><a href="booking.php">Visit the farm</a><a href="service-areas.php">Delivery areas</a><a href="gift-cards.php">Gift a box</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="ga-cta" href="booking.php">Visit the farm</a></li></ul><details class="ga-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Farm Boxes</a><a href="service.php">Single Box</a><a href="pricing.php">Farm Box Plans</a><a href="contact.php">Contact</a><a href="shop.php">Farm Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">From the Farm</a><a href="project.php">Single Farm story</a><a href="gallery.php">Gallery</a><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="schedule.php">Delivery days</a><a href="booking.php">Visit the farm</a><a href="service-areas.php">Delivery areas</a><a href="gift-cards.php">Gift a box</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="ga">
<main>
