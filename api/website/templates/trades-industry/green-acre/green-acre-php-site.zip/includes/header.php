<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Green Acre Farm';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Green Acre Farm</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="green-acre" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
.ga-nav{display:flex;list-style:none;align-items:center;gap:4px}
.ga-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.ga-nav .more{position:relative}
.ga-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.ga-nav .more:hover .dd,.ga-nav .more:focus-within .dd{display:grid}
.ga-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.ga-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.ga-m{display:none;position:relative;margin-left:auto}
.ga-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.ga-m summary::-webkit-details-marker{display:none}
.ga-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.ga-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.ga-nav{display:none}.ga-m{display:block}}
.ga-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.ga-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ga-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.ga-foot ul{list-style:none}.ga-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.ga-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.ga-foot .top{grid-template-columns:1fr}.ga-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Green Acre Farm v2 — farm shop with a seasonal box builder and harvest calendar, tokens only */
.ga-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:80px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:4px double var(--c-primary)}
.ga-logo{font:700 30px var(--f-head);color:var(--c-primary);text-decoration:none;display:flex;align-items:center;gap:10px;letter-spacing:.01em}
.ga-logo i{width:34px;height:34px;border-radius:50% 4px 50% 4px;background:var(--c-accent);border:3px solid var(--c-primary);transform:rotate(-12deg);display:inline-block}
.ga-nav{margin-left:auto}.ga-nav a{padding:0 14px;font:600 17px var(--f-body);color:var(--c-text)}.ga-nav a:hover{color:var(--c-primary);text-decoration:underline;text-decoration-color:var(--c-accent);text-decoration-thickness:4px;text-underline-offset:6px}
.ga-cta{background:var(--c-accent);color:var(--on-accent)!important;border-radius:6px;margin-left:8px;padding:0 20px!important;font-weight:700!important}
.ga-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.ga-hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,60px);align-items:start;padding:clamp(28px,5vw,64px) clamp(14px,4vw,56px)}
@media(max-width:900px){.ga-hero{grid-template-columns:1fr}}
.ga-hero h1{font:700 clamp(40px,6.4vw,var(--h1))/1.02 var(--f-head);color:var(--c-primary)}
.ga-hero h1 em{font-style:normal;background:linear-gradient(transparent 60%,var(--c-accent) 60% 90%,transparent 90%)}
.ga-hero p{font:500 19px/1.7 var(--f-body);margin:16px 0 22px;max-width:38ch}
.ga-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 26px;border-radius:6px;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);text-decoration:none;border:3px solid var(--c-primary);cursor:pointer}
.ga-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}.ga-btn.o{background:transparent;color:var(--c-primary)}
.ga-bx{border:4px solid var(--c-primary);background:var(--c-surface);padding:clamp(16px,2.2vw,28px);position:relative;box-shadow:inset 0 0 0 4px var(--c-surface),inset 0 0 0 6px var(--c-primary)}
.ga-bx h2{font:700 26px var(--f-head);color:var(--c-primary);margin-bottom:10px}
.ga-st{margin-bottom:14px}.ga-st b{display:block;font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px;filter:brightness(.7)}
.ga-op{display:flex;gap:6px;flex-wrap:wrap}
.ga-op button{min-height:46px;padding:0 16px;border:3px solid var(--c-primary);border-radius:6px;background:transparent;color:var(--c-primary);font:700 15px var(--f-body);cursor:pointer}
.ga-op button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.ga-in{border:3px dashed var(--c-primary);padding:12px 14px;margin:10px 0;font:600 15px/1.7 var(--f-body);min-height:90px}
.ga-in b{font:700 13px var(--f-body);letter-spacing:.12em;text-transform:uppercase;display:block;margin-bottom:2px}
.ga-tot{display:flex;justify-content:space-between;align-items:baseline;gap:10px;flex-wrap:wrap}.ga-tot b{font:700 36px var(--f-head);color:var(--c-primary)}
.ga-h{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:20px;flex-wrap:wrap;gap:10px;border-bottom:4px double var(--c-primary);padding-bottom:6px}
.ga-h h2{font:700 clamp(28px,3.8vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.ga-cal{display:grid;gap:0;border:3px solid var(--c-primary);background:var(--c-surface);overflow:auto}
.ga-cr{display:grid;grid-template-columns:130px repeat(12,minmax(34px,1fr));min-width:560px;align-items:stretch;border-bottom:1px solid var(--c-border)}
.ga-cr:last-child{border-bottom:0}
.ga-cr>span{display:grid;place-items:center;min-height:42px;font:700 12px var(--f-body)}.ga-cr>b{padding:10px 12px;font:700 15px var(--f-head);display:flex;align-items:center}
.ga-cr.hd>span{background:var(--c-primary);color:var(--on-primary);font-size:11px;letter-spacing:.06em}.ga-cr.hd>span.now{background:var(--c-accent);color:var(--on-accent)}
.ga-cr>span.on{background:var(--c-secondary);border-left:1px solid var(--c-surface)}.ga-cr>span.now.on{background:var(--c-accent)}
.ga-cr>span.now{box-shadow:inset 3px 0 0 var(--c-primary),inset -3px 0 0 var(--c-primary)}
.ga-vl{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.ga-vl>div{border-top:6px solid var(--c-accent);padding-top:14px}
.ga-vl b{font:700 24px var(--f-head);color:var(--c-primary);display:block}.ga-vl span{font:500 16px/1.7 var(--f-body)}
@media(max-width:800px){.ga-vl{grid-template-columns:1fr}}
.ga-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.ga-foot .big{font:700 34px var(--f-head)}
.ga .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.ga .pagehead h1{max-width:none}.ga .card,.ga .scard,.ga .qcard,.ga .pcard,.ga .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.ga .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.ga .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.ga .svc{display:grid;grid-template-columns:1fr;gap:clamp(18px,3vw,36px)}
.ga .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:0;align-items:stretch}
.ga .scard:nth-child(even) .ph{order:2}
.ga .scard .ph{aspect-ratio:auto!important;min-height:220px;height:100%;border-radius:inherit}
.ga .scard .b{padding:clamp(20px,3vw,40px);align-self:center}
@media(max-width:760px){.ga .scard{grid-template-columns:1fr}.ga .scard:nth-child(even) .ph{order:0}}

.ga .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:30px 20px}
.ga .person{text-align:center;background:none;border:0;box-shadow:none;padding:0}
.ga .person .ph{aspect-ratio:1!important;border-radius:50%!important;margin:0 auto 12px;max-width:190px}

.ga .qgrid{display:block}.ga .qgrid.mt{margin-top:0}
.ga .qcard{max-width:900px;margin:0 auto;padding:clamp(24px,4vw,48px) 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.ga .qcard blockquote{font-size:clamp(22px,3vw,36px);line-height:1.3;margin:10px 0 18px}

.ga .masonry{display:grid!important;grid-template-columns:repeat(4,1fr);grid-auto-rows:150px;gap:8px;columns:auto}
.ga .masonry .mi{margin:0;overflow:hidden}.ga .masonry .mi .ph{aspect-ratio:auto!important;height:100%}
.ga .masonry .mi:nth-child(5n+1){grid-column:span 2;grid-row:span 2}.ga .masonry .mi:nth-child(7n+3){grid-row:span 2}
.ga .masonry .mi h3,.ga .masonry .mi .muted{display:none}
@media(max-width:700px){.ga .masonry{grid-template-columns:1fr 1fr}}

.ga .art .ph,.ga .feat .ph{display:none}
.ga .art,.ga .feat{border-left:4px solid var(--c-accent);padding:4px 0 4px 20px;margin-bottom:22px}
.ga .faq{max-width:none;columns:2 340px;column-gap:clamp(24px,5vw,72px)}.ga .faq details{break-inside:avoid}

.ga .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.ga .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.ga .pricing .card.hl h3,.ga .pricing .card.hl .amt{color:var(--c-primary)!important}.ga .pricing .card.hl li::before{color:var(--c-accent)!important}

.ga .cinfo{display:block;border-top:2px solid var(--c-primary)}
.ga .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.ga .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.ga .cinfo .card p{margin:0}
.ga .sec.dark{background:var(--c-accent);color:var(--on-accent)}.ga .sec.dark h2,.ga .sec.dark p{color:var(--on-accent)}.ga .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.ga .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.ga .steps>div{border:0;padding:0 0 26px;position:relative}.ga .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.ga .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.ga .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.ga .tl>div:last-child{border-right:0}
.ga .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.ga .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.ga .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.ga .vals .card:last-child{border-right:0}
@media(max-width:700px){.ga .vals{grid-template-columns:1fr}.ga .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><header class="ga-head"><a class="ga-logo" href="index.php"><i></i>Green Acre Farm</a><ul class="ga-nav"><li><a href="shop.php">Veg boxes</a></li><li><a href="schedule.php">Harvest</a></li><li><a href="service-areas.php">Delivery</a></li><li><a href="gift-cards.php">Gifts</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Farm Boxes</a><a href="service.php">Single Box</a><a href="pricing.php">Farm Box Plans</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Farm Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">From the Farm</a><a href="project.php">Single Farm story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="schedule.php">Delivery days</a><a href="booking.php">Visit the farm</a><a href="service-areas.php">Delivery areas</a><a href="gift-cards.php">Gift a box</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="ga-cta" href="booking.php">Visit the farm</a></li></ul><details class="ga-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Farm Boxes</a><a href="service.php">Single Box</a><a href="pricing.php">Farm Box Plans</a><a href="contact.php">Contact</a><a href="shop.php">Farm Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">From the Farm</a><a href="project.php">Single Farm story</a><a href="gallery.php">Gallery</a><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="schedule.php">Delivery days</a><a href="booking.php">Visit the farm</a><a href="service-areas.php">Delivery areas</a><a href="gift-cards.php">Gift a box</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="ga"><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
