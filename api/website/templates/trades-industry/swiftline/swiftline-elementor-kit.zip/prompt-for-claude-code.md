# Build "Swiftline Logistics" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1c2b39 · Secondary #6b7a86 · Text #1c2b39 · Accent #00b894 · Surface #f5f8fa · Border #d3dde3

## 2. Global Fonts
Headings: Exo 2 · Body: Assistant
H1 76px / H2 42px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 10px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single Service (service) — html/service.html
- Rates (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Customer Stories (projects) — html/projects.html
- Single Customer story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- News (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Track a shipment (tracking) — html/tracking.html
- Get a quote (quote) — html/quote.html
- Our network (service-areas) — html/service-areas.html
- Industries we serve (industries) — html/industries.html
- How shipping works (process) — html/process.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
