<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Swiftline Logistics';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Swiftline Logistics</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.sl-nav{display:flex;list-style:none;align-items:center;gap:4px}
.sl-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.sl-nav .more{position:relative}
.sl-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.sl-nav .more:hover .dd,.sl-nav .more:focus-within .dd{display:grid}
.sl-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.sl-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.sl-m{display:none;position:relative;margin-left:auto}
.sl-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.sl-m summary::-webkit-details-marker{display:none}
.sl-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.sl-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.sl-nav{display:none}.sl-m{display:block}}
.sl-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.sl-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.sl-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.sl-foot ul{list-style:none}.sl-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.sl-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.sl-foot .top{grid-template-columns:1fr}.sl-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Swiftline v2 — logistics with tracking in the header and a rate calculator, tokens only */
.sl-head{display:flex;align-items:center;gap:18px;padding:0 clamp(14px,4vw,56px);min-height:72px;background:var(--c-primary);color:var(--on-primary);position:sticky;top:0;z-index:50}
.sl-logo{font:800 24px var(--f-head);letter-spacing:.02em;color:var(--on-primary);text-decoration:none;display:flex;align-items:center;gap:8px;font-style:italic}
.sl-logo i{width:28px;height:18px;background:linear-gradient(90deg,var(--c-accent) 0 60%,transparent 60% 70%,var(--c-accent) 70% 85%,transparent 85% 90%,var(--c-accent) 90%);transform:skewX(-20deg);display:inline-block}
.sl-trk{display:flex;margin-left:auto;border-radius:8px;overflow:hidden;background:color-mix(in srgb,var(--on-primary) 12%,transparent)}
.sl-trk input{min-height:44px;width:200px;border:0;background:transparent;color:var(--on-primary);padding:0 12px;font:600 15px var(--f-body);border-radius:0}.sl-trk input::placeholder{color:color-mix(in srgb,var(--on-primary) 70%,transparent)}
.sl-trk button{min-height:44px;padding:0 16px;border:0;background:var(--c-accent);color:var(--on-accent);font:800 14px var(--f-body);cursor:pointer}
.sl-nav a{padding:0 12px;font:700 15px var(--f-body);color:var(--on-primary)}.sl-nav a:hover{color:var(--c-accent)}
.sl-cta{background:var(--c-accent);color:var(--on-accent)!important;border-radius:8px;padding:0 18px!important}
@media(max-width:1100px){.sl-trk{display:none}.sl-m{margin-left:auto}}
.sl-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.sl-hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,60px);align-items:start;padding:clamp(28px,5vw,64px) clamp(14px,4vw,56px)}
@media(max-width:960px){.sl-hero{grid-template-columns:1fr}}
.sl-hero h1{font:800 clamp(36px,5.4vw,var(--h1))/1.04 var(--f-head);color:var(--c-primary);letter-spacing:-.01em}
.sl-hero h1 em{font-style:italic;color:var(--c-accent)}
.sl-hero p{font:500 19px/1.7 var(--f-body);margin:16px 0 22px;max-width:40ch}
.sl-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 26px;border-radius:8px;background:var(--c-primary);color:var(--on-primary);font:800 16px var(--f-body);text-decoration:none;border:2px solid var(--c-primary);cursor:pointer}
.sl-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}.sl-btn.o{background:transparent;color:var(--c-primary)}
.sl-box{border:2px solid var(--c-primary);border-radius:16px;background:var(--c-surface);padding:clamp(18px,2.4vw,30px)}
.sl-box h2{font:800 22px var(--f-head);margin-bottom:12px}
.sl-in{display:flex;gap:8px;margin-bottom:16px}.sl-in input{flex:1;min-height:50px;border:2px solid var(--c-primary);border-radius:8px;padding:0 12px;font:700 16px var(--f-body);background:var(--c-surface);color:var(--c-text)}
.sl-in button{min-height:50px;padding:0 18px;border:0;border-radius:8px;background:var(--c-accent);color:var(--on-accent);font:800 15px var(--f-body);cursor:pointer}
.sl-tl{list-style:none;position:relative;padding-left:26px;border-left:3px solid var(--c-border);margin-left:8px}
.sl-tl li{position:relative;padding:0 0 18px}.sl-tl li::before{content:"";position:absolute;left:-36px;top:3px;width:18px;height:18px;border-radius:50%;background:var(--c-surface);border:3px solid var(--c-border)}
.sl-tl li.done::before{background:var(--c-accent);border-color:var(--c-accent)}.sl-tl li.now::before{background:var(--c-primary);border-color:var(--c-primary);box-shadow:0 0 0 5px color-mix(in srgb,var(--c-accent) 35%,transparent)}
.sl-tl b{font:800 16px var(--f-body);display:block}.sl-tl span{font:500 14px var(--f-body);color:var(--c-secondary)}
.sl-eta{font:800 18px var(--f-head);color:var(--c-accent);margin-bottom:10px}
.sl-rc{display:grid;grid-template-columns:1fr 1fr;gap:clamp(18px,3vw,44px);align-items:center;background:var(--c-primary);color:var(--on-primary);border-radius:20px;padding:clamp(20px,3vw,44px)}
@media(max-width:860px){.sl-rc{grid-template-columns:1fr}}
.sl-rc h2{font:800 clamp(26px,3.4vw,42px)/1.1 var(--f-head);color:var(--on-primary)}.sl-rc p{font:500 17px/1.7 var(--f-body);margin-top:10px;opacity:.9}
.sl-ctl{display:grid;gap:14px}.sl-ctl label{display:grid;gap:6px;font:800 12px var(--f-body);letter-spacing:.12em;text-transform:uppercase}
.sl-ctl select{min-height:50px;border:0;border-radius:8px;padding:0 12px;font:700 16px var(--f-body);background:var(--c-surface);color:var(--c-text)}
.sl-ctl input[type=range]{accent-color:var(--c-accent);padding:0;border:0;background:none;min-height:44px;width:100%}
.sl-sp{display:flex;gap:6px}.sl-sp button{flex:1;min-height:48px;border:2px solid var(--on-primary);background:transparent;color:var(--on-primary);font:800 14px var(--f-body);cursor:pointer;border-radius:8px}
.sl-sp button[aria-pressed=true]{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.sl-pr{background:var(--c-surface);color:var(--c-text);border-radius:12px;padding:14px 18px;display:flex;justify-content:space-between;align-items:baseline}.sl-pr b{font:800 34px var(--f-head);color:var(--c-primary)}
.sl-st{display:grid;grid-template-columns:repeat(4,1fr);gap:0;border-top:3px solid var(--c-primary)}.sl-st>div{padding:22px 18px 22px 0}
.sl-st b{font:800 clamp(30px,4vw,48px)/1 var(--f-head);color:var(--c-primary);display:block}.sl-st span{font:600 15px var(--f-body);color:var(--c-secondary)}
@media(max-width:700px){.sl-st{grid-template-columns:1fr 1fr}}
.sl-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.sl-foot .big{font:800 30px var(--f-head);font-style:italic}
.sl .pagehead{background:var(--c-primary);color:var(--on-primary)}.sl .pagehead h1,.sl .pagehead .lead,.sl .pagehead .crumbs,.sl .pagehead .eyebrow{color:var(--on-primary)}.sl .card,.sl .scard,.sl .qcard,.sl .pcard,.sl .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.sl .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.sl .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.sl .svc{display:block;border-top:2px solid var(--c-primary);counter-reset:sv}
.sl .scard{display:grid;grid-template-columns:56px minmax(0,1.1fr) minmax(0,1.7fr) auto;gap:6px 24px;align-items:baseline;padding:22px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;counter-increment:sv;transition:padding .2s}
.sl .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.sl .scard .ph{display:none}.sl .scard .b{display:contents}
.sl .scard h3{font-size:clamp(20px,2.2vw,28px)}.sl .scard p{margin:0;opacity:.8}
.sl .scard .m{display:flex;flex-direction:column;align-items:flex-end;gap:2px;font:600 13px var(--f-body);white-space:nowrap}
.sl .scard:hover{padding-left:14px}
@media(max-width:760px){.sl .scard{grid-template-columns:36px 1fr}.sl .scard p,.sl .scard .m{grid-column:2;align-items:flex-start}}

.sl .tgrid{display:block;border-top:2px solid var(--c-primary)}.sl .tgrid.mt{margin-top:0}
.sl .person{display:grid;grid-template-columns:1fr auto;gap:4px 20px;align-items:baseline;padding:18px 0;border-bottom:1px solid var(--c-border);background:none;border-radius:0;box-shadow:none;border-left:0;border-right:0;border-top:0;text-align:left}
.sl .person .ph{display:none}.sl .person h3{font-size:clamp(20px,2.2vw,28px)}.sl .person span{font:600 13px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-accent)}

.sl .qgrid{display:block;border-top:2px solid var(--c-primary)}.sl .qgrid.mt{margin-top:0}
.sl .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.sl .qcard .stars{grid-column:1}.sl .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.sl .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.sl .qcard{grid-template-columns:1fr}.sl .qcard figcaption{grid-column:1;grid-row:auto}}

.sl .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.sl .masonry .mi{margin:0}.sl .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.sl .masonry{grid-template-columns:1fr 1fr}}

.sl .articles{display:block!important}
.sl .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.sl .art .ph{display:none}.sl .art .meta{grid-row:1/span 2;align-self:start}.sl .art h3{margin:0}
.sl .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}

.sl .faq{counter-reset:q;max-width:960px}
.sl .faq details{counter-increment:q;position:relative;padding-left:64px}
.sl .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.sl .pricing{display:block;border-top:2px solid var(--c-primary)}
.sl .pricing .card{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1.5fr) auto;gap:10px 28px;align-items:center;padding:24px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none!important;box-shadow:none;transform:none!important;color:inherit!important}
.sl .pricing .card h3,.sl .pricing .card .amt{color:var(--c-primary)!important;margin:0}
.sl .pricing .card.hl{background:color-mix(in srgb,var(--c-accent) 12%,var(--c-surface))!important}
.sl .pricing ul{margin:0;display:flex;gap:6px 16px;flex-wrap:wrap}.sl .pricing li{font-size:14px}
@media(max-width:820px){.sl .pricing .card{grid-template-columns:1fr auto}.sl .pricing ul{grid-column:1/-1}}

.sl .cinfo{display:block;border-top:2px solid var(--c-primary)}
.sl .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.sl .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.sl .cinfo .card p{margin:0}
.sl .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.sl .sec.dark h2,.sl .sec.dark p{color:var(--c-text)}
.sl .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.sl .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.sl .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.sl .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.sl .tl>div:last-child{border-right:0}
.sl .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.sl .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.sl .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.sl .vals .card:last-child{border-right:0}
@media(max-width:700px){.sl .vals{grid-template-columns:1fr}.sl .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><header class="sl-head"><a class="sl-logo" href="index.php"><i></i>Swiftline</a><form class="sl-trk" onsubmit="return false"><input id="sl-h" placeholder="Track a parcel: SL1234567" aria-label="Tracking number"><button type="button" id="sl-hb">Track</button></form><ul class="sl-nav"><li><a href="services.php">Services</a></li><li><a href="quote.php">Get a quote</a></li><li><a href="service-areas.php">Coverage</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Rates</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customer Stories</a><a href="project.php">Single Customer story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="tracking.php">Track a shipment</a><a href="quote.php">Get a quote</a><a href="service-areas.php">Our network</a><a href="industries.php">Industries we serve</a><a href="process.php">How shipping works</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="sl-cta" href="tracking.php">Track</a></li></ul><details class="sl-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Rates</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customer Stories</a><a href="project.php">Single Customer story</a><a href="gallery.php">Gallery</a><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="tracking.php">Track a shipment</a><a href="quote.php">Get a quote</a><a href="service-areas.php">Our network</a><a href="industries.php">Industries we serve</a><a href="process.php">How shipping works</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="sl">
<main>
