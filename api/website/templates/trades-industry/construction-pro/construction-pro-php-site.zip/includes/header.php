<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Construction Pro';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Construction Pro</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
.cp-nav{display:flex;list-style:none;align-items:center;gap:4px}
.cp-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.cp-nav .more{position:relative}
.cp-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.cp-nav .more:hover .dd,.cp-nav .more:focus-within .dd{display:grid}
.cp-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.cp-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.cp-m{display:none;position:relative;margin-left:auto}
.cp-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.cp-m summary::-webkit-details-marker{display:none}
.cp-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.cp-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.cp-nav{display:none}.cp-m{display:block}}
.cp-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.cp-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.cp-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.cp-foot ul{list-style:none}.cp-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.cp-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.cp-foot .top{grid-template-columns:1fr}.cp-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* Ironbridge Build v2 — contractor with a live programme chart and cost estimator, tokens only */
.cp-stripe{height:12px;background:repeating-linear-gradient(-45deg,var(--c-accent) 0 18px,var(--c-primary) 18px 36px)}
.cp-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:78px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:3px solid var(--c-primary)}
.cp-logo{font:700 26px var(--f-head);letter-spacing:.02em;text-transform:uppercase;color:var(--c-primary);text-decoration:none;display:flex;align-items:center;gap:10px}
.cp-logo i{width:38px;height:26px;border:4px solid var(--c-primary);border-bottom:0;border-radius:20px 20px 0 0;display:inline-block;background:linear-gradient(var(--c-accent),var(--c-accent)) 0 100%/100% 6px no-repeat}
.cp-nav{margin-left:auto}.cp-nav a{padding:0 14px;font:700 14px var(--f-body);letter-spacing:.08em;text-transform:uppercase;color:var(--c-text)}.cp-nav a:hover{color:var(--c-accent)}
.cp-cta{background:var(--c-accent);color:var(--on-accent)!important;margin-left:8px;padding:0 20px!important}
.cp-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.cp-hero{display:grid;grid-template-columns:.9fr 1.1fr;gap:clamp(20px,4vw,60px);align-items:center;padding:clamp(28px,5vw,64px) clamp(14px,4vw,56px)}
@media(max-width:960px){.cp-hero{grid-template-columns:1fr}}
.cp-hero h1{font:700 clamp(34px,5vw,var(--h1))/1.06 var(--f-head);color:var(--c-primary);text-transform:uppercase}
.cp-hero h1 em{font-style:normal;background:var(--c-accent);padding:0 .1em}
.cp-hero p{font:400 19px/1.7 var(--f-body);margin:16px 0 22px;max-width:40ch}
.cp-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 26px;background:var(--c-primary);color:var(--on-primary);font:700 15px var(--f-body);letter-spacing:.1em;text-transform:uppercase;text-decoration:none;border:3px solid var(--c-primary);cursor:pointer}
.cp-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}.cp-btn.o{background:transparent;color:var(--c-primary)}
.cp-gt{border:3px solid var(--c-primary);background:var(--c-surface);padding:clamp(14px,2vw,24px)}
.cp-gt h2{font:700 20px var(--f-head);text-transform:uppercase;margin-bottom:12px}
.cp-gm{display:grid;grid-template-columns:130px repeat(12,1fr);font:700 11px var(--f-body);color:var(--c-secondary);margin-bottom:6px}.cp-gm span:not(:first-child){text-align:center}
.cp-gr{display:grid;grid-template-columns:130px 1fr;gap:0;align-items:center;border-top:1px solid var(--c-border);min-height:40px}
.cp-gr b{font:600 13px var(--f-body);text-transform:uppercase;letter-spacing:.04em}
.cp-gr .t{position:relative;height:100%;background:repeating-linear-gradient(90deg,transparent 0 calc(100%/12 - 1px),var(--c-border) calc(100%/12 - 1px) calc(100%/12))}
.cp-gr .t i{position:absolute;top:9px;height:22px;background:var(--c-primary);left:var(--l);width:var(--w);transition:left .3s,width .3s}
.cp-gr:nth-child(odd) .t i{background:var(--c-accent)}
.cp-ct{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:16px}@media(max-width:700px){.cp-ct{grid-template-columns:1fr}}
.cp-ct label{display:grid;gap:4px;font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase}.cp-ct label span{font:700 17px var(--f-head);color:var(--c-primary);letter-spacing:0;text-transform:none}
.cp-ct select{min-height:48px;border:2px solid var(--c-primary);border-radius:0;padding:0 10px;font:600 15px var(--f-body);background:var(--c-surface);color:var(--c-text)}
.cp-ct input[type=range]{accent-color:var(--c-accent);padding:0;border:0;background:none;min-height:44px;width:100%}
.cp-out{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-top:14px;padding:14px 16px;background:var(--c-primary);color:var(--on-primary);flex-wrap:wrap}.cp-out b{font:700 32px var(--f-head);color:var(--c-accent)}
.cp-h{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:20px;flex-wrap:wrap;gap:10px;border-bottom:3px solid var(--c-primary);padding-bottom:8px}
.cp-h h2{font:700 clamp(24px,3.2vw,var(--h2)) var(--f-head);text-transform:uppercase}
.cp-sf{display:grid;grid-template-columns:repeat(4,1fr);gap:0;border:3px solid var(--c-primary)}.cp-sf>div{padding:20px;border-right:3px solid var(--c-primary)}.cp-sf>div:last-child{border-right:0}
.cp-sf b{font:700 clamp(30px,4vw,48px)/1 var(--f-head);color:var(--c-primary);display:block}.cp-sf span{font:600 14px var(--f-body);text-transform:uppercase;letter-spacing:.06em;color:var(--c-secondary)}
@media(max-width:700px){.cp-sf{grid-template-columns:1fr 1fr}.cp-sf>div:nth-child(2n){border-right:0}.cp-sf>div:nth-child(-n+2){border-bottom:3px solid var(--c-primary)}}
.cp-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.cp-foot .big{font:700 30px var(--f-head);text-transform:uppercase}
.cp .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.cp .pagehead h1{max-width:none}.cp .card,.cp .scard,.cp .qcard,.cp .pcard,.cp .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.cp .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.cp .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.cp .svc{display:block;border:2px solid var(--c-primary)}
.cp .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr) 150px 110px;gap:0;align-items:stretch;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:0}
.cp .scard:nth-child(even){background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}
.cp .scard .ph{display:none}.cp .scard .b{display:contents}
.cp .scard h3{padding:18px;font-size:19px;border-right:1px solid var(--c-border)}
.cp .scard p{padding:18px;margin:0;border-right:1px solid var(--c-border);opacity:.85;font-size:15px}
.cp .scard .m{display:contents}.cp .scard .m b{padding:18px;border-right:1px solid var(--c-border);font-size:15px}.cp .scard .m span{padding:18px;font-size:14px;opacity:.75}
@media(max-width:820px){.cp .scard{grid-template-columns:1fr 1fr}.cp .scard h3{grid-column:1/-1;border-right:0}.cp .scard p{grid-column:1/-1;border-right:0;padding-top:0}}

.cp .tgrid{display:block;border-top:2px solid var(--c-primary)}.cp .tgrid.mt{margin-top:0}
.cp .person{display:grid;grid-template-columns:1fr auto;gap:4px 20px;align-items:baseline;padding:18px 0;border-bottom:1px solid var(--c-border);background:none;border-radius:0;box-shadow:none;border-left:0;border-right:0;border-top:0;text-align:left}
.cp .person .ph{display:none}.cp .person h3{font-size:clamp(20px,2.2vw,28px)}.cp .person span{font:600 13px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-accent)}

.cp .qgrid{display:block;border-top:2px solid var(--c-primary)}.cp .qgrid.mt{margin-top:0}
.cp .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.cp .qcard .stars{grid-column:1}.cp .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.cp .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.cp .qcard{grid-template-columns:1fr}.cp .qcard figcaption{grid-column:1;grid-row:auto}}

.cp .masonry{display:grid!important;grid-template-columns:repeat(4,1fr);grid-auto-rows:150px;gap:8px;columns:auto}
.cp .masonry .mi{margin:0;overflow:hidden}.cp .masonry .mi .ph{aspect-ratio:auto!important;height:100%}
.cp .masonry .mi:nth-child(5n+1){grid-column:span 2;grid-row:span 2}.cp .masonry .mi:nth-child(7n+3){grid-row:span 2}
.cp .masonry .mi h3,.cp .masonry .mi .muted{display:none}
@media(max-width:700px){.cp .masonry{grid-template-columns:1fr 1fr}}

.cp .articles{display:block!important}
.cp .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.cp .art .ph{display:none}.cp .art .meta{grid-row:1/span 2;align-self:start}.cp .art h3{margin:0}
.cp .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}

.cp .faq{counter-reset:q;max-width:960px}
.cp .faq details{counter-increment:q;position:relative;padding-left:64px}
.cp .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.cp .pricing{display:block;border-top:2px solid var(--c-primary)}
.cp .pricing .card{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1.5fr) auto;gap:10px 28px;align-items:center;padding:24px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none!important;box-shadow:none;transform:none!important;color:inherit!important}
.cp .pricing .card h3,.cp .pricing .card .amt{color:var(--c-primary)!important;margin:0}
.cp .pricing .card.hl{background:color-mix(in srgb,var(--c-accent) 12%,var(--c-surface))!important}
.cp .pricing ul{margin:0;display:flex;gap:6px 16px;flex-wrap:wrap}.cp .pricing li{font-size:14px}
@media(max-width:820px){.cp .pricing .card{grid-template-columns:1fr auto}.cp .pricing ul{grid-column:1/-1}}

.cp .cinfo{display:block;border-top:2px solid var(--c-primary)}
.cp .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.cp .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.cp .cinfo .card p{margin:0}
.cp .sec.dark{background:var(--c-accent);color:var(--on-accent)}.cp .sec.dark h2,.cp .sec.dark p{color:var(--on-accent)}.cp .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.cp .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.cp .steps>div{border:0;padding:0 0 26px;position:relative}.cp .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.cp .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.cp .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.cp .tl>div:last-child{border-right:0}
.cp .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.cp .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.cp .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.cp .vals .card:last-child{border-right:0}
@media(max-width:700px){.cp .vals{grid-template-columns:1fr}.cp .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><div class="cp-stripe"></div><header class="cp-head"><a class="cp-logo" href="index.php"><i></i>Ironbridge</a><ul class="cp-nav"><li><a href="services.php">Services</a></li><li><a href="projects.php">Projects</a></li><li><a href="process.php">Process</a></li><li><a href="service-areas.php">Areas</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Projects</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="process.php">Process</a><a href="quote.php">Request a quote</a><a href="service-areas.php">Service areas</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="cp-cta" href="quote.php">Get a quote</a></li></ul><details class="cp-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Projects</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="process.php">Process</a><a href="quote.php">Request a quote</a><a href="service-areas.php">Service areas</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="cp">
<main>
