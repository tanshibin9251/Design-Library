# Build "Construction Pro" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2f3437 · Secondary #8a9099 · Text #25282a · Accent #f5a300 · Surface #eceae5 · Border #c9c6bd

## 2. Global Fonts
Headings: Roboto Slab · Body: Roboto
H1 68px / H2 40px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single service (service) — html/service.html
- Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Projects (projects) — html/projects.html
- Single Project (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- News (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Process (process) — html/process.html
- Request a quote (quote) — html/quote.html
- Service areas (service-areas) — html/service-areas.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
