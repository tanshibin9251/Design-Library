# Build "Sparkle Nest" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #0c4a6e · Secondary #475569 · Text #0f172a · Accent #5eead4 · Surface #fbfdfd · Border #d8e6ea

## 2. Global Fonts
Headings: Comfortaa · Body: Open Sans
H1 68px / H2 40px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 80px vertical · Border radius 20px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Services (services) — html/services.html
- Instant quote (quote) — html/quote.html
- Plans (plans) — html/plans.html
- Service areas (areas) — html/areas.html
- How it works (how) — html/how.html
- Reviews (reviews) — html/reviews.html
- Book (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
