# Autoline Motors

Exported from Design Library · 24 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Service Centre, Single Service, Finance, Contact, Inventory, Single Vehicle, Cart, Checkout, Testimonials, Team, Sold, Single Sold car, Gallery, News, Single post, FAQ, Book test drive, Sell your car, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
