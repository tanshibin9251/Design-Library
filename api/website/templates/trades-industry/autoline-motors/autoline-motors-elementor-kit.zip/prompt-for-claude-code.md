# Build "Autoline Motors" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #101820 · Secondary #8d99a6 · Text #101820 · Accent #0aa5ff · Surface #eef1f4 · Border #d2d8df

## 2. Global Fonts
Headings: Chakra Petch · Body: Inter
H1 72px / H2 40px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Service Centre (services) — html/services.html
- Single Service (service) — html/service.html
- Finance (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Inventory (shop) — html/shop.html
- Single Vehicle (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Sold (projects) — html/projects.html
- Single Sold car (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- News (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book test drive (booking) — html/booking.html
- Sell your car (quote) — html/quote.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
