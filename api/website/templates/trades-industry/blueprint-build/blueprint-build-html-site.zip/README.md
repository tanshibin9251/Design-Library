# Blueprint Build

Exported from Design Library · 12 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, Services, Schedule of works, Quick quote, Project register, Project file, Spec library, Licences & safety, Site enquiry, FAQ, Privacy policy, 404 error.

All text and images are placeholders — replace them with your own.
