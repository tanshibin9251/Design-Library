<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Blueprint Build';
$dark = true;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Blueprint Build</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="blueprint-build" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Blueprint Build — drafting sheet, tokens only */
body{background-image:linear-gradient(color-mix(in srgb,var(--c-text) 7%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in srgb,var(--c-text) 7%,transparent) 1px,transparent 1px),linear-gradient(color-mix(in srgb,var(--c-text) 3.5%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in srgb,var(--c-text) 3.5%,transparent) 1px,transparent 1px);background-size:100px 100px,100px 100px,20px 20px,20px 20px}
.bp-head{position:sticky;top:0;z-index:40;background:color-mix(in srgb,var(--c-surface) 94%,transparent);border-bottom:1px solid var(--c-text);backdrop-filter:blur(6px)}
.bp-head .in{max-width:var(--w);margin:auto;display:grid;grid-template-columns:auto 1fr auto;gap:30px;align-items:center;padding:0 20px}
.bp-logo{font:700 18px var(--f-head);letter-spacing:.06em;text-transform:uppercase;text-decoration:none;padding:16px 26px 16px 0;border-right:1px solid var(--c-text);display:flex;gap:10px;align-items:center}
.bp-logo svg{width:26px;height:26px}
.bp-head ul{display:flex;gap:26px;list-style:none;font:500 12.5px var(--f-head);letter-spacing:.08em;text-transform:uppercase}
.bp-head ul a{text-decoration:none}.bp-head ul a:hover{color:var(--c-accent)}
.bp-tb{font:500 11px var(--f-head);letter-spacing:.1em;text-align:right;opacity:.75;border-left:1px solid var(--c-text);padding-left:18px;line-height:1.5}
.bp-sheet{max-width:var(--w);margin:24px auto;padding:0;border:2px solid var(--c-text);position:relative}
.bp-sheet::before{content:"";position:absolute;inset:6px;border:1px solid var(--c-text);pointer-events:none;opacity:.5}
.bp-hero{display:grid;grid-template-columns:1.1fr 1fr;border-bottom:1px solid var(--c-text)}
.bp-hero>div{padding:clamp(30px,4vw,64px)}
.bp-hero>div+div{border-left:1px solid var(--c-text);display:grid;place-items:center;position:relative}
.bp-hero h1{font-size:clamp(34px,5.2vw,var(--h1));font-weight:700;line-height:1.02;letter-spacing:-.02em;text-transform:uppercase}
.bp-hero h1 mark{background:var(--c-accent);color:var(--c-surface);padding:0 .15em}
.bp-hero p{max-width:44ch;margin:22px 0 28px;font:400 18px/1.55 var(--f-body)}
.bp-label{font:500 11px var(--f-head);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent)}
.bp-btn{display:inline-block;border:1px solid var(--c-accent);background:var(--c-accent);color:var(--c-surface);padding:.85em 1.5em;font:700 13px var(--f-head);letter-spacing:.08em;text-transform:uppercase;text-decoration:none}
.bp-btn.o{background:none;color:var(--c-text);border-color:var(--c-text)}.bp-btn:hover{background:var(--c-text);color:var(--c-surface);border-color:var(--c-text)}
.bp-plan{width:100%;max-width:440px;aspect-ratio:1}
.bp-plan svg{width:100%;height:100%;overflow:visible}
.bp-plan .w{fill:none;stroke:var(--c-text);stroke-width:3}.bp-plan .t{fill:none;stroke:var(--c-text);stroke-width:1;stroke-dasharray:4 4}.bp-plan .d{stroke:var(--c-accent);stroke-width:1;fill:none}
.bp-plan text{font:500 9px var(--f-head);fill:var(--c-text);letter-spacing:.1em}.bp-plan text.a{fill:var(--c-accent)}
.bp-row{display:grid;grid-template-columns:repeat(4,1fr);border-bottom:1px solid var(--c-text)}
.bp-row>div{padding:24px;border-right:1px solid var(--c-text)}.bp-row>div:last-child{border:0}
.bp-row b{display:block;font:700 clamp(30px,3.6vw,50px)/1 var(--f-head);color:var(--c-accent)}
.bp-row span{font:500 11px var(--f-head);letter-spacing:.14em;text-transform:uppercase}
.bp-sec{padding:clamp(28px,4vw,56px);border-bottom:1px solid var(--c-text)}
.bp-sec>h2{font-size:clamp(26px,3.4vw,var(--h2));text-transform:uppercase;font-weight:700;letter-spacing:-.01em;margin:6px 0 28px}
.bp-svc{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--c-text)}
.bp-svc>div{padding:22px;border-right:1px solid var(--c-text);border-bottom:1px solid var(--c-text)}
.bp-svc>div:nth-child(3n){border-right:0}.bp-svc>div:nth-last-child(-n+3){border-bottom:0}
.bp-svc .no{font:700 13px var(--f-head);color:var(--c-accent)}.bp-svc h3{font-size:19px;text-transform:uppercase;margin:6px 0}
.bp-gantt{border:1px solid var(--c-text);font:500 12px var(--f-head)}
.bp-gantt .r{display:grid;grid-template-columns:200px repeat(12,1fr);border-bottom:1px solid color-mix(in srgb,var(--c-text) 30%,transparent);align-items:center}
.bp-gantt .r:last-child{border:0}.bp-gantt .r>span{padding:10px 12px;letter-spacing:.06em}
.bp-gantt .r.h{background:color-mix(in srgb,var(--c-text) 8%,transparent);text-transform:uppercase;letter-spacing:.1em}.bp-gantt .r.h span{text-align:center;padding:8px 0}.bp-gantt .r.h span:first-child{text-align:left;padding-left:12px}
.bp-gantt .bar{height:16px;background:var(--c-accent);grid-column:var(--s)/span var(--l);margin:8px 0;position:relative}
.bp-gantt .bar::after{content:attr(data-w);position:absolute;left:100%;top:50%;translate:6px -50%;font-size:10px;opacity:.7;white-space:nowrap}
.bp-reg{width:100%;border-collapse:collapse;font:500 13px var(--f-head)}
.bp-reg th{text-align:left;padding:10px 12px;border-bottom:2px solid var(--c-text);text-transform:uppercase;letter-spacing:.1em;font-size:11px;color:var(--c-accent)}
.bp-reg td{padding:14px 12px;border-bottom:1px dashed color-mix(in srgb,var(--c-text) 40%,transparent)}
.bp-reg tr:hover td{background:color-mix(in srgb,var(--c-accent) 10%,transparent)}
.bp-reg a{text-decoration:none;font-weight:700}
.bp-calc{display:grid;grid-template-columns:1fr 1fr;gap:30px}
.bp-calc .box{border:1px solid var(--c-text);padding:24px}
.bp-calc label{display:flex;justify-content:space-between;font:600 12px var(--f-head);letter-spacing:.08em;text-transform:uppercase;margin:16px 0 6px}
.bp-calc input[type=range]{width:100%;accent-color:var(--c-accent)}
.bp-calc .tot{font:700 clamp(36px,5vw,64px)/1 var(--f-head);color:var(--c-accent)}
.bp-foot{max-width:var(--w);margin:0 auto 24px;border:2px solid var(--c-text);padding:30px;display:grid;grid-template-columns:2fr repeat(3,1fr);gap:24px}
.bp-foot h4{font:700 11px var(--f-head);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:8px}
.bp-foot ul{list-style:none;display:grid;gap:4px;font:500 13px var(--f-head)}.bp-foot a{text-decoration:none}
@media(max-width:900px){.bp-head ul,.bp-tb{display:none}.bp-head .in{grid-template-columns:1fr}.bp-hero,.bp-calc,.bp-foot{grid-template-columns:1fr}.bp-hero>div+div{border-left:0;border-top:1px solid var(--c-text)}.bp-row{grid-template-columns:1fr 1fr}.bp-svc{grid-template-columns:1fr}.bp-gantt{overflow-x:auto}.bp-gantt .r{min-width:720px}}
.bp-head .more{position:relative}.bp-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:0;}.bp-head .more:hover .dd,.bp-head .more:focus-within .dd{display:grid}.bp-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.bp-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.bp-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3,h4{color:var(--c-text)}/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.bp-reg{display:block;overflow-x:auto;white-space:nowrap}.bp-sheet{margin:12px 8px}.bp-hero h1{font-size:clamp(30px,9.5vw,48px)}.bp-hero>div{padding:24px 18px}.bp-sec{padding:24px 16px}.bp-calc .box{padding:16px}.bp-row b{font-size:28px}.bp-logo{padding-right:0;border-right:0}}</style><header class="bp-head"><div class="in"><a class="bp-logo" href="index.php"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 29V13L16 4l13 9v16z"/><path d="M12 29v-9h8v9M3 13h26M8 9v-3"/></svg>Gridline Build</a><ul><li><a href="services.php">Services</a></li><li><a href="process.php">Schedule</a></li><li><a href="quote.php">Quick quote</a></li><li><a href="projects.php">Register</a></li><li class="more"><a href="#" tabindex="0">Sheets ▾</a><div class="dd"><div><h4>Sheet</h4><a href="index.php">Home</a><a href="services.php">Services</a><a href="process.php">Schedule of works</a><a href="quote.php">Quick quote</a><a href="projects.php">Project register</a><a href="project.php">Project file</a></div><div><h4>Reference</h4><a href="materials.php">Spec library</a><a href="licences.php">Licences & safety</a><a href="contact.php">Site enquiry</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><div class="bp-tb">DWG NO. GB-001 / REV C<br>SCALE 1:50 · A1</div><details class="dl-mobile"><summary>Menu</summary><nav class="dl-mobile-links" aria-label="Template pages"><h4>Sheet</h4><a href="index.php">Home</a><a href="services.php">Services</a><a href="process.php">Schedule of works</a><a href="quote.php">Quick quote</a><a href="projects.php">Project register</a><a href="project.php">Project file</a><h4>Reference</h4><a href="materials.php">Spec library</a><a href="licences.php">Licences &amp; safety</a><a href="contact.php">Site enquiry</a><a href="faq.php">FAQ</a><h4>Utility</h4><a href="privacy.php">Privacy policy</a></nav></details></div></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
