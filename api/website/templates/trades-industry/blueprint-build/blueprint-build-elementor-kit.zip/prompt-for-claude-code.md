# Build "Blueprint Build" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #14407f · Secondary #8fb4ea · Text #e8f1ff · Accent #6ef2c8 · Surface #0c2d62 · Border #2d5aa0

## 2. Global Fonts
Headings: JetBrains Mono · Body: Barlow
H1 76px / H2 44px / H3 20px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Services (services) — html/services.html
- Schedule of works (process) — html/process.html
- Quick quote (quote) — html/quote.html
- Project register (projects) — html/projects.html
- Project file (project) — html/project.html
- Spec library (materials) — html/materials.html
- Licences & safety (licences) — html/licences.html
- Site enquiry (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
