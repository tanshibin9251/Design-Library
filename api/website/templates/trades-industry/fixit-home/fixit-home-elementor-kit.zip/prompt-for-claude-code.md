# Build "FixIt Home Services" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2d4a6b · Secondary #cfd8e3 · Text #1f2d3d · Accent #ff7a1a · Surface #fbf7f0 · Border #d8dee6

## 2. Global Fonts
Headings: Passion One · Body: Barlow
H1 104px / H2 52px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 12px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single Service (service) — html/service.html
- Price Guide (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Service Packs (shop) — html/shop.html
- Single Pack (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Recent Jobs (projects) — html/projects.html
- Single Job (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Home Tips (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book a technician (booking) — html/booking.html
- Instant quote (quote) — html/quote.html
- Service areas (service-areas) — html/service-areas.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
