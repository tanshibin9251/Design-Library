<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'FixIt Home Services';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · FixIt Home Services</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="fixit-home" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
.fh-nav{display:flex;list-style:none;align-items:center;gap:4px}
.fh-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;color:inherit}
.fh-nav .more{position:relative}
.fh-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:620px;z-index:60;text-align:left;box-shadow:0 26px 50px -28px rgba(0,0,0,.4)}
.fh-nav .more:hover .dd,.fh-nav .more:focus-within .dd{display:grid}
.fh-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.fh-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);background:none;border:0;border-radius:0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.fh-m{display:none;position:relative;margin-left:auto}
.fh-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;padding:0 14px;border:2px solid currentColor;font:700 12px var(--f-body);letter-spacing:.14em}
.fh-m summary::-webkit-details-marker{display:none}
.fh-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.fh-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.fh-nav{display:none}.fh-m{display:block}}
.fh-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.fh-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.fh-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.fh-foot ul{list-style:none}.fh-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:inherit}
.fh-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:860px){.fh-foot .top{grid-template-columns:1fr}.fh-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
/* FixIt Home v2 — handyman service with a three-step job estimator, tokens only */
.fh-call{background:var(--c-accent);color:var(--on-accent);display:flex;justify-content:center;gap:16px;flex-wrap:wrap;align-items:center;font:700 15px var(--f-body);padding:8px 14px;letter-spacing:.04em}
.fh-call a{color:inherit;font:400 24px var(--f-head);letter-spacing:.04em;text-decoration:none}
.fh-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:76px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:4px solid var(--c-primary)}
.fh-logo{font:400 30px var(--f-head);text-transform:uppercase;color:var(--c-primary);text-decoration:none;letter-spacing:.02em;display:flex;align-items:center;gap:10px}
.fh-logo i{width:30px;height:30px;background:var(--c-accent);border-radius:6px;position:relative;display:inline-block;transform:rotate(-8deg)}
.fh-logo i::after{content:"";position:absolute;left:11px;top:-4px;width:8px;height:22px;background:var(--c-primary);border-radius:3px;transform:rotate(30deg)}
.fh-nav{margin-left:auto}.fh-nav a{padding:0 14px;font:700 16px var(--f-body);color:var(--c-text)}.fh-nav a:hover{color:var(--c-accent)}
.fh-cta{background:var(--c-primary);color:var(--on-primary)!important;border-radius:6px;margin-left:8px;padding:0 20px!important}
.fh-sec{padding:clamp(34px,5vw,72px) clamp(14px,4vw,56px)}
.fh-hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,60px);align-items:start;padding:clamp(28px,5vw,64px) clamp(14px,4vw,56px)}
@media(max-width:900px){.fh-hero{grid-template-columns:1fr}}
.fh-hero h1{font:400 clamp(44px,7vw,var(--h1))/.98 var(--f-head);text-transform:uppercase;color:var(--c-primary)}
.fh-hero h1 em{font-style:normal;color:var(--c-accent)}
.fh-hero p{font:500 19px/1.7 var(--f-body);margin:16px 0 22px;max-width:36ch}
.fh-btn{display:inline-flex;align-items:center;justify-content:center;min-height:54px;padding:0 28px;border-radius:8px;background:var(--c-accent);color:var(--on-accent);font:400 22px var(--f-head);letter-spacing:.04em;text-transform:uppercase;text-decoration:none;border:0;cursor:pointer}
.fh-btn:hover{background:var(--c-primary);color:var(--on-primary)}
.fh-w{background:var(--c-surface);border:4px solid var(--c-primary);border-radius:16px;padding:clamp(16px,2.2vw,28px);box-shadow:8px 8px 0 var(--c-accent)}
.fh-w h2{font:400 28px var(--f-head);text-transform:uppercase;color:var(--c-primary);margin-bottom:10px}
.fh-q{margin-bottom:14px}.fh-q b{display:flex;gap:10px;align-items:center;font:700 14px var(--f-body);letter-spacing:.08em;text-transform:uppercase;margin-bottom:8px}
.fh-q b i{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:var(--c-primary);color:var(--on-primary);font:400 16px var(--f-head);font-style:normal}
.fh-op{display:flex;gap:6px;flex-wrap:wrap}
.fh-op button{min-height:46px;padding:0 16px;border:2px solid var(--c-primary);border-radius:8px;background:transparent;color:var(--c-primary);font:700 15px var(--f-body);cursor:pointer}
.fh-op button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.fh-est{background:var(--c-primary);color:var(--on-primary);border-radius:10px;padding:14px 18px;display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap}
.fh-est b{font:400 38px var(--f-head);color:var(--c-accent)}.fh-est small{display:block;font:600 13px var(--f-body);opacity:.85}
.fh-tk{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}@media(max-width:800px){.fh-tk{grid-template-columns:1fr}}
.fh-t{background:var(--c-surface);border:3px solid var(--c-primary);border-radius:12px;padding:18px 20px;position:relative;display:grid;gap:6px;align-content:start}
.fh-t::before,.fh-t::after{content:"";position:absolute;top:50%;width:22px;height:22px;border-radius:50%;background:var(--c-surface);border:3px solid var(--c-primary);transform:translateY(-50%)}.fh-t::before{left:-14px;clip-path:inset(0 0 0 50%)}.fh-t::after{right:-14px;clip-path:inset(0 50% 0 0)}
.fh-t h3{font:400 26px var(--f-head);text-transform:uppercase;color:var(--c-primary)}.fh-t p{font:500 15px/1.6 var(--f-body)}.fh-t .pr{font:400 22px var(--f-head);color:var(--c-accent);border-top:3px dashed var(--c-primary);padding-top:8px}
.fh-h{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:20px;flex-wrap:wrap;gap:10px}
.fh-h h2{font:400 clamp(28px,3.8vw,var(--h2)) var(--f-head);text-transform:uppercase;color:var(--c-primary)}
.fh-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.fh-foot .big{font:400 36px var(--f-head);text-transform:uppercase}
.fh .pagehead{background:color-mix(in srgb,var(--c-secondary) 14%,var(--c-surface));border-left:10px solid var(--c-accent)}.fh .pagehead .wrap{padding-left:clamp(20px,3vw,40px)}.fh .card,.fh .scard,.fh .qcard,.fh .pcard,.fh .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.fh .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.fh .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.fh .svc{display:grid;grid-template-columns:repeat(3,1fr);gap:0;counter-reset:sv}
.fh .scard{display:flex;flex-direction:column;justify-content:space-between;aspect-ratio:1;padding:clamp(18px,2.4vw,32px);border:0;border-radius:0;box-shadow:none;background:color-mix(in srgb,var(--c-primary) 92%,var(--c-surface));color:var(--on-primary);counter-increment:sv}
.fh .scard:nth-child(3n+2){background:var(--c-accent);color:var(--on-accent)}
.fh .scard:nth-child(3n){background:color-mix(in srgb,var(--c-secondary) 55%,var(--c-surface));color:var(--c-text)}
.fh .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.16em;opacity:.8}
.fh .scard .ph{display:none}.fh .scard h3{color:inherit;font-size:clamp(22px,2.4vw,32px)}.fh .scard p{color:inherit;opacity:.85}.fh .scard .m{color:inherit;display:flex;gap:12px;font-size:13px}
@media(max-width:800px){.fh .svc{grid-template-columns:1fr 1fr}.fh .scard{aspect-ratio:auto;min-height:200px}}@media(max-width:520px){.fh .svc{grid-template-columns:1fr}}

.fh .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:30px}
.fh .person{background:color-mix(in srgb,var(--c-surface) 20%,#fff);padding:12px 12px 18px;box-shadow:0 16px 26px -18px rgba(0,0,0,.45);border:0;transform:rotate(-1.4deg);transition:transform .2s}
.fh .person:nth-child(2n){transform:rotate(1.2deg)}.fh .person:nth-child(3n){transform:rotate(-.5deg)}
.fh .person:hover{transform:rotate(0) translateY(-4px)}

.fh .qgrid{display:block;columns:2 300px;column-gap:20px}.fh .qgrid.mt{margin-top:20px}
.fh .qcard{break-inside:avoid;margin-bottom:20px}

.fh .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.fh .masonry .mi{margin:0}.fh .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.fh .masonry{grid-template-columns:1fr 1fr}}

.fh .split.w2{display:block}
.fh .feat{display:grid;grid-template-columns:1.3fr 1fr;gap:clamp(18px,3vw,40px);align-items:center;margin-bottom:clamp(24px,4vw,48px)}
.fh .feat h2{font-size:clamp(26px,3.6vw,48px);line-height:1.04}
.fh .articles.two{grid-template-columns:repeat(3,1fr)!important}
@media(max-width:800px){.fh .feat{grid-template-columns:1fr}.fh .articles.two{grid-template-columns:1fr!important}}

.fh .faq{display:grid;gap:10px}
.fh .faq details{border:1px solid var(--c-primary);padding:6px 18px;background:var(--c-surface)}.fh .faq details[open]{background:color-mix(in srgb,var(--c-accent) 10%,var(--c-surface))}

.fh .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.fh .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.fh .pricing .card.hl h3,.fh .pricing .card.hl .amt{color:var(--c-primary)!important}.fh .pricing .card.hl li::before{color:var(--c-accent)!important}
.fh .split{display:block;max-width:760px;margin:0 auto}.fh .cinfo{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:34px}
.fh .sec.dark{background:var(--c-accent);color:var(--on-accent)}.fh .sec.dark h2,.fh .sec.dark p{color:var(--on-accent)}.fh .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.fh .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.fh .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.fh .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.fh .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.fh .tl>div:last-child{border-right:0}
.fh .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.fh .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.fh .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.fh .vals .card:last-child{border-right:0}
@media(max-width:700px){.fh .vals{grid-template-columns:1fr}.fh .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}
</style><div class="fh-call"><span>Same-day callouts, 7 days a week</span><a href="tel:0312345678">03 1234 5678</a></div><header class="fh-head"><a class="fh-logo" href="index.php"><i></i>FixIt Home</a><ul class="fh-nav"><li><a href="services.php">Services</a></li><li><a href="pricing.php">Prices</a></li><li><a href="service-areas.php">Areas</a></li><li><a href="blog.php">Home tips</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Price Guide</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Service Packs</a><a href="product.php">Single Pack</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Recent Jobs</a><a href="project.php">Single Job</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Home Tips</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Book a technician</a><a href="quote.php">Instant quote</a><a href="service-areas.php">Service areas</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="fh-cta" href="booking.php">Book a visit</a></li></ul><details class="fh-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Price Guide</a><a href="contact.php">Contact</a><a href="shop.php">Service Packs</a><a href="product.php">Single Pack</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Recent Jobs</a><a href="project.php">Single Job</a><a href="gallery.php">Gallery</a><a href="blog.php">Home Tips</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Book a technician</a><a href="quote.php">Instant quote</a><a href="service-areas.php">Service areas</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="fh"><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
