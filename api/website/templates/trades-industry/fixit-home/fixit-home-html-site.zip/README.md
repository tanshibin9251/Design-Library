# FixIt Home Services

Exported from Design Library · 25 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single Service, Price Guide, Contact, Service Packs, Single Pack, Cart, Checkout, Testimonials, Team, Recent Jobs, Single Job, Gallery, Home Tips, Single post, FAQ, Book a technician, Instant quote, Service areas, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
