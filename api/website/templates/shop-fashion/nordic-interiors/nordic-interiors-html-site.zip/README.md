# Nordic Interiors

Exported from Design Library · 21 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single Service, Design Fees, Contact, Testimonials, Team, Projects, Single Project, Gallery, Journal, Single post, FAQ, Process, Book a consultation, Material library, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
