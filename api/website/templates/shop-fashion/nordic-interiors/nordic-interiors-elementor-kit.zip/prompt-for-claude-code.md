# Build "Nordic Interiors" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #4a4f5c · Secondary #9aa597 · Text #2e3138 · Accent #b98f6c · Surface #f5f2ee · Border #dcd6cc

## 2. Global Fonts
Headings: Marcellus · Body: Outfit
H1 104px / H2 52px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single Service (service) — html/service.html
- Design Fees (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Projects (projects) — html/projects.html
- Single Project (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Process (process) — html/process.html
- Book a consultation (booking) — html/booking.html
- Material library (resources) — html/resources.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
