# Aizome Goods

Exported from Design Library · 13 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, Shop all, Product, Shade guide, Cart, Our dye house, Care guide, Journal, Contact, Shipping & returns, FAQ, Privacy policy, 404 error.

All text and images are placeholders — replace them with your own.
