<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="az-sec" style="text-align:center;padding-top:clamp(80px,12vw,180px)"><div class="az-seal" style="margin:0 auto 26px;width:56px;height:56px;font-size:30px">藍</div><div class="az-line" style="justify-content:center">Error 404</div><h1 style="font-size:clamp(60px,12vw,160px)">404</h1><h2 style="margin:10px 0 28px">This cloth has not been dyed yet.</h2><a class="az-btn" href="index.php">BACK TO THE SHOP</a></section>
<?php include 'includes/footer.php'; ?>
