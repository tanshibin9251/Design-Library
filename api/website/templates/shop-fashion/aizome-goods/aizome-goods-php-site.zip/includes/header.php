<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Aizome Goods';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Aizome Goods</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="aizome-goods" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Aizome Goods — japanese indigo craft shop, tokens only */
.az-strip{background:var(--c-primary);color:var(--on-primary);text-align:center;font:500 12px var(--f-body);letter-spacing:.22em;padding:10px 14px}
.az-head{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:20px;padding:0 clamp(18px,4vw,52px);min-height:84px;border-bottom:1px solid var(--c-border);background:var(--c-surface);position:sticky;top:0;z-index:50}
.az-menu{display:flex;gap:clamp(18px,2.6vw,38px);list-style:none;font:500 14px var(--f-body);letter-spacing:.14em;align-items:center}
.az-menu.r{justify-content:flex-end}
.az-menu a{text-decoration:none;display:inline-block;padding:10px 0;min-height:44px;line-height:1.25}
.az-menu a:hover{color:var(--c-accent)}
.az-menu .jp{display:block;font:400 11px var(--f-body);letter-spacing:.3em;color:var(--c-secondary);margin-top:4px}
.az-logo{display:flex;flex-direction:column;align-items:center;gap:8px;text-decoration:none;color:var(--c-primary);line-height:1}
.az-seal{display:grid;place-items:center;width:32px;height:32px;background:var(--c-accent);color:var(--on-accent);font:500 17px var(--f-head);border-radius:0}
.az-logo b{font:500 15px var(--f-head);letter-spacing:.42em;margin-right:-.42em}
.az-cart{border:1px solid var(--c-primary);padding:.55em 1.1em!important;min-height:0!important}
.az-more{position:relative}
.az-more .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:20px 34px;padding:24px 28px;background:var(--c-surface);border:1px solid var(--c-border);min-width:640px;z-index:60;text-align:left;letter-spacing:0}
.az-more:hover .dd,.az-more:focus-within .dd{display:grid}
.az-more .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;margin:0 0 8px;color:var(--c-secondary)}
.az-more .dd a{display:block;padding:5px 0;min-height:0;font:500 14px var(--f-body);letter-spacing:0}
.az-m{display:none}
.az-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:500 13px var(--f-body);letter-spacing:.2em}
.az-m summary::-webkit-details-marker{display:none}
.az-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:1px solid var(--c-border);padding:14px 20px 22px;display:grid;gap:2px}
.az-m nav a{padding:12px 4px;text-decoration:none;font:500 15px var(--f-body);border-bottom:1px solid var(--c-border);min-height:44px}
@media(max-width:900px){.az-head{grid-template-columns:auto 1fr auto;min-height:70px}.az-head .az-menu{display:none}.az-m{display:block}.az-logo{align-items:flex-start;flex-direction:row;align-items:center}.az-logo b{margin:0;letter-spacing:.3em}}

.az-sec{padding:var(--pad) clamp(20px,5vw,80px)}
.az-line{display:flex;align-items:center;gap:18px;margin:0 0 34px;font:500 12px var(--f-body);letter-spacing:.34em;text-transform:uppercase;color:var(--c-secondary)}
.az-line::after{content:"";flex:1;height:1px;background:var(--c-border)}
.az-btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;min-height:48px;padding:.9em 2.2em;border:1px solid var(--c-primary);background:var(--c-primary);color:var(--on-primary);font:500 14px var(--f-body);letter-spacing:.24em;text-decoration:none;cursor:pointer;transition:background .25s,color .25s}
.az-btn:hover{background:transparent;color:var(--c-primary)}
.az-btn.o{background:transparent;color:var(--c-primary)}.az-btn.o:hover{background:var(--c-primary);color:var(--on-primary)}
.az-ph{position:relative;width:100%;aspect-ratio:3/4;background:
  repeating-linear-gradient(90deg,transparent 0 11px,color-mix(in srgb,var(--c-primary) 14%,transparent) 11px 12px),
  repeating-linear-gradient(0deg,transparent 0 11px,color-mix(in srgb,var(--c-primary) 14%,transparent) 11px 12px),
  color-mix(in srgb,var(--c-primary) 18%,var(--c-surface))}
.az-ph::after{content:attr(data-l);position:absolute;left:12px;bottom:10px;font:600 10px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-primary)}
.az-ph.w{aspect-ratio:16/10}.az-ph.sq{aspect-ratio:1}

/* hero: noren curtain */
.az-noren{position:relative;padding:0 clamp(20px,5vw,80px)}
.az-rod{height:8px;background:var(--c-primary);margin:0 calc(-1*clamp(20px,5vw,80px))}
.az-curt{display:grid;grid-template-columns:repeat(5,1fr);gap:clamp(8px,1.4vw,18px);padding:0 clamp(0px,3vw,60px);align-items:start}
.az-p{display:flex;flex-direction:column;justify-content:space-between;align-items:center;height:var(--h);min-height:240px;padding:26px 10px 22px;color:var(--on-primary);text-decoration:none;background:color-mix(in srgb,var(--c-primary) var(--m),#fff);transform-origin:50% 0;transition:transform .9s cubic-bezier(.2,.8,.2,1)}
.az-p:hover,.az-p:focus-visible{transform:rotate(-1.6deg) skewX(-1deg)}
.az-p:nth-child(even):hover{transform:rotate(1.6deg) skewX(1deg)}
.az-p .v{writing-mode:vertical-rl;font:500 clamp(20px,2.4vw,30px) var(--f-head);letter-spacing:.4em}
.az-p i{font:400 11px var(--f-body);letter-spacing:.26em;text-transform:uppercase;font-style:normal;opacity:.85}
.az-p.lt{color:var(--c-primary)}
.az-hero-txt{display:grid;grid-template-columns:1.2fr 1fr;gap:clamp(24px,6vw,100px);align-items:end;padding:clamp(40px,6vw,84px) 0 clamp(50px,7vw,100px)}
.az-hero-txt h1{font-size:clamp(40px,6.4vw,var(--h1));color:var(--c-primary);letter-spacing:.06em}
.az-hero-txt .en{display:block;font:500 12px var(--f-body);letter-spacing:.34em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:22px}
.az-hero-txt p{font:400 16px/2 var(--f-body);max-width:40ch}
@media(max-width:800px){.az-curt{grid-template-columns:repeat(5,minmax(0,1fr));padding:0}.az-p{min-height:190px;padding:18px 4px 14px}.az-p i{display:none}.az-hero-txt{grid-template-columns:1fr}}

/* products */
.az-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:clamp(18px,2.4vw,36px) clamp(14px,2vw,28px)}
.az-card{display:grid;gap:6px;text-decoration:none;align-content:start}
.az-card .no{font:500 11px var(--f-body);letter-spacing:.3em;color:var(--c-accent);margin-top:10px}
.az-card h3{font:500 19px var(--f-head);letter-spacing:.08em;color:var(--c-primary)}
.az-card .jp{font:400 12px var(--f-body);letter-spacing:.26em;color:var(--c-secondary)}
.az-card .pr{font:500 15px var(--f-body);margin-top:2px}
.az-card .dots{display:flex;gap:6px;margin-top:4px}.az-card .dots i{width:12px;height:12px;border-radius:50%;border:1px solid var(--c-border)}
.az-card .az-ph{transition:filter .4s}.az-card:hover .az-ph{filter:saturate(1.3) brightness(.96)}
@media(max-width:1000px){.az-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:700px){.az-grid{grid-template-columns:repeat(2,1fr)}}

/* shade picker */
.az-shades{display:grid;grid-template-columns:repeat(6,1fr);gap:0;border:1px solid var(--c-border)}
.az-shades button{border:0;border-right:1px solid var(--c-border);padding:0;background:none;cursor:pointer;text-align:left;font:inherit;color:inherit;display:grid;grid-template-rows:150px auto;min-height:44px}
.az-shades button:last-child{border-right:0}
.az-shades .sw{background:color-mix(in srgb,var(--c-primary) var(--m),#fff);position:relative;transition:transform .35s}
.az-shades .lb{padding:14px 12px 16px;display:grid;gap:4px}
.az-shades .lb b{font:500 17px var(--f-head);letter-spacing:.14em;color:var(--c-primary)}
.az-shades .lb span{font:400 11px var(--f-body);letter-spacing:.14em;color:var(--c-secondary)}
.az-shades button[aria-pressed=true] .sw::after{content:"";position:absolute;left:50%;bottom:-1px;width:14px;height:14px;background:var(--c-surface);transform:translateX(-50%) rotate(45deg) translateY(50%);border:1px solid var(--c-border);border-width:1px 0 0 1px}
.az-shades button[aria-pressed=true]{background:color-mix(in srgb,var(--c-primary) 5%,var(--c-surface))}
.az-shade-info{display:grid;grid-template-columns:auto 1fr auto;gap:clamp(18px,4vw,60px);align-items:center;padding:32px 6px 0}
.az-shade-info .big{font:500 clamp(54px,7vw,100px)/1 var(--f-head);color:var(--c-primary);letter-spacing:.06em}
.az-shade-info p{max-width:52ch;line-height:1.9}
.az-shade-info .dip{text-align:center;font:400 12px var(--f-body);letter-spacing:.2em;color:var(--c-secondary)}
.az-shade-info .dip b{display:block;font:500 clamp(36px,5vw,64px)/1 var(--f-head);color:var(--c-accent)}
@media(max-width:800px){.az-shades{grid-template-columns:repeat(3,1fr)}.az-shades button:nth-child(3n){border-right:0}.az-shades button:nth-child(-n+3){border-bottom:1px solid var(--c-border)}.az-shade-info{grid-template-columns:1fr;text-align:left}}

/* story band */
.az-story{display:grid;grid-template-columns:.9fr 1.1fr;gap:clamp(30px,6vw,100px);align-items:center}
.az-story .mark{font:500 clamp(120px,18vw,260px)/.9 var(--f-head);color:color-mix(in srgb,var(--c-primary) 10%,var(--c-surface));margin-bottom:-.2em}
.az-steps{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid var(--c-border)}
.az-steps>div{padding:28px 22px 30px 0;border-right:1px solid var(--c-border);padding-left:22px}
.az-steps>div:first-child{padding-left:0}.az-steps>div:last-child{border-right:0}
.az-steps .n{font:500 12px var(--f-body);letter-spacing:.3em;color:var(--c-accent)}
.az-steps h3{font:500 20px var(--f-head);letter-spacing:.1em;margin:8px 0 6px}
.az-steps p{font-size:14px;opacity:.8;line-height:1.8}
@media(max-width:800px){.az-story{grid-template-columns:1fr}.az-steps{grid-template-columns:1fr 1fr}.az-steps>div{border-bottom:1px solid var(--c-border);padding-left:0}.az-steps>div:nth-child(2n){border-right:0;padding-left:18px}}

/* lists */
.az-post{display:grid;grid-template-columns:110px 1fr auto;gap:24px;align-items:baseline;padding:26px 0;border-top:1px solid var(--c-border);text-decoration:none}
.az-post:last-child{border-bottom:1px solid var(--c-border)}
.az-post time{font:500 12px var(--f-body);letter-spacing:.2em;color:var(--c-secondary)}
.az-post h3{font:500 21px var(--f-head);letter-spacing:.06em}
.az-post:hover h3{color:var(--c-accent)}
.az-post .tg{font:500 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}
@media(max-width:700px){.az-post{grid-template-columns:1fr;gap:6px}}
.az-pdp{display:grid;grid-template-columns:1.1fr 1fr;gap:clamp(28px,5vw,80px);align-items:start}
.az-thumbs{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:10px}
.az-pdp h1{font-size:clamp(30px,4vw,48px);letter-spacing:.08em}
.az-pdp .pr{font:500 24px var(--f-body);margin:14px 0 20px}
.az-opt{display:flex;gap:10px;flex-wrap:wrap;margin:8px 0 22px}
.az-opt label{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--c-border);padding:.6em 1em;min-height:44px;cursor:pointer;font:500 13px var(--f-body);letter-spacing:.1em}
.az-opt input{width:auto;accent-color:var(--c-primary)}
.az-opt i{width:16px;height:16px;border-radius:50%;background:color-mix(in srgb,var(--c-primary) var(--m),#fff);border:1px solid var(--c-border)}
.az-lbl{font:600 11px var(--f-body);letter-spacing:.22em;text-transform:uppercase;color:var(--c-secondary)}
.az-tbl{width:100%;border-collapse:collapse;font-size:15px}
.az-tbl th,.az-tbl td{padding:16px 10px;border-top:1px solid var(--c-border);text-align:left;vertical-align:middle}
.az-tbl th{font:600 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-secondary)}
.az-tbl tr:last-child td{border-bottom:1px solid var(--c-border)}
.az-cartwrap{display:grid;grid-template-columns:1.7fr 1fr;gap:clamp(28px,5vw,70px);align-items:start}
.az-sum{border:1px solid var(--c-border);padding:30px;display:grid;gap:14px}
.az-sum div{display:flex;justify-content:space-between;font-size:15px}
.az-sum .t{border-top:1px solid var(--c-border);padding-top:16px;font:500 20px var(--f-head)}
@media(max-width:800px){.az-pdp,.az-cartwrap{grid-template-columns:1fr}.az-tbl{font-size:14px}}

/* footer */
.az-foot{margin-top:var(--pad);color:var(--c-primary)}
.az-wave{height:28px;background:
 radial-gradient(circle at 50% 100%,transparent 0 34%,currentColor 34% 38%,transparent 38% 52%,currentColor 52% 56%,transparent 56% 70%,currentColor 70% 74%,transparent 74%) 0 0/56px 28px,
 radial-gradient(circle at 50% 100%,transparent 0 34%,currentColor 34% 38%,transparent 38% 52%,currentColor 52% 56%,transparent 56% 70%,currentColor 70% 74%,transparent 74%) 28px 14px/56px 28px;opacity:.28}
.az-foot-in{background:var(--c-primary);color:var(--on-primary);padding:clamp(48px,6vw,84px) clamp(20px,5vw,80px) 28px}
.az-foot-top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(30px,6vw,100px)}
.az-foot h4{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;opacity:.7;margin-bottom:12px;color:var(--on-primary)}
.az-foot ul{list-style:none;display:grid;gap:4px}.az-foot li a{text-decoration:none;display:inline-block;padding:6px 0;font-size:14px;opacity:.88;min-height:32px}
.az-foot li a:hover{opacity:1;text-decoration:underline}
.az-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:24px}
.az-foot .big{font:500 28px var(--f-head);letter-spacing:.3em}
.az-foot .copy{margin-top:40px;padding-top:18px;border-top:1px solid color-mix(in srgb,var(--on-primary) 25%,transparent);font-size:12px;letter-spacing:.14em;opacity:.7}
@media(max-width:800px){.az-foot-top{grid-template-columns:1fr}.az-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,video,svg{max-width:100%}
@media(max-width:700px){.az-sec{padding-left:18px;padding-right:18px}}
@media(prefers-reduced-motion:reduce){.az-p,.az-p:hover{transition:none;transform:none}}
</style>
<div class="az-strip">全国送料無料 · Free delivery over RM 250 · Hand-dyed in small lots</div>
<header class="az-head">
<ul class="az-menu"><li><a href="shop.php">Shop<span class="jp">商品</span></a></li><li><a href="shades.php">Shades<span class="jp">色見本</span></a></li><li><a href="story.php">Dye house<span class="jp">染工房</span></a></li></ul>
<details class="az-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="shop.php">Shop all</a><a href="product.php">Product</a><a href="shades.php">Shade guide</a><a href="cart.php">Cart</a><a href="story.php">Our dye house</a><a href="care.php">Care guide</a><a href="journal.php">Journal</a><a href="contact.php">Contact</a><a href="shipping.php">Shipping & returns</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details>
<a class="az-logo" href="index.php"><span class="az-seal">藍</span><b>AIZOME</b></a>
<ul class="az-menu r"><li><a href="care.php">Care<span class="jp">手入れ</span></a></li><li class="az-more"><a href="#" tabindex="0">More<span class="jp">他</span></a><div class="dd"><div><h4>Shop</h4><a href="index.php">Home</a><a href="shop.php">Shop all</a><a href="product.php">Product</a><a href="shades.php">Shade guide</a><a href="cart.php">Cart</a></div><div><h4>Story</h4><a href="story.php">Our dye house</a><a href="care.php">Care guide</a><a href="journal.php">Journal</a></div><div><h4>Help</h4><a href="contact.php">Contact</a><a href="shipping.php">Shipping & returns</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="az-cart" href="cart.php">Cart · 0</a></li></ul>
</header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
