# Build "Aizome Goods" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1f3a5f · Secondary #6f7f93 · Text #1d2733 · Accent #b98322 · Surface #f4efe4 · Border #d9d1bf

## 2. Global Fonts
Headings: Zen Old Mincho · Body: Zen Maru Gothic
H1 80px / H2 42px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 100px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Shop all (shop) — html/shop.html
- Product (product) — html/product.html
- Shade guide (shades) — html/shades.html
- Cart (cart) — html/cart.html
- Our dye house (story) — html/story.html
- Care guide (care) — html/care.html
- Journal (journal) — html/journal.html
- Contact (contact) — html/contact.html
- Shipping & returns (shipping) — html/shipping.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
