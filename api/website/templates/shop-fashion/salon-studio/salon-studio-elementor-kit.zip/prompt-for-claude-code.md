# Build "Maison Verde" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #14803c · Secondary #6b4c4c · Text #1d1a1a · Accent #ff8fa3 · Surface #f7efe9 · Border #e3d6cc

## 2. Global Fonts
Headings: Syne · Body: Albert Sans
H1 104px / H2 52px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 92px vertical · Border radius 16px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Services & prices (services) — html/services.html
- Stylists (stylists) — html/stylists.html
- Stylist profile (stylist) — html/stylist.html
- Gallery (gallery) — html/gallery.html
- Packages (packages) — html/packages.html
- Book (book) — html/book.html
- Visit us (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
