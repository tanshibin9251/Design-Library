<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="sl-sec"><div class="in"><div class="faq"><details open><summary>Do you do consultations?</summary><p>Yes, 15 minutes free before any colour service.</p></details><details><summary>How do I cancel?</summary><p>Up to 12 hours before, free.</p></details></div></div></section></div>
<?php include 'includes/footer.php'; ?>
