<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Oakline Furniture';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Oakline Furniture</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="oakline-furniture" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Oakline — template-specific styles (tokens only, no hex) */
.ok-rail{display:flex;gap:26px;list-style:none;font:600 13px var(--f-body);letter-spacing:.04em}
.ok-bar{background:var(--c-secondary);color:var(--c-surface);font:500 12.5px var(--f-body);letter-spacing:.03em;text-align:center;padding:9px 16px}
.ok-bar b{color:color-mix(in srgb,var(--c-accent) 55%,#fff)}
.ok-hero{display:grid;grid-template-columns:minmax(320px,5fr) 7fr;min-height:min(86vh,760px)}
.ok-hero-l{padding:clamp(32px,5vw,80px) clamp(20px,4vw,64px);display:flex;flex-direction:column;justify-content:space-between;gap:36px;border-right:1px solid var(--c-border)}
.ok-hero-l h1{font-size:clamp(44px,6.4vw,var(--h1));line-height:.98;letter-spacing:-.02em}
.ok-rooms{display:flex;flex-wrap:wrap;gap:8px}
.ok-rooms a{border:1px solid var(--c-border);border-radius:99px;padding:.5em 1.1em;font:600 13px var(--f-body);text-decoration:none}
.ok-rooms a:hover,.ok-rooms a.on{background:var(--c-primary);color:var(--c-surface);border-color:var(--c-primary)}
.ok-scene{position:relative;min-height:420px}
.ok-scene .ph{position:absolute;inset:0;border-radius:0;height:100%}
.ok-pin{position:absolute;z-index:2}
.ok-pin>button{width:34px;height:34px;border-radius:50%;border:2px solid var(--c-surface);background:var(--c-accent);color:var(--c-surface);font:700 16px/1 var(--f-body);cursor:pointer;box-shadow:0 0 0 0 color-mix(in srgb,var(--c-accent) 60%,transparent);animation:ok-pulse 2.4s infinite}
.ok-pin .tip{position:absolute;left:44px;top:50%;translate:0 -50%;min-width:200px;background:var(--c-surface);border:1px solid var(--c-border);padding:12px 14px;border-radius:var(--radius);opacity:0;pointer-events:none;transition:opacity .2s;font:500 13px var(--f-body)}
.ok-pin .tip b{display:block;font:600 15px var(--f-head);margin-bottom:2px}
.ok-pin:hover .tip,.ok-pin:focus-within .tip{opacity:1;pointer-events:auto}
@keyframes ok-pulse{70%{box-shadow:0 0 0 14px transparent}}
.ok-roomtiles{display:grid;grid-template-columns:repeat(5,1fr);gap:0;border-block:1px solid var(--c-border)}
.ok-roomtiles a{padding:30px 22px 26px;border-right:1px solid var(--c-border);text-decoration:none;display:flex;flex-direction:column;gap:46px;transition:background .25s}
.ok-roomtiles a:last-child{border-right:0}
.ok-roomtiles a:hover{background:color-mix(in srgb,var(--c-primary) 8%,var(--c-surface))}
.ok-roomtiles small{font:600 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;opacity:.6}
.ok-roomtiles h3{font-size:clamp(22px,2.2vw,30px)}
.ok-swatches{display:flex;flex-wrap:wrap;gap:22px 34px;align-items:flex-end}
.ok-sw{display:flex;flex-direction:column;gap:10px;align-items:flex-start;font:600 13px var(--f-body);text-decoration:none}
.ok-sw i{width:84px;height:84px;border-radius:50%;border:1px solid var(--c-border);background:var(--s);box-shadow:inset 0 0 0 5px var(--c-surface),inset 0 0 0 6px color-mix(in srgb,var(--c-text) 12%,transparent)}
.ok-sw small{opacity:.6;font-weight:500}
.ok-prods{display:grid;grid-template-columns:repeat(4,1fr);gap:34px 22px}
.ok-prod{text-decoration:none;display:flex;flex-direction:column;gap:6px}
.ok-prod .ph{border-radius:2px}
.ok-prod .lead-t{position:absolute;left:10px;top:10px;z-index:2;background:var(--c-surface);padding:.3em .7em;border-radius:99px;font:600 11px var(--f-body)}
.ok-prod h3{font-size:19px;margin-top:8px}
.ok-prod .dim{font:500 12.5px var(--f-body);opacity:.62}
.ok-prod .row{display:flex;justify-content:space-between;align-items:center}
.ok-dots{display:flex;gap:5px}.ok-dots i{width:13px;height:13px;border-radius:50%;background:var(--s);border:1px solid color-mix(in srgb,var(--c-text) 22%,transparent)}
.ok-craft{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--c-border)}
.ok-craft>div{padding:clamp(24px,3vw,44px);border-right:1px solid var(--c-border)}.ok-craft>div:last-child{border-right:0}
.ok-craft .n{font:400 clamp(54px,6vw,92px)/1 var(--f-head);color:var(--c-accent)}
.ok-craft h3{margin:14px 0 8px}
.ok-showroom{display:grid;grid-template-columns:1fr 1fr;background:var(--c-primary);color:var(--c-surface)}
.ok-showroom>div{padding:clamp(32px,5vw,72px)}
.ok-showroom .ph{height:100%;border-radius:0;min-height:300px}
.ok-showroom h2{color:inherit;margin-bottom:12px}
.ok-showroom .btn{background:var(--c-surface);color:var(--c-primary);border-color:var(--c-surface)}
.ok-filter{display:grid;grid-template-columns:230px 1fr;gap:clamp(24px,4vw,56px)}
.ok-side h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;margin:0 0 12px}
.ok-side ul{list-style:none;margin-bottom:28px;display:grid;gap:8px;font:500 14px var(--f-body)}
.ok-side li a{text-decoration:none;display:flex;justify-content:space-between}.ok-side li a:hover,.ok-side li a.on{color:var(--c-accent);font-weight:700}
.ok-side li small{opacity:.5}
.ok-specs{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:1px solid var(--c-border);margin:22px 0}
.ok-specs div{padding:12px 0;border-bottom:1px solid var(--c-border);display:flex;justify-content:space-between;font:500 14px var(--f-body)}
.ok-specs div:nth-child(odd){padding-right:18px}.ok-specs div:nth-child(even){padding-left:18px;border-left:1px solid var(--c-border)}
.ok-finish{display:flex;gap:12px;margin:8px 0 20px}
.ok-finish button{width:44px;height:44px;border-radius:50%;border:1px solid var(--c-border);background:var(--s);cursor:pointer;outline-offset:3px}
.ok-finish button[aria-pressed=true]{outline:2px solid var(--c-accent)}
.ok-ship{background:color-mix(in srgb,var(--c-primary) 7%,var(--c-surface));padding:14px 16px;border-radius:var(--radius);font:500 13.5px var(--f-body)}
@media(max-width:960px){.ok-hero,.ok-showroom,.ok-filter{grid-template-columns:1fr}.ok-hero-l{border-right:0}.ok-roomtiles{grid-template-columns:repeat(2,1fr)}.ok-roomtiles a{border-bottom:1px solid var(--c-border)}.ok-prods{grid-template-columns:repeat(2,1fr)}.ok-craft{grid-template-columns:1fr}.ok-craft>div{border-right:0;border-bottom:1px solid var(--c-border)}.ok-side{display:none}}
@media(prefers-reduced-motion:reduce){.ok-pin>button{animation:none}}
/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.shoptop{flex-wrap:wrap;gap:8px}.shoptop .sort{width:100%}.shoptop select{max-width:100%}.ok-prods{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px 12px}.ok-pin .tip{left:auto;right:44px;min-width:170px}.ok-scene{overflow:hidden;min-height:340px}.ok-hero h1{font-size:clamp(38px,11vw,60px)}.ok-roomtiles a{padding:20px 14px;gap:24px}.ok-swatches{gap:18px 22px}.ok-sw i{width:64px;height:64px}.ok-specs{grid-template-columns:1fr}.ok-specs div:nth-child(even){padding-left:0;border-left:0}}</style><div class="ok-bar">Made to order in Malaysia · <b>Free delivery &amp; assembly</b> in Klang Valley</div><header class="nav"><div class="wrap"><a class="logo" href="index.php">Oakline</a><ul class="ok-rail"><li><a href="shop.php">Living</a></li><li><a href="shop.php">Dining</a></li><li><a href="shop.php">Bedroom</a></li><li><a href="shop.php">Workspace</a></li><li><a href="materials.php">Woods</a></li><li class="more"><a href="#" tabindex="0">All pages ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">Our workshop</a><a href="contact.php">Showroom</a></div><div><h4>Shop</h4><a href="shop.php">Shop all</a><a href="product.php">Single product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Special</h4><a href="materials.php">Woods & finishes</a><a href="delivery.php">Delivery & assembly</a></div><div><h4>Content</h4><a href="faq.php">FAQ</a><a href="blog.php">Journal</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="btn" href="cart.php">Cart (2)</a><details class="dl-mobile"><summary>Menu</summary><nav class="dl-mobile-links" aria-label="Template pages"><h4>Main</h4><a href="index.php">Home</a><a href="about.php">Our workshop</a><a href="contact.php">Showroom</a><h4>Shop</h4><a href="shop.php">Shop all</a><a href="product.php">Single product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><h4>Special</h4><a href="materials.php">Woods &amp; finishes</a><a href="delivery.php">Delivery &amp; assembly</a><h4>Content</h4><a href="faq.php">FAQ</a><a href="blog.php">Journal</a><h4>Utility</h4><a href="privacy.php">Privacy policy</a></nav></details></div></header>
<style>@media(max-width:820px){.ok-finish button{min-width:44px;min-height:44px}}</style>
<script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Illustrative variant pricing and stock; no real inventory is queried. */
(function(){function start(){document.querySelectorAll('.pdp').forEach(function(detail){var info=detail.querySelector('.pinfo');if(!info)return;var price=info.querySelector('.price'),spec=detail.querySelector('.ok-specs div b'),add=info.querySelector('.buy a'),size='200 cm',finish='Natural oak',status=document.createElement('p');status.className='dl-feedback';status.setAttribute('role','status');info.querySelector('.buy').before(status);var contact=document.querySelector('header a[href*="contact"]')||document.querySelector('.dl-mobile a[href*="contact"]')||document.querySelector('footer a[href*="contact"]'),original=add.getAttribute('href');function update(){var custom=size==='Custom',unavailable=size==='240 cm';price.textContent=custom?'Custom quote':size==='160 cm'?'RM 2,890':'RM 3,290';if(size==='240 cm')price.textContent='RM 3,890';if(spec)spec.textContent=custom?'Made to measure':size;add.setAttribute('aria-disabled',unavailable);add.textContent=custom?'Request a custom quote':unavailable?'Unavailable · sample stock':'Add to cart';add.setAttribute('href',custom&&contact?contact.getAttribute('href'):original);status.textContent=finish+' · '+size+'. '+(custom?'Tell us your dimensions for a quote.':unavailable?'This option demonstrates an out-of-stock state.':'Made to order · 3–4 weeks.')+' Prices and stock are illustrative.';var ship=info.querySelector('.ok-ship');if(ship)ship.textContent=unavailable?'Unavailable in this demo. Choose another size or request a custom quote.':custom?'Made to measure. Lead time is confirmed with your quote.':'Ready in 3–4 weeks. Delivery and assembly included within Klang Valley.';}
info.querySelectorAll('.ok-finish button').forEach(function(button){button.addEventListener('click',function(){finish=button.getAttribute('aria-label');info.querySelectorAll('.ok-finish button').forEach(function(b){b.setAttribute('aria-pressed',b===button)});update()})});info.querySelectorAll('.chips .chip').forEach(function(button){button.addEventListener('click',function(){size=button.textContent.trim();update()})});add.addEventListener('click',function(e){if(add.getAttribute('aria-disabled')==='true'){e.preventDefault();e.stopPropagation()}});update()})}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start()})();
</script>
<main>
