<?php $title = 'Restoration'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Restoration</b></div><h1>Restoration</h1></div></section><section class="hl-sec"><div class="wrap"><div class="hl-col"><a><div class="roman">I</div><h3>Assess</h3><p>A written condition report</p></a><a><div class="roman">II</div><h3>Restore</h3><p>Period-correct repair</p></a><a><div class="roman">III</div><h3>Return</h3><p>Re-signed and recorded</p></a></div></div></section>
<?php include 'includes/footer.php'; ?>
