<?php $title = 'Provenance & timber'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Provenance & timber</b></div><h1>Provenance &amp; timber</h1></div></section><section class="hl-sec"><div class="wrap prose"><p class="lead">Every plank is logged from felling to finish.</p><p>Replace with timber sourcing, certification and drying notes.</p></div></section></div>
<?php include 'includes/footer.php'; ?>
