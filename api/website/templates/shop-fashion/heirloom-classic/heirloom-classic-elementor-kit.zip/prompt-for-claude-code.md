# Build "Heirloom Classic" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #4a1c24 · Secondary #7a6a52 · Text #2a1e1a · Accent #a8803a · Surface #f8f3e8 · Border #d9ccb0

## 2. Global Fonts
Headings: Newsreader · Body: Jost
H1 92px / H2 50px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 112px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Collections (collections) — html/collections.html
- Single collection (collection) — html/collection.html
- The piece (piece) — html/piece.html
- Request a quotation (enquire) — html/enquire.html
- Bespoke commissions (bespoke) — html/bespoke.html
- The atelier (atelier) — html/atelier.html
- Provenance & timber (provenance) — html/provenance.html
- Restoration (restoration) — html/restoration.html
- Chronicle (journal) — html/journal.html
- Visit the salon (visit) — html/visit.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
