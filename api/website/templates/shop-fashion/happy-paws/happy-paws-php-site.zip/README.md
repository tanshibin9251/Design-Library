# Happy Paws

Exported from Design Library · 25 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Vet Care, Single Service, Grooming Prices, Contact, Pet Shop, Single Product, Cart, Checkout, Testimonials, Team, Pet Gallery, Single Pet story, Gallery, Pet Tips, Single post, FAQ, Book a visit, Grooming day, Pet taxi areas, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
