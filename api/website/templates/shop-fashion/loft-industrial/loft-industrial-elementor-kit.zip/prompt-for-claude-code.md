# Build "Loft Industrial" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2a2a2a · Secondary #8a8f94 · Text #ebe6db · Accent #e0793a · Surface #131313 · Border #343434

## 2. Global Fonts
Headings: Big Shoulders Display · Body: IBM Plex Sans
H1 112px / H2 56px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Collection (collection) — html/collection.html
- Spec sheet (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Trade & fit-outs (trade) — html/trade.html
- Installed (projects) — html/projects.html
- Steel & leather (materials) — html/materials.html
- Workshop (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Field notes (journal) — html/journal.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
