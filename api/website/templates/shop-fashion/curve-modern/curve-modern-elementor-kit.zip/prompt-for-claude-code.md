# Build "Curve Modern" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #e4572e · Secondary #3a6ea5 · Text #1c1b22 · Accent #ffc83d · Surface #fff7ec · Border #1c1b22

## 2. Global Fonts
Headings: Plus Jakarta Sans · Body: DM Sans
H1 128px / H2 60px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 32px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Shop (shop) — html/shop.html
- Product (product) — html/product.html
- Bag (bag) — html/bag.html
- Pay (pay) — html/pay.html
- Room ideas (rooms) — html/rooms.html
- Colour club (colours) — html/colours.html
- Our story (about) — html/about.html
- Help centre (help) — html/help.html
- Reviews (reviews) — html/reviews.html
- Say hi (contact) — html/contact.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
