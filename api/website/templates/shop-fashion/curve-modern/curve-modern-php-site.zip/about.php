<?php $title = 'Our story'; include 'includes/header.php'; ?>
<section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Our story</b></div><h1>Two designers, one soft spot for circles</h1></div></section><section class="sec"><div class="wrap split"><div class="ph soft" data-l="Founders (缺图)" style="aspect-ratio:4/5"></div><div class="prose"><p>Replace with your founding story in a friendly, first-person voice. Keep it short and a bit funny.</p></div></div></section>
<?php include 'includes/footer.php'; ?>
