# Build "Renovo Studio" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1b2a41 · Secondary #5c677d · Text #14181f · Accent #c4553a · Surface #ecebe6 · Border #cfcdc5

## 2. Global Fonts
Headings: Libre Bodoni · Body: Work Sans
H1 150px / H2 56px / H3 28px / Body 16px

## 3. Layout
Content width 1300px · Section padding 104px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Projects (projects) — html/projects.html
- Case study (project) — html/project.html
- Services (services) — html/services.html
- How we work (process) — html/process.html
- Investment guide (investment) — html/investment.html
- The studio (about) — html/about.html
- Book a site visit (visit) — html/visit.html
- Notes (journal) — html/journal.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
