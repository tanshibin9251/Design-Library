<?php $title = '404 error'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="sec loose center404"><div class="wrap"><span class="eyebrow">Error 404</span><h1 style="font-size:clamp(80px,16vw,220px)">404</h1><h2>This room is still under construction.</h2><div class="actions" style="justify-content:center;margin-top:24px"><a class="btn" href="index.php">Back to the studio</a></div></div></section></div>
<?php include 'includes/footer.php'; ?>
