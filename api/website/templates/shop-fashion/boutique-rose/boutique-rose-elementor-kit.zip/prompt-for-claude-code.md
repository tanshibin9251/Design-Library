# Build "Boutique Rose" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2a1f2d · Secondary #f2d3da · Text #2a1f2d · Accent #d94f70 · Surface #fbf5f3 · Border #ead9da

## 2. Global Fonts
Headings: Bodoni Moda · Body: Figtree
H1 104px / H2 52px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single service (service) — html/service.html
- Gift Cards (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Shop (shop) — html/shop.html
- Single product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Lookbook (projects) — html/projects.html
- Single Look (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Lookbook (lookbook) — html/lookbook.html
- Size guide (size-guide) — html/size-guide.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
