<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="pb-sec"><div class="in"><div class="faq"><details open><summary>Are vaccinations required?</summary><p>Yes, up to date, with a vet card on first visit.</p></details><details><summary>Do you groom anxious pets?</summary><p>Yes, with a calm one-to-one session and no cages.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
