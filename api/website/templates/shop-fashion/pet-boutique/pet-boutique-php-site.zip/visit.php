<?php $title = 'Visit'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Visit</b></div><h1>Visit</h1></div></section><section class="pb-sec"><div class="in split"><div class="ph soft" data-l="Shop (缺图)" style="aspect-ratio:4/3;border-radius:24px"></div><ul class="kv"><li><span>Address</span><b>G-12 Publika, Solaris Dutamas</b></li><li><span>Hours</span><b>Daily 10am–8pm</b></li><li><span>WhatsApp</span><b>+60 12-345 6000</b></li></ul></div></section>
<?php include 'includes/footer.php'; ?>
