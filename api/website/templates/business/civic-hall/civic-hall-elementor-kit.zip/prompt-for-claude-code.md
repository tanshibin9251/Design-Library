# Build "Civic Hall" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #3f2a73 · Secondary #5b5675 · Text #1b1b1b · Accent #ffdd00 · Surface #ffffff · Border #b9b4c9

## 2. Global Fonts
Headings: Atkinson Hyperlegible · Body: Atkinson Hyperlegible
H1 60px / H2 36px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single Service (service) — html/service.html
- Fees & Permits (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Community Projects (projects) — html/projects.html
- Single Project (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- News & Notices (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Council meetings (schedule) — html/schedule.html
- Report an issue (booking) — html/booking.html
- Notices by email (newsletter) — html/newsletter.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
