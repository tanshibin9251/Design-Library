<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Civic Hall';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Civic Hall</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="civic-hall" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Civic Hall v2 — municipal service directory with accessibility tools, tokens only */
.cv-util{background:var(--c-text);color:var(--c-surface);font:700 13px var(--f-body);display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;padding:0 clamp(14px,4vw,56px);min-height:44px}
.cv-tools{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.cv-tools button,.cv-tools a{min-height:36px;min-width:44px;padding:0 10px;border:2px solid var(--c-surface);background:transparent;color:var(--c-surface);font:700 13px var(--f-body);cursor:pointer;text-decoration:none;display:inline-grid;place-items:center}
.cv-tools button:hover,.cv-tools a:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.cv-head{display:flex;align-items:center;gap:clamp(14px,3vw,40px);padding:0 clamp(14px,4vw,56px);min-height:84px;background:var(--c-surface);border-bottom:8px solid var(--c-primary)}
.cv-logo{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--c-primary)}
.cv-logo i{display:grid;place-items:center;width:48px;height:48px;background:var(--c-primary);color:var(--on-primary);font:700 26px var(--f-head);font-style:normal}
.cv-logo b{display:block;font:700 22px var(--f-head);line-height:1.1}
.cv-logo small{font:700 12px var(--f-body);letter-spacing:.06em;color:var(--c-secondary)}
.cv-nav{display:flex;list-style:none;margin-left:auto;gap:2px;align-items:center}
.cv-nav a{display:inline-flex;align-items:center;min-height:48px;padding:0 14px;font:700 16px var(--f-body);color:var(--c-text);text-decoration:underline;text-decoration-color:transparent;text-underline-offset:6px;text-decoration-thickness:3px}
.cv-nav a:hover,.cv-nav a:focus-visible{text-decoration-color:var(--c-accent);background:color-mix(in srgb,var(--c-accent) 18%,transparent)}
.cv-nav .more{position:relative}
.cv-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(150px,1fr));gap:18px 28px;padding:22px 26px;background:var(--c-surface);border:3px solid var(--c-primary);min-width:680px;z-index:60}
.cv-nav .more:hover .dd,.cv-nav .more:focus-within .dd{display:grid}
.cv-nav .dd h4{font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.cv-nav .dd a{display:block;min-height:0;padding:5px 0;font-weight:600;font-size:15px}
.cv-m{display:none;margin-left:auto;position:relative}
.cv-m summary{list-style:none;cursor:pointer;min-height:48px;min-width:48px;display:grid;place-items:center;border:3px solid var(--c-primary);padding:0 14px;font:700 14px var(--f-body)}
.cv-m summary::-webkit-details-marker{display:none}
.cv-m nav{position:absolute;right:0;top:100%;min-width:260px;background:var(--c-surface);border:3px solid var(--c-primary);padding:6px 18px;display:grid;z-index:60}
.cv-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);font:700 16px var(--f-body);min-height:48px;text-decoration:none}
@media(max-width:980px){.cv-nav{display:none}.cv-m{display:block}}
.cv-hc{--c-surface:#000;--c-text:#fff;--c-primary:#ffdd00;--c-secondary:#fff;--c-border:#fff;--c-accent:#ffdd00;--on-primary:#000;--on-accent:#000;background:#000;color:#fff}
.cv-hc .cv-util{background:#fff;color:#000}.cv-hc .cv-tools button,.cv-hc .cv-tools a{color:#000;border-color:#000}

.cv-sec{padding:clamp(34px,5vw,64px) clamp(14px,4vw,56px)}
.cv-hero{background:color-mix(in srgb,var(--c-primary) 8%,var(--c-surface));padding:clamp(36px,6vw,80px) clamp(14px,4vw,56px)}
.cv-hero h1{font:700 clamp(34px,5.4vw,var(--h1))/1.1 var(--f-head);color:var(--c-primary);max-width:18ch}
.cv-hero p{font:400 20px/1.6 var(--f-body);margin:14px 0 24px;max-width:50ch}
.cv-find{display:flex;max-width:720px;border:3px solid var(--c-text);background:var(--c-surface)}
.cv-find input{flex:1;min-height:60px;border:0;font:400 20px var(--f-body);padding:0 16px;background:transparent;color:var(--c-text);outline:0;border-radius:0}
.cv-find button{min-width:120px;border:0;background:var(--c-primary);color:var(--on-primary);font:700 18px var(--f-body);cursor:pointer}
.cv-find:focus-within{outline:4px solid var(--c-accent);outline-offset:2px}
.cv-tasks{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:3px solid var(--c-text);border-left:3px solid var(--c-text);margin-top:28px;max-width:980px}
.cv-task{display:grid;gap:6px;padding:20px 20px 22px;border-right:3px solid var(--c-text);border-bottom:3px solid var(--c-text);background:var(--c-surface);text-decoration:none;color:var(--c-text);min-height:132px;align-content:space-between}
.cv-task b{font:700 24px var(--f-head);color:var(--c-primary);text-decoration:underline;text-decoration-thickness:3px;text-underline-offset:5px}
.cv-task span{font:400 16px/1.5 var(--f-body)}
.cv-task em{font:700 14px var(--f-body);font-style:normal;color:var(--c-secondary)}
.cv-task:hover{background:var(--c-accent);color:var(--on-accent)}.cv-task:hover b,.cv-task:hover em{color:var(--on-accent)}
.cv-task.hide{display:none}
@media(max-width:800px){.cv-tasks{grid-template-columns:1fr 1fr}}@media(max-width:520px){.cv-tasks{grid-template-columns:1fr}}
.cv-two{display:grid;grid-template-columns:1.4fr 1fr;gap:clamp(24px,4vw,56px);align-items:start}
@media(max-width:860px){.cv-two{grid-template-columns:1fr}}
.cv-h{font:700 clamp(24px,3vw,var(--h2)) var(--f-head);color:var(--c-text);border-bottom:4px solid var(--c-primary);padding-bottom:8px;margin-bottom:6px}
.cv-notice{display:grid;grid-template-columns:110px 1fr auto;gap:16px;align-items:baseline;padding:16px 0;border-bottom:1px solid var(--c-border);text-decoration:none;color:var(--c-text)}
.cv-notice time{font:700 14px var(--f-body);color:var(--c-secondary)}
.cv-notice b{font:700 18px/1.35 var(--f-body);text-decoration:underline;text-underline-offset:4px;color:var(--c-primary)}
.cv-notice span{font:700 12px var(--f-body);letter-spacing:.06em;text-transform:uppercase;background:var(--c-accent);color:var(--on-accent);padding:2px 8px}
@media(max-width:560px){.cv-notice{grid-template-columns:1fr;gap:4px}}
.cv-box{border:3px solid var(--c-text);padding:22px;background:var(--c-surface);display:grid;gap:12px}
.cv-box h3{font:700 22px var(--f-head);color:var(--c-primary)}
.cv-date{display:inline-grid;grid-template-columns:auto 1fr;gap:14px;align-items:center}
.cv-date i{display:grid;place-items:center;width:76px;height:76px;background:var(--c-primary);color:var(--on-primary);font:700 30px/1 var(--f-head);font-style:normal;text-align:center}
.cv-date i small{display:block;font:700 12px var(--f-body);letter-spacing:.1em}
.cv-bin{display:flex;gap:8px;flex-wrap:wrap}
.cv-bin input{flex:1;min-width:140px;min-height:52px;border:3px solid var(--c-text);padding:0 12px;font:400 18px var(--f-body);background:var(--c-surface);color:var(--c-text);border-radius:0}
.cv-bin button{min-height:52px;padding:0 20px;border:0;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);cursor:pointer}
.cv-res{font:700 18px/1.5 var(--f-body);background:color-mix(in srgb,var(--c-accent) 25%,var(--c-surface));border-left:8px solid var(--c-accent);padding:12px 14px;display:none}
.cv-res.on{display:block}
.cv-steps{counter-reset:s;list-style:none;display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.cv-steps li{counter-increment:s;border-top:6px solid var(--c-primary);padding-top:14px;font:400 17px/1.6 var(--f-body)}
.cv-steps li::before{content:"Step " counter(s);display:block;font:700 13px var(--f-body);letter-spacing:.08em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:4px}
.cv-steps b{font:700 20px var(--f-head);display:block;color:var(--c-primary)}
@media(max-width:700px){.cv-steps{grid-template-columns:1fr}}
.cv-btn{display:inline-flex;align-items:center;min-height:52px;padding:0 24px;background:var(--c-primary);color:var(--on-primary);font:700 17px var(--f-body);text-decoration:none;border:3px solid var(--c-primary);cursor:pointer}
.cv-btn:hover{background:var(--c-accent);color:var(--on-accent);border-color:var(--c-text)}
.cv-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 24px;margin-top:clamp(30px,5vw,70px)}
.cv-foot .top{display:grid;grid-template-columns:1.2fr 2.4fr;gap:clamp(24px,5vw,80px)}
.cv-foot h4{font:700 13px var(--f-body);letter-spacing:.08em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.cv-foot ul{list-style:none}.cv-foot li a{display:inline-block;padding:6px 0;font:600 16px var(--f-body);color:var(--on-primary);min-height:36px}
.cv-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.cv-foot .emg{border:3px solid var(--c-accent);padding:14px 16px;margin-top:16px;font:700 17px/1.5 var(--f-body)}
.cv-foot .copy{margin-top:26px;padding-top:16px;border-top:1px solid color-mix(in srgb,var(--on-primary) 40%,transparent);font:400 14px var(--f-body)}
@media(max-width:860px){.cv-foot .top{grid-template-columns:1fr}.cv-foot .cols{grid-template-columns:1fr 1fr}}
.cv a:focus-visible,.cv button:focus-visible,.cv input:focus-visible{outline:4px solid var(--c-accent);outline-offset:2px}
html,body{overflow-x:clip}img,svg{max-width:100%}
.cv .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.cv .pagehead h1{max-width:none}.cv .card,.cv .scard,.cv .qcard,.cv .pcard,.cv .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.cv .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.cv .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.cv .svc{display:block;border-top:2px solid var(--c-primary);counter-reset:sv}
.cv .scard{display:grid;grid-template-columns:56px minmax(0,1.1fr) minmax(0,1.7fr) auto;gap:6px 24px;align-items:baseline;padding:22px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;counter-increment:sv;transition:padding .2s}
.cv .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.cv .scard .ph{display:none}.cv .scard .b{display:contents}
.cv .scard h3{font-size:clamp(20px,2.2vw,28px)}.cv .scard p{margin:0;opacity:.8}
.cv .scard .m{display:flex;flex-direction:column;align-items:flex-end;gap:2px;font:600 13px var(--f-body);white-space:nowrap}
.cv .scard:hover{padding-left:14px}
@media(max-width:760px){.cv .scard{grid-template-columns:36px 1fr}.cv .scard p,.cv .scard .m{grid-column:2;align-items:flex-start}}

.cv .tgrid{display:block;border-top:2px solid var(--c-primary)}.cv .tgrid.mt{margin-top:0}
.cv .person{display:grid;grid-template-columns:1fr auto;gap:4px 20px;align-items:baseline;padding:18px 0;border-bottom:1px solid var(--c-border);background:none;border-radius:0;box-shadow:none;border-left:0;border-right:0;border-top:0;text-align:left}
.cv .person .ph{display:none}.cv .person h3{font-size:clamp(20px,2.2vw,28px)}.cv .person span{font:600 13px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-accent)}

.cv .qgrid{display:block;border-top:2px solid var(--c-primary)}.cv .qgrid.mt{margin-top:0}
.cv .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.cv .qcard .stars{grid-column:1}.cv .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.cv .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.cv .qcard{grid-template-columns:1fr}.cv .qcard figcaption{grid-column:1;grid-row:auto}}

.cv .masonry{display:block!important;columns:auto;border-top:2px solid var(--c-primary)}
.cv .masonry .mi{display:grid;grid-template-columns:150px 1fr auto;gap:18px;align-items:center;padding:14px 0;border-bottom:1px solid var(--c-border);margin:0}
.cv .masonry .mi .ph{aspect-ratio:3/2!important;min-height:0}
@media(max-width:600px){.cv .masonry .mi{grid-template-columns:100px 1fr}.cv .masonry .mi .muted{display:none}}

.cv .articles{display:block!important}
.cv .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.cv .art .ph{display:none}.cv .art .meta{grid-row:1/span 2;align-self:start}.cv .art h3{margin:0}
.cv .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}

.cv .faq{counter-reset:q;max-width:960px}
.cv .faq details{counter-increment:q;position:relative;padding-left:64px}
.cv .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.cv .pricing{display:block;border-top:2px solid var(--c-primary)}
.cv .pricing .card{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1.5fr) auto;gap:10px 28px;align-items:center;padding:24px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none!important;box-shadow:none;transform:none!important;color:inherit!important}
.cv .pricing .card h3,.cv .pricing .card .amt{color:var(--c-primary)!important;margin:0}
.cv .pricing .card.hl{background:color-mix(in srgb,var(--c-accent) 12%,var(--c-surface))!important}
.cv .pricing ul{margin:0;display:flex;gap:6px 16px;flex-wrap:wrap}.cv .pricing li{font-size:14px}
@media(max-width:820px){.cv .pricing .card{grid-template-columns:1fr auto}.cv .pricing ul{grid-column:1/-1}}

.cv .cinfo{display:block;border-top:2px solid var(--c-primary)}
.cv .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.cv .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.cv .cinfo .card p{margin:0}
.cv .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.cv .sec.dark h2,.cv .sec.dark p{color:var(--c-text)}
.cv .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.cv .steps>div{border:0;padding:0 0 26px;position:relative}.cv .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.cv .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.cv .tl>div{position:relative;padding:0 0 28px}.cv .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.cv .tl b{font-size:clamp(24px,3vw,36px)}

.cv .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.cv .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.cv .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.cv .vals .card h3{margin:0}.cv .vals .card p{margin:0}
@media(max-width:700px){.cv .vals .card{grid-template-columns:36px 1fr}.cv .vals .card p{grid-column:2}}

.cv-bud{display:grid;gap:10px;margin-top:12px}.cv-bud div{display:grid;grid-template-columns:150px 1fr 60px;gap:14px;align-items:center;font:700 16px var(--f-body)}
.cv-bud i{display:block;height:22px;background:var(--c-border)}.cv-bud i::after{content:"";display:block;height:100%;width:var(--p);background:var(--c-primary)}
.cv-az{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:22px}.cv-az a{display:grid;place-items:center;min-width:44px;min-height:44px;border:2px solid var(--c-text);font:700 17px var(--f-body);text-decoration:none;color:var(--c-primary)}.cv-az a:hover{background:var(--c-accent)}
.cv-dir h3{font:700 32px var(--f-head);color:var(--c-primary);border-bottom:3px solid var(--c-text);margin:26px 0 4px;padding-bottom:4px}
.cv-dir a{display:grid;grid-template-columns:1fr 150px 120px;gap:14px;padding:14px 0;border-bottom:1px solid var(--c-border);text-decoration:none;color:var(--c-text);align-items:baseline;min-height:48px}
.cv-dir a b{font:700 18px var(--f-body);color:var(--c-primary);text-decoration:underline;text-underline-offset:4px}
.cv-dir a span{font:400 15px var(--f-body)}
@media(max-width:700px){.cv-dir a{grid-template-columns:1fr}.cv-bud div{grid-template-columns:100px 1fr 44px}}</style><div class="cv-util"><span>Municipal Council of Contoh · Open Mon–Fri 08:00–17:00</span><div class="cv-tools" role="group" aria-label="Accessibility"><button type="button" data-z="0.9" aria-label="Smaller text">A−</button><button type="button" data-z="1" aria-label="Normal text">A</button><button type="button" data-z="1.15" aria-label="Larger text">A+</button><button type="button" id="cv-hc" aria-pressed="false">High contrast</button><a href="#">BM</a></div></div><header class="cv-head"><a class="cv-logo" href="index.php"><i>C</i><span><b>Civic Hall</b><small>MUNICIPAL COUNCIL</small></span></a><ul class="cv-nav"><li><a href="services.php">Services</a></li><li><a href="schedule.php">Meetings</a></li><li><a href="blog.php">News</a></li><li><a href="contact.php">Contact</a></li><li class="more"><a href="#" tabindex="0">All pages</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Fees & Permits</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Community Projects</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">News & Notices</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="schedule.php">Council meetings</a><a href="booking.php">Report an issue</a><a href="newsletter.php">Notices by email</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><details class="cv-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Fees & Permits</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Community Projects</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a><a href="blog.php">News & Notices</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="schedule.php">Council meetings</a><a href="booking.php">Report an issue</a><a href="newsletter.php">Notices by email</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="cv"><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
