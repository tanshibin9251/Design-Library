# Build "Lexington & Co" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2e3440 · Secondary #6e7a85 · Text #232830 · Accent #a1453b · Surface #f6f5f1 · Border #d6d6d0

## 2. Global Fonts
Headings: Domine · Body: Public Sans
H1 62px / H2 38px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Practice Areas (services) — html/services.html
- Single Practice area (service) — html/service.html
- Fees (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Case Results (projects) — html/projects.html
- Single Case result (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Insights (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Free consultation (booking) — html/booking.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
