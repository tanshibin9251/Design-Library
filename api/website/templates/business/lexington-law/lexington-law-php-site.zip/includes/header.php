<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Lexington & Co';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Lexington &amp; Co</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Lexington & Co v2 — case-file broadsheet law firm, tokens only */
.lx-mast{border-bottom:1px solid var(--c-text);padding:8px clamp(14px,4vw,56px);display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;font:600 12px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary)}
.lx-head{text-align:center;padding:clamp(18px,2.4vw,30px) clamp(14px,4vw,56px) 0}
.lx-logo{font:700 clamp(30px,4.4vw,52px)/1 var(--f-head);letter-spacing:.01em;color:var(--c-primary);text-decoration:none}
.lx-logo small{display:block;font:600 11px var(--f-body);letter-spacing:.36em;text-transform:uppercase;color:var(--c-accent);margin-top:8px}
.lx-nav{display:flex;justify-content:center;gap:clamp(8px,2vw,34px);list-style:none;margin-top:16px;border-top:3px double var(--c-text);border-bottom:1px solid var(--c-text);flex-wrap:wrap;position:sticky;top:0;background:var(--c-surface);z-index:50}
.lx-nav a{display:inline-flex;align-items:center;min-height:48px;padding:0 6px;text-decoration:none;font:700 13px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-text)}
.lx-nav a:hover{color:var(--c-accent)}
.lx-nav .more{position:relative}
.lx-nav .dd{position:absolute;left:50%;transform:translateX(-50%);top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-text);min-width:620px;z-index:60;text-align:left}
.lx-nav .more:hover .dd,.lx-nav .more:focus-within .dd{display:grid}
.lx-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.lx-nav .dd a{display:block;min-height:0;padding:5px 0;font:500 15px var(--f-body);letter-spacing:0;text-transform:none}
.lx-m{display:none}
.lx-m summary{list-style:none;cursor:pointer;min-height:48px;display:grid;place-items:center;font:700 12px var(--f-body);letter-spacing:.2em;border-top:3px double var(--c-text);border-bottom:1px solid var(--c-text);margin-top:16px}
.lx-m summary::-webkit-details-marker{display:none}
.lx-m nav{display:grid;text-align:left;padding:4px 0 8px}
.lx-m nav a{padding:12px 6px;border-bottom:1px solid var(--c-border);text-decoration:none;font:500 16px var(--f-body);min-height:46px}
@media(max-width:860px){.lx-nav{display:none}.lx-m{display:block}}
.lx-wrap{display:grid;grid-template-columns:230px minmax(0,1fr) 300px;gap:0;padding:0 clamp(14px,4vw,56px)}
@media(max-width:1060px){.lx-wrap{grid-template-columns:1fr}}
.lx-col{padding:clamp(22px,3vw,36px) clamp(16px,2vw,28px);border-right:1px solid var(--c-border)}
.lx-col:first-child{padding-left:0}.lx-col:last-child{border-right:0;padding-right:0}
@media(max-width:1060px){.lx-col{border-right:0;border-bottom:1px solid var(--c-border);padding-left:0;padding-right:0}}
.lx-lab{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent);border-bottom:1px solid var(--c-text);padding-bottom:6px;margin-bottom:10px}
.lx-az{list-style:none}
.lx-az a{display:flex;justify-content:space-between;gap:10px;padding:9px 0;border-bottom:1px dotted var(--c-secondary);text-decoration:none;font:600 16px var(--f-head);color:var(--c-primary);min-height:44px;align-items:center}
.lx-az a span{font:700 11px var(--f-body);letter-spacing:.1em;color:var(--c-secondary)}
.lx-az a:hover{color:var(--c-accent)}
.lx-hl h1{font:700 clamp(34px,4.8vw,var(--h1))/1.08 var(--f-head);letter-spacing:-.01em;color:var(--c-primary)}
.lx-by{font:600 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin:14px 0}
.lx-hl .st{font:italic 400 21px/1.6 var(--f-head);color:var(--c-text);border-top:1px solid var(--c-text);border-bottom:1px solid var(--c-text);padding:16px 0;margin:16px 0}
.lx-hl p{font:400 17px/1.85 var(--f-body)}
.lx-hl .dc::first-letter{font:700 4em/.8 var(--f-head);float:left;padding:6px 10px 0 0;color:var(--c-accent)}
.lx-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 24px;background:var(--c-primary);color:var(--on-primary);font:700 13px var(--f-body);letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border:2px solid var(--c-primary);cursor:pointer}
.lx-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.lx-btn.o{background:transparent;color:var(--c-primary)}.lx-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.lx-ask{border:1px solid var(--c-text);padding:20px;display:grid;gap:12px;background:color-mix(in srgb,var(--c-secondary) 8%,var(--c-surface))}
.lx-ask h3{font:700 22px var(--f-head);color:var(--c-primary)}
.lx-ask p{font:400 15px/1.7 var(--f-body)}
.lx-ask input,.lx-ask select{min-height:48px;border:1px solid var(--c-text);border-radius:0;padding:0 12px;font:500 15px var(--f-body);background:var(--c-surface);color:var(--c-text);width:100%}
.lx-tri{max-width:820px;margin:0 auto;border:1px solid var(--c-text);padding:clamp(20px,3vw,40px);background:var(--c-surface)}
.lx-tri h2{font:700 clamp(24px,3vw,36px) var(--f-head);color:var(--c-primary);margin-bottom:6px}
.lx-q{margin:20px 0 6px;font:700 17px var(--f-body)}
.lx-o{display:flex;gap:8px;flex-wrap:wrap}
.lx-o button{min-height:46px;padding:0 18px;border:1px solid var(--c-text);background:transparent;color:var(--c-text);font:600 15px var(--f-body);cursor:pointer}
.lx-o button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.lx-res{margin-top:22px;padding:16px 18px;border-left:6px solid var(--c-accent);background:color-mix(in srgb,var(--c-accent) 8%,var(--c-surface));font:500 16px/1.7 var(--f-body);display:none}
.lx-res.on{display:block}
.lx-ins{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:3px double var(--c-text)}
.lx-ins a{padding:20px 22px 22px 0;border-right:1px solid var(--c-border);text-decoration:none;color:var(--c-text);display:grid;gap:6px;padding-left:22px;align-content:start}
.lx-ins a:first-child{padding-left:0}.lx-ins a:last-child{border-right:0}
.lx-ins time{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent)}
.lx-ins b{font:700 20px/1.3 var(--f-head);color:var(--c-primary)}
.lx-ins a:hover b{color:var(--c-accent)}
.lx-ins span{font:400 15px/1.7 var(--f-body)}
@media(max-width:800px){.lx-ins{grid-template-columns:1fr}.lx-ins a{border-right:0;border-bottom:1px solid var(--c-border);padding-left:0}}
.lx-sec{padding:clamp(34px,5vw,70px) clamp(14px,4vw,56px)}
.lx-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,4vw,56px) 22px}
.lx-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.lx-foot .big{font:700 30px var(--f-head)}
.lx-foot h4{font:700 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.lx-foot ul{list-style:none}.lx-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:400 15px var(--f-body);color:var(--on-primary);min-height:34px}
.lx-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.lx-foot .copy{margin-top:24px;font:400 12px/1.7 var(--f-body);opacity:.8}
@media(max-width:860px){.lx-foot .top{grid-template-columns:1fr}.lx-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
.lx .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.lx .pagehead h1{max-width:none}.lx .card,.lx .scard,.lx .qcard,.lx .pcard,.lx .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.lx .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.lx .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.lx .svc{display:block;border-top:2px solid var(--c-primary);counter-reset:sv}
.lx .scard{display:grid;grid-template-columns:56px minmax(0,1.1fr) minmax(0,1.7fr) auto;gap:6px 24px;align-items:baseline;padding:22px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;counter-increment:sv;transition:padding .2s}
.lx .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.14em;color:var(--c-accent)}
.lx .scard .ph{display:none}.lx .scard .b{display:contents}
.lx .scard h3{font-size:clamp(20px,2.2vw,28px)}.lx .scard p{margin:0;opacity:.8}
.lx .scard .m{display:flex;flex-direction:column;align-items:flex-end;gap:2px;font:600 13px var(--f-body);white-space:nowrap}
.lx .scard:hover{padding-left:14px}
@media(max-width:760px){.lx .scard{grid-template-columns:36px 1fr}.lx .scard p,.lx .scard .m{grid-column:2;align-items:flex-start}}

.lx .tgrid{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:2px solid var(--c-primary)}
.lx .person{display:grid;grid-template-columns:110px 1fr;gap:4px 18px;align-items:center;padding:20px 20px 20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;text-align:left}
.lx .person .ph{grid-row:span 2;aspect-ratio:1!important}
@media(max-width:700px){.lx .tgrid{grid-template-columns:1fr}}

.lx .qgrid{display:block;border-top:2px solid var(--c-primary)}.lx .qgrid.mt{margin-top:0}
.lx .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.lx .qcard .stars{grid-column:1}.lx .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.lx .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.lx .qcard{grid-template-columns:1fr}.lx .qcard figcaption{grid-column:1;grid-row:auto}}

.lx .masonry{display:block!important;columns:auto;border-top:2px solid var(--c-primary)}
.lx .masonry .mi{display:grid;grid-template-columns:150px 1fr auto;gap:18px;align-items:center;padding:14px 0;border-bottom:1px solid var(--c-border);margin:0}
.lx .masonry .mi .ph{aspect-ratio:3/2!important;min-height:0}
@media(max-width:600px){.lx .masonry .mi{grid-template-columns:100px 1fr}.lx .masonry .mi .muted{display:none}}

.lx .art .ph,.lx .feat .ph{display:none}
.lx .art,.lx .feat{border-left:4px solid var(--c-accent);padding:4px 0 4px 20px;margin-bottom:22px}

.lx .faq{counter-reset:q;max-width:960px}
.lx .faq details{counter-increment:q;position:relative;padding-left:64px}
.lx .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.lx .pricing{display:block;border-top:2px solid var(--c-primary)}
.lx .pricing .card{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1.5fr) auto;gap:10px 28px;align-items:center;padding:24px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none!important;box-shadow:none;transform:none!important;color:inherit!important}
.lx .pricing .card h3,.lx .pricing .card .amt{color:var(--c-primary)!important;margin:0}
.lx .pricing .card.hl{background:color-mix(in srgb,var(--c-accent) 12%,var(--c-surface))!important}
.lx .pricing ul{margin:0;display:flex;gap:6px 16px;flex-wrap:wrap}.lx .pricing li{font-size:14px}
@media(max-width:820px){.lx .pricing .card{grid-template-columns:1fr auto}.lx .pricing ul{grid-column:1/-1}}

.lx .cinfo{display:block;border-top:2px solid var(--c-primary)}
.lx .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.lx .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.lx .cinfo .card p{margin:0}
.lx .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.lx .sec.dark h2,.lx .sec.dark p{color:var(--c-text)}
.lx .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.lx .steps>div{border:0;padding:0 0 26px;position:relative}.lx .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.lx .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.lx .tl>div{position:relative;padding:0 0 28px}.lx .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.lx .tl b{font-size:clamp(24px,3vw,36px)}

.lx .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.lx .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.lx .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.lx .vals .card h3{margin:0}.lx .vals .card p{margin:0}
@media(max-width:700px){.lx .vals .card{grid-template-columns:36px 1fr}.lx .vals .card p{grid-column:2}}

.lx-pa{display:grid;grid-template-columns:repeat(2,1fr);gap:0;border-top:3px double var(--c-text)}
.lx-pa>div{padding:22px 24px 24px 0;border-bottom:1px solid var(--c-border);display:grid;gap:6px}.lx-pa>div:nth-child(2n){padding-left:24px;border-left:1px solid var(--c-border)}
.lx-pa h3{font:700 22px var(--f-head);color:var(--c-primary)}.lx-pa p{font:400 16px/1.75 var(--f-body)}.lx-pa small{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent)}
@media(max-width:700px){.lx-pa{grid-template-columns:1fr}.lx-pa>div:nth-child(2n){padding-left:0;border-left:0}}</style><div class="lx-mast"><span>Est. 1987 · Kuala Lumpur</span><span>Partners available by direct line</span></div><header class="lx-head"><a class="lx-logo" href="index.php">Lexington &amp; Co<small>Advocates &amp; Solicitors</small></a><ul class="lx-nav"><li><a href="services.php">Practice areas</a></li><li><a href="team.php">Partners</a></li><li><a href="blog.php">Insights</a></li><li><a href="pricing.php">Fees</a></li><li><a href="contact.php">Contact</a></li><li class="more"><a href="#" tabindex="0">All pages</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Practice Areas</a><a href="service.php">Single Practice area</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Case Results</a><a href="project.php">Single Case result</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Insights</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Free consultation</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><details class="lx-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Practice Areas</a><a href="service.php">Single Practice area</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Case Results</a><a href="project.php">Single Case result</a><a href="gallery.php">Gallery</a><a href="blog.php">Insights</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Free consultation</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="lx">
<main>
