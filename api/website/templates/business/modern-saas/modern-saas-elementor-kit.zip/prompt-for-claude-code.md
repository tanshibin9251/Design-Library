# Build "Modern SaaS" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #4F46E5 · Secondary #0F172A · Text #1E293B · Accent #0E7490 · Surface #F8FAFC · Border #E2E8F0

## 2. Global Fonts
Headings: Inter · Body: Inter
H1 68px / H2 42px / H3 21px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 14px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Features (services) — html/services.html
- Single service (service) — html/service.html
- Pricing (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Customers (projects) — html/projects.html
- Single Customer Story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Blog (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Features (features) — html/features.html
- Integrations (integrations) — html/integrations.html
- Changelog (changelog) — html/changelog.html
- Sign up (signup) — html/signup.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
