<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Gilded Ledger';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Gilded Ledger</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Gilded Ledger v2 — ledger-paper private office, tokens only */
.gl{background-image:repeating-linear-gradient(0deg,transparent 0 35px,color-mix(in srgb,var(--c-secondary) 22%,transparent) 35px 36px);background-position:0 8px}
.gl-head{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:clamp(14px,3vw,44px);padding:0 clamp(16px,5vw,72px);min-height:84px;background:var(--c-surface);border-bottom:2px solid var(--c-primary);position:sticky;top:0;z-index:50}
.gl-logo{font:700 26px var(--f-head);letter-spacing:.01em;color:var(--c-primary);text-decoration:none;display:flex;align-items:baseline;gap:10px}
.gl-logo small{font:600 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-accent)}
.gl-nav{display:flex;gap:clamp(8px,2vw,30px);list-style:none;justify-content:center}
.gl-nav a{display:inline-flex;align-items:center;min-height:46px;text-decoration:none;font:500 15px var(--f-body);color:var(--c-text);border-bottom:2px solid transparent;padding:0 2px}
.gl-nav a:hover{border-bottom-color:var(--c-accent)}
.gl-nav .more{position:relative}
.gl-nav .dd{position:absolute;left:50%;transform:translateX(-50%);top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:2px solid var(--c-primary);min-width:620px;z-index:60;text-align:left}
.gl-nav .more:hover .dd,.gl-nav .more:focus-within .dd{display:grid}
.gl-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.gl-nav .dd a{display:block;min-height:0;padding:5px 0;border:0}
.gl-cta{display:inline-flex;align-items:center;min-height:46px;padding:0 20px;border:2px solid var(--c-primary);color:var(--c-primary);font:700 13px var(--f-body);letter-spacing:.16em;text-transform:uppercase;text-decoration:none}
.gl-cta:hover{background:var(--c-primary);color:var(--on-primary)}
.gl-m{display:none;justify-self:end;position:relative}
.gl-m summary{list-style:none;cursor:pointer;min-height:46px;min-width:46px;display:grid;place-items:center;border:2px solid var(--c-primary);padding:0 14px;font:700 12px var(--f-body);letter-spacing:.14em}
.gl-m summary::-webkit-details-marker{display:none}
.gl-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);border:2px solid var(--c-primary);padding:8px 18px;display:grid;z-index:60}
.gl-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:500 16px var(--f-body);min-height:46px}
@media(max-width:940px){.gl-head{grid-template-columns:1fr auto}.gl-nav,.gl-cta{display:none}.gl-m{display:block}}
.gl-sec{padding:clamp(40px,6vw,90px) clamp(16px,5vw,72px)}
.gl-hero{display:grid;grid-template-columns:1.2fr .8fr;gap:clamp(24px,6vw,100px);padding:clamp(40px,7vw,100px) clamp(16px,5vw,72px) clamp(30px,4vw,60px);background:linear-gradient(90deg,transparent 0 calc(clamp(16px,5vw,72px) - 18px),color-mix(in srgb,var(--c-accent) 55%,transparent) calc(clamp(16px,5vw,72px) - 18px) calc(clamp(16px,5vw,72px) - 17px),transparent 0)}
@media(max-width:900px){.gl-hero{grid-template-columns:1fr}}
.gl-hero h1{font:700 clamp(38px,5.6vw,var(--h1))/1.1 var(--f-head);color:var(--c-primary);letter-spacing:-.01em}
.gl-hero p{font:400 19px/1.85 var(--f-body);margin:20px 0 28px;max-width:46ch}
.gl-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 28px;background:var(--c-primary);color:var(--on-primary);font:700 14px var(--f-body);letter-spacing:.14em;text-transform:uppercase;text-decoration:none;border:2px solid var(--c-primary);cursor:pointer}
.gl-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.gl-btn.o{background:transparent;color:var(--c-primary)}.gl-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.gl-tab{background:var(--c-surface);border:2px solid var(--c-primary);padding:clamp(18px,2.4vw,30px)}
.gl-tab h3{font:700 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent);margin-bottom:12px}
.gl-r{display:flex;justify-content:space-between;gap:14px;padding:12px 0;border-bottom:1px dotted var(--c-secondary);font:400 17px var(--f-body)}
.gl-r:last-child{border-bottom:0}
.gl-r b{font:700 18px var(--f-head);color:var(--c-primary);font-variant-numeric:tabular-nums}
.gl-h{display:flex;align-items:baseline;gap:18px;border-bottom:2px solid var(--c-primary);padding-bottom:10px;margin-bottom:26px}
.gl-h span{font:700 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent)}
.gl-h h2{font:700 clamp(26px,3.2vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.gl-pr{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:2px solid var(--c-primary);background:var(--c-surface)}
.gl-pr>div{padding:26px 24px;border-right:1px solid var(--c-border)}.gl-pr>div:last-child{border-right:0}
.gl-pr .n{font:700 38px/1 var(--f-head);color:var(--c-accent);font-variant-numeric:tabular-nums}
.gl-pr h3{font:700 21px var(--f-head);color:var(--c-primary);margin:10px 0 6px}
.gl-pr p{font:400 16px/1.75 var(--f-body)}
@media(max-width:800px){.gl-pr{grid-template-columns:1fr}.gl-pr>div{border-right:0;border-bottom:1px solid var(--c-border)}}
.gl-ex{display:grid;grid-template-columns:1fr 1.2fr;gap:clamp(20px,4vw,60px);align-items:center;background:var(--c-surface);border:2px solid var(--c-primary);padding:clamp(22px,3vw,44px)}
@media(max-width:860px){.gl-ex{grid-template-columns:1fr}}
.gl-ex h2{font:700 clamp(26px,3.2vw,40px)/1.15 var(--f-head);color:var(--c-primary)}
.gl-ex p{font:400 17px/1.8 var(--f-body);margin-top:10px}
.gl-risk{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-bottom:20px}
.gl-risk button{min-height:50px;border:2px solid var(--c-primary);background:transparent;font:700 15px var(--f-body);color:var(--c-primary);cursor:pointer}
.gl-risk button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.gl-stack{display:flex;height:52px;border:2px solid var(--c-primary)}
.gl-stack i{display:grid;place-items:center;font:700 13px var(--f-body);font-style:normal;color:var(--on-primary);width:var(--w);transition:width .4s;overflow:hidden;white-space:nowrap}
.gl-stack i:nth-child(1){background:var(--c-primary)}.gl-stack i:nth-child(2){background:var(--c-accent);color:var(--on-accent)}.gl-stack i:nth-child(3){background:var(--c-secondary);color:var(--on-primary)}.gl-stack i:nth-child(4){background:color-mix(in srgb,var(--c-primary) 30%,var(--c-surface));color:var(--c-primary)}
.gl-lg{display:flex;gap:16px;flex-wrap:wrap;margin-top:10px;font:600 13px var(--f-body)}
.gl-note{margin-top:14px;font:400 14px/1.7 var(--f-body);color:var(--c-secondary)}
.gl-tbl{width:100%;border-collapse:collapse;background:var(--c-surface);border:2px solid var(--c-primary);font:400 17px var(--f-body)}
.gl-tbl th,.gl-tbl td{padding:14px 18px;text-align:left;border-bottom:1px solid var(--c-border)}
.gl-tbl th{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;background:color-mix(in srgb,var(--c-primary) 6%,var(--c-surface))}
.gl-tbl td:last-child,.gl-tbl th:last-child{text-align:right;font-variant-numeric:tabular-nums;font-weight:700}
.gl-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(34px,5vw,80px);padding:clamp(34px,5vw,60px) clamp(16px,5vw,72px) 24px}
.gl-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.gl-foot .big{font:700 30px var(--f-head)}
.gl-foot h4{font:700 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.gl-foot ul{list-style:none}.gl-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);color:var(--on-primary);min-height:34px}
.gl-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.gl-foot .copy{margin-top:26px;padding-top:16px;border-top:1px solid color-mix(in srgb,var(--on-primary) 30%,transparent);font:400 12px/1.7 var(--f-body);opacity:.8}
@media(max-width:860px){.gl-foot .top{grid-template-columns:1fr}.gl-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.gl-stack i{transition:none}}
.gl .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.gl .pagehead h1{max-width:none}.gl .card,.gl .scard,.gl .qcard,.gl .pcard,.gl .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.gl .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.gl .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.gl .svc{display:block;border:2px solid var(--c-primary)}
.gl .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr) 150px 110px;gap:0;align-items:stretch;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:0}
.gl .scard:nth-child(even){background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}
.gl .scard .ph{display:none}.gl .scard .b{display:contents}
.gl .scard h3{padding:18px;font-size:19px;border-right:1px solid var(--c-border)}
.gl .scard p{padding:18px;margin:0;border-right:1px solid var(--c-border);opacity:.85;font-size:15px}
.gl .scard .m{display:contents}.gl .scard .m b{padding:18px;border-right:1px solid var(--c-border);font-size:15px}.gl .scard .m span{padding:18px;font-size:14px;opacity:.75}
@media(max-width:820px){.gl .scard{grid-template-columns:1fr 1fr}.gl .scard h3{grid-column:1/-1;border-right:0}.gl .scard p{grid-column:1/-1;border-right:0;padding-top:0}}

.gl .tgrid{display:block;border-top:2px solid var(--c-primary)}.gl .tgrid.mt{margin-top:0}
.gl .person{display:grid;grid-template-columns:1fr auto;gap:4px 20px;align-items:baseline;padding:18px 0;border-bottom:1px solid var(--c-border);background:none;border-radius:0;box-shadow:none;border-left:0;border-right:0;border-top:0;text-align:left}
.gl .person .ph{display:none}.gl .person h3{font-size:clamp(20px,2.2vw,28px)}.gl .person span{font:600 13px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-accent)}

.gl .qgrid{display:block;border-top:2px solid var(--c-primary)}.gl .qgrid.mt{margin-top:0}
.gl .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.gl .qcard .stars{grid-column:1}.gl .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.gl .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.gl .qcard{grid-template-columns:1fr}.gl .qcard figcaption{grid-column:1;grid-row:auto}}

.gl .masonry{display:block!important;columns:auto;border-top:2px solid var(--c-primary)}
.gl .masonry .mi{display:grid;grid-template-columns:150px 1fr auto;gap:18px;align-items:center;padding:14px 0;border-bottom:1px solid var(--c-border);margin:0}
.gl .masonry .mi .ph{aspect-ratio:3/2!important;min-height:0}
@media(max-width:600px){.gl .masonry .mi{grid-template-columns:100px 1fr}.gl .masonry .mi .muted{display:none}}

.gl .art .ph,.gl .feat .ph{display:none}
.gl .art,.gl .feat{border-left:4px solid var(--c-accent);padding:4px 0 4px 20px;margin-bottom:22px}

.gl .faq{counter-reset:q;max-width:960px}
.gl .faq details{counter-increment:q;position:relative;padding-left:64px}
.gl .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.gl .pricing{display:block;border-top:2px solid var(--c-primary)}
.gl .pricing .card{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1.5fr) auto;gap:10px 28px;align-items:center;padding:24px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none!important;box-shadow:none;transform:none!important;color:inherit!important}
.gl .pricing .card h3,.gl .pricing .card .amt{color:var(--c-primary)!important;margin:0}
.gl .pricing .card.hl{background:color-mix(in srgb,var(--c-accent) 12%,var(--c-surface))!important}
.gl .pricing ul{margin:0;display:flex;gap:6px 16px;flex-wrap:wrap}.gl .pricing li{font-size:14px}
@media(max-width:820px){.gl .pricing .card{grid-template-columns:1fr auto}.gl .pricing ul{grid-column:1/-1}}

.gl .cinfo{display:block;border-top:2px solid var(--c-primary)}
.gl .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.gl .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.gl .cinfo .card p{margin:0}
.gl .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.gl .sec.dark h2,.gl .sec.dark p{color:var(--c-text)}
.gl .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.gl .steps>div{border:0;padding:0 0 26px;position:relative}.gl .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.gl .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.gl .tl>div{position:relative;padding:0 0 28px}.gl .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.gl .tl b{font-size:clamp(24px,3vw,36px)}

.gl .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.gl .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.gl .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.gl .vals .card h3{margin:0}.gl .vals .card p{margin:0}
@media(max-width:700px){.gl .vals .card{grid-template-columns:36px 1fr}.gl .vals .card p{grid-column:2}}

.gl-it{display:grid;grid-template-columns:90px 1fr auto;gap:10px 28px;align-items:baseline;padding:20px 0;border-bottom:1px dotted var(--c-secondary)}
.gl-it .n{font:700 28px var(--f-head);color:var(--c-accent);font-variant-numeric:tabular-nums}.gl-it h3{font:700 22px var(--f-head);color:var(--c-primary)}.gl-it p{font:400 16px/1.7 var(--f-body);margin-top:4px}.gl-it .f{font:700 16px var(--f-body);font-variant-numeric:tabular-nums;white-space:nowrap}
@media(max-width:700px){.gl-it{grid-template-columns:50px 1fr}.gl-it .f{grid-column:2}}</style><header class="gl-head"><a class="gl-logo" href="index.php">Gilded Ledger<small>Private office</small></a><ul class="gl-nav"><li><a href="services.php">Services</a></li><li><a href="process.php">How we work</a></li><li><a href="resources.php">Insights</a></li><li><a href="pricing.php">Fees</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Private Banking</a><a href="service.php">Single Service</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Client Outcomes</a><a href="project.php">Single Client outcome</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Insights</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Private consultation</a><a href="process.php">Process</a><a href="industries.php">Client types</a><a href="resources.php">Resources</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><a class="gl-cta" href="booking.php">Request a meeting</a><details class="gl-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Private Banking</a><a href="service.php">Single Service</a><a href="pricing.php">Fees</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Client Outcomes</a><a href="project.php">Single Client outcome</a><a href="gallery.php">Gallery</a><a href="blog.php">Insights</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Private consultation</a><a href="process.php">Process</a><a href="industries.php">Client types</a><a href="resources.php">Resources</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="gl">
<main>
