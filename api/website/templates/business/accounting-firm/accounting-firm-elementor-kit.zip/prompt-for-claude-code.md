# Build "Verde & Co. Accountants" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #14532d · Secondary #6b6b5a · Text #1c1f1c · Accent #b45309 · Surface #fbfaf5 · Border #dad8c9

## 2. Global Fonts
Headings: Literata · Body: Public Sans
H1 60px / H2 38px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 80px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Services (services) — html/services.html
- Tax service (service) — html/service.html
- Tax calendar (deadlines) — html/deadlines.html
- Fees (pricing) — html/pricing.html
- Team (team) — html/team.html
- Guides (resources) — html/resources.html
- Free consultation (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
