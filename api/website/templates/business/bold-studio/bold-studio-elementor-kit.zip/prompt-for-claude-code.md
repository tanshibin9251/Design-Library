# Build "Bold Studio" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #18181B · Secondary #BE123C · Text #18181B · Accent #E11D48 · Surface #FAFAFA · Border #E4E4E7

## 2. Global Fonts
Headings: Anton · Body: Work Sans
H1 120px / H2 64px / H3 28px / Body 16px

## 3. Layout
Content width 1300px · Section padding 100px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single service (service) — html/service.html
- Rates (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Shop (shop) — html/shop.html
- Single Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Work (projects) — html/projects.html
- Single Project (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Process (process) — html/process.html
- Showreel (showreel) — html/showreel.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
