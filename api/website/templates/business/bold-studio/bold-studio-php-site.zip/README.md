# Bold Studio

Exported from Design Library · 24 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Services, Single service, Rates, Contact, Shop, Single Product, Cart, Checkout, Testimonials, Team, Work, Single Project, Gallery, Journal, Single post, FAQ, Process, Showreel, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
