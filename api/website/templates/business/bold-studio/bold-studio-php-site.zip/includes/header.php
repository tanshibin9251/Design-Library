<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Bold Studio';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Bold Studio</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<header class="nav nav-min"><div class="wrap"><a class="logo" href="index.php">Kiln Studio</a><details class="navmenu minmenu"><summary>Menu +</summary><div class="minov"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single service</a><a href="pricing.php">Rates</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Shop</a><a href="product.php">Single Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Work</a><a href="project.php">Single Project</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="process.php">Process</a><a href="showreel.php">Showreel</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></details></div></header>
<main>
