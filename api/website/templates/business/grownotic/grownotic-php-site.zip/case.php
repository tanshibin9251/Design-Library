<?php $title = 'Case study'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="gn-pg gn-d"><span class="gn-ring" aria-hidden="true"></span><div class="gn-w"><a class="gn-tag" href="portfolio.php" style="text-decoration:none;color:inherit">← All work</a><h1 class="gn-h" style="margin-top:28px">Stem Cell <em>JB</em></h1><p class="gn-lead">一句话描述这个项目 [待你填]</p>
<div class="gn-meta"><div><small>Client</small>Stem Cell JB</div><div><small>Type</small>Company site</div><div><small>What I did</small>WordPress / SEO / … [待你填]</div><div><small>Visit</small><a href="#">stemcelljb.com ↗</a></div></div></div></section>

<section class="gn-s gn-l" style="padding-bottom:0"><div class="gn-w"><div class="gn-ph" data-l="缺图：整页长截图" style="min-height:clamp(360px,60vw,760px);border-radius:24px"></div></div></section>

<section class="gn-s gn-l"><div class="gn-w"><div class="gn-3"><div><h3>The challenge</h3><p>客户遇到什么问题（一两句，真实）[待你填]</p></div><div><h3>What I did</h3><p>你具体做了什么 [待你填]</p></div><div><h3>The result</h3><p>只写真实、可验证的结果；没有就写做了什么，不编数字 [待你填]</p></div></div></div></section>

<section class="gn-s gn-t"><div class="gn-w"><div class="gn-dev"><div class="gn-ph" data-l="缺图：桌面截图" style="min-height:420px"></div><div class="gn-ph" data-l="缺图：手机截图" style="min-height:420px"></div></div>
<div style="margin-top:44px"><span class="gn-k">Built with</span><div class="gn-tools" style="color:var(--c-text)"><span style="border-color:var(--c-border)">WordPress</span><span style="border-color:var(--c-border)">Elementor</span><span style="border-color:var(--c-border)">Rank Math</span><span style="border-color:var(--c-border)">其他插件 [待你填]</span></div></div></div></section>

<section class="gn-s gn-d sm"><div class="gn-w"><div class="gn-pn"><a href="case.php">← Previous project</a><a href="case.php">Next project →</a></div></div></section>

<section class="gn-s gn-l sm"><div class="gn-w" style="display:flex;justify-content:space-between;gap:24px;flex-wrap:wrap;align-items:center"><h2 class="gn-h" style="max-width:12em">Need something <em>like this?</em></h2><a class="gn-b" href="contact.php">Get a Quotation <i>↗</i></a></div></section>
</div>
<?php include 'includes/footer.php'; ?>
