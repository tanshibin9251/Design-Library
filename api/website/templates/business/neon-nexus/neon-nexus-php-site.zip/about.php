<?php $title = 'About'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="pagehead alt"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>About</b></div><h1 style="">A small lab with a big API</h1><p class="lead">We build models and the plumbing that makes them useful.</p></div></section><section class="nx-sec" style="padding-top:0"><div class="nx-feat"><div><h3>Research</h3><p>A team of 22 researchers publishing evaluations before every release.</p></div><div><h3>Platform</h3><p>One API, one bill, regional endpoints and a 99.95% uptime target.</p></div><div><h3>Safety</h3><p>Red-team reports are public and our usage policy is one page long.</p></div></div></section><section class="nx-sec" style="padding-top:0"><div class="nx-h"><h2>Principles</h2></div><div class="nx-code"><span class="s"># how we ship</span>
<span class="k">1.</span> Publish evals, not adjectives.
<span class="k">2.</span> Never train on customer data without opt-in.
<span class="k">3.</span> Price per token, no minimums, no seats.
<span class="k">4.</span> Deprecate slowly; give twelve months' notice.</div></section></div>
<?php include 'includes/footer.php'; ?>
