<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Nexus AI';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Nexus AI</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="neon-nexus" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Nexus AI v2 — light paper AI-lab site with a live request/response demo, tokens only */
.nx-head{display:flex;align-items:center;gap:24px;padding:0 clamp(16px,4vw,56px);min-height:72px;background:color-mix(in srgb,var(--c-surface) 92%,transparent);backdrop-filter:blur(8px);position:sticky;top:0;z-index:50;border-bottom:1px solid var(--c-border)}
.nx-logo{font:700 22px var(--f-head);letter-spacing:-.03em;color:var(--c-primary);text-decoration:none;display:flex;align-items:center;gap:10px}
.nx-logo i{width:22px;height:22px;border-radius:50%;background:conic-gradient(var(--c-accent) 0 25%,var(--c-primary) 0 50%,var(--c-accent) 0 75%,var(--c-primary) 0);display:inline-block}
.nx-nav{display:flex;gap:2px;list-style:none;margin-left:auto;align-items:center}
.nx-nav a{display:inline-flex;align-items:center;min-height:44px;padding:0 14px;font:500 15px var(--f-body);color:var(--c-text);text-decoration:none;border-radius:8px}
.nx-nav a:hover{background:color-mix(in srgb,var(--c-primary) 6%,transparent)}
.nx-nav .key{background:var(--c-primary);color:var(--on-primary);margin-left:8px;font-weight:700}
.nx-nav .more{position:relative}
.nx-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:14px;box-shadow:0 30px 60px -30px rgba(0,0,0,.3);min-width:620px;z-index:60}
.nx-nav .more:hover .dd,.nx-nav .more:focus-within .dd{display:grid}
.nx-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.nx-nav .dd a{display:block;min-height:0;padding:5px 0;border-radius:0}
.nx-m{display:none;margin-left:auto;position:relative}
.nx-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:1px solid var(--c-border);border-radius:8px;padding:0 14px;font:700 12px var(--f-body);letter-spacing:.1em}
.nx-m summary::-webkit-details-marker{display:none}
.nx-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:12px;padding:8px 18px;display:grid;z-index:60}
.nx-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:500 15px var(--f-body);min-height:44px}
@media(max-width:900px){.nx-nav{display:none}.nx-m{display:block}}
.nx-sec{padding:clamp(40px,6vw,92px) clamp(16px,4vw,56px)}
.nx-hero{padding:clamp(48px,8vw,110px) clamp(16px,4vw,56px) clamp(20px,3vw,40px);max-width:1200px;margin:0 auto}
.nx-hero .pill{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--c-border);border-radius:99px;padding:5px 14px;font:600 13px var(--f-body);color:var(--c-secondary);background:var(--c-surface)}
.nx-hero .pill b{color:var(--c-accent)}
.nx-hero h1{font:700 clamp(40px,6.6vw,var(--h1))/1.02 var(--f-head);letter-spacing:-.04em;color:var(--c-primary);margin:20px 0 18px;max-width:16ch}
.nx-hero h1 em{font-style:normal;color:var(--c-accent)}
.nx-hero p{font:400 20px/1.6 var(--f-body);max-width:48ch;margin-bottom:26px}
.nx-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 24px;border-radius:10px;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);text-decoration:none;border:1.5px solid var(--c-primary);cursor:pointer}
.nx-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.nx-btn.o{background:transparent;color:var(--c-primary)}.nx-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.nx-demo{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;border:1.5px solid var(--c-primary);border-radius:16px;overflow:hidden;background:var(--c-surface)}
@media(max-width:860px){.nx-demo{grid-template-columns:1fr}}
.nx-pane{padding:20px 22px;min-width:0}
.nx-pane+.nx-pane{border-left:1.5px solid var(--c-primary);background:color-mix(in srgb,var(--c-primary) 4%,var(--c-surface))}
@media(max-width:860px){.nx-pane+.nx-pane{border-left:0;border-top:1.5px solid var(--c-primary)}}
.nx-lab{display:flex;justify-content:space-between;align-items:center;font:700 12px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:12px}
.nx-pre{font:500 14px/1.75 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-word;min-height:240px;color:var(--c-text)}
.nx-pre .k{color:var(--c-accent)}.nx-pre .s{color:var(--c-secondary)}
.nx-run{min-height:40px;padding:0 16px;border-radius:8px;border:0;background:var(--c-accent);color:var(--on-accent);font:700 13px var(--f-body);cursor:pointer}
.nx-cur{display:inline-block;width:.55em;height:1.05em;background:var(--c-accent);vertical-align:-.15em;animation:nxb 1s steps(2) infinite}
@keyframes nxb{50%{opacity:0}}
.nx-h{max-width:1200px;margin:0 auto 26px;display:flex;justify-content:space-between;align-items:baseline;gap:14px;flex-wrap:wrap}
.nx-h h2{font:700 clamp(26px,3.4vw,var(--h2)) var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.nx-h a{font:700 15px var(--f-body);color:var(--c-accent)}
.nx-tbl{max-width:1200px;margin:0 auto;border:1.5px solid var(--c-primary);border-radius:16px;overflow:hidden;background:var(--c-surface)}
.nx-row{display:grid;grid-template-columns:1.3fr 1fr 1fr 1.4fr;gap:16px;padding:18px 22px;align-items:center;border-bottom:1px solid var(--c-border)}
.nx-row:last-child{border-bottom:0}
.nx-row.hd{font:700 12px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary);background:color-mix(in srgb,var(--c-primary) 5%,var(--c-surface))}
.nx-row b{font:700 18px var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.nx-row small{display:block;font:500 13px var(--f-body);color:var(--c-secondary)}
.nx-bar{height:8px;border-radius:99px;background:var(--c-border);overflow:hidden}.nx-bar i{display:block;height:100%;width:var(--p);background:var(--c-accent)}
@media(max-width:700px){.nx-row{grid-template-columns:1fr 1fr}.nx-row.hd{display:none}}
.nx-calc{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,56px);align-items:center}
@media(max-width:860px){.nx-calc{grid-template-columns:1fr}}
.nx-calc h2{font:700 clamp(28px,3.6vw,48px)/1.05 var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.nx-ctl{border:1.5px solid var(--c-primary);border-radius:16px;padding:24px;display:grid;gap:16px;background:var(--c-surface)}
.nx-ctl label{display:grid;gap:6px;font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase;color:var(--c-secondary)}
.nx-ctl select{min-height:48px;border:1.5px solid var(--c-border);border-radius:10px;padding:0 12px;font:600 16px var(--f-body);background:var(--c-surface);color:var(--c-text)}
.nx-ctl input[type=range]{accent-color:var(--c-accent);min-height:44px;padding:0;border:0;background:none;width:100%}
.nx-out{font:700 clamp(40px,6vw,64px)/1 var(--f-head);letter-spacing:-.04em;color:var(--c-primary)}
.nx-out small{font:600 14px var(--f-body);color:var(--c-secondary);letter-spacing:0}
.nx-log{max-width:1200px;margin:0 auto}
.nx-log a{display:grid;grid-template-columns:120px 90px 1fr;gap:20px;padding:20px 0;border-top:1px solid var(--c-border);text-decoration:none;align-items:baseline}
.nx-log a:last-child{border-bottom:1px solid var(--c-border)}
.nx-log time{font:600 14px var(--f-body);color:var(--c-secondary)}
.nx-log .t{font:700 11px var(--f-body);letter-spacing:.12em;text-transform:uppercase;border:1px solid currentColor;border-radius:99px;padding:2px 10px;justify-self:start;color:var(--c-accent)}
.nx-log b{font:600 18px var(--f-body);color:var(--c-primary)}
@media(max-width:640px){.nx-log a{grid-template-columns:1fr;gap:4px}}
.nx-foot{border-top:1px solid var(--c-border);margin-top:clamp(30px,5vw,70px);padding:clamp(30px,4vw,56px) clamp(16px,4vw,56px) 22px}
.nx-foot .top{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.nx-foot .big{font:700 24px var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.nx-foot h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:10px}
.nx-foot ul{list-style:none}.nx-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:32px}
.nx-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.nx-foot .copy{max-width:1200px;margin:24px auto 0;font:500 12px var(--f-body);color:var(--c-secondary)}
@media(max-width:860px){.nx-foot .top{grid-template-columns:1fr}.nx-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.nx-cur{animation:none}}
.nx .pagehead{background:none}.nx .card,.nx .scard,.nx .qcard,.nx .pcard,.nx .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.nx .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.nx .pagehead h1{letter-spacing:-.03em}.nx .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.nx .svc{display:block;border:2px solid var(--c-primary)}
.nx .scard{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr) 150px 110px;gap:0;align-items:stretch;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:0}
.nx .scard:nth-child(even){background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}
.nx .scard .ph{display:none}.nx .scard .b{display:contents}
.nx .scard h3{padding:18px;font-size:19px;border-right:1px solid var(--c-border)}
.nx .scard p{padding:18px;margin:0;border-right:1px solid var(--c-border);opacity:.85;font-size:15px}
.nx .scard .m{display:contents}.nx .scard .m b{padding:18px;border-right:1px solid var(--c-border);font-size:15px}.nx .scard .m span{padding:18px;font-size:14px;opacity:.75}
@media(max-width:820px){.nx .scard{grid-template-columns:1fr 1fr}.nx .scard h3{grid-column:1/-1;border-right:0}.nx .scard p{grid-column:1/-1;border-right:0;padding-top:0}}

.nx .tgrid{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:2px solid var(--c-primary)}
.nx .person{display:grid;grid-template-columns:110px 1fr;gap:4px 18px;align-items:center;padding:20px 20px 20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;text-align:left}
.nx .person .ph{grid-row:span 2;aspect-ratio:1!important}
@media(max-width:700px){.nx .tgrid{grid-template-columns:1fr}}

.nx .qgrid{display:block;border-top:2px solid var(--c-primary)}.nx .qgrid.mt{margin-top:0}
.nx .qcard{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(180px,1fr);gap:8px 40px;align-items:center;padding:26px 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.nx .qcard .stars{grid-column:1}.nx .qcard blockquote{grid-column:1;font-size:clamp(18px,2vw,24px)}.nx .qcard figcaption{grid-column:2;grid-row:1/span 2}
@media(max-width:700px){.nx .qcard{grid-template-columns:1fr}.nx .qcard figcaption{grid-column:1;grid-row:auto}}

.nx .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.nx .masonry .mi{margin:0}.nx .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.nx .masonry{grid-template-columns:1fr 1fr}}

.nx .split.w2{display:block}
.nx .feat{display:grid;grid-template-columns:1.3fr 1fr;gap:clamp(18px,3vw,40px);align-items:center;margin-bottom:clamp(24px,4vw,48px)}
.nx .feat h2{font-size:clamp(26px,3.6vw,48px);line-height:1.04}
.nx .articles.two{grid-template-columns:repeat(3,1fr)!important}
@media(max-width:800px){.nx .feat{grid-template-columns:1fr}.nx .articles.two{grid-template-columns:1fr!important}}
.nx .faq{max-width:none;columns:2 340px;column-gap:clamp(24px,5vw,72px)}.nx .faq details{break-inside:avoid}

.nx .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.nx .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.nx .pricing .card.hl h3,.nx .pricing .card.hl .amt{color:var(--c-primary)!important}.nx .pricing .card.hl li::before{color:var(--c-accent)!important}

.nx .cinfo{display:block;border-top:2px solid var(--c-primary)}
.nx .cinfo .card{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:baseline;padding:14px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.nx .cinfo .card h3{font:700 12px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin:0}.nx .cinfo .card p{margin:0}
.nx .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.nx .sec.dark h2,.nx .sec.dark p{color:var(--c-text)}
.nx .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.nx .steps>div{border:0;padding:0 0 26px;position:relative}.nx .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.nx .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.nx .tl>div{position:relative;padding:0 0 28px}.nx .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.nx .tl b{font-size:clamp(24px,3vw,36px)}

.nx .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.nx .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.nx .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.nx .vals .card h3{margin:0}.nx .vals .card p{margin:0}
@media(max-width:700px){.nx .vals .card{grid-template-columns:36px 1fr}.nx .vals .card p{grid-column:2}}

.nx-code{border:1.5px solid var(--c-primary);border-radius:14px;background:color-mix(in srgb,var(--c-primary) 4%,var(--c-surface));padding:20px 22px;font:500 14px/1.75 ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;overflow:auto}
.nx-code .k{color:var(--c-accent)}.nx-code .s{color:var(--c-secondary)}
.nx-feat{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:1.5px solid var(--c-primary);border-radius:16px;overflow:hidden;background:var(--c-surface)}
.nx-feat>div{padding:26px;border-right:1px solid var(--c-border);display:grid;gap:8px;align-content:start}.nx-feat>div:last-child{border-right:0}
.nx-feat h3{font:700 20px var(--f-head);letter-spacing:-.02em}.nx-feat p{font:400 15px/1.7 var(--f-body)}
@media(max-width:800px){.nx-feat{grid-template-columns:1fr}.nx-feat>div{border-right:0;border-bottom:1px solid var(--c-border)}}</style><header class="nx-head"><a class="nx-logo" href="index.php"><i></i>Nexus</a><ul class="nx-nav"><li><a href="features.php">Models</a></li><li><a href="integrations.php">Integrations</a></li><li><a href="pricing.php">Pricing</a></li><li><a href="changelog.php">Changelog</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Platform</a><a href="service.php">Single Product</a><a href="pricing.php">Pricing</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customers</a><a href="project.php">Single Customer story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Developers</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="changelog.php">Changelog</a><a href="signup.php">Sign up</a><a href="integrations.php">Integrations</a><a href="features.php">Features</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="key" href="signup.php">Get API key</a></li></ul><details class="nx-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Platform</a><a href="service.php">Single Product</a><a href="pricing.php">Pricing</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Customers</a><a href="project.php">Single Customer story</a><a href="gallery.php">Gallery</a><a href="blog.php">Developers</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="changelog.php">Changelog</a><a href="signup.php">Sign up</a><a href="integrations.php">Integrations</a><a href="features.php">Features</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="nx"><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
