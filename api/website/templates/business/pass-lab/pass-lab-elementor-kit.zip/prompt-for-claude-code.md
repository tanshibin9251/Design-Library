# Build "Pass Lab" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1b2733 · Secondary #5b6b7b · Text #1b2733 · Accent #f0a202 · Surface #f5f7fa · Border #d7dde4

## 2. Global Fonts
Headings: Wix Madefor Display · Body: Wix Madefor Text
H1 68px / H2 42px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 88px vertical · Border radius 12px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Exams (exams) — html/exams.html
- Exam: Project Management (PMP) (exam) — html/exam.html
- Practice test (practice) — html/practice.html
- Study planner (planner) — html/planner.html
- Pass stories (results) — html/results.html
- Pricing (pricing) — html/pricing.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
