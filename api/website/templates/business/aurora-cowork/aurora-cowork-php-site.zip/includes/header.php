<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Aurora Cowork';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Aurora Cowork</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Aurora Cowork v2 — warm light coworking with a bookable floor plan, tokens only */
.ac-head{display:flex;align-items:center;gap:18px;padding:12px clamp(14px,4vw,56px);position:sticky;top:0;z-index:50;background:var(--c-surface)}
.ac-pill{display:flex;align-items:center;gap:6px;width:100%;max-width:1280px;margin:0 auto;background:var(--c-primary);color:var(--on-primary);border-radius:999px;padding:6px 8px 6px 22px;min-height:60px}
.ac-logo{font:800 22px var(--f-head);letter-spacing:-.02em;color:var(--on-primary);text-decoration:none;margin-right:auto;display:flex;align-items:center;gap:10px}
.ac-logo i{display:inline-block;width:16px;height:16px;border-radius:50%;background:var(--c-accent);box-shadow:10px 0 0 var(--c-secondary)}
.ac-logo span{margin-left:10px}
.ac-nav{display:flex;list-style:none;gap:2px;align-items:center}
.ac-nav a{display:inline-flex;align-items:center;min-height:44px;padding:0 16px;border-radius:999px;font:600 15px var(--f-body);color:var(--on-primary);text-decoration:none}
.ac-nav a:hover{background:color-mix(in srgb,var(--on-primary) 14%,transparent)}
.ac-nav .go{background:var(--c-accent);color:var(--on-accent)}
.ac-nav .more{position:relative}
.ac-nav .dd{position:absolute;right:0;top:calc(100% + 12px);display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border-radius:24px;box-shadow:0 30px 60px -26px rgba(0,0,0,.35);min-width:640px;z-index:60}
.ac-nav .more:hover .dd,.ac-nav .more:focus-within .dd{display:grid}
.ac-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.ac-nav .dd a{color:var(--c-text);display:block;min-height:0;padding:5px 0;border-radius:0;font-weight:500}
.ac-m{display:none;position:relative}
.ac-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border-radius:999px;background:var(--c-accent);color:var(--on-accent);padding:0 18px;font:800 13px var(--f-body);letter-spacing:.1em}
.ac-m summary::-webkit-details-marker{display:none}
.ac-m nav{position:absolute;right:0;top:calc(100% + 12px);min-width:250px;background:var(--c-surface);color:var(--c-text);border-radius:22px;padding:8px 18px;display:grid;box-shadow:0 30px 60px -26px rgba(0,0,0,.35);z-index:60}
.ac-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:600 15px var(--f-body);min-height:44px}
@media(max-width:900px){.ac-nav{display:none}.ac-m{display:block}}
.ac-sec{padding:clamp(40px,6vw,88px) clamp(14px,4vw,56px)}
.ac-hero{display:grid;grid-template-columns:.9fr 1.1fr;gap:clamp(20px,4vw,64px);align-items:center;padding:clamp(24px,4vw,56px) clamp(14px,4vw,56px)}
@media(max-width:960px){.ac-hero{grid-template-columns:1fr}}
.ac-hero h1{font:800 clamp(42px,6vw,var(--h1))/1 var(--f-head);letter-spacing:-.035em;color:var(--c-primary)}
.ac-hero h1 em{font-style:normal;color:var(--c-accent)}
.ac-hero p{font:400 19px/1.7 var(--f-body);margin:16px 0 24px;max-width:40ch}
.ac-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 26px;border-radius:999px;background:var(--c-primary);color:var(--on-primary);font:700 16px var(--f-body);text-decoration:none;border:0;cursor:pointer}
.ac-btn:hover{background:var(--c-accent);color:var(--on-accent)}
.ac-btn.o{background:transparent;color:var(--c-primary);box-shadow:inset 0 0 0 2px var(--c-primary)}.ac-btn.o:hover{background:var(--c-primary);color:var(--on-primary)}
.ac-plan{background:color-mix(in srgb,var(--c-secondary) 28%,var(--c-surface));border-radius:32px;padding:clamp(14px,2vw,26px)}
.ac-grid{display:grid;grid-template-columns:repeat(8,1fr);grid-auto-rows:minmax(54px,7vw);gap:8px}
.ac-s{border:0;border-radius:14px;background:var(--c-surface);color:var(--c-primary);font:800 13px var(--f-body);cursor:pointer;min-height:44px;transition:transform .15s,background .15s;position:relative;padding:0}
.ac-s:hover{transform:translateY(-3px)}
.ac-s.studio{grid-column:span 2;background:var(--c-primary);color:var(--on-primary)}
.ac-s.room{grid-column:span 2;background:var(--c-accent);color:var(--on-accent)}
.ac-s.busy{opacity:.35;cursor:not-allowed}
.ac-s.busy:hover{transform:none}
.ac-s[aria-pressed=true]{outline:4px solid var(--c-accent);outline-offset:2px}
.ac-s.room[aria-pressed=true]{outline-color:var(--c-primary)}
.ac-k{display:flex;gap:6px;align-items:flex-end;grid-column:span 4;font:700 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-secondary);align-self:center;padding:0 6px}
.ac-leg{display:flex;gap:16px;flex-wrap:wrap;margin-top:14px;font:700 12px var(--f-body)}
.ac-leg i{display:inline-block;width:14px;height:14px;border-radius:5px;vertical-align:-2px;margin-right:6px;background:var(--c-surface);border:1px solid var(--c-primary)}
.ac-info{margin-top:14px;background:var(--c-surface);border-radius:22px;padding:18px 22px;display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.ac-info b{font:800 22px var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.ac-info span{font:500 14px var(--f-body);color:var(--c-secondary)}
.ac-h{display:flex;justify-content:space-between;align-items:baseline;gap:14px;margin-bottom:22px;flex-wrap:wrap}
.ac-h h2{font:800 clamp(26px,3.4vw,var(--h2)) var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.ac-key{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.ac-card{border-radius:30px;padding:28px;display:grid;gap:10px;align-content:start;background:color-mix(in srgb,var(--c-surface) 40%,#fff);position:relative;overflow:hidden}
.ac-card::after{content:"";position:absolute;right:-28px;top:-28px;width:96px;height:96px;border-radius:50%;background:var(--c-secondary);opacity:.55}
.ac-card.d{background:var(--c-primary);color:var(--on-primary)}.ac-card.d::after{background:var(--c-accent);opacity:1}
.ac-card.d h3,.ac-card.d .p{color:var(--on-primary)}
.ac-card h3{font:800 24px var(--f-head);letter-spacing:-.02em}
.ac-card .p{font:800 38px var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.ac-card li{list-style:none;font:500 15px var(--f-body);padding:6px 0;border-top:1px solid color-mix(in srgb,currentColor 18%,transparent)}
@media(max-width:860px){.ac-key{grid-template-columns:1fr}}
.ac-week{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}
.ac-day{background:color-mix(in srgb,var(--c-secondary) 25%,var(--c-surface));border-radius:20px;padding:16px;display:grid;gap:4px;align-content:start;min-height:120px}
.ac-day b{font:800 13px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary)}
.ac-day span{font:800 17px/1.25 var(--f-head);color:var(--c-primary)}
.ac-day em{font:500 13px var(--f-body);font-style:normal}
@media(max-width:860px){.ac-week{grid-template-columns:1fr 1fr}}
.ac-foot{background:var(--c-primary);color:var(--on-primary);border-radius:44px 44px 0 0;margin-top:clamp(36px,5vw,80px);padding:clamp(32px,5vw,60px) clamp(14px,4vw,56px) 22px}
.ac-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.ac-foot .big{font:800 34px var(--f-head);letter-spacing:-.03em}
.ac-foot h4{font:800 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:10px}
.ac-foot ul{list-style:none}.ac-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 15px var(--f-body);min-height:34px;color:var(--on-primary)}
.ac-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ac-foot .copy{margin-top:24px;font:500 12px var(--f-body);opacity:.7}
@media(max-width:860px){.ac-foot .top{grid-template-columns:1fr}.ac-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.ac-s{transition:none}}
.ac .pagehead{text-align:center;background:none}.ac .pagehead .crumbs{justify-content:center}.ac .pagehead h1,.ac .pagehead .lead{margin-left:auto;margin-right:auto}.ac .card,.ac .scard,.ac .qcard,.ac .pcard,.ac .person{background:#fff;background:color-mix(in srgb,var(--c-surface) 30%,#fff);border:0;box-shadow:0 14px 34px -20px color-mix(in srgb,var(--c-primary) 55%,transparent)}.ac .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.ac .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.ac .svc{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:16px;-webkit-overflow-scrolling:touch}
.ac .scard{flex:0 0 min(320px,78vw);scroll-snap-align:start}
.ac .scard .ph{aspect-ratio:4/3!important}

.ac .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:30px 20px}
.ac .person{text-align:center;background:none;border:0;box-shadow:none;padding:0}
.ac .person .ph{aspect-ratio:1!important;border-radius:50%!important;margin:0 auto 12px;max-width:190px}

.ac .qgrid{display:block}.ac .qgrid.mt{margin-top:0}
.ac .qcard{max-width:900px;margin:0 auto;padding:clamp(24px,4vw,48px) 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.ac .qcard blockquote{font-size:clamp(22px,3vw,36px);line-height:1.3;margin:10px 0 18px}

.ac .masonry{display:grid!important;grid-template-columns:repeat(4,1fr);grid-auto-rows:150px;gap:8px;columns:auto}
.ac .masonry .mi{margin:0;overflow:hidden}.ac .masonry .mi .ph{aspect-ratio:auto!important;height:100%}
.ac .masonry .mi:nth-child(5n+1){grid-column:span 2;grid-row:span 2}.ac .masonry .mi:nth-child(7n+3){grid-row:span 2}
.ac .masonry .mi h3,.ac .masonry .mi .muted{display:none}
@media(max-width:700px){.ac .masonry{grid-template-columns:1fr 1fr}}

.ac .split.w2{display:block}
.ac .feat{display:grid;grid-template-columns:1.3fr 1fr;gap:clamp(18px,3vw,40px);align-items:center;margin-bottom:clamp(24px,4vw,48px)}
.ac .feat h2{font-size:clamp(26px,3.6vw,48px);line-height:1.04}
.ac .articles.two{grid-template-columns:repeat(3,1fr)!important}
@media(max-width:800px){.ac .feat{grid-template-columns:1fr}.ac .articles.two{grid-template-columns:1fr!important}}

.ac .faq{display:grid;gap:10px}
.ac .faq details{border:1px solid var(--c-primary);padding:6px 18px;background:var(--c-surface)}.ac .faq details[open]{background:color-mix(in srgb,var(--c-accent) 10%,var(--c-surface))}

.ac .pricing{display:grid;grid-template-columns:1fr;max-width:760px;gap:14px}
.ac .pricing .card{transform:none!important}
.ac .split{display:flex;flex-direction:column-reverse;gap:30px}.ac .cinfo{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}@media(max-width:800px){.ac .cinfo{grid-template-columns:1fr 1fr}}
.ac .ctaband{display:block;text-align:center}.ac .ctaband h2{max-width:22ch;margin:0 auto}.ac .ctaband .btn{margin-top:22px}
.ac .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.ac .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.ac .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.ac .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.ac .tl>div:last-child{border-right:0}
.ac .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.ac .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.ac .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.ac .vals .card:last-child{border-right:0}
@media(max-width:700px){.ac .vals{grid-template-columns:1fr}.ac .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}

.ac-sp{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.ac-sp>div{border-radius:30px;padding:28px;background:color-mix(in srgb,var(--c-secondary) 40%,var(--c-surface));display:grid;gap:8px;align-content:start}
.ac-sp>div:nth-child(2){background:var(--c-primary);color:var(--on-primary)}.ac-sp>div:nth-child(2) h3,.ac-sp>div:nth-child(2) .p{color:var(--on-primary)}
.ac-sp>div:nth-child(3){background:var(--c-accent);color:var(--on-accent)}.ac-sp>div:nth-child(3) h3,.ac-sp>div:nth-child(3) .p{color:var(--on-accent)}
.ac-sp h3{font:800 26px var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}.ac-sp .p{font:800 22px var(--f-head);color:var(--c-primary)}.ac-sp li{list-style:none;font:500 15px var(--f-body);padding:6px 0;border-top:1px solid color-mix(in srgb,currentColor 20%,transparent)}
@media(max-width:860px){.ac-sp{grid-template-columns:1fr}}
.ac-fa{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.ac-fa div{background:color-mix(in srgb,var(--c-secondary) 30%,var(--c-surface));border-radius:22px;padding:18px;font:700 16px var(--f-head)}.ac-fa small{display:block;font:500 13px var(--f-body);margin-top:4px;color:var(--c-text);opacity:.8}
@media(max-width:700px){.ac-fa{grid-template-columns:1fr 1fr}}</style><header class="ac-head"><div class="ac-pill"><a class="ac-logo" href="index.php"><i></i><span>Aurora Cowork</span></a><ul class="ac-nav"><li><a href="features.php">Spaces</a></li><li><a href="pricing.php">Plans</a></li><li><a href="schedule.php">Events</a></li><li><a href="blog.php">Journal</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Spaces</a><a href="service.php">Single Space</a><a href="pricing.php">Membership</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Member Stories</a><a href="project.php">Single Member story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Community</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Book a tour</a><a href="schedule.php">Events</a><a href="features.php">Amenities</a><a href="signup.php">Join Aurora</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="go" href="booking.php">Book a tour</a></li></ul><details class="ac-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Spaces</a><a href="service.php">Single Space</a><a href="pricing.php">Membership</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Member Stories</a><a href="project.php">Single Member story</a><a href="gallery.php">Gallery</a><a href="blog.php">Community</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Book a tour</a><a href="schedule.php">Events</a><a href="features.php">Amenities</a><a href="signup.php">Join Aurora</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></div></header><div class="ac">
<main>
