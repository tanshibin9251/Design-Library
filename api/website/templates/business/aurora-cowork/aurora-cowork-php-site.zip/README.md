# Aurora Cowork

Exported from Design Library · 22 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Spaces, Single Space, Membership, Contact, Testimonials, Team, Member Stories, Single Member story, Gallery, Community, Single post, FAQ, Book a tour, Events, Amenities, Join Aurora, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
