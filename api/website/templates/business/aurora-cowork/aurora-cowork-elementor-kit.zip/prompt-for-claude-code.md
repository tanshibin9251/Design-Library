# Build "Aurora Cowork" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #232a3b · Secondary #b9c9a3 · Text #2a2f3d · Accent #e2725b · Surface #f7f3ec · Border #ddd5c6

## 2. Global Fonts
Headings: Urbanist · Body: DM Sans
H1 88px / H2 46px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 22px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Spaces (services) — html/services.html
- Single Space (service) — html/service.html
- Membership (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Member Stories (projects) — html/projects.html
- Single Member story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Community (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book a tour (booking) — html/booking.html
- Events (schedule) — html/schedule.html
- Amenities (features) — html/features.html
- Join Aurora (signup) — html/signup.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
