<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Ippon Dojo';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Ippon Dojo</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="ippon-dojo" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Ippon Dojo — brush ink, black and caution yellow, tokens only */
.dj-head{position:sticky;top:0;z-index:50;display:flex;align-items:stretch;justify-content:space-between;background:var(--c-primary);color:var(--on-primary);border-bottom:6px solid var(--c-accent)}
.dj-logo{display:flex;align-items:center;gap:16px;padding:10px clamp(18px,3vw,40px);text-decoration:none;color:var(--on-primary)}
.dj-logo b{font:400 38px/1 var(--f-head);letter-spacing:.1em;border-bottom:5px solid var(--c-accent);padding-bottom:2px}
.dj-logo small{font:700 11px var(--f-body);letter-spacing:.3em;text-transform:uppercase;opacity:.8}
.dj-nav{display:flex;align-items:stretch;list-style:none}
.dj-nav a{display:flex;align-items:center;padding:0 clamp(12px,1.6vw,24px);min-height:64px;text-decoration:none;color:var(--on-primary);font:700 13px var(--f-body);letter-spacing:.2em;text-transform:uppercase;border-left:1px solid color-mix(in srgb,var(--on-primary) 22%,transparent);transition:background .15s,color .15s}
.dj-nav a:hover{background:var(--c-accent);color:var(--on-accent)}
.dj-nav .more{position:relative}
.dj-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:18px 28px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:3px solid var(--c-primary);min-width:620px;z-index:60}
.dj-nav .more:hover .dd,.dj-nav .more:focus-within .dd{display:grid}
.dj-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.dj-nav .dd a{display:block;min-height:0;padding:5px 0;border:0;color:var(--c-text);text-transform:none;letter-spacing:0;font:500 14px var(--f-body)}
.dj-nav .dd a:hover{background:none;color:var(--c-primary);text-decoration:underline}
.dj-cta{background:var(--c-accent)!important;color:var(--on-accent)!important}
.dj-cta:hover{filter:brightness(1.08)}
.dj-m{display:none;align-self:center;margin-right:12px}
.dj-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:700 12px var(--f-body);letter-spacing:.2em;border:2px solid var(--on-primary);padding:0 14px}
.dj-m summary::-webkit-details-marker{display:none}
.dj-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-primary);padding:8px 20px 20px;display:grid;border-bottom:6px solid var(--c-accent)}
.dj-m nav a{padding:12px 4px;color:var(--on-primary);text-decoration:none;border-bottom:1px solid color-mix(in srgb,var(--on-primary) 25%,transparent);font:700 14px var(--f-body);letter-spacing:.12em;min-height:44px}
@media(max-width:1000px){.dj-nav{display:none}.dj-m{display:block}}

.dj-sec{padding:var(--pad) clamp(20px,5vw,80px)}
.dj-k{display:inline-block;font:700 12px var(--f-body);letter-spacing:.3em;text-transform:uppercase;background:var(--c-accent);color:var(--on-accent);padding:5px 12px;margin-bottom:18px}
.dj-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:.9em 2.2em;border:3px solid var(--c-primary);background:var(--c-accent);color:var(--on-accent);font:700 14px var(--f-body);letter-spacing:.2em;text-transform:uppercase;text-decoration:none;cursor:pointer;box-shadow:6px 6px 0 var(--c-primary);transition:transform .12s,box-shadow .12s}
.dj-btn:hover{transform:translate(3px,3px);box-shadow:3px 3px 0 var(--c-primary)}
.dj-btn.k{background:var(--c-primary);color:var(--on-primary);border-color:var(--on-primary);box-shadow:6px 6px 0 var(--c-accent)}
.dj-btn.k:hover{box-shadow:3px 3px 0 var(--c-accent)}
.dj-ph{position:relative;min-height:240px;background:repeating-linear-gradient(135deg,var(--c-primary) 0 2px,transparent 2px 14px),color-mix(in srgb,var(--c-accent) 16%,var(--c-surface));border:3px solid var(--c-primary)}
.dj-ph::after{content:attr(data-l);position:absolute;left:0;bottom:0;background:var(--c-primary);color:var(--on-primary);font:700 10px var(--f-body);letter-spacing:.18em;text-transform:uppercase;padding:5px 10px}

/* hero: brush circle and diagonal cut */
.dj-hero{position:relative;background:var(--c-primary);color:var(--on-primary);overflow:hidden;clip-path:polygon(0 0,100% 0,100% 90%,0 100%);padding:clamp(48px,7vw,110px) clamp(20px,5vw,80px) clamp(110px,12vw,190px);min-height:min(88vh,760px);display:grid;align-items:center}
.dj-enso{position:absolute;right:clamp(-120px,-4vw,0px);top:50%;width:clamp(300px,50vw,720px);aspect-ratio:1;transform:translateY(-50%) rotate(-12deg);color:var(--c-accent);opacity:.95}
.dj-enso circle{fill:none;stroke:currentColor;stroke-width:15;stroke-linecap:round;stroke-dasharray:1760;stroke-dashoffset:1760;animation:djdraw 1.9s cubic-bezier(.3,.6,.2,1) .2s forwards}
@keyframes djdraw{to{stroke-dashoffset:260}}
.dj-hero-in{position:relative;max-width:820px}
.dj-hero .en{font:700 12px var(--f-body);letter-spacing:.34em;text-transform:uppercase;color:var(--c-accent)}
.dj-hero h1{white-space:nowrap;font:400 clamp(96px,18vw,280px)/.95 var(--f-head);letter-spacing:.04em;color:var(--on-primary);margin:12px 0 20px;text-shadow:6px 6px 0 color-mix(in srgb,var(--c-accent) 70%,transparent)}
.dj-hero p{font:500 clamp(16px,1.6vw,19px)/1.9 var(--f-body);max-width:40ch;opacity:.92}
.dj-tape{background:var(--c-accent);color:var(--on-accent);border-top:4px solid var(--c-primary);border-bottom:4px solid var(--c-primary);overflow:hidden;white-space:nowrap;margin-top:-52px;transform:rotate(-1.4deg);position:relative;z-index:2}
.dj-tape span{display:inline-block;padding:12px 0;font:700 15px var(--f-body);letter-spacing:.34em;animation:djtape 30s linear infinite}
@keyframes djtape{from{transform:translateX(0)}to{transform:translateX(-50%)}}
@media(max-width:700px){.dj-enso{opacity:.35}}

/* classes slabs */
.dj-3{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(18px,2.4vw,34px)}
.dj-slab{border:3px solid var(--c-primary);background:var(--c-surface);padding:30px 26px 34px;box-shadow:8px 8px 0 var(--c-primary);display:grid;gap:12px;align-content:start;text-decoration:none;transition:transform .15s,box-shadow .15s}
.dj-slab:hover{transform:translate(4px,4px);box-shadow:4px 4px 0 var(--c-primary)}
.dj-slab .kj{font:400 78px/1 var(--f-head);color:var(--c-primary)}
.dj-slab h3{font:700 20px var(--f-body);letter-spacing:.12em;text-transform:uppercase}
.dj-slab .age{font:700 12px var(--f-body);letter-spacing:.2em;background:var(--c-primary);color:var(--on-primary);padding:4px 10px;justify-self:start}
.dj-slab p{font-size:15px;line-height:1.8}
@media(max-width:900px){.dj-3{grid-template-columns:1fr}}

/* belt ladder */
.dj-belt{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:clamp(24px,5vw,80px);align-items:start}
.dj-ladder{display:grid;gap:8px}
.dj-ladder button{display:grid;grid-template-columns:auto 1fr;gap:16px;align-items:center;text-align:left;border:3px solid var(--c-primary);background:var(--c-surface);padding:0;cursor:pointer;color:inherit;font:inherit;min-height:52px;transition:transform .12s}
.dj-ladder button:hover{transform:translateX(6px)}
.dj-ladder .bar{width:clamp(60px,var(--w),240px);align-self:stretch;min-height:50px;background:var(--bc);border-right:3px solid var(--c-primary)}
.dj-ladder .nm{font:700 14px var(--f-body);letter-spacing:.14em;text-transform:uppercase;padding-right:14px}
.dj-ladder .nm small{display:block;font:500 12px var(--f-body);letter-spacing:.1em;opacity:.7;text-transform:none}
.dj-ladder button[aria-pressed=true]{background:var(--c-accent);color:var(--on-accent);transform:translateX(14px);box-shadow:6px 6px 0 var(--c-primary)}
.dj-info{border:3px solid var(--c-primary);background:var(--c-primary);color:var(--on-primary);padding:clamp(24px,3.4vw,44px);position:sticky;top:96px}
.dj-info .big{font:400 clamp(60px,7vw,110px)/1 var(--f-head);color:var(--c-accent)}
.dj-info h3{font:700 20px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--on-primary);margin:8px 0 14px}
.dj-info ul{list-style:none;display:grid;gap:0;margin-top:18px}
.dj-info li{padding:12px 0;border-top:1px solid color-mix(in srgb,var(--on-primary) 25%,transparent);font:500 15px var(--f-body)}
@media(max-width:900px){.dj-belt{grid-template-columns:1fr}.dj-info{position:static}}

/* timetable */
.dj-chips{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:28px}
.dj-chips button{min-height:44px;padding:0 18px;border:3px solid var(--c-primary);background:var(--c-surface);font:700 13px var(--f-body);letter-spacing:.16em;text-transform:uppercase;cursor:pointer;color:var(--c-primary)}
.dj-chips button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.dj-tt{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border:3px solid var(--c-primary)}
.dj-tt>div{border-right:3px solid var(--c-primary);min-height:100px;padding:0 0 10px}
.dj-tt>div:last-child{border-right:0}
.dj-tt h4{font:700 13px var(--f-body);letter-spacing:.16em;text-transform:uppercase;background:var(--c-primary);color:var(--on-primary);padding:10px;text-align:center}
.dj-tt .c{margin:10px 8px 0;padding:8px 8px;border:2px solid var(--c-primary);background:var(--c-accent);color:var(--on-accent);font:600 12px/1.4 var(--f-body)}
.dj-tt .c b{display:block;font:700 13px var(--f-body)}
.dj-tt .c.hide{display:none}
.dj-tt .c[data-t=kids]{background:var(--c-surface);color:var(--c-text)}
.dj-tt .c[data-t=adult]{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:900px){.dj-tt{grid-template-columns:1fr 1fr}.dj-tt>div{border-bottom:3px solid var(--c-primary)}.dj-tt>div:nth-child(2n){border-right:0}}
@media(max-width:480px){.dj-tt{grid-template-columns:1fr}.dj-tt>div{border-right:0}}

.dj-pr{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(18px,2.4vw,34px)}
.dj-pr>div{border:3px solid var(--c-primary);padding:34px 28px;display:grid;gap:12px;align-content:start;background:var(--c-surface)}
.dj-pr>div.hl{background:var(--c-accent);color:var(--on-accent);box-shadow:8px 8px 0 var(--c-primary)}
.dj-pr .n{font:400 62px/1 var(--f-head)}
.dj-pr .p{font:700 28px var(--f-body)}
.dj-pr li{list-style:none;padding:9px 0;border-top:2px solid currentColor;font-size:15px}
@media(max-width:900px){.dj-pr{grid-template-columns:1fr}}
.dj-two{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:center}
.dj-two h2{font:400 clamp(34px,4.6vw,var(--h2)) var(--f-head);letter-spacing:.04em;margin-bottom:14px}
.dj-two p{line-height:1.95;max-width:48ch}
@media(max-width:800px){.dj-two{grid-template-columns:1fr}}
.dj-rules{counter-reset:r;display:grid;gap:0;border-top:3px solid var(--c-primary)}
.dj-rules li{counter-increment:r;list-style:none;display:grid;grid-template-columns:90px 1fr;gap:20px;padding:22px 0;border-bottom:3px solid var(--c-primary);align-items:baseline}
.dj-rules li::before{content:counter(r,cjk-ideographic);font:400 44px/1 var(--f-head)}
.dj-rules b{display:block;font:700 18px var(--f-body);letter-spacing:.08em;margin-bottom:4px}
.dj-news{display:grid;grid-template-columns:130px 1fr auto;gap:18px;padding:20px 0;border-top:3px solid var(--c-primary);text-decoration:none;align-items:baseline}
.dj-news:last-child{border-bottom:3px solid var(--c-primary)}
.dj-news time{font:700 13px var(--f-body);letter-spacing:.14em}
.dj-news h3{font:700 19px var(--f-body)}
.dj-news .t{font:700 11px var(--f-body);letter-spacing:.2em;background:var(--c-accent);color:var(--on-accent);padding:4px 10px;text-transform:uppercase}
@media(max-width:600px){.dj-news{grid-template-columns:1fr;gap:6px}}
.dj-foot{background:var(--c-primary);color:var(--on-primary);padding:clamp(44px,6vw,80px) clamp(20px,5vw,80px) 26px;border-top:6px solid var(--c-accent);margin-top:var(--pad)}
.dj-foot .top{display:grid;grid-template-columns:1.2fr 2fr;gap:clamp(24px,6vw,100px)}
.dj-foot .big{font:400 80px/1 var(--f-head);letter-spacing:.06em}
.dj-foot h4{font:700 11px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.dj-foot ul{list-style:none}.dj-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font-size:14px;min-height:32px}.dj-foot li a:hover{color:var(--c-accent)}
.dj-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.dj-foot .copy{margin-top:34px;padding-top:16px;border-top:1px solid color-mix(in srgb,var(--on-primary) 30%,transparent);font:700 11px var(--f-body);letter-spacing:.2em;opacity:.7}
@media(max-width:800px){.dj-foot .top{grid-template-columns:1fr}.dj-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(max-width:700px){.dj-sec{padding-left:18px;padding-right:18px}.dj-logo small{display:none}}
@media(prefers-reduced-motion:reduce){.dj-enso circle{animation:none;stroke-dashoffset:260}.dj-tape span{animation:none}.dj-btn,.dj-slab,.dj-ladder button{transition:none}}
</style><header class="dj-head"><a class="dj-logo" href="index.php"><b>一本</b><small>Ippon Dojo<br>Karate &amp; Judo</small></a><ul class="dj-nav"><li><a href="classes.php">Classes</a></li><li><a href="timetable.php">Timetable</a></li><li><a href="ranks.php">Ranks</a></li><li><a href="pricing.php">Fees</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Dojo</h4><a href="index.php">Home</a><a href="classes.php">Classes</a><a href="timetable.php">Timetable</a><a href="ranks.php">Belt ranks</a><a href="sensei.php">Sensei</a><a href="etiquette.php">Dojo etiquette</a></div><div><h4>Join</h4><a href="trial.php">Free trial</a><a href="pricing.php">Membership</a><a href="news.php">News & events</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="dj-cta" href="trial.php">無料体験 Free trial</a></li></ul><details class="dj-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="classes.php">Classes</a><a href="timetable.php">Timetable</a><a href="ranks.php">Belt ranks</a><a href="sensei.php">Sensei</a><a href="etiquette.php">Dojo etiquette</a><a href="trial.php">Free trial</a><a href="pricing.php">Membership</a><a href="news.php">News & events</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
