# Build "Ippon Dojo" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #111111 · Secondary #6b6b6b · Text #1a1a1a · Accent #f2c200 · Surface #f4f2ec · Border #111111

## 2. Global Fonts
Headings: Yuji Boku · Body: BIZ UDPGothic
H1 120px / H2 56px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Classes (classes) — html/classes.html
- Timetable (timetable) — html/timetable.html
- Belt ranks (ranks) — html/ranks.html
- Sensei (sensei) — html/sensei.html
- Dojo etiquette (etiquette) — html/etiquette.html
- Free trial (trial) — html/trial.html
- Membership (pricing) — html/pricing.html
- News & events (news) — html/news.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
