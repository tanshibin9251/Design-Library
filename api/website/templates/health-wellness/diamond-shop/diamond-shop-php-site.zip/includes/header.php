<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Diamond Shop';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Diamond Shop</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="diamond-shop" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Diamond Shop v2 — dark-and-bone sports store. Warm black + oxblood glow, bone-paper product sections, one brand red, condensed-sport caps headings; diamond marker from the logo; slanted product plates; size-first product page. Tokens only. */
.dm-in{max-width:var(--w);margin:0 auto;padding:0 clamp(18px,3.4vw,40px)}
.dm-dk{background:var(--c-primary);color:#efe7df}
.dm-dk h1,.dm-dk h2,.dm-dk h3,.dm-dk h4{color:#fff}
.dm-ann{background:var(--c-accent);color:var(--on-accent);text-align:center;font:600 13px/1 var(--f-body);letter-spacing:.03em;padding:10px 16px}
.dm-ann a{color:inherit;font-weight:800;text-decoration:underline}
.dm-head{position:sticky;top:0;z-index:50;background:var(--c-primary);color:#f4efe9;border-bottom:1px solid rgba(255,255,255,.1)}
.dm-head .dm-in{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:20px;height:80px}
.dm-head nav,.dm-head .r{display:flex;gap:4px;align-items:center}
.dm-head .r{justify-content:flex-end}
.dm-head nav a,.dm-head .r a{padding:12px 12px;font:600 14px/1 var(--f-head);letter-spacing:.08em;text-transform:uppercase;text-decoration:none;position:relative;min-height:44px;display:inline-flex;align-items:center;color:#f4efe9;opacity:.85}
.dm-head nav a:hover,.dm-head .r a:hover{opacity:1;color:#fff}
.dm-head nav a::after{content:"";position:absolute;left:12px;right:12px;bottom:6px;height:2px;background:var(--c-accent);transform:scaleX(0);transform-origin:left;transition:transform .25s}
.dm-head nav a:hover::after{transform:scaleX(1)}
.dm-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:#fff;font:800 26px/1 var(--f-head);letter-spacing:.02em;text-transform:uppercase}
.dm-logo img{height:40px;width:auto;display:block}
.dm-logo .dia{width:24px;height:24px;background:var(--c-accent);transform:rotate(45deg);flex:none}
.dm-head .r a.dm-cart{background:var(--c-accent);color:#fff;padding:12px 18px;opacity:1}
.dm-head .r a.dm-cart:hover{background:#fff;color:var(--c-accent)}
.dm-burger{display:none}
.dm-burger summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:700 13px var(--f-head);letter-spacing:.1em;text-transform:uppercase;color:#fff}
.dm-burger summary::-webkit-details-marker{display:none}
.dm-burger div{position:absolute;left:0;right:0;top:100%;background:var(--c-primary);border-bottom:1px solid rgba(255,255,255,.12);padding:8px 20px 20px;display:grid}
.dm-burger a{padding:14px 0;border-bottom:1px solid rgba(255,255,255,.1);text-decoration:none;font:600 16px var(--f-head);letter-spacing:.08em;text-transform:uppercase;color:#fff}
@media(max-width:900px){.dm-head .dm-in{grid-template-columns:auto 1fr auto;height:66px}.dm-head nav{display:none}.dm-head .r a:not(.dm-cart){display:none}.dm-logo{justify-self:center;grid-column:2}.dm-burger{display:block;grid-column:1;grid-row:1}.dm-head .r{grid-column:3}.dm-logo img{height:32px}}
.dm-rail{background:var(--c-secondary);border-bottom:1px solid rgba(255,255,255,.08)}
.dm-rail .dm-in{display:flex;gap:2px;overflow-x:auto;scrollbar-width:none}
.dm-rail a{white-space:nowrap;padding:13px 16px;font:600 13px/1 var(--f-head);letter-spacing:.1em;text-transform:uppercase;text-decoration:none;display:inline-flex;gap:8px;align-items:center;min-height:44px;color:#e8dcd2}
.dm-rail a small{opacity:.5;font-weight:500}
.dm-rail a:hover{color:#fff}
.dm-rail a.hot{color:#ff5a63}

.dm-btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;min-height:50px;padding:0 30px 0 28px;background:var(--c-accent);color:var(--on-accent);font:700 14px/1 var(--f-head);letter-spacing:.1em;text-transform:uppercase;text-decoration:none;border:2px solid var(--c-accent);cursor:pointer;transition:background .2s,color .2s;clip-path:polygon(0 0,100% 0,calc(100% - 12px) 100%,0 100%)}
.dm-btn:hover{background:#fff;border-color:#fff;color:var(--c-accent)}
.dm-btn.o{background:transparent;color:var(--c-text);border-color:var(--c-text);clip-path:none}
.dm-btn.o:hover{background:var(--c-text);color:var(--c-surface)}
.dm-dk .dm-btn.o,.dm-btn.ow{background:transparent;border-color:#fff;color:#fff;clip-path:none}
.dm-dk .dm-btn.o:hover,.dm-btn.ow:hover{background:#fff;color:var(--c-primary)}
.dm-btn.w{background:#fff;border-color:#fff;color:var(--c-accent)}
.dm-btn.w:hover{background:var(--c-primary);border-color:var(--c-primary);color:#fff}
.dm-btn.wa{background:#1f9d55;border-color:#1f9d55;clip-path:none}
.dm-btn.wa:hover{background:#fff;border-color:#fff;color:#1f9d55}
.dm-btn.block{display:flex;width:100%}
.dm-eyebrow{display:flex;align-items:center;gap:10px;font:700 12px/1 var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-accent);margin-bottom:14px}
.dm-eyebrow::before{content:"";width:9px;height:9px;background:currentColor;transform:rotate(45deg);flex:none}
.dm-h2{font-size:clamp(28px,3.8vw,56px);line-height:1}
.dm-todo{background:#ffd54a;color:#111;padding:0 .35em;font:600 .82em/1.5 var(--f-body);text-transform:none;letter-spacing:0}
.dm-src{display:block;margin-top:8px;font:500 12px/1.4 var(--f-body);opacity:.6}
.dm-sec{padding:var(--pad) 0}.dm-sec.t{padding:calc(var(--pad)*.65) 0}
.dm-ph{border-radius:0}

.dm-hero{position:relative;overflow:hidden;background:radial-gradient(900px 560px at 80% 45%,#5b0d18 0%,rgba(91,13,24,0) 70%),linear-gradient(180deg,#0c0809,#150607);color:#efe7df}
.dm-hero::after{content:"";position:absolute;left:0;right:0;bottom:0;height:6px;background:var(--c-accent)}
.dm-hero .dm-in{position:relative;display:grid;grid-template-columns:1.05fr .95fr;gap:30px;align-items:center;padding-top:clamp(44px,6vw,92px);padding-bottom:clamp(54px,7vw,104px)}
.dm-hero h1{font-size:clamp(46px,7.4vw,var(--h1));line-height:.95;letter-spacing:.005em;color:#fff}
.dm-hero h1 em{font-style:normal;color:var(--c-accent)}
.dm-hero p{font-size:clamp(16px,1.5vw,19px);margin:22px 0 32px;max-width:46ch;color:#d9cdc4}
.dm-hero .btns{display:flex;gap:14px;flex-wrap:wrap}
.dm-stage{position:relative;justify-self:center;width:min(100%,540px);aspect-ratio:1/1.02}
.dm-stage .slab{position:absolute;inset:6% -5% -5% 12%;background:var(--c-accent);clip-path:polygon(14% 0,100% 0,86% 100%,0 100%)}
.dm-stage .plate{position:absolute;inset:0 8% 6% 0;clip-path:polygon(14% 0,100% 0,86% 100%,0 100%);background:#fff;overflow:hidden}
.dm-stage .plate .ph{position:absolute;inset:0;width:100%;height:100%;aspect-ratio:auto!important;min-height:0}
.dm-stage .tag{position:absolute;left:0;bottom:8%;background:#fff;color:var(--c-primary);font:800 13px/1 var(--f-head);letter-spacing:.1em;text-transform:uppercase;padding:12px 16px}
.dm-stage .tag::before{content:"";display:inline-block;width:8px;height:8px;background:var(--c-accent);transform:rotate(45deg);margin-right:10px}
@media(max-width:860px){.dm-hero .dm-in{grid-template-columns:1fr}.dm-stage{width:min(88%,400px)}}

.dm-cats{display:grid;grid-template-columns:repeat(5,1fr);gap:clamp(10px,1.6vw,22px)}
.dm-cat{position:relative;text-decoration:none;display:block;color:var(--c-text)}
.dm-cat .dia{aspect-ratio:4/5;background:color-mix(in srgb,var(--c-text) 6%,#fff);overflow:hidden;clip-path:polygon(0 0,100% 0,100% calc(100% - 22px),calc(100% - 22px) 100%,0 100%);transition:filter .2s}
.dm-cat .dia .ph{width:100%;height:100%;aspect-ratio:auto!important;min-height:0;border-radius:0}
.dm-cat .b{padding:20px 2px 6px;position:relative}
.dm-cat .b::before{content:"";position:absolute;left:6px;top:8px;width:34px;height:4px;background:var(--c-accent);transform:skewX(-28deg);transition:width .25s}
.dm-cat h3{font-size:clamp(17px,1.5vw,22px);letter-spacing:.04em;color:var(--c-text)}
.dm-cat small{font:600 12px var(--f-body);opacity:.6}
.dm-cat::before{content:"";position:absolute;right:14px;top:14px;width:12px;height:12px;background:var(--c-accent);transform:rotate(45deg);z-index:2}
.dm-cat:hover .b::before{width:76px}.dm-cat:hover h3{color:var(--c-accent)}.dm-cat:hover .dia{filter:brightness(.96)}
@media(max-width:900px){.dm-cats{grid-template-columns:repeat(3,1fr)}}
@media(max-width:520px){.dm-cats{grid-template-columns:repeat(2,1fr)}}

.dm-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:clamp(14px,2vw,26px)}
.dm-grid.g3{grid-template-columns:repeat(3,1fr)}
.dm-card{position:relative;text-decoration:none;display:block;color:var(--c-text)}
.dm-card .img{position:relative;overflow:hidden;background:color-mix(in srgb,var(--c-text) 6%,#fff);clip-path:polygon(0 0,100% 0,100% calc(100% - 26px),calc(100% - 26px) 100%,0 100%);transition:filter .2s}
.dm-card .img .ph{border-radius:0;aspect-ratio:1/1!important;width:100%}
.dm-card .badge{position:absolute;left:0;top:14px;background:var(--c-accent);color:#fff;font:800 12px/1 var(--f-head);letter-spacing:.1em;padding:8px 14px 8px 12px;clip-path:polygon(0 0,100% 0,calc(100% - 8px) 100%,0 100%)}
.dm-card .quick{position:absolute;left:0;right:0;bottom:0;background:var(--c-primary);color:#fff;text-align:center;padding:13px;font:700 13px var(--f-head);letter-spacing:.12em;text-transform:uppercase;transform:translateY(100%);transition:transform .2s}
.dm-card:hover .quick,.dm-card.is-tap .quick{transform:none}
@media(pointer:coarse){.dm-card .quick{display:none}}
.dm-card .meta{margin-top:14px;padding:12px 2px 0;border-top:2px solid var(--c-text);transition:border-color .2s}
.dm-card:hover .meta{border-top-color:var(--c-accent)}.dm-card:hover h3{color:var(--c-accent)}.dm-card:hover .img{filter:brightness(.96)}
.dm-card small{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent)}
.dm-card h3{font:600 clamp(16px,1.3vw,18px)/1.3 var(--f-body);margin-top:5px;letter-spacing:0;text-transform:none;color:var(--c-text)}
.dm-card .pr{margin-top:8px;font:800 18px var(--f-head);letter-spacing:.02em;color:var(--c-text)}
.dm-card .pr s{opacity:.45;font-weight:500;margin-left:8px;font-size:14px}
.dm-card .sz{margin-top:6px;font:500 12px var(--f-body);opacity:.6}
@media(max-width:1000px){.dm-grid,.dm-grid.g3{grid-template-columns:repeat(2,1fr)}}

.dm-head2{display:flex;justify-content:space-between;align-items:end;gap:20px;flex-wrap:wrap;margin-bottom:clamp(24px,3vw,40px)}
.dm-pick-sec{background:radial-gradient(700px 400px at 12% 80%,#4a0b15 0%,rgba(74,11,21,0) 70%),var(--c-primary);color:#e8ddd4}
.dm-pick-sec h2,.dm-pick-sec h3{color:#fff}
.dm-pick{display:grid;grid-template-columns:.8fr 1.2fr;gap:clamp(24px,5vw,80px);align-items:start}
.dm-pick ul{list-style:none;border-top:2px solid var(--c-accent)}
.dm-pick li a{display:grid;grid-template-columns:48px 1fr auto;gap:18px;padding:22px 0;border-bottom:1px solid rgba(255,255,255,.14);text-decoration:none;align-items:center;color:#fff}
.dm-pick li a:hover{background:rgba(255,255,255,.04)}
.dm-pick .n{width:30px;height:30px;background:var(--c-accent);transform:rotate(45deg) scale(.7);color:#fff;display:grid;place-items:center}
.dm-pick .n b{transform:rotate(-45deg);font:800 13px var(--f-head)}
.dm-pick h3{font-size:clamp(20px,2.2vw,30px)}.dm-pick p{font-size:14px;opacity:.7;margin-top:2px}
.dm-pick .go{font:700 22px var(--f-head);color:var(--c-accent)}
@media(max-width:860px){.dm-pick{grid-template-columns:1fr}}

.dm-promo{display:grid;grid-template-columns:1.1fr .9fr;background:linear-gradient(120deg,#2a0a10,#4a0b15);color:#f4efe9;overflow:hidden}
.dm-promo>div{padding:clamp(30px,5vw,70px)}
.dm-promo h2{color:#fff}
.dm-promo .side{background:var(--c-accent);clip-path:polygon(16% 0,100% 0,100% 100%,0 100%);display:grid;place-items:center;padding-left:14%}
.dm-promo .side b{font:800 clamp(34px,4.6vw,68px)/.95 var(--f-head);letter-spacing:.02em;text-transform:uppercase;color:#fff;text-align:center}
@media(max-width:800px){.dm-promo{grid-template-columns:1fr}.dm-promo .side{min-height:200px;clip-path:polygon(0 14%,100% 0,100% 100%,0 100%);padding:40px 0 0}}
.dm-trust{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;border-top:2px solid var(--c-text);padding:26px 0 0}
.dm-trust div{display:flex;gap:12px;align-items:flex-start;font-size:14px}
.dm-trust div::before{content:"";width:10px;height:10px;background:var(--c-accent);transform:rotate(45deg);margin-top:6px;flex:none}
.dm-trust b{display:block;font:700 15px var(--f-head);letter-spacing:.08em;text-transform:uppercase}
@media(max-width:800px){.dm-trust{grid-template-columns:1fr 1fr}}

.dm-ph2{background:radial-gradient(700px 300px at 85% 50%,#4a0b15 0%,rgba(74,11,21,0) 70%),var(--c-primary);color:#e8ddd4;padding:clamp(30px,4.5vw,64px) 0;border-bottom:4px solid var(--c-accent)}
.dm-ph2 h1{font-size:clamp(36px,5.2vw,76px);line-height:1;color:#fff}
.dm-ph2 p{margin-top:12px;max-width:62ch;color:#d9cdc4}
.dm-crumbs{display:flex;gap:8px;flex-wrap:wrap;font:600 13px var(--f-body);opacity:.7;margin-bottom:14px}
.dm-crumbs a{text-decoration:none}
.dm-shop{display:grid;grid-template-columns:260px 1fr;gap:clamp(24px,4vw,56px);align-items:start}
.dm-filter{position:sticky;top:104px;display:grid;gap:26px}
.dm-filter h4{font:700 14px var(--f-head);letter-spacing:.1em;text-transform:uppercase;margin-bottom:10px;padding-bottom:8px;border-bottom:2px solid var(--c-text)}
.dm-filter label{display:flex;gap:10px;align-items:center;padding:7px 0;font-size:15px;cursor:pointer;min-height:44px}
.dm-filter input[type=checkbox]{accent-color:var(--c-accent);width:18px;height:18px}
.dm-pills{display:flex;gap:8px;flex-wrap:wrap}
.dm-pill{min-width:48px;min-height:44px;padding:0 14px;display:inline-flex;align-items:center;justify-content:center;border:1.5px solid color-mix(in srgb,var(--c-text) 25%,transparent);background:#fff;font:600 14px var(--f-body);cursor:pointer}
.dm-pill:hover{border-color:var(--c-text)}
.dm-pill.on{background:var(--c-primary);border-color:var(--c-primary);color:#fff}
.dm-pill.off{opacity:.35;text-decoration:line-through;cursor:not-allowed}
.dm-dot{width:30px;height:30px;border-radius:50%;border:2px solid var(--c-border);display:inline-block;min-width:44px;min-height:44px;background-clip:content-box;padding:7px}
.dm-dot.on{border-color:var(--c-text)}
.dm-sort{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:22px;flex-wrap:wrap;font-size:14px}
.dm-sort select{min-height:44px;padding:0 14px;border:1.5px solid color-mix(in srgb,var(--c-text) 25%,transparent);background:#fff;font:600 14px var(--f-body)}
.dm-pager{display:flex;gap:8px;justify-content:center;margin-top:44px}
.dm-pager a{min-width:46px;min-height:46px;display:grid;place-items:center;border:1.5px solid color-mix(in srgb,var(--c-text) 25%,transparent);background:#fff;text-decoration:none;font-weight:700}
.dm-pager a.on{background:var(--c-accent);border-color:var(--c-accent);color:#fff}
.dm-fbtn{display:none}
@media(max-width:900px){.dm-shop{grid-template-columns:1fr}.dm-filter{position:static;display:none}.dm-fbtn{display:inline-flex}.dm-filter.open{display:grid}}

.dm-pdp{display:grid;grid-template-columns:1.1fr .9fr;gap:clamp(24px,5vw,72px);align-items:start}
.dm-gal{display:grid;grid-template-columns:84px 1fr;gap:14px}
.dm-gal .th{display:grid;gap:10px;align-content:start}
.dm-gal .th .ph{aspect-ratio:1!important;min-height:0;border-radius:0}
.dm-gal .big{background:color-mix(in srgb,var(--c-text) 6%,#fff)}
.dm-gal .big .ph{aspect-ratio:1/1.05!important;border-radius:0}
.dm-buy h1{font-size:clamp(28px,3.2vw,46px);line-height:1.02;color:var(--c-text)}
.dm-buy .pr{font:800 32px var(--f-head);color:var(--c-accent);margin:14px 0 4px;letter-spacing:.02em}
.dm-buy .pr s{font-size:18px;opacity:.5;color:var(--c-text);font-weight:500;margin-left:10px}
.dm-buy .lab{display:flex;justify-content:space-between;align-items:baseline;margin:22px 0 10px;font:700 13px var(--f-head);letter-spacing:.1em;text-transform:uppercase}
.dm-buy .lab a{font:600 13px var(--f-body);letter-spacing:0;text-transform:none;color:var(--c-accent)}
.dm-qty{display:inline-flex;align-items:center;border:1.5px solid color-mix(in srgb,var(--c-text) 25%,transparent);background:#fff;min-height:50px}
.dm-qty b{width:46px;text-align:center;font:700 16px var(--f-head)}
.dm-qty span{width:46px;height:50px;display:grid;place-items:center;font:700 20px var(--f-head);cursor:pointer}
.dm-buyrow{display:flex;gap:12px;margin-top:22px;flex-wrap:wrap}
.dm-buyrow .dm-btn{flex:1 1 200px}
.dm-perks{list-style:none;margin-top:24px;display:grid;gap:10px;font-size:14px}
.dm-perks li{padding-left:22px;position:relative}
.dm-perks li::before{content:"";position:absolute;left:2px;top:.5em;width:8px;height:8px;background:var(--c-accent);transform:rotate(45deg)}
.dm-sticky{display:none}
@media(max-width:860px){.dm-pdp{grid-template-columns:1fr}.dm-gal{grid-template-columns:1fr}.dm-gal .th{grid-template-columns:repeat(4,1fr);order:2}
 .dm-sticky{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:60;background:var(--c-primary);color:#fff;padding:10px 16px;gap:12px;align-items:center}
 .dm-sticky b{font:800 18px var(--f-head);color:#fff}.dm-sticky .dm-btn{flex:1;min-height:46px}}
.dm-spec{border-top:2px solid var(--c-text)}
.dm-spec>div{display:grid;grid-template-columns:220px 1fr;gap:20px;padding:16px 0;border-bottom:1px solid color-mix(in srgb,var(--c-text) 18%,transparent)}
.dm-spec dt{font:700 14px var(--f-head);letter-spacing:.08em;text-transform:uppercase}
@media(max-width:600px){.dm-spec>div{grid-template-columns:1fr;gap:2px}}
.dm-size{width:100%;border-collapse:collapse;font-size:15px}
.dm-size th{font:700 12px var(--f-head);letter-spacing:.1em;text-transform:uppercase;text-align:left;padding:12px 14px;background:var(--c-primary);color:#fff}
.dm-size td{padding:12px 14px;border-bottom:1px solid color-mix(in srgb,var(--c-text) 12%,transparent)}
.dm-size tr:nth-child(even) td{background:color-mix(in srgb,var(--c-text) 6%,#fff)}
.dm-scroll{overflow-x:auto}
.dm-note{background:color-mix(in srgb,var(--c-text) 6%,#fff);border-left:5px solid var(--c-accent);padding:18px 22px;font-size:15px;margin-top:18px}

.dm-table{width:100%;border-collapse:collapse}
.dm-table th{font:700 12px var(--f-head);text-align:left;padding:14px 14px;background:var(--c-primary);color:#fff;letter-spacing:.1em;text-transform:uppercase}
.dm-table td{padding:18px 14px;border-bottom:1px solid color-mix(in srgb,var(--c-text) 12%,transparent);vertical-align:middle}
.dm-table .it{display:flex;gap:16px;align-items:center}.dm-table .it .ph{width:84px;aspect-ratio:1!important;min-height:0;border-radius:0}
.dm-two{display:grid;grid-template-columns:1.5fr 1fr;gap:clamp(24px,4vw,56px);align-items:start}
.dm-sum{background:var(--c-primary);color:#e8ddd4;padding:clamp(22px,3vw,36px);position:sticky;top:110px}
.dm-sum h3{color:#fff}
.dm-sum dl{display:grid;grid-template-columns:1fr auto;gap:10px;margin:18px 0}
.dm-sum dt{opacity:.7}.dm-sum dd{font-weight:700;text-align:right;color:#fff}
.dm-sum .tot{font:800 22px var(--f-head);border-top:1px solid rgba(255,255,255,.18);padding-top:14px;color:#fff}
.dm-form{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.dm-form .full{grid-column:1/-1}
.dm-field span{display:block;font:700 12px var(--f-head);letter-spacing:.1em;text-transform:uppercase;margin-bottom:6px}
.dm-field input,.dm-field select,.dm-field textarea{width:100%;min-height:50px;padding:12px 14px;border:1.5px solid color-mix(in srgb,var(--c-text) 22%,transparent);background:#fff;font:500 15px var(--f-body)}
.dm-field input:focus,.dm-field select:focus{outline:3px solid color-mix(in srgb,var(--c-accent) 35%,transparent);border-color:var(--c-accent)}
.dm-pay{display:grid;gap:10px;margin-top:10px}
.dm-pay label{display:flex;gap:12px;align-items:center;border:1.5px solid color-mix(in srgb,var(--c-text) 22%,transparent);background:#fff;padding:14px 16px;min-height:56px;cursor:pointer}
.dm-pay input{accent-color:var(--c-accent);width:18px;height:18px}
.dm-two.leg{grid-template-columns:minmax(0,1fr) 300px}.dm-two.eq{grid-template-columns:1fr 1fr}
@media(max-width:860px){.dm-two,.dm-two.leg,.dm-two.eq{grid-template-columns:minmax(0,1fr)}.dm-sum{position:static}.dm-form{grid-template-columns:1fr}.dm-toc{position:static}}

.dm-side2{display:grid;grid-template-columns:1.05fr .95fr;gap:clamp(24px,5vw,80px);align-items:center}
.dm-collage{position:relative;aspect-ratio:1}
.dm-collage .a{position:absolute;left:0;top:10%;width:58%;aspect-ratio:4/5;clip-path:polygon(12% 0,100% 0,88% 100%,0 100%)}
.dm-collage .b{position:absolute;right:0;top:0;width:44%;aspect-ratio:4/5;clip-path:polygon(12% 0,100% 0,88% 100%,0 100%)}
.dm-collage .c{position:absolute;right:6%;bottom:0;width:48%;aspect-ratio:4/5;clip-path:polygon(12% 0,100% 0,88% 100%,0 100%)}
.dm-collage .ph{width:100%;height:100%;aspect-ratio:auto!important;min-height:0;border-radius:0}
@media(max-width:860px){.dm-side2{grid-template-columns:1fr}}
.dm-list{list-style:none;display:grid;gap:12px;margin-top:20px}
.dm-list li{padding-left:26px;position:relative}
.dm-list li::before{content:"";position:absolute;left:2px;top:.55em;width:9px;height:9px;background:var(--c-accent);transform:rotate(45deg)}
.dm-wa{background:var(--c-accent);color:var(--on-accent);padding:clamp(28px,4vw,52px);position:relative;overflow:hidden;clip-path:polygon(0 0,100% 0,96% 100%,0 100%)}
.dm-wa h2{color:#fff}.dm-wa p{margin:14px 0 24px;max-width:44ch}
.dm-prose{max-width:76ch}.dm-prose h2{font-size:clamp(20px,2.2vw,28px);margin:34px 0 8px;display:flex;gap:12px;align-items:center}
.dm-prose h2::before{content:"";width:9px;height:9px;background:var(--c-accent);transform:rotate(45deg);flex:none}
.dm-prose p{margin-top:8px}
.dm-toc{position:sticky;top:110px;background:color-mix(in srgb,var(--c-text) 6%,#fff);border-top:3px solid var(--c-accent);padding:20px 22px}
.dm-toc h3{font-size:16px;margin-bottom:8px;color:var(--c-text)}.dm-toc li{list-style:none;padding:8px 0;border-bottom:1px solid color-mix(in srgb,var(--c-text) 12%,transparent);font-size:14px}
.dm-404{text-align:center;padding:clamp(60px,10vw,140px) 0;background:var(--c-primary);color:#e8ddd4}
.dm-404 .big{display:flex;justify-content:center;align-items:center;gap:clamp(8px,2vw,24px);font:800 clamp(90px,18vw,240px)/1 var(--f-head);color:#fff}
.dm-404 .big i{width:.6em;height:.6em;background:var(--c-accent);transform:rotate(45deg)}
.dm-404 h1{color:#fff}

.dm-foot{background:radial-gradient(600px 300px at 90% 0%,#3d0911 0%,rgba(61,9,17,0) 70%),var(--c-primary);color:#e1d6cd;position:relative;overflow:hidden;font-size:14px;border-top:6px solid var(--c-accent)}
.dm-foot .cols{position:relative;display:grid;grid-template-columns:1.5fr repeat(3,1fr);gap:34px;padding:56px 0 34px}
.dm-foot h4{font:700 13px var(--f-head);letter-spacing:.14em;text-transform:uppercase;color:#fff;margin-bottom:14px}
.dm-foot ul{list-style:none;display:grid;gap:10px}
.dm-foot a{color:inherit;text-decoration:none;opacity:.85}.dm-foot a:hover{opacity:1;color:#fff;text-decoration:underline}
.dm-foot .copy{position:relative;border-top:1px solid rgba(255,255,255,.14);padding:20px 0;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;opacity:.75;font-size:13px}
.dm-foot .copy span a{margin-left:18px}
@media(max-width:800px){.dm-foot .cols{grid-template-columns:1fr 1fr}}
@media(max-width:520px){.dm-foot .cols{grid-template-columns:1fr}}
</style>
<div class="dm-ann">Free delivery over RM 150 · Easy 14-day returns · <a href='#'>WhatsApp us</a></div><header class="dm-head"><div class="dm-in"><nav><a href="shop.php">Shop</a><a href="category.php">Rackets</a><a href="category.php">Shoes</a><a href="about.php">About</a><a href="contact.php">Contact</a></nav><a class="dm-logo" href="index.php"><span class="dia"></span>Rally</a><div class="r"><a href="shop.php">Search</a><a href="my-account.php">Account</a><a class="dm-cart" href="cart.php">Cart (0)</a></div><details class="dm-burger"><summary>Menu</summary><div><a href="shop.php">Shop</a><a href="category.php">Rackets</a><a href="category.php">Shoes</a><a href="about.php">About</a><a href="contact.php">Contact</a><a href="my-account.php">Account</a></div></details></div></header><div class="dm-rail"><div class="dm-in"><a href="shop.php">All</a><a href="category.php">Rackets <small>24</small></a><a href="category.php">Shoes <small>18</small></a><a href="category.php">Bags <small>12</small></a><a href="category.php">Apparel <small>36</small></a><a href="category.php">Grips & accessories <small>20</small></a><a class="hot" href="shop.php">Sale</a></div></div>
<style>.dm-qty button{min-width:44px;min-height:44px;border:0;background:transparent;color:inherit;font:inherit;cursor:pointer}.dm-in.dm-two>.dl-form-note,.dm-in.dm-two>.dl-feedback{grid-column:1/-1}</style>
<script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Local sample quantities. No orders or payment requests are transmitted. */
(function(){function start(){var key='dl-diamond-sample-quantities',quantities=[1,1];try{var saved=JSON.parse(localStorage.getItem(key));if(Array.isArray(saved)&&saved.length===2&&saved.every(function(n){return Number.isInteger(n)&&n>0&&n<=99}))quantities=saved}catch(e){}function money(n){return 'RM '+n.toFixed(2)}function update(){Array.from(document.querySelectorAll('.dm-table tbody tr')).filter(function(row){return row.querySelector('.dm-qty')}).forEach(function(row,i){if(i>1)return;var q=row.querySelector('.dm-qty b');if(q)q.textContent=quantities[i];var price=row.querySelector('td:last-child b');if(price)price.textContent=money([329,79][i]*quantities[i]);row.dataset.dmRow=i});var subtotal=329*quantities[0]+79*quantities[1];document.querySelectorAll('.dm-sum').forEach(function(summary){if(summary.parentElement.classList.contains('dm-sum'))return;var form=summary.closest('form'),list=summary.querySelector('dl'),total=summary.querySelector('.tot span:last-child,.tot dd');if(list&&form){list.innerHTML='<dt>'+quantities[0]+' × Court Pro Shoes</dt><dd>'+money(329*quantities[0])+'</dd><dt>'+quantities[1]+' × Match Tee</dt><dd>'+money(79*quantities[1])+'</dd><dt>Demo shipping</dt><dd>RM 8.00</dd>';if(total)total.textContent=money(subtotal+8);var button=form.querySelector('[type=submit]');if(button)button.textContent='Preview order · '+money(subtotal+8)}else if(list){var dd=list.querySelector('dd');if(dd)dd.textContent=money(subtotal);if(total)total.textContent=money(subtotal)}})}document.addEventListener('click',function(e){var button=e.target.closest('[data-dm-change]');if(!button)return;var row=button.closest('[data-dm-row]');if(!row)return;var i=Number(row.dataset.dmRow);quantities[i]=Math.max(1,Math.min(99,quantities[i]+Number(button.dataset.dmChange)));try{localStorage.setItem(key,JSON.stringify(quantities))}catch(e){}update()});update()}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start()})();
</script>
<main>
