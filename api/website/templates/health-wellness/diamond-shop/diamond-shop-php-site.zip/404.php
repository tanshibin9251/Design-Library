<?php $title = '404 error'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="dm-404"><div class="dm-in"><div class="big">4<i></i>4</div><h1 style="font-size:clamp(26px,3vw,40px);margin-top:10px">Out of bounds.</h1><p style="margin:12px auto 26px">That page is not on this court. Head back to the shop.</p><a class="dm-btn" href="shop.php">Back to shop</a></div></section></div>
<?php include 'includes/footer.php'; ?>
