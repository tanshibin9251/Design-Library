<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Mind Notes';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Mind Notes</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="mind-notes" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Mind Notes — calm psychology reading site, tokens only */
.mn-prog{position:fixed;left:0;top:0;height:3px;width:var(--p,0%);background:var(--c-accent);z-index:80;transition:width .1s}
.mn-head{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:0 clamp(18px,5vw,72px);min-height:84px;position:relative;z-index:30}
.mn-logo{font:600 24px var(--f-head);color:var(--c-primary);text-decoration:none;letter-spacing:.01em}
.mn-logo i{font-style:normal;color:var(--c-accent)}
.mn-nav{display:flex;gap:clamp(14px,2.4vw,34px);list-style:none;align-items:center}
.mn-nav a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;font:500 15px var(--f-body);color:var(--c-text);border-bottom:1px solid transparent}
.mn-nav a:hover{border-bottom-color:var(--c-accent);color:var(--c-primary)}
.mn-nav .more{position:relative}
.mn-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:16px;box-shadow:0 24px 50px -30px color-mix(in srgb,var(--c-primary) 50%,transparent);min-width:580px;z-index:60}
.mn-nav .more:hover .dd,.mn-nav .more:focus-within .dd{display:grid}
.mn-nav .dd h4{font:600 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:6px}
.mn-nav .dd a{display:block;min-height:0;padding:5px 0;border:0}
.mn-m{display:none;position:relative}
.mn-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:1px solid var(--c-border);border-radius:999px;padding:0 16px;font:500 13px var(--f-body)}
.mn-m summary::-webkit-details-marker{display:none}
.mn-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:16px;padding:8px 18px;display:grid;z-index:60;box-shadow:0 24px 50px -30px color-mix(in srgb,var(--c-primary) 50%,transparent)}
.mn-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:500 15px var(--f-body);min-height:44px}
@media(max-width:860px){.mn-nav{display:none}.mn-m{display:block}}

.mn-sec{padding:clamp(40px,6vw,96px) clamp(18px,5vw,72px)}
.mn-narrow{max-width:720px;margin:0 auto}
.mn-hero{display:grid;grid-template-columns:1.1fr .9fr;gap:clamp(24px,6vw,100px);align-items:center;padding:clamp(30px,6vw,90px) clamp(18px,5vw,72px)}
.mn-hero h1{font:500 clamp(38px,5.6vw,var(--h1))/1.15 var(--f-head);color:var(--c-primary);letter-spacing:-.01em}
.mn-hero h1 em{color:var(--c-accent);font-style:italic}
.mn-hero p{font:400 19px/1.85 var(--f-body);margin:20px 0 28px;max-width:44ch}
@media(max-width:860px){.mn-hero{grid-template-columns:1fr}}
.mn-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 28px;border-radius:999px;background:var(--c-primary);color:var(--on-primary);text-decoration:none;font:500 15px var(--f-body);border:1px solid var(--c-primary);cursor:pointer}
.mn-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.mn-btn.o{background:transparent;color:var(--c-primary)}.mn-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
/* breathing circle */
.mn-breath{position:relative;width:min(100%,380px);aspect-ratio:1;margin:0 auto;display:grid;place-items:center}
.mn-breath .o{position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--c-secondary) 55%,var(--c-surface)) 0,color-mix(in srgb,var(--c-secondary) 25%,var(--c-surface)) 60%,transparent 72%);animation:mnbreath 8s ease-in-out infinite}
.mn-breath .i{position:absolute;inset:26%;border-radius:50%;background:color-mix(in srgb,var(--c-primary) 14%,var(--c-surface));border:1px solid color-mix(in srgb,var(--c-primary) 30%,transparent);animation:mnbreath 8s ease-in-out infinite;animation-delay:-.2s}
.mn-breath b{position:relative;font:500 22px var(--f-head);color:var(--c-primary);letter-spacing:.04em}
@keyframes mnbreath{0%,100%{transform:scale(.72)}50%{transform:scale(1)}}
.mn-h{margin-bottom:28px}
.mn-h h2{font:500 clamp(26px,3.2vw,var(--h2))/1.2 var(--f-head);color:var(--c-primary)}
.mn-h p{font:400 17px/1.8 var(--f-body);color:var(--c-secondary);margin-top:6px;max-width:52ch}
.mn-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(14px,2vw,26px)}
@media(max-width:900px){.mn-grid{grid-template-columns:1fr 1fr}}@media(max-width:560px){.mn-grid{grid-template-columns:1fr}}
.mn-flip{perspective:900px;background:none;border:0;padding:0;cursor:pointer;text-align:left;min-height:240px;font:inherit;color:inherit}
.mn-flip .in{position:relative;width:100%;height:100%;min-height:240px;transition:transform .7s cubic-bezier(.2,.8,.2,1);transform-style:preserve-3d}
.mn-flip[aria-pressed=true] .in{transform:rotateY(180deg)}
.mn-flip .f,.mn-flip .b{position:absolute;inset:0;border-radius:22px;padding:26px;backface-visibility:hidden;-webkit-backface-visibility:hidden;display:grid;align-content:space-between;gap:12px}
.mn-flip .f{background:color-mix(in srgb,var(--c-surface) 40%,#fff);border:1px solid var(--c-border)}
.mn-flip .b{background:var(--c-primary);color:var(--on-primary);transform:rotateY(180deg)}
.mn-flip .f span,.mn-flip .b span{font:600 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary)}
.mn-flip .b span{color:var(--c-secondary)}
.mn-flip h3{font:500 26px/1.2 var(--f-head);color:var(--c-primary)}
.mn-flip .b p{font:400 16px/1.7 var(--f-body)}
.mn-flip .f p{font:400 15px/1.6 var(--f-body);color:var(--c-text);opacity:.8}
.mn-flip .hint{font:500 13px var(--f-body);color:var(--c-accent)}
.mn-list a{display:grid;grid-template-columns:auto 1fr auto;gap:20px;padding:26px 0;border-bottom:1px solid var(--c-border);text-decoration:none;align-items:baseline}
.mn-list a:first-child{border-top:1px solid var(--c-border)}
.mn-list .n{font:italic 400 18px var(--f-head);color:var(--c-accent)}
.mn-list h3{font:500 clamp(22px,2.6vw,30px)/1.25 var(--f-head);color:var(--c-primary)}
.mn-list p{font:400 16px/1.7 var(--f-body);color:var(--c-secondary);margin-top:4px}
.mn-list .m{font:500 13px var(--f-body);color:var(--c-secondary)}
.mn-list a:hover h3{color:var(--c-accent)}
@media(max-width:600px){.mn-list a{grid-template-columns:1fr}}
.mn-read{font:400 20px/1.95 var(--f-body)}
.mn-read p{margin-bottom:1.4em;max-width:none}
.mn-read h2{font:500 30px/1.3 var(--f-head);color:var(--c-primary);margin:1.6em 0 .6em}
.mn-read blockquote{border-left:3px solid var(--c-accent);padding:4px 0 4px 24px;margin:1.8em 0;font:italic 400 26px/1.5 var(--f-head);color:var(--c-primary)}
.mn-read .lede::first-letter{font:500 3.6em/.9 var(--f-head);float:left;margin:.08em .1em 0 0;color:var(--c-accent)}
.mn-meta{display:flex;gap:18px;flex-wrap:wrap;font:500 14px var(--f-body);color:var(--c-secondary);margin:14px 0 36px}
.mn-note{background:color-mix(in srgb,var(--c-secondary) 20%,var(--c-surface));border-radius:16px;padding:20px 24px;font:400 16px/1.8 var(--f-body)}
/* check-in */
.mn-q{border-bottom:1px solid var(--c-border);padding:22px 0}
.mn-q p{font:400 19px/1.6 var(--f-body);margin-bottom:12px;max-width:none}
.mn-q .sc{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
.mn-q label{display:grid;place-items:center;min-height:48px;border:1px solid var(--c-border);border-radius:12px;font:500 14px var(--f-body);cursor:pointer;text-align:center;padding:4px 6px}
.mn-q label{position:relative;overflow:hidden}.mn-q input{position:absolute;left:0;top:0;width:1px;height:1px;opacity:0;pointer-events:none;min-height:0;padding:0;border:0}
.mn-q input:checked+span{color:var(--on-primary)}
.mn-q label:has(input:checked){background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.mn-q label:has(input:focus-visible){outline:2px solid var(--c-accent);outline-offset:2px}
@media(max-width:560px){.mn-q .sc{grid-template-columns:1fr 1fr}}
.mn-res{margin-top:30px;border-radius:22px;padding:clamp(22px,3vw,40px);background:var(--c-primary);color:var(--on-primary);display:none}
.mn-res.on{display:block}
.mn-res h3{font:500 clamp(26px,3vw,36px) var(--f-head);color:var(--on-primary);margin-bottom:10px}
.mn-res p{font:400 17px/1.8 var(--f-body);max-width:56ch}
.mn-res .sc{font:500 54px var(--f-head);color:var(--c-secondary)}
.mn-pat{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:26px}
.mn-pat button{min-height:46px;padding:0 20px;border-radius:999px;border:1px solid var(--c-primary);background:transparent;font:500 15px var(--f-body);cursor:pointer;color:var(--c-primary)}
.mn-pat button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.mn-big{width:min(100%,460px);aspect-ratio:1;margin:0 auto;position:relative;display:grid;place-items:center}
.mn-big .o{position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--c-secondary) 60%,var(--c-surface)) 0,color-mix(in srgb,var(--c-secondary) 25%,var(--c-surface)) 62%,transparent 74%);transform:scale(.6);transition:transform var(--t,4s) ease-in-out}
.mn-big .o.in{transform:scale(1)}
.mn-big b{position:relative;font:500 clamp(24px,3vw,34px) var(--f-head);color:var(--c-primary);text-align:center}
.mn-big small{display:block;font:500 15px var(--f-body);color:var(--c-secondary);margin-top:6px}
.mn-bk{display:grid;grid-template-columns:repeat(2,1fr);gap:18px}
@media(max-width:700px){.mn-bk{grid-template-columns:1fr}}
.mn-bk div{border:1px solid var(--c-border);border-radius:18px;padding:24px;background:color-mix(in srgb,var(--c-surface) 40%,#fff)}
.mn-bk h3{font:500 22px/1.25 var(--f-head);color:var(--c-primary)}
.mn-bk span{font:500 13px var(--f-body);color:var(--c-secondary)}
.mn-bk p{font:400 15px/1.75 var(--f-body);margin-top:8px}
.mn-foot{border-top:1px solid var(--c-border);margin-top:clamp(40px,6vw,96px);padding:clamp(34px,4vw,60px) clamp(18px,5vw,72px) 24px}
.mn-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,6vw,90px)}
.mn-foot .big{font:500 28px var(--f-head);color:var(--c-primary)}
.mn-foot h4{font:600 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:8px}
.mn-foot ul{list-style:none}.mn-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:400 15px var(--f-body);min-height:32px}
.mn-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.mn-foot .copy{margin-top:26px;font:400 13px/1.7 var(--f-body);color:var(--c-secondary);max-width:70ch}
@media(max-width:800px){.mn-foot .top{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.mn-breath .o,.mn-breath .i{animation:none}.mn-flip .in,.mn-big .o{transition:none}}
</style><div class="mn-prog" id="mn-prog"></div><header class="mn-head"><a class="mn-logo" href="index.php">mind notes<i>.</i></a><ul class="mn-nav"><li><a href="concepts.php">Concepts</a></li><li><a href="checkin.php">Check-in</a></li><li><a href="breathe.php">Breathe</a></li><li><a href="books.php">Books</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Read</h4><a href="index.php">Home</a><a href="concepts.php">Concept cards</a><a href="article.php">Article: Why we keep doing what we regret</a></div><div><h4>Practise</h4><a href="checkin.php">Stress check-in</a><a href="breathe.php">Breathing space</a><a href="books.php">Reading list</a></div><div><h4>About</h4><a href="support.php">Getting support</a><a href="about.php">About</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a href="support.php">Support</a></li></ul><details class="mn-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="concepts.php">Concept cards</a><a href="article.php">Article: Why we keep doing what we regret</a><a href="checkin.php">Stress check-in</a><a href="breathe.php">Breathing space</a><a href="books.php">Reading list</a><a href="support.php">Getting support</a><a href="about.php">About</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header><script>(function(){var b=document.getElementById("mn-prog");if(!b)return;function u(){var h=document.documentElement,m=h.scrollHeight-h.clientHeight;b.style.setProperty("--p",(m>0?h.scrollTop/m*100:0)+"%")}addEventListener("scroll",u,{passive:true});u()})();</script><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
