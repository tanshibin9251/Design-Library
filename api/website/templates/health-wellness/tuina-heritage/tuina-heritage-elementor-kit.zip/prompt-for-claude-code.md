# Build "Tuina Heritage" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #a52a1d · Secondary #6d5a3a · Text #1d1814 · Accent #c9a04a · Surface #f6eedd · Border #ddd0b0

## 2. Global Fonts
Headings: Limelight · Body: Nunito Sans
H1 84px / H2 46px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Treatments (services) — html/services.html
- Body constitution check (constitution) — html/constitution.html
- Conditions we treat (conditions) — html/conditions.html
- Master practitioner (master) — html/master.html
- Fees (pricing) — html/pricing.html
- Book a consultation (book) — html/book.html
- Patient stories (stories) — html/stories.html
- Visit the clinic (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
