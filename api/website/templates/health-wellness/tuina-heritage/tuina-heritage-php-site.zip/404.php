<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="sec loose center404"><div class="wrap"><span class="eyebrow">Error 404</span><h1 style="font-size:clamp(80px,16vw,220px)">404</h1><h2>This meridian is blocked.</h2><div class="actions" style="justify-content:center;margin-top:24px"><a class="btn" href="index.php">Return to the clinic</a></div></div></section>
<?php include 'includes/footer.php'; ?>
