<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Tuina Heritage';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Tuina Heritage</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Tuina Heritage — art deco TCM, tokens only */
.th-bar{background:var(--c-text);color:var(--c-surface);font:500 12px var(--f-body);letter-spacing:.2em;text-transform:uppercase;display:flex;justify-content:space-between;padding:8px clamp(14px,4vw,60px);flex-wrap:wrap;gap:6px}
.th-bar b{color:var(--c-accent)}
.td-head{background:var(--c-surface);border-bottom:3px double var(--c-accent);position:sticky;top:0;z-index:40}
.td-head .in{max-width:var(--w);margin:auto;display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:12px 20px}
.td-head ul{display:flex;gap:26px;list-style:none;font:600 13px var(--f-body);letter-spacing:.14em;text-transform:uppercase}
.td-head ul.r{justify-content:flex-end}
.td-head ul a{text-decoration:none}.td-head ul a:hover{color:var(--c-primary)}
.td-logo{display:flex;align-items:center;gap:14px;text-decoration:none;padding:0 26px}
.td-seal{width:52px;height:52px;background:var(--c-primary);color:var(--c-surface);display:grid;place-items:center;font:400 26px var(--f-head);border:2px solid var(--c-accent);outline:2px solid var(--c-primary);outline-offset:2px;line-height:1}
.td-logo b{font:400 24px var(--f-head);letter-spacing:.14em;text-transform:uppercase;display:block;line-height:1}
.td-logo small{font:600 10px var(--f-body);letter-spacing:.34em;text-transform:uppercase;color:var(--c-primary)}
.td-head .more{position:relative}
.td-hero{position:relative;background:var(--c-primary);color:var(--on-primary);overflow:hidden}
.td-hero::before{content:"";position:absolute;inset:0;background:repeating-conic-gradient(from 0deg at 50% 120%,transparent 0 6deg,color-mix(in srgb,var(--c-accent) 14%,transparent) 6deg 7deg);opacity:.9}
.td-hero .in{position:relative;max-width:var(--w);margin:auto;padding:clamp(50px,7vw,110px) 20px;display:grid;grid-template-columns:1.2fr 1fr;gap:40px;align-items:center}
.td-hero h1{font-weight:400;font-size:clamp(44px,6.6vw,var(--h1));line-height:1.04;letter-spacing:.02em;color:var(--on-primary);text-transform:uppercase}
.td-hero h1 em{font-style:normal;color:var(--c-accent)}
.td-hero p{max-width:44ch;margin:22px 0 30px;font:400 18px/1.7 var(--f-body);opacity:.9}
.td-hanzi{position:absolute;right:-1%;top:50%;translate:0 -50%;font:400 clamp(180px,30vw,460px)/1 var(--f-head);color:color-mix(in srgb,var(--c-accent) 18%,transparent);writing-mode:vertical-rl;pointer-events:none;letter-spacing:.1em;user-select:none}
.td-gate{position:relative;aspect-ratio:3/4;max-width:420px;justify-self:center;width:100%}
.td-gate .ph{position:absolute;inset:0;border-radius:0;clip-path:polygon(0 18%,8% 8%,18% 0,82% 0,92% 8%,100% 18%,100% 100%,0 100%);border:0}
.td-gate::before{content:"";position:absolute;inset:-10px;border:2px solid var(--c-accent);clip-path:polygon(0 18%,8% 8%,18% 0,82% 0,92% 8%,100% 18%,100% 100%,0 100%);background:none;pointer-events:none;z-index:2;opacity:.7}
.td-btn{display:inline-block;background:var(--c-accent);color:var(--c-text);padding:1em 2em;font:700 13px var(--f-body);letter-spacing:.2em;text-transform:uppercase;text-decoration:none;border:2px solid var(--c-accent);position:relative}
.td-btn.o{background:none;color:inherit;border-color:currentColor}
.td-btn:hover{background:var(--c-surface);color:var(--c-primary);border-color:var(--c-surface)}
.td-sec{padding:var(--pad) 20px}.td-sec>.in{max-width:var(--w);margin:auto}
.td-ttl{text-align:center;margin-bottom:44px}
.td-ttl small{font:600 12px var(--f-body);letter-spacing:.4em;text-transform:uppercase;color:var(--c-primary)}
.td-ttl h2{font-weight:400;letter-spacing:.08em;text-transform:uppercase;margin-top:8px}
.td-ttl::after{content:"";display:block;width:140px;height:14px;margin:18px auto 0;background:linear-gradient(90deg,transparent,var(--c-accent) 20%,var(--c-accent) 80%,transparent) center/100% 1px no-repeat,linear-gradient(var(--c-accent),var(--c-accent)) center/10px 10px no-repeat;rotate:0deg;clip-path:none}
.td-card{border:1px solid var(--c-accent);outline:1px solid var(--c-accent);outline-offset:-7px;padding:34px 26px;text-align:center;background:var(--c-surface);position:relative}
.td-card .hz{font:400 54px/1 var(--f-head);color:var(--c-primary);margin-bottom:12px}
.td-card h3{font:400 22px var(--f-head);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px}
.td-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:22px}
.td-grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:22px}
.td-prof{display:grid;grid-template-columns:1fr 1.3fr;gap:50px;align-items:center;border:1px solid var(--c-accent);padding:30px;background:color-mix(in srgb,var(--c-accent) 8%,var(--c-surface))}
.td-prof .ph{aspect-ratio:3/4;border-radius:0}
.td-cred{display:grid;grid-template-columns:repeat(3,1fr);gap:0;margin:24px 0;border-block:1px solid var(--c-accent)}
.td-cred div{padding:18px 10px;text-align:center;border-right:1px solid var(--c-accent)}.td-cred div:last-child{border:0}
.td-cred b{display:block;font:400 38px/1 var(--f-head);color:var(--c-primary)}.td-cred span{font:600 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase}
.td-q{background:var(--c-text);color:var(--c-surface);padding:60px 20px;text-align:center}
.td-q blockquote{font:400 clamp(24px,3.2vw,38px)/1.4 var(--f-head);max-width:820px;margin:auto}
.td-q cite{display:block;margin-top:18px;font:600 12px var(--f-body);letter-spacing:.3em;text-transform:uppercase;color:var(--c-accent);font-style:normal}
.td-quiz{max-width:720px;margin:auto;border:1px solid var(--c-accent);outline:1px solid var(--c-accent);outline-offset:-8px;padding:40px;background:var(--c-surface)}
.td-quiz h3{font:400 24px var(--f-head);margin-bottom:20px}
.td-quiz label{display:flex;gap:12px;align-items:center;padding:12px 14px;border:1px solid var(--c-border);margin-bottom:8px;cursor:pointer;font:500 16px var(--f-body)}
.td-quiz label:has(input:checked){border-color:var(--c-primary);background:color-mix(in srgb,var(--c-primary) 8%,var(--c-surface))}
.td-quiz input{accent-color:var(--c-primary)}
.td-fee{width:100%;border-collapse:collapse;font:500 16px var(--f-body)}
.td-fee td{padding:16px 6px;border-bottom:1px solid var(--c-border)}.td-fee td:last-child{text-align:right;font:400 22px var(--f-head);color:var(--c-primary)}
.td-fee tr:first-child td{border-top:3px double var(--c-accent)}
.td-foot{background:var(--c-text);color:var(--c-surface)}
@media(max-width:900px){.td-head .in{grid-template-columns:1fr;justify-items:center;gap:8px}.td-head ul{display:none}.td-hero .in,.td-prof{grid-template-columns:1fr}.td-grid,.td-grid3{grid-template-columns:1fr 1fr}.td-hanzi{display:none}}
.td-head .more{position:relative}.td-head .dd{position:absolute;left:50%;translate:-50% 0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border:1px solid var(--c-accent);outline:1px solid var(--c-accent);outline-offset:-5px;}.td-head .more:hover .dd,.td-head .more:focus-within .dd{display:grid}.td-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.td-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.td-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3,h4{color:var(--c-text)}.td-hero h1,.td-hero h2,.td-hero h3{color:var(--on-primary)}.td-q h2,.td-q h3,.td-foot h4{color:inherit}/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.td-grid,.td-grid3{grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.td-card{padding:22px 12px;min-width:0}.td-card h3{font-size:16px;letter-spacing:.04em;overflow-wrap:anywhere}.td-card .hz{font-size:40px}.td-hero h1{font-size:clamp(34px,10.5vw,52px)}.td-ttl h2{font-size:clamp(24px,7.5vw,38px)}.th-bar{font-size:10.5px;letter-spacing:.1em}.td-prof{padding:18px}}</style><div class="th-bar"><span>Open Tue–Sun · 10am – 8pm</span><span><b>Registered TCM practitioner</b> · Reg. No. TCM-02931</span></div><header class="td-head"><div class="in"><ul><li><a href="services.php">Treatments</a></li><li><a href="conditions.php">Conditions</a></li><li><a href="constitution.php">Body check</a></li></ul><a class="td-logo" href="index.php"><span class="td-seal" aria-hidden="true">推</span><span><b>Wong Tuina</b><small>Chinese Medical Massage</small></span></a><ul class="r"><li><a href="master.php">The Master</a></li><li><a href="pricing.php">Fees</a></li><li class="more"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Clinic</h4><a href="index.php">Home</a><a href="services.php">Treatments</a><a href="constitution.php">Body constitution check</a><a href="conditions.php">Conditions we treat</a><a href="master.php">Master practitioner</a><a href="pricing.php">Fees</a></div><div><h4>Visit</h4><a href="book.php">Book a consultation</a><a href="stories.php">Patient stories</a><a href="contact.php">Visit the clinic</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="td-btn" style="padding:.6em 1.2em" href="book.php">Book</a></li></ul></div></header>
<main>
