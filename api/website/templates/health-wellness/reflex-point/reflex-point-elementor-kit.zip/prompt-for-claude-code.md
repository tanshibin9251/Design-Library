# Build "Reflex Point" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2f3d33 · Secondary #7d8a7e · Text #26302a · Accent #d94f30 · Surface #f7f5ef · Border #d8d6cb

## 2. Global Fonts
Headings: Shippori Mincho · Body: Zen Kaku Gothic New
H1 88px / H2 44px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 110px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Treatments (treatments) — html/treatments.html
- Reflex map (map) — html/map.html
- Course tickets (tickets) — html/tickets.html
- Practitioner (practitioner) — html/practitioner.html
- Reserve (reserve) — html/reserve.html
- Access & hours (access) — html/access.html
- Journal (notes) — html/notes.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
