# Build "Trailhead Outdoor" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2f4a3a · Secondary #8a6f4e · Text #25291f · Accent #d8742a · Surface #f1ede2 · Border #cfc7b3

## 2. Global Fonts
Headings: Bitter · Body: Source Sans 3
H1 84px / H2 46px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 92px vertical · Border radius 12px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Gear by activity (shop) — html/shop.html
- Product (product) — html/product.html
- Pack (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Trail guides (guides) — html/guides.html
- Single guide (guide) — html/guide.html
- Packing lists (packing) — html/packing.html
- Rent gear (rentals) — html/rentals.html
- Outfitter shops (stores) — html/stores.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
