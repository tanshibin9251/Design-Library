<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Trailhead Outdoor';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Trailhead Outdoor</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="trailhead-outdoor" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Trailhead Outdoor — tokens only */
.th-bar{background:var(--c-primary);color:var(--on-primary);font:600 12.5px var(--f-body);display:flex;gap:26px;justify-content:center;padding:8px 14px;flex-wrap:wrap;letter-spacing:.02em}
.th-bar b{color:var(--c-accent)}
.th-head{background:var(--c-surface);border-bottom:2px solid var(--c-text);position:sticky;top:0;z-index:40}
.th-head .in{max-width:var(--w);margin:auto;display:grid;grid-template-columns:auto 1fr auto;gap:26px;align-items:center;padding:14px 20px}
.th-logo{font:700 24px var(--f-head);text-decoration:none;display:flex;align-items:center;gap:10px;letter-spacing:-.01em}
.th-logo svg{width:34px;height:34px}
.th-act{display:flex;gap:6px;list-style:none;justify-content:center;font:700 14px var(--f-body)}
.th-act>li>a{display:flex;align-items:center;gap:7px;padding:.55em 1em;border-radius:99px;text-decoration:none}
.th-act>li>a i{width:.55em;height:.55em;border-radius:50%;background:var(--d)}
.th-act>li>a:hover{background:color-mix(in srgb,var(--c-primary) 12%,var(--c-surface))}
.th-pack{background:var(--c-accent);color:var(--c-text);border-radius:8px;padding:.6em 1.1em;font:700 14px var(--f-body);text-decoration:none}
.th-head .more{position:relative}
.th-hero{position:relative;min-height:min(86vh,720px);display:flex;align-items:flex-end;color:var(--on-primary);overflow:hidden}
.th-hero .ph{position:absolute;inset:0;border-radius:0;height:100%}
.th-hero::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,color-mix(in srgb,var(--c-primary) 92%,#000) 0,transparent 65%)}
.th-hero .in{position:relative;z-index:2;max-width:var(--w);margin:auto;width:100%;padding:0 20px 56px;display:grid;grid-template-columns:1.3fr 1fr;gap:30px;align-items:end}
.th-hero h1{font-weight:700;font-size:clamp(46px,7.4vw,var(--h1));line-height:.98;color:var(--on-primary);letter-spacing:-.02em}
.th-cond{background:color-mix(in srgb,var(--c-surface) 94%,transparent);color:var(--c-text);padding:18px 20px;border-radius:12px;font:500 14px var(--f-body)}
.th-cond h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;margin-bottom:8px;opacity:.6}
.th-cond li{list-style:none;display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px dashed var(--c-border)}
.th-cond li:last-child{border:0}
.th-cond .ok{color:var(--c-primary)}.th-cond .warn{color:var(--c-accent)}
.th-topo{position:relative;background-color:var(--c-surface);background-image:radial-gradient(ellipse at 20% 30%,transparent 0 22%,color-mix(in srgb,var(--c-border) 70%,transparent) 22.3% 22.8%,transparent 23% 31%,color-mix(in srgb,var(--c-border) 70%,transparent) 31.3% 31.8%,transparent 32% 40%,color-mix(in srgb,var(--c-border) 70%,transparent) 40.3% 40.8%,transparent 41%),radial-gradient(ellipse at 85% 70%,transparent 0 18%,color-mix(in srgb,var(--c-border) 70%,transparent) 18.3% 18.8%,transparent 19% 27%,color-mix(in srgb,var(--c-border) 70%,transparent) 27.3% 27.8%,transparent 28%)}
.th-acts{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.th-act-card{border-radius:16px;overflow:hidden;position:relative;aspect-ratio:3/4;display:flex;align-items:flex-end;color:var(--on-primary);text-decoration:none}
.th-act-card .ph{position:absolute;inset:0;border-radius:0;height:100%}
.th-act-card::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,rgba(0,0,0,.65),transparent 55%)}
.th-act-card div{position:relative;z-index:2;padding:18px}
.th-act-card h3{color:var(--on-primary);font-size:28px}
.th-act-card small{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;opacity:.85}
.th-prods{display:grid;grid-template-columns:repeat(4,1fr);gap:22px}
.th-p{text-decoration:none;display:flex;flex-direction:column;gap:8px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:14px;padding:12px;transition:translate .2s,box-shadow .2s}
.th-p:hover{translate:0 -4px;box-shadow:0 14px 28px -14px color-mix(in srgb,var(--c-text) 50%,transparent)}
.th-p .ph{aspect-ratio:1;border-radius:10px}
.th-p h3{font-size:19px}
.th-chips{display:flex;gap:6px;flex-wrap:wrap}
.th-chips span{font:600 11.5px var(--f-body);padding:.25em .65em;border-radius:6px;background:color-mix(in srgb,var(--c-primary) 10%,var(--c-surface));color:var(--c-primary)}
.th-p .row{display:flex;justify-content:space-between;align-items:center;font:700 17px var(--f-body)}
.th-diff{display:inline-flex;gap:3px;align-items:center;font:700 11px var(--f-body);letter-spacing:.08em;text-transform:uppercase}
.th-diff i{width:9px;height:9px;border-radius:50%;background:var(--c-border)}.th-diff i.on{background:var(--c-accent)}
.th-trip{display:grid;grid-template-columns:1fr 1.2fr;gap:0;border-radius:18px;overflow:hidden;background:var(--c-primary);color:var(--on-primary)}
.th-trip>div{padding:clamp(26px,4vw,54px)}
.th-trip h2{color:inherit}
.th-trip .sel{display:grid;gap:10px;margin:18px 0}
.th-trip select{background:color-mix(in srgb,var(--on-primary) 10%,transparent);color:inherit;border:1px solid color-mix(in srgb,var(--on-primary) 30%,transparent);padding:.8em;border-radius:8px;font:600 15px var(--f-body)}
.th-trip option{color:var(--c-text)}
.th-spec{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}
.th-spec div{border:1px solid var(--c-border);border-radius:10px;padding:12px;text-align:center;background:var(--c-surface)}
.th-spec b{display:block;font:700 22px var(--f-head);color:var(--c-primary)}.th-spec small{font:600 11px var(--f-body);letter-spacing:.1em;text-transform:uppercase;opacity:.65}
.th-foot{background:var(--c-primary);color:var(--on-primary)}
@media(max-width:900px){.th-head .in{grid-template-columns:1fr auto}.th-act{display:none}.th-hero .in,.th-trip{grid-template-columns:1fr}.th-acts,.th-prods{grid-template-columns:repeat(2,1fr)}.th-spec{grid-template-columns:repeat(2,1fr)}}
.th-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);border-radius:12px;box-shadow:0 24px 50px -18px rgba(0,0,0,.35);min-width:500px;z-index:50;text-align:left;font-family:var(--f-body)}.th-head .more:hover .dd,.th-head .more:focus-within .dd{display:grid}.th-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55}.th-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-decoration:none;border:0;background:none}.th-head .dd a:hover{color:var(--c-accent)}
/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.th-hero{min-height:560px}.th-hero h1{font-size:clamp(36px,10.5vw,54px)}.th-acts,.th-prods{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px}.th-p h3{font-size:16px}.th-diff{flex-wrap:wrap}.th-p{padding:8px}.th-bar{font-size:11.5px;gap:6px 16px}.th-trip>div{padding:24px}}</style><div class="th-bar"><span>Trail report: <b>Gunung Datuk — dry, 24°C</b></span><span>Free shipping over RM 250</span><span>Rent before you buy</span></div><header class="th-head"><div class="in"><a class="th-logo" href="index.php"><svg viewBox="0 0 40 40" aria-hidden="true"><path d="M2 34 L15 10 L22 22 L27 14 L38 34Z" fill="var(--c-primary)"/><path d="M15 10 L18.5 16.5 L14 15Z" fill="var(--c-surface)"/><circle cx="31" cy="9" r="4" fill="var(--c-accent)"/></svg>Ridgeline</a><ul class="th-act"><li><a href="shop.php"><i style="--d:var(--c-primary)"></i>Hike</a></li><li><a href="shop.php"><i style="--d:var(--c-accent)"></i>Camp</a></li><li><a href="shop.php"><i style="--d:var(--c-secondary)"></i>Climb</a></li><li><a href="shop.php"><i style="--d:var(--c-text)"></i>Paddle</a></li><li><a href="guides.php">Guides</a></li><li class="more"><a href="#" tabindex="0">All ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a></div><div><h4>Shop</h4><a href="shop.php">Gear by activity</a><a href="product.php">Product</a><a href="cart.php">Pack</a><a href="checkout.php">Checkout</a></div><div><h4>Explore</h4><a href="guides.php">Trail guides</a><a href="guide.php">Single guide</a><a href="packing.php">Packing lists</a><a href="rentals.php">Rent gear</a></div><div><h4>Support</h4><a href="stores.php">Outfitter shops</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="th-pack" href="cart.php">Pack (2)</a><details class="dl-mobile"><summary>Menu</summary><nav class="dl-mobile-links" aria-label="Template pages"><h4>Main</h4><a href="index.php">Home</a><h4>Shop</h4><a href="shop.php">Gear by activity</a><a href="product.php">Product</a><a href="cart.php">Pack</a><a href="checkout.php">Checkout</a><h4>Explore</h4><a href="guides.php">Trail guides</a><a href="guide.php">Single guide</a><a href="packing.php">Packing lists</a><a href="rentals.php">Rent gear</a><h4>Support</h4><a href="stores.php">Outfitter shops</a><a href="faq.php">FAQ</a><h4>Utility</h4><a href="privacy.php">Privacy policy</a></nav></details></div></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
