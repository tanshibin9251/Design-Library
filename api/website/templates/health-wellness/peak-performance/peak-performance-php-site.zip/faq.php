<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="pk-sec" style="padding-top:20px"><div class="wrap"><div class="faq"><details open><summary>Does it work with Strava?</summary><p>Yes, activities sync automatically.</p></details><details><summary>How long is delivery?</summary><p>2–4 working days within Malaysia.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
