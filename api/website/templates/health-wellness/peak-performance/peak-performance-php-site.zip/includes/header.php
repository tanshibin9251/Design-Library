<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Peak Performance';
$dark = true;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Peak Performance</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="peak-performance" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Peak Performance — tokens only */
.pk-head{position:fixed;inset:14px 14px auto;z-index:50;display:flex;justify-content:space-between;align-items:center;padding:12px 18px 12px 24px;border:1px solid var(--c-border);border-radius:18px;background:color-mix(in srgb,var(--c-surface) 72%,transparent);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);max-width:calc(var(--w) - 28px);margin:auto}
.pk-logo{font:700 18px var(--f-head);letter-spacing:.2em;text-decoration:none;text-transform:uppercase;display:flex;align-items:center;gap:10px}
.pk-logo i{width:12px;height:12px;border-radius:50%;background:var(--c-accent);box-shadow:0 0 14px var(--c-accent)}
.pk-head ul{display:flex;gap:28px;list-style:none;font:500 13px var(--f-body);letter-spacing:.04em}
.pk-head ul a{text-decoration:none;opacity:.78}.pk-head ul a:hover{opacity:1;color:var(--c-accent)}
.pk-head .more{position:relative}
.pk-btn{display:inline-flex;align-items:center;gap:10px;background:var(--c-accent);color:var(--on-accent);border:0;border-radius:99px;padding:.85em 1.6em;font:600 14px var(--f-body);text-decoration:none;letter-spacing:.02em}
.pk-btn.g{background:none;color:var(--c-text);box-shadow:inset 0 0 0 1px var(--c-border)}
.pk-btn:hover{filter:brightness(1.12)}
body{padding-top:0}
.pk-hero{min-height:100vh;position:relative;display:grid;place-items:center;text-align:center;overflow:hidden;padding:140px 20px 80px}
.pk-hero::before{content:"";position:absolute;width:min(900px,90vw);aspect-ratio:1;border-radius:50%;background:conic-gradient(from 200deg,var(--c-accent),transparent 30%,var(--c-secondary) 55%,transparent 80%,var(--c-accent));filter:blur(90px);opacity:.28;z-index:0;animation:pk-spin 22s linear infinite}
@keyframes pk-spin{to{rotate:360deg}}
.pk-hero .in{position:relative;z-index:2;max-width:980px}
.pk-hero small{font:500 12px var(--f-body);letter-spacing:.34em;text-transform:uppercase;color:var(--c-secondary)}
.pk-hero h1{font-weight:700;font-size:clamp(44px,8.6vw,var(--h1));line-height:1;letter-spacing:-.04em;margin:18px 0;background:linear-gradient(180deg,var(--c-text),color-mix(in srgb,var(--c-text) 45%,var(--c-surface)));-webkit-background-clip:text;background-clip:text;color:transparent}
.pk-hero p{max-width:50ch;margin:0 auto 30px;font:400 18px/1.6 var(--f-body);color:var(--c-secondary)}
.pk-device{margin:56px auto 0;width:min(520px,80vw);aspect-ratio:1;border-radius:50%;position:relative;display:grid;place-items:center;background:radial-gradient(circle at 30% 25%,color-mix(in srgb,var(--c-text) 18%,var(--c-surface)),var(--c-surface) 65%);border:1px solid var(--c-border);box-shadow:0 0 120px -20px color-mix(in srgb,var(--c-accent) 40%,transparent)}
.pk-device .ring{position:absolute;inset:8%;border-radius:50%;background:conic-gradient(var(--c-accent) calc(var(--v)*1%),var(--c-border) 0);-webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 14px),#000 calc(100% - 13px));mask:radial-gradient(farthest-side,transparent calc(100% - 14px),#000 calc(100% - 13px))}
.pk-device .ring.b{inset:18%;--v:62;background:conic-gradient(var(--c-secondary) calc(var(--v)*1%),var(--c-border) 0)}
.pk-device .ring.c{inset:28%;--v:41;background:conic-gradient(var(--c-text) calc(var(--v)*1%),var(--c-border) 0)}
.pk-device .num{text-align:center;position:relative;z-index:2}
.pk-device .num b{display:block;font:700 clamp(44px,9vw,84px)/1 var(--f-head);letter-spacing:-.04em}
.pk-device .num span{font:500 11px var(--f-body);letter-spacing:.3em;text-transform:uppercase;color:var(--c-secondary)}
.pk-kpis{display:grid;grid-template-columns:repeat(4,1fr);border-block:1px solid var(--c-border)}
.pk-kpis div{padding:34px 24px;border-right:1px solid var(--c-border)}.pk-kpis div:last-child{border:0}
.pk-kpis b{display:block;font:700 clamp(34px,4.4vw,60px)/1 var(--f-head);letter-spacing:-.04em;color:var(--c-accent)}
.pk-kpis span{font:500 12px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-secondary)}
.pk-bento{display:grid;grid-template-columns:repeat(6,1fr);gap:14px}
.pk-tile{border:1px solid var(--c-border);border-radius:24px;padding:28px;background:linear-gradient(160deg,color-mix(in srgb,var(--c-primary) 90%,var(--c-text)),var(--c-primary));position:relative;overflow:hidden;min-height:280px;display:flex;flex-direction:column;justify-content:flex-end}
.pk-tile.s2{grid-column:span 2}.pk-tile.s3{grid-column:span 3}.pk-tile.s4{grid-column:span 4}
.pk-tile h3{font:600 clamp(22px,2.4vw,32px)/1.1 var(--f-head);letter-spacing:-.03em;margin:8px 0}
.pk-tile small{font:500 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-accent)}
.pk-tile .ph{position:absolute;inset:0;border-radius:0;opacity:.35}
.pk-tile>*{position:relative}
.pk-bars{display:flex;gap:6px;align-items:flex-end;height:110px}.pk-bars i{flex:1;background:linear-gradient(0deg,var(--c-accent),transparent);border-radius:4px 4px 0 0;height:var(--h)}
.pk-prods{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.pk-p{border:1px solid var(--c-border);border-radius:24px;padding:20px;text-decoration:none;display:grid;gap:14px;background:linear-gradient(180deg,color-mix(in srgb,var(--c-primary) 94%,var(--c-text)),var(--c-surface));transition:border-color .25s,translate .25s}
.pk-p:hover{border-color:var(--c-accent);translate:0 -6px}
.pk-p .ph{aspect-ratio:1;border-radius:18px;opacity:.9}
.pk-p h3{font:600 22px var(--f-head);letter-spacing:-.02em}
.pk-p .sp{display:flex;gap:16px;font:500 12px var(--f-body);color:var(--c-secondary)}
.pk-p .sp b{color:var(--c-text);display:block;font-size:16px}
.pk-p .pr{display:flex;justify-content:space-between;align-items:center;font:600 18px var(--f-body)}
.pk-tabs{display:flex;gap:6px;border-bottom:1px solid var(--c-border);margin-bottom:24px}
.pk-tabs button{background:none;border:0;color:var(--c-secondary);padding:.9em 1.2em;font:600 14px var(--f-body);cursor:pointer;border-bottom:2px solid transparent}
.pk-tabs button[aria-selected=true]{color:var(--c-text);border-color:var(--c-accent)}
.pk-spec{display:grid;grid-template-columns:1fr 1fr;gap:0 40px;font:500 15px var(--f-body)}
.pk-spec div{display:flex;justify-content:space-between;padding:14px 0;border-bottom:1px solid var(--c-border)}.pk-spec span{color:var(--c-secondary)}
.pk-sec{padding:var(--pad) 0}
.pk-title{font-weight:700;font-size:clamp(30px,4.6vw,var(--h2));letter-spacing:-.04em;line-height:1.05;max-width:20ch;margin-bottom:34px}
.pk-title small{display:block;font:500 12px var(--f-body);letter-spacing:.3em;text-transform:uppercase;color:var(--c-accent);margin-bottom:12px}
.pk-pdp{display:grid;grid-template-columns:1.1fr 1fr;gap:50px;align-items:center;padding-top:130px}
@media(max-width:900px){.pk-head ul{display:none}.pk-kpis{grid-template-columns:1fr 1fr}.pk-bento,.pk-prods{grid-template-columns:1fr}.pk-tile.s2,.pk-tile.s3,.pk-tile.s4{grid-column:auto}.pk-pdp,.pk-spec{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.pk-hero::before{animation:none}.pk-p{transition:none}}
.pk-head .dd{position:absolute;right:0;top:calc(100% + 18px);display:none;grid-template-columns:repeat(2,minmax(150px,1fr));gap:18px 30px;padding:22px 26px;background:color-mix(in srgb,var(--c-surface) 92%,transparent);backdrop-filter:blur(18px);color:var(--c-text);border:1px solid var(--c-border);border-radius:18px;min-width:380px;z-index:50;font-family:var(--f-body)}.pk-head .more:hover .dd,.pk-head .more:focus-within .dd{display:grid}.pk-head .dd h4{font:500 11px var(--f-body);letter-spacing:.24em;text-transform:uppercase;color:var(--c-accent);margin:0 0 8px}.pk-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);opacity:.85}
h1,h2,h3,h4{color:var(--c-text)}.pk-title,.pk-hero h1{color:inherit}/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.pk-head{inset:8px 8px auto;padding:10px 12px 10px 16px;border-radius:14px}.pk-logo{font-size:15px}.pk-hero{padding:96px 16px 56px}.pk-kpis b{font-size:28px}.pk-kpis div{padding:22px 14px}.pk-tile{min-height:200px;padding:20px}.pk-device .num b{font-size:clamp(34px,13vw,56px)}}</style><header class="pk-head"><a class="pk-logo" href="index.php"><i></i>Apex Labs</a><ul><li><a href="products.php">Watches</a></li><li><a href="products.php">Shoes</a></li><li><a href="lab.php">The Lab</a></li><li><a href="app.php">App</a></li><li><a href="athletes.php">Athletes</a></li><li class="more"><a href="#" tabindex="0">More +</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="lab.php">The Lab</a><a href="athletes.php">Athletes</a><a href="app.php">The app</a></div><div><h4>Shop</h4><a href="products.php">Products</a><a href="product.php">Product</a><a href="compare.php">Compare</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Support</h4><a href="support.php">Support</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="pk-btn" href="cart.php">Cart · 1</a><details class="dl-mobile"><summary>Menu</summary><nav class="dl-mobile-links" aria-label="Template pages"><h4>Main</h4><a href="index.php">Home</a><a href="lab.php">The Lab</a><a href="athletes.php">Athletes</a><a href="app.php">The app</a><h4>Shop</h4><a href="products.php">Products</a><a href="product.php">Product</a><a href="compare.php">Compare</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><h4>Support</h4><a href="support.php">Support</a><a href="faq.php">FAQ</a><h4>Utility</h4><a href="privacy.php">Privacy policy</a></nav></details></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>(function(){function start(){document.querySelectorAll('.pk-tabs').forEach(function(list){var tabs=Array.from(list.querySelectorAll('[role=tab]')),panels=list.parentElement.querySelectorAll('[data-pk-panel]');function select(index){tabs.forEach(function(tab,i){tab.type='button';tab.setAttribute('aria-selected',i===index);tab.tabIndex=i===index?0:-1;tab.id='pk-tab-'+i;tab.setAttribute('aria-controls','pk-panel-'+i)});panels.forEach(function(panel,i){panel.id='pk-panel-'+i;panel.setAttribute('aria-labelledby','pk-tab-'+i);panel.hidden=i!==index})}tabs.forEach(function(tab,i){tab.addEventListener('click',function(){select(i)});tab.addEventListener('keydown',function(e){if(['ArrowLeft','ArrowRight','Home','End'].indexOf(e.key)<0)return;e.preventDefault();var n=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:tabs.length-1))%tabs.length;select(n);tabs[n].focus()})});select(0)})}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start()})();
</script>
<main>
