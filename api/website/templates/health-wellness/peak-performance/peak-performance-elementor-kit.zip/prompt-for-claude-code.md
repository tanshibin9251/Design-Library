# Build "Peak Performance" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #10141c · Secondary #8d9bb3 · Text #eef2f8 · Accent #ff3b5c · Surface #07090d · Border #232a38

## 2. Global Fonts
Headings: Unbounded · Body: Sora
H1 92px / H2 56px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 104px vertical · Border radius 18px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Products (products) — html/products.html
- Product (product) — html/product.html
- Compare (compare) — html/compare.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- The Lab (lab) — html/lab.html
- Athletes (athletes) — html/athletes.html
- The app (app) — html/app.html
- Support (support) — html/support.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
