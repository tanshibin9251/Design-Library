<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Thai Touch';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Thai Touch</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="thai-touch" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Thai Touch — warm hand-drawn, tokens only */
.tt-top{background:var(--c-primary);color:var(--on-primary);text-align:center;font:500 13px var(--f-body);padding:8px;letter-spacing:.04em}
.tt-head{background:var(--c-surface);position:relative;z-index:40}
.tt-head .in{max-width:var(--w);margin:auto;display:flex;flex-direction:column;align-items:center;padding:20px 20px 0}
.tt-logo{font:400 38px/1 var(--f-head);text-decoration:none;color:var(--c-primary);text-align:center}
.tt-logo small{display:block;font:600 11px var(--f-body);letter-spacing:.42em;text-transform:uppercase;color:var(--c-accent);margin-top:6px}
.tt-orn{width:230px;height:18px;margin:10px auto 0;color:var(--c-accent)}
.tt-head ul{display:flex;gap:34px;list-style:none;justify-content:center;font:700 15px var(--f-body);padding:12px 0 16px;flex-wrap:wrap}
.tt-head ul a{text-decoration:none;position:relative}.tt-head ul a:hover{color:var(--c-accent)}
.tt-head ul a::after{content:"";position:absolute;left:0;right:0;bottom:-4px;height:5px;background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 6'%3E%3Cpath d='M0 3 Q5 0 10 3 T20 3 T30 3 T40 3' fill='none' stroke='%23b8860b' stroke-width='1.6'/%3E%3C/svg%3E") center/20px 5px repeat-x;opacity:0}
.tt-head ul a:hover::after{opacity:1}
.tt-btn{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:.9em 1.9em;border-radius:99px;font:700 15px var(--f-body);text-decoration:none;border:2px solid var(--c-accent);position:relative}
.tt-btn::after{content:"";position:absolute;inset:-6px;border:1.5px dashed var(--c-accent);border-radius:99px;opacity:.55}
.tt-btn.o{background:none;color:var(--c-primary);border-color:var(--c-primary)}.tt-btn.o::after{border-color:var(--c-primary)}
.tt-hero{display:grid;grid-template-columns:1fr 1fr;align-items:center;gap:0;max-width:var(--w);margin:auto;padding:clamp(20px,4vw,50px) 20px 0}
.tt-hero h1{font-size:clamp(46px,7vw,var(--h1));line-height:1;font-weight:400;color:var(--c-primary)}
.tt-hero h1 em{font-style:normal;color:var(--c-accent);position:relative;white-space:nowrap}
.tt-hero h1 em::after{content:"";position:absolute;left:0;right:0;bottom:-.18em;height:.3em;background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 14' preserveAspectRatio='none'%3E%3Cpath d='M2 9 C40 2 80 12 120 6 S180 3 198 8' fill='none' stroke='%23b8860b' stroke-width='3' stroke-linecap='round'/%3E%3C/svg%3E") center/100% 100% no-repeat}
.tt-hero p{max-width:40ch;margin:24px 0 30px;font:500 19px/1.6 var(--f-body)}
.tt-arch{position:relative;justify-self:center;width:min(100%,460px);aspect-ratio:3/4}
.tt-arch .ph{position:absolute;inset:0;border-radius:230px 230px 20px 20px;border:2px solid var(--c-primary)}
.tt-arch::before{content:"";position:absolute;inset:-14px;border:1.5px dashed var(--c-accent);border-radius:244px 244px 28px 28px}
.tt-arch .lotus{position:absolute;left:50%;bottom:-26px;translate:-50% 0;width:96px;height:56px;background:var(--c-surface);padding:0 10px;color:var(--c-accent)}
.tt-sec{padding:var(--pad) 20px}.tt-sec>.in{max-width:var(--w);margin:auto}
.tt-title{text-align:center;margin-bottom:46px}.tt-title h2{font-weight:400;color:var(--c-primary)}.tt-title p{max-width:50ch;margin:10px auto 0;opacity:.8}
.tt-title .tt-orn{margin-bottom:8px}
.tt-menu{max-width:860px;margin:auto}
.tt-item{display:grid;grid-template-columns:auto 1fr auto;align-items:baseline;gap:12px;padding:20px 0;border-bottom:1.5px dashed color-mix(in srgb,var(--c-primary) 30%,transparent);text-decoration:none}
.tt-item h3{font:400 28px var(--f-head);color:var(--c-primary)}
.tt-item .dots{border-bottom:2px dotted color-mix(in srgb,var(--c-text) 40%,transparent);transform:translateY(-6px);min-width:40px}
.tt-item .pr{font:700 20px var(--f-head);color:var(--c-accent);white-space:nowrap}
.tt-item p{grid-column:1/-1;font:500 15px var(--f-body);opacity:.78;margin-top:-4px;max-width:60ch}
.tt-item small{font:700 12px var(--f-body);letter-spacing:.12em;text-transform:uppercase;color:var(--c-secondary)}
.tt-item:hover h3{color:var(--c-accent)}
.tt-cat{font:700 13px var(--f-body);letter-spacing:.3em;text-transform:uppercase;color:var(--c-accent);margin:36px 0 4px;text-align:center}
.tt-th{display:grid;grid-template-columns:repeat(4,1fr);gap:24px}
.tt-th figure{margin:0;text-align:center}
.tt-th .ph{aspect-ratio:3/4;border-radius:120px 120px 14px 14px;border:2px solid var(--c-primary);margin-bottom:14px}
.tt-th h3{font:400 24px var(--f-head);color:var(--c-primary)}.tt-th small{font:600 13px var(--f-body);opacity:.7;display:block;margin-top:3px}
.tt-quote{background:var(--c-primary);color:var(--on-primary);text-align:center;padding:70px 20px;position:relative}
.tt-quote blockquote{font:400 clamp(24px,3.2vw,40px)/1.35 var(--f-head);max-width:800px;margin:auto}
.tt-quote cite{display:block;margin-top:18px;font:600 13px var(--f-body);letter-spacing:.2em;text-transform:uppercase;color:var(--c-accent);font-style:normal}
.tt-pk{display:grid;grid-template-columns:repeat(3,1fr);gap:26px}
.tt-pkc{border:2px solid var(--c-primary);border-radius:200px 200px 20px 20px;padding:70px 28px 30px;text-align:center;background:var(--c-surface);position:relative}
.tt-pkc h3{font:400 30px var(--f-head);color:var(--c-primary)}.tt-pkc .pr{font:700 30px var(--f-head);color:var(--c-accent);margin:10px 0}
.tt-pkc p{margin-bottom:22px}
.tt-form{max-width:640px;margin:auto;border:2px solid var(--c-primary);border-radius:22px;padding:34px;background:var(--c-surface)}
.tt-foot{background:var(--c-secondary);color:var(--on-secondary,#fff)}
@media(max-width:900px){.tt-hero{grid-template-columns:1fr;text-align:center}.tt-hero p{margin-inline:auto}.tt-th{grid-template-columns:1fr 1fr}.tt-pk{grid-template-columns:1fr}.tt-head ul{gap:16px}}
.tt-head .more{position:relative}.tt-head .dd{position:absolute;left:50%;translate:-50% 0;top:100%;display:none;grid-template-columns:repeat(3,minmax(130px,1fr));gap:20px 30px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:1px solid var(--c-border);min-width:500px;z-index:60;text-align:left;font-family:var(--f-body);text-transform:none;letter-spacing:0;font-style:normal;border-radius:20px;border:2px solid var(--c-primary);}.tt-head .more:hover .dd,.tt-head .more:focus-within .dd{display:grid}.tt-head .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;margin:0 0 8px;opacity:.55;color:inherit}.tt-head .dd a{display:block;padding:4px 0;font:500 14px var(--f-body);text-transform:none;letter-spacing:0;border:0;height:auto;opacity:.85;color:inherit;text-decoration:none;background:none;transform:none}.tt-head .dd a:hover{color:var(--c-accent);opacity:1}
h1,h2,h3,h4{color:var(--c-primary)}/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.tt-item{grid-template-columns:1fr auto;gap:4px 12px}.tt-item .dots{display:none}.tt-item h3{font-size:22px}.tt-item .pr{white-space:normal;text-align:right;font-size:16px;max-width:9em}.tt-hero h1{font-size:clamp(40px,12vw,60px)}.tt-th{grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.tt-th .ph{border-radius:70px 70px 12px 12px}.tt-arch::before{inset:-8px}.tt-btn::after{inset:-4px}}</style><div class="tt-top">First visit? Enjoy a complimentary herbal tea ritual and 15-minute foot soak.</div><header class="tt-head"><div class="in"><a class="tt-logo" href="index.php">Baan Sabai<small>Thai Massage &amp; Spa</small></a><svg class="tt-orn" viewBox="0 0 230 18" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M2 9h84M144 9h84"/><path d="M115 2c-6 4-6 10 0 14 6-4 6-10 0-14zM103 6c-6 0-9 4-7 8 5 0 8-3 7-8zM127 6c6 0 9 4 7 8-5 0-8-3-7-8z"/></svg><ul><li><a href="menu.php">Treatments</a></li><li><a href="therapists.php">Therapists</a></li><li><a href="packages.php">Packages</a></li><li><a href="vouchers.php">Vouchers</a></li><li><a href="story.php">Our story</a></li><li class="more"><a href="#" tabindex="0">More ▾</a><div class="dd"><div><h4>Spa</h4><a href="index.php">Home</a><a href="menu.php">Treatment menu</a><a href="treatment.php">Treatment</a><a href="therapists.php">Our therapists</a><a href="packages.php">Couple & group packages</a><a href="vouchers.php">Gift vouchers</a></div><div><h4>Visit</h4><a href="book.php">Book a treatment</a><a href="story.php">Our story</a><a href="find.php">Find us</a><a href="faq.php">Before you come</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="tt-btn" style="padding:.5em 1.3em" href="book.php">Book now</a></li></ul><details class="dl-mobile"><summary>Menu</summary><nav class="dl-mobile-links" aria-label="Template pages"><h4>Spa</h4><a href="index.php">Home</a><a href="menu.php">Treatment menu</a><a href="treatment.php">Treatment</a><a href="therapists.php">Our therapists</a><a href="packages.php">Couple &amp; group packages</a><a href="vouchers.php">Gift vouchers</a><h4>Visit</h4><a href="book.php">Book a treatment</a><a href="story.php">Our story</a><a href="find.php">Find us</a><a href="faq.php">Before you come</a><h4>Utility</h4><a href="privacy.php">Privacy policy</a></nav></details></div></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
