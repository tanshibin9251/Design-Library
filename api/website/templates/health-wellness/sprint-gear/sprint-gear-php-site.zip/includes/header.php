<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Sprint Gear';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Sprint Gear</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="sprint-gear" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Sprint Gear — tokens only */
.sg-tick{background:var(--c-accent);color:var(--c-primary);overflow:hidden;border-bottom:3px solid var(--c-primary)}
.sg-tick div{display:flex;gap:36px;width:max-content;white-space:nowrap;padding:7px 0;font:400 15px var(--f-head);letter-spacing:.12em;text-transform:uppercase;animation:sg-t 26s linear infinite}
@keyframes sg-t{to{transform:translateX(-50%)}}
.sg-head{background:var(--c-surface);border-bottom:3px solid var(--c-primary);position:sticky;top:0;z-index:40}
.sg-head .in{max-width:var(--w);margin:auto;display:flex;align-items:center;gap:26px;padding:10px 20px}
.sg-logo{font:400 38px/1 var(--f-head);text-transform:uppercase;text-decoration:none;font-style:italic;transform:skew(-8deg);display:inline-block;background:var(--c-primary);color:var(--c-accent);padding:.05em .4em}
.sg-head ul{display:flex;gap:6px;list-style:none;margin-left:auto;font:700 14px var(--f-body);text-transform:uppercase;letter-spacing:.04em}
.sg-head ul>li>a{display:block;padding:.55em 1em;text-decoration:none;border:3px solid transparent;transform:skew(-8deg)}
.sg-head ul>li>a:hover{border-color:var(--c-primary);background:var(--c-accent)}
.sg-cart{background:var(--c-secondary);color:var(--c-surface);padding:.55em 1.1em;font:700 14px var(--f-body);text-transform:uppercase;text-decoration:none;border:3px solid var(--c-primary);box-shadow:4px 4px 0 var(--c-primary);transform:skew(-8deg)}
.sg-head .more{position:relative}
.sg-hero{position:relative;background:var(--c-accent);border-bottom:3px solid var(--c-primary);overflow:hidden}
.sg-hero .in{max-width:var(--w);margin:auto;padding:clamp(30px,5vw,70px) 20px;display:grid;grid-template-columns:1.25fr 1fr;gap:30px;align-items:center;position:relative;z-index:2}
.sg-hero h1{font:400 clamp(72px,14vw,210px)/.82 var(--f-head);text-transform:uppercase;letter-spacing:-.01em;font-style:italic}
.sg-hero h1 span{display:block;-webkit-text-stroke:3px var(--c-primary);color:transparent}
.sg-hero p{max-width:34ch;font:600 20px/1.35 var(--f-body);margin:22px 0}
.sg-cutout{position:relative;aspect-ratio:1;display:grid;place-items:center}
.sg-cutout .ph{position:absolute;inset:6%;border-radius:0;border:3px solid var(--c-primary);box-shadow:12px 12px 0 var(--c-primary);rotate:-6deg}
.sg-sticker{position:absolute;right:0;top:0;z-index:3;width:130px;height:130px;background:var(--c-secondary);color:var(--c-surface);clip-path:polygon(50% 0,61% 12%,76% 6%,80% 22%,95% 25%,89% 40%,100% 50%,89% 60%,95% 75%,80% 78%,76% 94%,61% 88%,50% 100%,39% 88%,24% 94%,20% 78%,5% 75%,11% 60%,0 50%,11% 40%,5% 25%,20% 22%,24% 6%,39% 12%);display:grid;place-items:center;text-align:center;font:400 22px/1 var(--f-head);text-transform:uppercase;rotate:12deg}
.sg-btn{display:inline-block;background:var(--c-primary);color:var(--c-accent);border:3px solid var(--c-primary);padding:.85em 1.7em;font:700 15px var(--f-body);text-transform:uppercase;letter-spacing:.05em;text-decoration:none;box-shadow:6px 6px 0 var(--c-secondary);transition:translate .12s,box-shadow .12s}
.sg-btn:hover{translate:3px 3px;box-shadow:3px 3px 0 var(--c-secondary)}
.sg-btn.w{background:var(--c-surface);color:var(--c-primary);box-shadow:6px 6px 0 var(--c-primary)}
.sg-rail{display:grid;grid-template-columns:70px 1fr;border-bottom:3px solid var(--c-primary)}
.sg-rail aside{border-right:3px solid var(--c-primary);background:var(--c-primary);color:var(--c-accent);display:grid;place-items:center}
.sg-rail aside span{writing-mode:vertical-rl;rotate:180deg;font:400 34px var(--f-head);letter-spacing:.14em;text-transform:uppercase;padding:20px 0}
.sg-scroll{display:flex;gap:0;overflow-x:auto;scroll-snap-type:x mandatory}
.sg-card{flex:0 0 min(340px,80vw);scroll-snap-align:start;border-right:3px solid var(--c-primary);text-decoration:none;position:relative;background:var(--c-surface);display:block}
.sg-card .ph{border-radius:0;aspect-ratio:1/1.1;border-bottom:3px solid var(--c-primary)}
.sg-card .m{padding:14px 16px 18px}
.sg-card h3{font:400 30px/1 var(--f-head);text-transform:uppercase}
.sg-card .pr{position:absolute;right:12px;top:12px;background:var(--c-primary);color:var(--c-accent);padding:.3em .7em;font:400 24px var(--f-head);rotate:4deg}
.sg-card .tag{display:inline-block;background:var(--c-secondary);color:var(--c-surface);padding:.1em .6em;font:700 11px var(--f-body);letter-spacing:.1em;text-transform:uppercase;margin-bottom:6px}
.sg-grid{display:grid;grid-template-columns:repeat(4,1fr);border:3px solid var(--c-primary)}
.sg-grid .sg-card{border-right:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}
.sg-grid .sg-card:nth-child(4n){border-right:0}
.sg-count{display:grid;grid-template-columns:repeat(4,auto);gap:10px;justify-content:start;margin:14px 0}
.sg-count div{background:var(--c-primary);color:var(--c-accent);padding:.3em .6em;text-align:center;min-width:76px}
.sg-count b{display:block;font:400 44px/1 var(--f-head)}.sg-count small{font:700 10px var(--f-body);letter-spacing:.14em;text-transform:uppercase}
.sg-big{font:400 clamp(60px,10vw,150px)/.85 var(--f-head);text-transform:uppercase;-webkit-text-stroke:2px var(--c-primary);color:transparent;font-style:italic}
.sg-sizes{display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin:10px 0 20px}
.sg-sizes button{border:3px solid var(--c-primary);background:var(--c-surface);color:var(--c-primary);padding:.8em 0;font:400 20px var(--f-head);cursor:pointer}
.sg-sizes button[aria-pressed=true]{background:var(--c-primary);color:var(--c-accent)}
.sg-sizes button:disabled{opacity:.35;text-decoration:line-through;cursor:not-allowed}
.sg-buy{position:sticky;top:90px;border:3px solid var(--c-primary);padding:24px;background:var(--c-surface);box-shadow:10px 10px 0 var(--c-primary)}
.sg-pdp{display:grid;grid-template-columns:1.3fr 1fr;gap:40px;align-items:start}
.sg-foot{background:var(--c-primary);color:var(--c-surface)}
.sg-foot .big{font:400 clamp(70px,16vw,260px)/.8 var(--f-head);text-transform:uppercase;font-style:italic;color:var(--c-accent);padding:30px 0 0}
@media(max-width:900px){.sg-hero .in,.sg-pdp{grid-template-columns:1fr}.sg-head ul{display:none}.sg-grid{grid-template-columns:repeat(2,1fr)}.sg-grid .sg-card:nth-child(2n){border-right:0}.sg-rail{grid-template-columns:44px 1fr}.sg-rail aside span{font-size:22px}.sg-buy{position:static}}
@media(prefers-reduced-motion:reduce){.sg-tick div{animation:none}.sg-btn{transition:none}}
.sg-head .more{position:relative}.sg-head .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(2,minmax(150px,1fr));gap:20px 34px;padding:22px 26px;background:var(--c-surface);color:var(--c-primary);border:3px solid var(--c-primary);box-shadow:8px 8px 0 var(--c-primary);min-width:380px;z-index:50;text-align:left;font-family:var(--f-body)}.sg-head .more:hover .dd,.sg-head .more:focus-within .dd{display:grid}.sg-head .dd h4{font:400 20px var(--f-head);letter-spacing:.06em;text-transform:uppercase;margin:0 0 6px}.sg-head .dd a{display:block;padding:3px 0;font:600 14px var(--f-body);text-transform:none;border:0;transform:none;letter-spacing:0;text-decoration:none;color:inherit}.sg-head .dd a:hover{background:var(--c-accent);border:0}
/* m-fix */html,body{overflow-x:clip}img,video,svg{max-width:100%}@media(max-width:700px){.sg-rail>div{min-width:0}.sg-hero h1{font-size:clamp(54px,17vw,96px)}.sg-hero h1 span{-webkit-text-stroke-width:2px}.sg-sticker{width:96px;height:96px;font-size:16px}.sg-cutout .ph{box-shadow:7px 7px 0 var(--c-primary)}.sg-buy{box-shadow:6px 6px 0 var(--c-primary)}.sg-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.sg-card h3{font-size:22px}.sg-card .pr{font-size:18px}.sg-count div{min-width:60px}.sg-big{font-size:clamp(44px,14vw,80px)}}</style><div class="sg-tick" aria-hidden="true"><div><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span><span>Free shipping over RM 199</span><span>★</span><span>Next drop: Friday 8pm</span><span>★</span><span>30-day run-in guarantee</span><span>★</span></div></div><header class="sg-head"><div class="in"><a class="sg-logo" href="index.php">Sprint</a><ul><li><a href="shop.php">Run</a></li><li><a href="shop.php">Train</a></li><li><a href="shop.php">Court</a></li><li><a href="drops.php">Drops</a></li><li><a href="athletes.php">Squad</a></li><li class="more"><a href="#" tabindex="0">All ▾</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="drops.php">Drops</a><a href="athletes.php">Squad</a></div><div><h4>Shop</h4><a href="shop.php">Shop all</a><a href="product.php">Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Support</h4><a href="size-guide.php">Size & fit</a><a href="stores.php">Stores</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li></ul><a class="sg-cart" href="cart.php">Cart 2</a><details class="dl-mobile"><summary>Menu</summary><nav class="dl-mobile-links" aria-label="Template pages"><h4>Main</h4><a href="index.php">Home</a><a href="drops.php">Drops</a><a href="athletes.php">Squad</a><h4>Shop</h4><a href="shop.php">Shop all</a><a href="product.php">Product</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><h4>Support</h4><a href="size-guide.php">Size &amp; fit</a><a href="stores.php">Stores</a><a href="faq.php">FAQ</a><h4>Utility</h4><a href="privacy.php">Privacy policy</a></nav></details></div></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
