# Build "Calm Spa" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #115E59 · Secondary #134E4A · Text #1F2937 · Accent #0F766E · Surface #F0FDFA · Border #CCFBF1

## 2. Global Fonts
Headings: Crimson Pro · Body: Mulish
H1 64px / H2 42px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 96px vertical · Border radius 24px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Treatments (services) — html/services.html
- Single Treatment (service) — html/service.html
- Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Shop (shop) — html/shop.html
- Single Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Rituals (projects) — html/projects.html
- Single Ritual (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Booking (booking) — html/booking.html
- Gift cards (gift-cards) — html/gift-cards.html
- Rooms (rooms) — html/rooms.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
