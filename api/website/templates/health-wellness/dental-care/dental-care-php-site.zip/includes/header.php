<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Smile Dental';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Smile Dental</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="dental-care" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Smile Dental v2 — appointment-first clinic site, tokens only */
.dc-head{display:flex;align-items:center;gap:20px;padding:0 clamp(14px,4vw,56px);min-height:76px;background:var(--c-surface);position:sticky;top:0;z-index:50;border-bottom:1px solid var(--c-border)}
.dc-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--c-primary);font:600 24px var(--f-head);letter-spacing:-.01em}
.dc-logo i{display:grid;place-items:center;width:38px;height:38px;border-radius:50% 50% 50% 12px;background:var(--c-accent);color:var(--on-accent);font:600 18px var(--f-head);font-style:normal}
.dc-nav{display:flex;gap:2px;list-style:none;margin-left:auto;align-items:center}
.dc-nav a{display:inline-flex;align-items:center;min-height:46px;padding:0 14px;border-radius:999px;font:500 15px var(--f-body);color:var(--c-text);text-decoration:none}
.dc-nav a:hover{background:color-mix(in srgb,var(--c-secondary) 40%,transparent)}
.dc-nav .tel{font-weight:600;color:var(--c-primary)}
.dc-nav .more{position:relative}
.dc-nav .dd{position:absolute;right:0;top:calc(100% + 6px);display:none;grid-template-columns:repeat(3,minmax(140px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:20px;box-shadow:0 24px 50px -26px color-mix(in srgb,var(--c-primary) 45%,transparent);min-width:540px;z-index:60}
.dc-nav .more:hover .dd,.dc-nav .more:focus-within .dd{display:grid}
.dc-nav .dd h4{font:600 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.dc-nav .dd a{display:block;min-height:0;padding:5px 0;border-radius:0}.dc-nav .dd a:hover{background:none;color:var(--c-primary)}
.dc-m{display:none;margin-left:auto;position:relative}
.dc-m summary{list-style:none;cursor:pointer;min-height:46px;min-width:46px;display:grid;place-items:center;border:1px solid var(--c-primary);border-radius:999px;padding:0 16px;font:600 12px var(--f-body);letter-spacing:.1em}
.dc-m summary::-webkit-details-marker{display:none}
.dc-m nav{position:absolute;right:0;top:calc(100% + 6px);min-width:250px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:18px;padding:8px 18px;display:grid;z-index:60}
.dc-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:500 15px var(--f-body);min-height:46px}
@media(max-width:900px){.dc-nav{display:none}.dc-m{display:block}}
.dc-sec{padding:clamp(36px,5vw,76px) clamp(14px,4vw,56px)}
.dc-hero{padding:clamp(30px,5vw,70px) clamp(14px,4vw,56px) 0;max-width:1240px;margin:0 auto}
.dc-hero h1{font:600 clamp(36px,5.6vw,var(--h1))/1.08 var(--f-head);letter-spacing:-.025em;color:var(--c-primary);max-width:18ch}
.dc-hero h1 em{font-style:normal;color:var(--c-accent)}
.dc-hero p{font:400 19px/1.7 var(--f-body);margin:16px 0 0;max-width:46ch}
.dc-book{max-width:1240px;margin:clamp(22px,3vw,40px) auto 0;background:var(--c-primary);color:var(--on-primary);border-radius:26px;padding:clamp(18px,2.4vw,28px);display:grid;grid-template-columns:repeat(4,1fr) auto;gap:14px;align-items:end}
@media(max-width:960px){.dc-book{grid-template-columns:1fr 1fr}}@media(max-width:520px){.dc-book{grid-template-columns:1fr}}
.dc-book label{display:grid;gap:6px;font:600 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase}
.dc-book select,.dc-book input{min-height:52px;border-radius:14px;border:0;padding:0 14px;font:500 16px var(--f-body);background:var(--c-surface);color:var(--c-text);width:100%}
.dc-go{min-height:52px;padding:0 26px;border-radius:14px;border:0;background:var(--c-accent);color:var(--on-accent);font:700 16px var(--f-body);cursor:pointer;white-space:nowrap}
.dc-go:hover{filter:brightness(1.06)}
.dc-slots{max-width:1240px;margin:16px auto 0;display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.dc-slots b{font:600 14px var(--f-body);margin-right:6px;color:var(--c-secondary)}
.dc-slots button{min-height:44px;padding:0 16px;border-radius:999px;border:1.5px solid var(--c-primary);background:transparent;color:var(--c-primary);font:600 14px var(--f-body);cursor:pointer}
.dc-slots button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}
.dc-slots .msg{font:500 15px var(--f-body);color:var(--c-primary);margin-left:6px}
.dc-h{max-width:1240px;margin:0 auto 24px;display:flex;justify-content:space-between;align-items:baseline;gap:14px;flex-wrap:wrap}
.dc-h h2{font:600 clamp(26px,3.4vw,var(--h2)) var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.dc-ba{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:1.2fr 1fr;gap:clamp(20px,4vw,60px);align-items:center}
@media(max-width:860px){.dc-ba{grid-template-columns:1fr}}
.dc-cmp{position:relative;aspect-ratio:16/10;border-radius:26px;overflow:hidden;--p:50%;border:1px solid var(--c-border)}
.dc-cmp>div{position:absolute;inset:0;display:grid;place-items:end start;padding:16px}
.dc-cmp .a{background:radial-gradient(circle at 30% 50%,#d8c58a 0 8%,transparent 9%),radial-gradient(circle at 45% 50%,#cdb877 0 8%,transparent 9%),radial-gradient(circle at 60% 50%,#d6c284 0 8%,transparent 9%),color-mix(in srgb,var(--c-secondary) 40%,var(--c-surface))}
.dc-cmp .b{background:radial-gradient(circle at 30% 50%,#fff 0 8%,transparent 9%),radial-gradient(circle at 45% 50%,#fff 0 8%,transparent 9%),radial-gradient(circle at 60% 50%,#fff 0 8%,transparent 9%),color-mix(in srgb,var(--c-secondary) 40%,var(--c-surface));clip-path:inset(0 0 0 var(--p))}
.dc-cmp span{font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;background:var(--c-surface);padding:5px 12px;border-radius:99px}
.dc-cmp .b span{place-self:end end}
.dc-cmp i{position:absolute;top:0;bottom:0;left:var(--p);width:3px;background:var(--c-surface);pointer-events:none}
.dc-cmp i::after{content:"↔";position:absolute;left:50%;top:50%;width:46px;height:46px;border-radius:50%;background:var(--c-surface);color:var(--c-primary);display:grid;place-items:center;transform:translate(-50%,-50%);font:700 18px var(--f-body);box-shadow:0 6px 16px rgba(0,0,0,.25)}
.dc-cmp input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:ew-resize;margin:0;padding:0}
.dc-ba h2{font:600 clamp(26px,3.4vw,42px)/1.1 var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.dc-ba p{font:400 17px/1.8 var(--f-body);margin-top:12px}
.dc-est{max-width:1240px;margin:0 auto;background:color-mix(in srgb,var(--c-secondary) 28%,var(--c-surface));border-radius:30px;padding:clamp(22px,3vw,44px);display:grid;grid-template-columns:1fr 1fr;gap:clamp(20px,4vw,56px);align-items:center}
@media(max-width:860px){.dc-est{grid-template-columns:1fr}}
.dc-est h2{font:600 clamp(26px,3.4vw,42px)/1.1 var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.dc-opt{display:grid;gap:8px}
.dc-opt label{display:flex;justify-content:space-between;gap:14px;align-items:center;min-height:56px;padding:0 18px;border-radius:16px;background:var(--c-surface);font:500 16px var(--f-body);cursor:pointer}
.dc-opt input{width:22px;height:22px;accent-color:var(--c-primary);padding:0;min-height:0}
.dc-opt label span:first-child{display:flex;gap:12px;align-items:center}
.dc-tot{display:flex;justify-content:space-between;align-items:baseline;margin-top:10px;padding:14px 18px;border-radius:16px;background:var(--c-primary);color:var(--on-primary);font:600 16px var(--f-body)}
.dc-tot b{font:600 30px var(--f-head);letter-spacing:-.02em}
.dc-team{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
@media(max-width:800px){.dc-team{grid-template-columns:1fr}}
.dc-p{border-radius:26px;border:1px solid var(--c-border);padding:24px;display:grid;gap:6px;background:color-mix(in srgb,var(--c-surface) 40%,#fff)}
.dc-p i{width:64px;height:64px;border-radius:50%;background:color-mix(in srgb,var(--c-secondary) 55%,var(--c-surface));display:grid;place-items:center;font:600 22px var(--f-head);font-style:normal;color:var(--c-primary)}
.dc-p b{font:600 20px var(--f-head);color:var(--c-primary)}
.dc-p span{font:500 15px/1.6 var(--f-body)}
.dc-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);border-radius:40px 40px 0 0;padding:clamp(32px,5vw,60px) clamp(14px,4vw,56px) 22px}
.dc-foot .top{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.dc-foot .big{font:600 30px var(--f-head);letter-spacing:-.02em}
.dc-foot h4{font:600 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.dc-foot ul{list-style:none}.dc-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:400 15px var(--f-body);color:var(--on-primary);min-height:34px}
.dc-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.dc-foot .copy{max-width:1240px;margin:24px auto 0;font:400 12px var(--f-body);opacity:.75}
@media(max-width:860px){.dc-foot .top{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
.dc .pagehead{background:color-mix(in srgb,var(--c-secondary) 14%,var(--c-surface));border-left:10px solid var(--c-accent)}.dc .pagehead .wrap{padding-left:clamp(20px,3vw,40px)}.dc .card,.dc .scard,.dc .qcard,.dc .pcard,.dc .person{background:#fff;background:color-mix(in srgb,var(--c-surface) 30%,#fff);border:0;box-shadow:0 14px 34px -20px color-mix(in srgb,var(--c-primary) 55%,transparent)}.dc .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.dc .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.dc .svc{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:16px;-webkit-overflow-scrolling:touch}
.dc .scard{flex:0 0 min(320px,78vw);scroll-snap-align:start}
.dc .scard .ph{aspect-ratio:4/3!important}

.dc .tgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:30px 20px}
.dc .person{text-align:center;background:none;border:0;box-shadow:none;padding:0}
.dc .person .ph{aspect-ratio:1!important;border-radius:50%!important;margin:0 auto 12px;max-width:190px}

.dc .qgrid{display:block;columns:2 300px;column-gap:20px}.dc .qgrid.mt{margin-top:20px}
.dc .qcard{break-inside:avoid;margin-bottom:20px}

.dc .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.dc .masonry .mi{margin:0}.dc .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.dc .masonry{grid-template-columns:1fr 1fr}}

.dc .split.w2{display:block}
.dc .feat{display:grid;grid-template-columns:1.3fr 1fr;gap:clamp(18px,3vw,40px);align-items:center;margin-bottom:clamp(24px,4vw,48px)}
.dc .feat h2{font-size:clamp(26px,3.6vw,48px);line-height:1.04}
.dc .articles.two{grid-template-columns:repeat(3,1fr)!important}
@media(max-width:800px){.dc .feat{grid-template-columns:1fr}.dc .articles.two{grid-template-columns:1fr!important}}
.dc .faq{max-width:none;columns:2 340px;column-gap:clamp(24px,5vw,72px)}.dc .faq details{break-inside:avoid}

.dc .pricing{display:grid;grid-template-columns:1fr;max-width:760px;gap:14px}
.dc .pricing .card{transform:none!important}
.dc .split{display:block;max-width:760px;margin:0 auto}.dc .cinfo{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:34px}
.dc .ctaband{display:block;text-align:center}.dc .ctaband h2{max-width:22ch;margin:0 auto}.dc .ctaband .btn{margin-top:22px}
.dc .steps{display:block;border-left:3px solid var(--c-primary);padding-left:28px}.dc .steps>div{border:0;padding:0 0 26px;position:relative}.dc .steps>div::before{content:"";position:absolute;left:-38px;top:4px;width:14px;height:14px;background:var(--c-accent)}

.dc .tl{display:block;position:relative;max-width:760px;border-left:2px solid var(--c-primary);padding-left:30px}
.dc .tl>div{position:relative;padding:0 0 28px}.dc .tl>div::before{content:"";position:absolute;left:-39px;top:6px;width:16px;height:16px;border-radius:50%;background:var(--c-accent);border:3px solid var(--c-surface);box-shadow:0 0 0 2px var(--c-primary)}
.dc .tl b{font-size:clamp(24px,3vw,36px)}

.dc .vals{display:block;border-top:2px solid var(--c-primary);counter-reset:v}
.dc .vals .card{display:grid;grid-template-columns:56px 1fr 1.4fr;gap:6px 24px;align-items:baseline;padding:20px 0;border:0;border-bottom:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none}
.dc .vals .card .ico{background:none;width:auto;height:auto;font:700 14px var(--f-body);letter-spacing:.14em;color:var(--c-accent);margin:0;justify-content:start}
.dc .vals .card h3{margin:0}.dc .vals .card p{margin:0}
@media(max-width:700px){.dc .vals .card{grid-template-columns:36px 1fr}.dc .vals .card p{grid-column:2}}

.dc-tr{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;max-width:1240px;margin:0 auto}.dc-tr>div{border:1px solid var(--c-border);border-radius:24px;padding:24px;background:color-mix(in srgb,var(--c-surface) 40%,#fff);display:grid;gap:8px;align-content:start}
.dc-tr h3{font:600 22px var(--f-head);color:var(--c-primary)}.dc-tr .pr{font:600 18px var(--f-head);color:var(--c-accent)}.dc-tr p{font:400 16px/1.7 var(--f-body)}
@media(max-width:800px){.dc-tr{grid-template-columns:1fr}}</style><header class="dc-head"><a class="dc-logo" href="index.php"><i>S</i>Smile Dental</a><ul class="dc-nav"><li><a href="services.php">Treatments</a></li><li><a href="pricing.php">Prices</a></li><li><a href="team.php">Our dentists</a></li><li><a class="tel" href="contact.php">03 1234 5678</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Treatments</a><a href="service.php">Single Treatment</a><a href="pricing.php">Prices</a><a href="contact.php">Contact</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Smile Stories</a><a href="project.php">Single Smile story</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Dental Tips</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Book appointment</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><details class="dc-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Treatments</a><a href="service.php">Single Treatment</a><a href="pricing.php">Prices</a><a href="contact.php">Contact</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Smile Stories</a><a href="project.php">Single Smile story</a><a href="gallery.php">Gallery</a><a href="blog.php">Dental Tips</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Book appointment</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="dc"><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
