# Build "Smile Dental" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #20354f · Secondary #bfe3dc · Text #20354f · Accent #f08a6c · Surface #fffaf5 · Border #f0e1d6

## 2. Global Fonts
Headings: Outfit · Body: Karla
H1 72px / H2 42px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 18px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Treatments (services) — html/services.html
- Single Treatment (service) — html/service.html
- Prices (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Smile Stories (projects) — html/projects.html
- Single Smile story (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Dental Tips (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book appointment (booking) — html/booking.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
