# Smile Dental

Exported from Design Library · 19 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Treatments, Single Treatment, Prices, Contact, Testimonials, Team, Smile Stories, Single Smile story, Gallery, Dental Tips, Single post, FAQ, Book appointment, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
