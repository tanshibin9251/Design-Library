# Build "Fitness Energy" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1a0f2e · Secondary #08d9d6 · Text #1a0f2e · Accent #ff2e63 · Surface #f4f1f8 · Border #d9d0e6

## 2. Global Fonts
Headings: Teko · Body: Heebo
H1 132px / H2 56px / H3 28px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Programs (services) — html/services.html
- Single Program (service) — html/service.html
- Membership (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Store (shop) — html/shop.html
- Single Gear (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Transformations (projects) — html/projects.html
- Single Transformation (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Blog (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Class schedule (schedule) — html/schedule.html
- Free trial (trial) — html/trial.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
