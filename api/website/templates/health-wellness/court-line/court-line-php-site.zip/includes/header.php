<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Court Line';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Court Line</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="court-line" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Court Line — light sports-brand site. Badminton-court geometry as the layout language: hairline zones, mono dimension labels, black / grey / white only. Tokens only. */
@import url('https://fonts.googleapis.com/css?family=IBM+Plex+Mono:400,500,600&display=swap');
:root{--f-mono:'IBM Plex Mono',ui-monospace,Menlo,Consolas,monospace}
.cl-in{max-width:var(--w);margin:0 auto;padding:0 clamp(20px,4vw,40px)}
.cl-mono,.cl-eyebrow,.cl-tag,.cl-cap,.cl-crumbs,.cl-pgno{font:500 12px/1.3 var(--f-mono);letter-spacing:.08em;text-transform:uppercase}

/* header */
.cl-head{position:sticky;top:0;z-index:40;background:var(--c-surface);border-bottom:1.5px solid var(--c-primary);box-shadow:0 4px 0 -2.5px var(--c-surface),0 5px 0 -2.5px var(--c-primary)}
.cl-head .cl-in{display:flex;align-items:center;gap:28px;height:76px}
.cl-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--c-primary);font:700 22px/1 var(--f-head);letter-spacing:-.02em}
.cl-logo svg{width:30px;height:18px;flex:none}
.cl-logo b{color:var(--c-accent);font-weight:700}
.cl-logo img{height:36px;width:auto;display:block}
.cl-head nav{display:flex;gap:4px;margin-left:auto}
.cl-head nav a{position:relative;display:flex;gap:7px;align-items:baseline;padding:10px 12px;font:500 12.5px/1 var(--f-mono);letter-spacing:.08em;text-transform:uppercase;text-decoration:none;color:var(--c-text)}
.cl-head nav a i{font-style:normal;color:var(--c-accent);opacity:.9}
.cl-head nav a::after{content:"";position:absolute;left:12px;right:12px;bottom:-1px;height:3px;background:var(--c-primary);transform:scaleX(0);transform-origin:left;transition:transform .2s}
.cl-head nav a:hover::after,.cl-head nav a.on::after{transform:scaleX(1)}
.cl-burger{display:none;margin-left:auto}
.cl-burger summary{list-style:none;cursor:pointer;font:500 12.5px var(--f-mono);letter-spacing:.08em;text-transform:uppercase;padding:11px 16px;border:1.5px solid var(--c-primary)}
.cl-burger summary::-webkit-details-marker{display:none}
.cl-burger div{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:1.5px solid var(--c-primary);padding:8px clamp(20px,4vw,40px) 20px;display:grid}
.cl-burger a{padding:14px 0;text-decoration:none;font:500 14px var(--f-mono);letter-spacing:.08em;text-transform:uppercase;border-bottom:1px solid var(--c-border)}
@media(max-width:960px){.cl-head nav,.cl-head .cl-in>.cl-btn{display:none}.cl-burger{display:block}}

/* atoms */
.cl-btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;padding:1.05em 1.5em;min-height:44px;background:var(--c-primary);color:var(--on-primary);border:1.5px solid var(--c-primary);font:500 12.5px/1 var(--f-mono);letter-spacing:.08em;text-transform:uppercase;text-decoration:none;transition:background .15s,color .15s}
.cl-btn:hover{background:transparent;color:var(--c-primary)}
.cl-btn.o{background:transparent;color:var(--c-primary);border-color:var(--c-primary)}
.cl-btn.o:hover{background:var(--c-primary);color:var(--on-primary)}
.cl-btn.w{background:var(--c-surface);color:var(--c-primary);border-color:var(--c-surface)}
.cl-btn.w:hover{background:transparent;color:var(--on-accent);border-color:var(--on-accent)}
.cl-btns{display:flex;gap:12px;flex-wrap:wrap;align-items:center}
.cl-eyebrow{display:flex;align-items:center;gap:10px;color:var(--c-accent);margin-bottom:18px}
.cl-eyebrow::before{content:"";width:10px;height:10px;border:1.5px solid currentColor;flex:none}
.cl-tag{display:inline-flex;gap:10px;align-items:center;padding:7px 12px;border:1px solid var(--c-primary);color:var(--c-primary);background:var(--c-surface)}
.cl-tag::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--c-primary)}
.cl-h2{font-size:clamp(30px,3.9vw,var(--h2));line-height:1.04;margin:0;max-width:20ch}
.cl-lead{font-size:clamp(16px,1.5vw,19px);max-width:46ch}
.cl-sec{padding:var(--pad) 0}.cl-sec.t{padding:calc(var(--pad)*.55) 0}
.cl-head2{display:flex;justify-content:space-between;align-items:flex-end;gap:24px;flex-wrap:wrap;margin-bottom:clamp(26px,4vw,48px)}
.cl-todo{background:#ffd54a;color:#111;padding:0 .35em;font:500 .82em/1.5 var(--f-body)}
.cl-src{display:block;margin-top:12px;font:400 12px/1.4 var(--f-mono);opacity:.6}
.cl-fig{position:relative;padding:10px}
.cl-fig::before,.cl-fig::after{content:"";position:absolute;width:22px;height:22px;border:2px solid var(--c-primary);pointer-events:none}
.cl-fig::before{top:0;left:0;border-right:0;border-bottom:0}
.cl-fig::after{right:0;bottom:0;border-left:0;border-top:0}
.cl-fig .ph{border-radius:0;background:color-mix(in srgb,var(--c-primary) 8%,var(--c-surface))}

/* hero + court diagram */
.cl-hero{padding:clamp(36px,5vw,72px) 0 clamp(40px,5vw,72px)}
.cl-hero-top{display:grid;grid-template-columns:1.25fr .75fr;gap:clamp(24px,5vw,80px);align-items:end;margin-bottom:clamp(28px,4vw,52px)}
.cl-hero h1{font-size:clamp(48px,8.2vw,var(--h1));line-height:.98;margin-top:22px}
.cl-hero h1 u{text-decoration:none;background:linear-gradient(var(--c-primary),var(--c-primary)) 0 90%/100% .08em no-repeat}
.cl-hero-side{display:grid;gap:26px;padding-bottom:8px}
.cl-court{position:relative;margin:0;border:1.5px solid var(--c-primary);background:color-mix(in srgb,var(--c-accent) 9%,var(--c-surface));padding:clamp(10px,2.4vw,30px)}
.cl-court svg{display:block;width:100%;height:auto}
.cl-ln{fill:none;stroke:var(--c-primary);stroke-width:3;stroke-linecap:square;stroke-linejoin:miter}
.cl-net{fill:none;stroke:var(--c-primary);stroke-width:6;stroke-dasharray:3 9}
.cl-dim{fill:none;stroke:var(--c-primary);stroke-width:1.2;opacity:.65}
.cl-arc{fill:none;stroke:var(--c-accent);stroke-width:3;stroke-dasharray:2 11;stroke-linecap:round}
.cl-cork{fill:var(--c-surface);stroke:var(--c-primary);stroke-width:3}
.cl-t{font:500 15px var(--f-mono);fill:var(--c-primary);letter-spacing:.08em}
.cl-lbl{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);background:var(--c-surface);border:1.5px solid var(--c-primary);padding:clamp(8px,1.4vw,18px) clamp(12px,2vw,28px);display:grid;place-items:center}
.cl-lbl img{height:clamp(26px,5vw,68px);width:auto;display:block}
.cl-lbl span{font:700 clamp(18px,3vw,38px)/1 var(--f-head);letter-spacing:-.02em;color:var(--c-primary)}
.cl-lbl span b{color:var(--c-accent)}
.cl-cap{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-top:14px;opacity:.75}
@media(max-width:900px){.cl-hero-top{grid-template-columns:1fr}}
@media(max-width:700px){.cl-t{display:none}}

/* trio: 3 columns split by court lines */
.cl-trio{display:grid;grid-template-columns:repeat(3,1fr);border-top:1.5px solid var(--c-primary);border-bottom:1px solid var(--c-border)}
.cl-trio>div{padding:clamp(22px,3vw,40px) clamp(18px,2.6vw,36px) clamp(26px,3vw,44px)}
.cl-trio>div+div{border-left:1px solid var(--c-border)}
.cl-trio .cl-mono{color:var(--c-accent);display:block;margin-bottom:34px}
.cl-trio h3{font-size:clamp(22px,2.2vw,var(--h3));line-height:1.1;margin-bottom:10px}
.cl-trio p{opacity:.8}
@media(max-width:800px){.cl-trio{grid-template-columns:1fr}.cl-trio>div+div{border-left:0;border-top:1px solid var(--c-border)}.cl-trio .cl-mono{margin-bottom:16px}}

/* zones: category grid sharing hairlines */
.cl-zones{display:grid;grid-template-columns:repeat(3,1fr);border-top:1.5px solid var(--c-primary);border-left:1px solid var(--c-border)}
.cl-zone{position:relative;display:flex;flex-direction:column;justify-content:space-between;gap:48px;min-height:220px;padding:clamp(20px,2.4vw,32px);border-right:1px solid var(--c-border);border-bottom:1px solid var(--c-border);text-decoration:none;color:var(--c-text);transition:background .2s}
.cl-zone .cl-mono{color:var(--c-accent);display:flex;justify-content:space-between}
.cl-zone h3{font-size:clamp(22px,2.2vw,var(--h3));line-height:1.1}
.cl-zone p{font-size:15px;margin-top:8px;opacity:.78}
.cl-zone::after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:3px;background:var(--c-primary);transform:scaleX(0);transform-origin:left;transition:transform .25s}
.cl-zone:hover{background:color-mix(in srgb,var(--c-accent) 8%,var(--c-surface))}.cl-zone:hover::after{transform:scaleX(1)}
.cl-zone.all{background:var(--c-primary);color:var(--on-primary)}
.cl-zone.all .cl-mono,.cl-zone.all h3{color:var(--on-primary)}
.cl-zone.all:hover{background:var(--c-accent)}
@media(max-width:900px){.cl-zones{grid-template-columns:repeat(2,1fr)}}
@media(max-width:560px){.cl-zones{grid-template-columns:1fr}.cl-zone{min-height:0}}

/* line-call band */
.cl-note{display:flex;justify-content:space-between;align-items:center;gap:24px;flex-wrap:wrap;padding:clamp(24px,3.4vw,44px) 0;border-top:1.5px solid var(--c-primary);border-bottom:1.5px solid var(--c-primary);box-shadow:0 5px 0 -3.5px var(--c-primary) inset}
.cl-note h3{font-size:clamp(24px,2.8vw,40px);line-height:1.05}
.cl-note p{margin-top:8px;max-width:52ch;opacity:.82}

/* board: grey court panel with white lines */
.cl-board{position:relative;background:var(--c-accent);color:var(--on-accent);padding:clamp(34px,5vw,72px);display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);overflow:hidden}
.cl-board::before{content:"";position:absolute;inset:clamp(12px,1.6vw,22px);border:2px solid color-mix(in srgb,var(--on-accent) 55%,transparent);pointer-events:none}
.cl-board::after{content:"";position:absolute;top:clamp(12px,1.6vw,22px);bottom:clamp(12px,1.6vw,22px);left:50%;width:0;border-left:2px solid color-mix(in srgb,var(--on-accent) 55%,transparent);pointer-events:none}
.cl-board>*{position:relative;z-index:1}
.cl-board .cl-eyebrow{color:var(--on-accent)}
.cl-board h2,.cl-board h3{color:var(--on-accent)}
.cl-board dl{display:grid;gap:0}
.cl-board dl>div{display:grid;grid-template-columns:110px 1fr;gap:16px;padding:18px 0;border-top:1px solid color-mix(in srgb,var(--on-accent) 40%,transparent)}
.cl-board dt{font:500 12px/1.4 var(--f-mono);letter-spacing:.08em;text-transform:uppercase;opacity:.8;padding-top:3px}
.cl-board dd{font-size:clamp(16px,1.5vw,19px);line-height:1.4}
/* single-column board (no centre line through text) */
.cl-board.one{grid-template-columns:1fr}.cl-board.one::after{display:none}
@media(max-width:900px){.cl-board{grid-template-columns:1fr}.cl-board::after{display:none}}

/* closing call */
.cl-call{padding:clamp(48px,7vw,104px) 0;border-top:1.5px solid var(--c-primary)}
.cl-call .cl-mono{display:block;margin-bottom:18px;opacity:.7}
.cl-call a{display:inline-block;font:700 clamp(36px,7vw,112px)/1 var(--f-head);letter-spacing:-.03em;text-decoration:none;color:var(--c-primary);background:linear-gradient(var(--c-primary),var(--c-primary)) 0 96%/0 .07em no-repeat;transition:background-size .35s}
.cl-call a:hover{background-size:100% .07em}

/* inner page head: baseline with ruler ticks */
.cl-ph{padding:clamp(28px,4vw,56px) 0 0}
.cl-crumbs{display:flex;gap:10px;margin-bottom:26px;opacity:.7}
.cl-crumbs a{text-decoration:none}
.cl-ph-row{display:flex;justify-content:space-between;align-items:flex-end;gap:24px}
.cl-ph h1{font-size:clamp(40px,6vw,92px);line-height:1;max-width:16ch}
.cl-pgno{opacity:.6;padding-bottom:10px;white-space:nowrap}
.cl-ph .cl-lead{margin-top:22px}
.cl-ph::after{content:"";display:block;margin-top:clamp(28px,4vw,52px);height:14px;border-top:1.5px solid var(--c-primary);background:repeating-linear-gradient(90deg,var(--c-primary) 0 1px,transparent 1px 24px) 0 0/100% 8px no-repeat}

/* split / dl table */
.cl-split{display:grid;grid-template-columns:.8fr 1.2fr;gap:clamp(28px,6vw,100px);align-items:start}
.cl-grid2{display:grid;grid-template-columns:1.05fr .95fr;gap:clamp(28px,5vw,80px);align-items:center}
@media(max-width:900px){.cl-split,.cl-grid2{grid-template-columns:1fr}}
.cl-dl{border-top:1.5px solid var(--c-primary)}
.cl-dl>div{display:grid;grid-template-columns:200px 1fr;gap:20px;padding:20px 0;border-bottom:1px solid var(--c-border);align-items:baseline}
.cl-dl dt{font:500 12.5px/1.4 var(--f-mono);letter-spacing:.08em;text-transform:uppercase;color:var(--c-accent)}
.cl-dl dd{font-size:clamp(16px,1.4vw,18px)}
@media(max-width:640px){.cl-dl>div{grid-template-columns:1fr;gap:6px}}

/* chain: company -> brand -> store */
.cl-chain{display:grid;grid-template-columns:1fr 1fr 1fr;border:1.5px solid var(--c-primary)}
.cl-chain>div{position:relative;padding:clamp(20px,2.6vw,34px)}
.cl-chain>div+div{border-left:1.5px solid var(--c-primary)}
.cl-chain>div+div::before{content:"→";position:absolute;left:-14px;top:22px;width:26px;height:26px;display:grid;place-items:center;background:var(--c-surface);font:500 15px var(--f-mono);color:var(--c-accent)}
.cl-chain .cl-mono{color:var(--c-accent);display:block;margin-bottom:26px}
.cl-chain h3{font-size:clamp(20px,2vw,28px);line-height:1.1;margin-bottom:8px}
.cl-chain p{font-size:15px;opacity:.8}
@media(max-width:800px){.cl-chain{grid-template-columns:1fr}.cl-chain>div+div{border-left:0;border-top:1.5px solid var(--c-primary)}.cl-chain>div+div::before{content:"↓";left:20px;top:-14px}}

/* products: index strip + zone rows */
.cl-index{position:sticky;top:76px;z-index:20;background:var(--c-surface);border-bottom:1px solid var(--c-border)}
.cl-index .cl-in{display:flex;gap:0;overflow-x:auto}
.cl-index a{flex:none;padding:15px 20px;border-right:1px solid var(--c-border);font:500 12px var(--f-mono);letter-spacing:.08em;text-transform:uppercase;text-decoration:none;color:var(--c-text)}
.cl-index a:first-child{border-left:1px solid var(--c-border)}
.cl-index a i{font-style:normal;color:var(--c-accent);margin-right:8px}
.cl-index a:hover{background:color-mix(in srgb,var(--c-accent) 8%,var(--c-surface))}
.cl-row{display:grid;grid-template-columns:120px 1fr 1fr;gap:clamp(20px,3vw,56px);padding:clamp(30px,4vw,56px) 0;border-bottom:1px solid var(--c-border);align-items:center;scroll-margin-top:140px}
.cl-row:first-child{border-top:1.5px solid var(--c-primary)}
.cl-row .code{font:600 clamp(40px,5vw,72px)/1 var(--f-mono);color:var(--c-accent);letter-spacing:-.04em}
.cl-row h2{font-size:clamp(26px,3vw,44px);line-height:1.05}
.cl-row p{margin-top:12px;opacity:.82}
.cl-row .chips{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0 22px}
.cl-chip{display:inline-flex;padding:7px 12px;border:1px solid var(--c-primary);font:500 12px/1.2 var(--f-mono);letter-spacing:.06em;text-transform:uppercase}
@media(max-width:900px){.cl-row{grid-template-columns:70px 1fr}.cl-row .cl-fig{grid-column:1/-1}}

/* services: drill sheet */
.cl-drill{display:grid;grid-template-columns:120px 1fr 1fr;gap:clamp(20px,3vw,56px);padding:clamp(28px,3.6vw,48px) 0;border-bottom:1px solid var(--c-border)}
.cl-drill:first-of-type{border-top:1.5px solid var(--c-primary)}
.cl-drill .code{font:600 clamp(36px,4vw,56px)/1 var(--f-mono);color:var(--c-accent);letter-spacing:-.04em}
.cl-drill h2{font-size:clamp(26px,3vw,42px);line-height:1.05}
.cl-drill ul{list-style:none;display:grid;gap:12px}
.cl-drill li{position:relative;padding-left:30px}
.cl-drill li::before{content:"";position:absolute;left:0;top:.28em;width:15px;height:15px;border:1.5px solid var(--c-primary)}
@media(max-width:800px){.cl-drill{grid-template-columns:70px 1fr}.cl-drill ul{grid-column:2}}

/* contact / legal */
.cl-side{display:grid;grid-template-columns:1fr 300px;gap:clamp(28px,5vw,80px);align-items:start}
.cl-prose{max-width:72ch;counter-reset:s}
.cl-prose h2{counter-increment:s;font-size:clamp(22px,2.3vw,30px);line-height:1.1;margin:44px 0 10px;padding-top:16px;border-top:1px solid var(--c-border)}
.cl-prose h2::before{content:counter(s,decimal-leading-zero);font:500 12px var(--f-mono);letter-spacing:.08em;color:var(--c-accent);margin-right:14px;vertical-align:middle}
.cl-prose h2:first-of-type{margin-top:0}
.cl-prose p{margin-top:10px}
.cl-toc{position:sticky;top:110px;border:1.5px solid var(--c-primary);padding:22px 24px}
.cl-toc h3{font:500 12px var(--f-mono);letter-spacing:.08em;text-transform:uppercase;color:var(--c-accent);margin-bottom:12px}
.cl-toc li{list-style:none;padding:9px 0;border-bottom:1px solid var(--c-border);font-size:14px}
.cl-toc li:last-child{border:0}
@media(max-width:900px){.cl-side{grid-template-columns:1fr}.cl-toc{position:static}}

/* sitemap */
.cl-map ul{list-style:none;display:grid;gap:0}
.cl-map li{border-bottom:1px solid var(--c-border)}
.cl-map li:last-child{border-bottom:0}
.cl-map li a{display:flex;gap:18px;align-items:baseline;padding:14px 0;text-decoration:none;color:var(--c-text);font-size:clamp(17px,1.5vw,20px)}
.cl-map li a b{font:500 12px var(--f-mono);letter-spacing:.08em;color:var(--c-accent);min-width:34px}
.cl-map li a span{background:linear-gradient(var(--c-primary),var(--c-primary)) 0 100%/0 2px no-repeat;transition:background-size .25s}
.cl-map li a:hover span{background-size:100% 2px}
.cl-map li.sub a{padding-left:52px;font-size:15px;opacity:.82}

/* footer */
.cl-foot{background:var(--c-secondary);color:var(--on-secondary);font-size:14px;border-top:1.5px solid var(--c-primary);box-shadow:inset 0 6px 0 -3.5px var(--on-secondary)}
.cl-foot .cols{display:grid;grid-template-columns:1.5fr repeat(3,1fr);gap:34px;padding:60px 0 38px}
.cl-foot h4{font:500 12px var(--f-mono);letter-spacing:.08em;text-transform:uppercase;color:color-mix(in srgb,var(--on-secondary) 60%,transparent);margin-bottom:14px}
.cl-foot ul{list-style:none;display:grid;gap:9px}
.cl-foot a{color:inherit;text-decoration:none;opacity:.88}.cl-foot a:hover{opacity:1;text-decoration:underline}
.cl-foot .cl-logo{color:var(--on-secondary)}.cl-foot .cl-logo b{color:var(--on-secondary)}
.cl-foot .copy{border-top:1px solid color-mix(in srgb,currentColor 22%,transparent);padding:20px 0;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;opacity:.72;font:400 12px var(--f-mono);letter-spacing:.04em}
.cl-foot .copy span a{margin-left:18px}
@media(max-width:800px){.cl-foot .cols{grid-template-columns:1fr 1fr}}
@media(max-width:520px){.cl-foot .cols{grid-template-columns:1fr}}
</style>
<header class="cl-head"><div class="cl-in"><a class="cl-logo" href="index.php"><svg viewBox="0 0 30 18" aria-hidden="true"><rect x=".75" y=".75" width="28.5" height="16.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M15 .75v16.5M10 .75v16.5M20 .75v16.5M.75 9H10M20 9h9.25" fill="none" stroke="currentColor" stroke-width="1.5"/></svg><span>Court<b>Line</b></span></a><nav><a href="index.php"><i>01</i>Home</a><a href="about.php"><i>02</i>About</a><a href="products.php"><i>03</i>Products</a><a href="services.php"><i>04</i>Services</a><a href="contact.php"><i>05</i>Contact</a></nav><a class="cl-btn" href="#">Shop Court Gear</a><details class="cl-burger"><summary>Menu</summary><div><a href="index.php">Home</a><a href="about.php">About</a><a href="products.php">Products</a><a href="services.php">Services</a><a href="contact.php">Contact</a><a href="#">Shop Court Gear</a></div></details></div></header><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
