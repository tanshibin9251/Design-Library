<?php $title = '404 error'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section data-nav="none" id="ja-main"><div class="ja-in"><div class="ja-lost"><span class="em"><svg class="ja-em" aria-hidden="true"><use href="#ja-e-paw"/></svg></span><p class="ja-lab">Specimen not found · 找不到</p><h1>This page isn’t in the collection.</h1><p>It may have moved, or it was never catalogued. Try the search, or walk the shelves.</p><div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-top:10px"><a class="ja-btn" href="index.php">Back to the atlas</a><a class="ja-btn o" href="search.php"><svg class="ja-i" aria-hidden="true"><use href="#ja-i-search"/></svg>Search roles</a></div></div></div></section>
</div>
<?php include 'includes/footer.php'; ?>
