# Job Atlas

Exported from Design Library · 10 pages · PHP

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- includes/header.php, includes/footer.php  ← shared header and footer
- *.php  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home: the atlas, All fields (plates), Field: Banking, Role profile: Credit Analyst, Search roles, Match me, Compare two roles, Switch careers, Method & sources, 404 error.

All text and images are placeholders — replace them with your own.
