<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Nihongo Path';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Nihongo Path</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="nihongo-path" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Nihongo Path — playful pastel Japanese-learning platform, tokens only */
.np-wrap{padding:14px clamp(12px,3vw,40px);position:sticky;top:0;z-index:50;pointer-events:none}
.np-head{pointer-events:auto;display:flex;align-items:center;justify-content:space-between;gap:16px;max-width:1240px;margin:0 auto;background:color-mix(in srgb,var(--c-surface) 92%,#fff);border-radius:999px;padding:8px 10px 8px 22px;box-shadow:0 10px 30px color-mix(in srgb,var(--c-primary) 14%,transparent);backdrop-filter:blur(8px)}
.np-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--c-primary);font:400 22px var(--f-head);letter-spacing:.04em}
.np-logo i{display:grid;place-items:center;width:36px;height:36px;border-radius:50%;background:var(--c-accent);color:var(--on-accent);font:400 18px var(--f-head);font-style:normal}
.np-nav{display:flex;gap:4px;list-style:none;align-items:center}
.np-nav a{display:inline-flex;align-items:center;min-height:44px;padding:0 16px;border-radius:999px;text-decoration:none;font:700 14px var(--f-body);color:var(--c-text);transition:background .2s}
.np-nav a:hover{background:color-mix(in srgb,var(--c-secondary) 30%,transparent)}
.np-nav .cta{background:var(--c-primary);color:var(--on-primary)}
.np-nav .more{position:relative}
.np-nav .dd{position:absolute;right:0;top:calc(100% + 8px);display:none;grid-template-columns:repeat(3,minmax(140px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border-radius:24px;box-shadow:0 18px 40px color-mix(in srgb,var(--c-primary) 20%,transparent);min-width:520px;z-index:60}
.np-nav .more:hover .dd,.np-nav .more:focus-within .dd{display:grid}
.np-nav .dd h4{font:700 11px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-primary);margin-bottom:6px}
.np-nav .dd a{display:block;min-height:0;padding:5px 0;border-radius:0;font-weight:500}.np-nav .dd a:hover{background:none;color:var(--c-primary)}
.np-m{display:none}
.np-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border-radius:999px;background:var(--c-primary);color:var(--on-primary);font:700 12px var(--f-body);letter-spacing:.14em;padding:0 16px}
.np-m summary::-webkit-details-marker{display:none}
.np-m nav{position:absolute;left:12px;right:12px;top:100%;background:var(--c-surface);border-radius:24px;padding:10px 20px;display:grid;box-shadow:0 18px 40px color-mix(in srgb,var(--c-primary) 20%,transparent);pointer-events:auto}
.np-m nav a{padding:12px 0;border-bottom:2px dotted var(--c-border);text-decoration:none;font:700 15px var(--f-body);min-height:44px}
@media(max-width:900px){.np-nav{display:none}.np-m{display:block}}

.np-sec{padding:clamp(40px,6vw,90px) clamp(18px,5vw,80px)}
.np-blob{position:absolute;border-radius:58% 42% 61% 39%/45% 55% 45% 55%;z-index:0}
.np-hero{position:relative;overflow:hidden;padding:clamp(40px,6vw,90px) clamp(18px,5vw,80px) clamp(70px,9vw,130px);display:grid;grid-template-columns:1.15fr .85fr;gap:clamp(24px,5vw,70px);align-items:center}
.np-hero>*:not(.np-blob){position:relative;z-index:1}
.np-hero h1{font:400 clamp(40px,6.4vw,var(--h1))/1.2 var(--f-head);color:var(--c-primary);letter-spacing:.02em}
.np-hero h1 span{background:linear-gradient(transparent 62%,var(--c-accent) 62% 92%,transparent 92%)}
.np-hero .lead{font:500 18px/1.8 var(--f-body);margin:20px 0 28px;max-width:44ch}
.np-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:52px;padding:0 28px;border-radius:999px;background:var(--c-primary);color:var(--on-primary);text-decoration:none;font:700 16px var(--f-body);border:0;cursor:pointer;transition:transform .15s}
.np-btn:hover{transform:translateY(-3px) rotate(-1deg)}
.np-btn.y{background:var(--c-accent);color:var(--on-accent)}.np-btn.m{background:var(--c-secondary);color:var(--c-primary)}
.np-tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;transform:rotate(4deg)}
.np-tiles div{aspect-ratio:1;border-radius:28px;display:grid;place-items:center;font:400 clamp(40px,6vw,76px) var(--f-head);color:var(--c-primary);background:var(--c-surface);box-shadow:0 12px 24px color-mix(in srgb,var(--c-primary) 14%,transparent)}
.np-tiles div:nth-child(3n+1){background:var(--c-secondary)}.np-tiles div:nth-child(5n){background:var(--c-accent)}.np-tiles div:nth-child(2n){transform:translateY(14px)}
@media(max-width:860px){.np-hero{grid-template-columns:1fr}.np-tiles{max-width:360px}}

.np-h{display:flex;align-items:center;gap:14px;margin-bottom:26px}
.np-h h2{font:400 clamp(26px,3.4vw,var(--h2)) var(--f-head);color:var(--c-primary)}
.np-h i{width:40px;height:40px;border-radius:50%;background:var(--c-secondary);display:grid;place-items:center;font:400 18px var(--f-head);font-style:normal;color:var(--c-primary);flex:none}
.np-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.np-card{background:color-mix(in srgb,var(--c-surface) 55%,#fff);border-radius:28px;padding:26px;display:grid;gap:10px;align-content:start;text-decoration:none;box-shadow:0 8px 22px color-mix(in srgb,var(--c-primary) 9%,transparent);transition:transform .2s}
.np-card:hover{transform:translateY(-5px)}
.np-card .lv{justify-self:start;background:var(--c-secondary);color:var(--c-primary);font:700 13px var(--f-body);padding:3px 14px;border-radius:999px}
.np-card.y .lv{background:var(--c-accent);color:var(--on-accent)}
.np-card h3{font:400 24px var(--f-head);color:var(--c-primary)}
.np-card p{font:500 15px/1.7 var(--f-body)}
.np-card .jp{font:400 54px/1 var(--f-head);color:var(--c-primary);opacity:.9}
@media(max-width:900px){.np-grid{grid-template-columns:1fr 1fr}}@media(max-width:560px){.np-grid{grid-template-columns:1fr}}

/* learning path map */
.np-pathwrap{display:grid;grid-template-columns:minmax(260px,380px) 1fr;gap:clamp(24px,5vw,80px);align-items:start}
.np-map{position:relative;width:100%;max-width:380px;aspect-ratio:360/900;justify-self:center}
.np-map svg{position:absolute;inset:0;width:100%;height:100%}
.np-map path{fill:none;stroke:var(--c-secondary);stroke-width:10;stroke-linecap:round;stroke-dasharray:1 18}
.np-node{position:absolute;transform:translate(-50%,-50%);width:64px;height:64px;border-radius:50%;border:0;background:var(--c-surface);color:var(--c-primary);font:400 22px var(--f-head);cursor:pointer;box-shadow:0 8px 18px color-mix(in srgb,var(--c-primary) 20%,transparent);display:grid;place-items:center;transition:transform .2s}
.np-node:hover{transform:translate(-50%,-50%) scale(1.1)}
.np-node.done{background:var(--c-secondary)}
.np-node.now{background:var(--c-accent);color:var(--on-accent);box-shadow:0 0 0 8px color-mix(in srgb,var(--c-accent) 35%,transparent)}
.np-node[aria-pressed=true]{outline:4px solid var(--c-primary);outline-offset:3px}
.np-bubble{background:var(--c-surface);border-radius:32px;padding:clamp(24px,3.4vw,44px);box-shadow:0 14px 34px color-mix(in srgb,var(--c-primary) 12%,transparent);position:sticky;top:110px}
.np-bubble .big{font:400 clamp(60px,8vw,110px)/1 var(--f-head);color:var(--c-primary)}
.np-bubble h3{font:400 28px var(--f-head);margin:10px 0}
.np-bubble ul{list-style:none;margin:18px 0 24px;display:flex;gap:8px;flex-wrap:wrap}
.np-bubble li{background:var(--c-secondary);border-radius:999px;padding:6px 16px;font:700 14px var(--f-body);color:var(--c-primary)}
@media(max-width:860px){.np-pathwrap{grid-template-columns:1fr}.np-bubble{position:static;order:-1}}

/* kana */
.np-kana{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;max-width:640px}
.np-kana button{aspect-ratio:1;min-height:56px;border:0;border-radius:20px;background:color-mix(in srgb,var(--c-surface) 50%,#fff);font:400 clamp(26px,4vw,40px) var(--f-head);color:var(--c-primary);cursor:pointer;position:relative;box-shadow:0 5px 12px color-mix(in srgb,var(--c-primary) 8%,transparent)}
.np-kana button span{position:absolute;left:0;right:0;bottom:6px;font:700 12px var(--f-body);color:var(--c-primary);opacity:0;transition:opacity .15s}
.np-kana button.on{background:var(--c-accent);color:var(--on-accent)}.np-kana button.on span{opacity:1}
.np-kana button.e{visibility:hidden}
.np-quiz{background:var(--c-secondary);border-radius:32px;padding:clamp(24px,3vw,40px);max-width:520px;text-align:center}
.np-quiz .q{font:400 clamp(80px,12vw,140px)/1 var(--f-head);color:var(--c-primary)}
.np-quiz .o{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:18px}
.np-quiz .o button{min-height:56px;border:0;border-radius:18px;background:var(--c-surface);font:700 20px var(--f-body);cursor:pointer;color:var(--c-primary)}
.np-quiz .o button.ok{background:var(--c-accent)}.np-quiz .o button.no{opacity:.4}
.np-quiz .s{margin-top:16px;font:700 14px var(--f-body);color:var(--c-primary)}
.np-two{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,70px);align-items:start}
@media(max-width:860px){.np-two{grid-template-columns:1fr}}
.np-price{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.np-price>div{background:color-mix(in srgb,var(--c-surface) 55%,#fff);border-radius:32px;padding:30px;display:grid;gap:10px;align-content:start;box-shadow:0 8px 22px color-mix(in srgb,var(--c-primary) 9%,transparent)}
.np-price>.hl{background:var(--c-accent);color:var(--on-accent)}
.np-price .p{font:400 40px var(--f-head)}.np-price li{list-style:none;padding:8px 0;border-top:2px dotted currentColor;font:500 15px var(--f-body)}
@media(max-width:860px){.np-price{grid-template-columns:1fr}}
.np-foot{margin-top:clamp(40px,6vw,90px);background:var(--c-primary);color:var(--on-primary);border-radius:48px 48px 0 0;padding:clamp(36px,5vw,70px) clamp(18px,5vw,80px) 24px}
.np-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,6vw,100px)}
.np-foot .big{font:400 36px var(--f-head)}
.np-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.np-foot ul{list-style:none}.np-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 14px var(--f-body);min-height:32px}
.np-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.np-foot .copy{margin-top:30px;font:500 12px var(--f-body);opacity:.75}
@media(max-width:800px){.np-foot .top{grid-template-columns:1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.np-btn,.np-card,.np-node{transition:none}}
</style><div class="np-wrap"><header class="np-head"><a class="np-logo" href="index.php"><i>あ</i>にほんごパス</a><ul class="np-nav"><li><a href="path.php">Path</a></li><li><a href="kana.php">Kana</a></li><li><a href="courses.php">Courses</a></li><li><a href="pricing.php">Pricing</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Learn</h4><a href="index.php">Home</a><a href="path.php">Learning path</a><a href="kana.php">Kana practice</a><a href="courses.php">Courses</a><a href="course.php">Course: JLPT N5</a><a href="lesson.php">Lesson</a></div><div><h4>School</h4><a href="pricing.php">Pricing</a><a href="teachers.php">Teachers</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="cta" href="pricing.php">Start free</a></li></ul><details class="np-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="path.php">Learning path</a><a href="kana.php">Kana practice</a><a href="courses.php">Courses</a><a href="course.php">Course: JLPT N5</a><a href="lesson.php">Lesson</a><a href="pricing.php">Pricing</a><a href="teachers.php">Teachers</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header></div><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
