<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="np-sec" style="text-align:center;padding-top:clamp(60px,10vw,140px)"><div class="np-tiles" style="max-width:240px;margin:0 auto 24px;transform:none;grid-template-columns:repeat(3,1fr)"><div>み</div><div>つ</div><div>か</div></div><h1 style="font:400 clamp(34px,6vw,64px) var(--f-head);color:var(--c-primary)">みつかりません</h1><p style="margin:12px 0 26px;font:500 18px var(--f-body)">404 · This page wandered off the path.</p><a class="np-btn" href="index.php">Back to start</a></section>
<?php include 'includes/footer.php'; ?>
