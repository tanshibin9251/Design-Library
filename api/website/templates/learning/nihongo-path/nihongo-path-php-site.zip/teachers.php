<?php $title = 'Teachers'; include 'includes/header.php'; ?>
<section class="np-sec"><div class="np-h"><i>師</i><h2>Teachers</h2></div><div class="np-grid"><div class="np-card"><span class="jp">先</span><h3>Sakura-sensei</h3><p>Tokyo · beginners · 12 years teaching.</p></div><div class="np-card y"><span class="jp">先</span><h3>Kenta-sensei</h3><p>Osaka · conversation · loves slang.</p></div><div class="np-card"><span class="jp">先</span><h3>Yuki-sensei</h3><p>Sapporo · JLPT coach · patient with kanji.</p></div></div></section>
<?php include 'includes/footer.php'; ?>
