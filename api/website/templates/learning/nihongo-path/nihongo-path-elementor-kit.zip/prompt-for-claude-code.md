# Build "Nihongo Path" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #c2386b · Secondary #6cc6b4 · Text #3a2230 · Accent #ffb703 · Surface #fff6f1 · Border #f1d9cf

## 2. Global Fonts
Headings: Mochiy Pop One · Body: Zen Kaku Gothic Antique
H1 84px / H2 44px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 90px vertical · Border radius 24px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Learning path (path) — html/path.html
- Kana practice (kana) — html/kana.html
- Courses (courses) — html/courses.html
- Course: JLPT N5 (course) — html/course.html
- Lesson (lesson) — html/lesson.html
- Pricing (pricing) — html/pricing.html
- Teachers (teachers) — html/teachers.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
