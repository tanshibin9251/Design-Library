<?php $title = 'Results'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Results</b></div><h1>Results wall</h1></div></section><section class="tc-sec"><div class="in"><div class="tc-nums" style="border:0"><div><b>240+</b><span>A’s</span></div><div><b>61</b><span>straight-A students</span></div><div><b>96%</b><span>pass rate</span></div><div><b>+1.5</b><span>avg grade jump</span></div></div></div></section></div>
<?php include 'includes/footer.php'; ?>
