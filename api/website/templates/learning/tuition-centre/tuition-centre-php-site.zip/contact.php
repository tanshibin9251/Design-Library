<?php $title = 'Contact'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>Contact</b></div><h1>Contact</h1></div></section><section class="tc-sec"><div class="in split"><div class="ph soft" data-l="Centre (缺图)" style="aspect-ratio:4/3;border-radius:18px"></div><ul class="kv"><li><span>Address</span><b>3A Jalan SS 15/4, Subang Jaya</b></li><li><span>Hours</span><b>Mon–Sat 2pm–9pm</b></li><li><span>WhatsApp</span><b>+60 12-998 3000</b></li></ul></div></section>
<?php include 'includes/footer.php'; ?>
