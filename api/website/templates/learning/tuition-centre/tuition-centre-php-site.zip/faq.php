<?php $title = 'FAQ'; include 'includes/header.php'; ?>
<section class="pagehead"><div class="wrap"><div class="crumbs"><a href="index.php">Home</a><span>/</span><b>FAQ</b></div><h1>FAQ</h1></div></section><section class="tc-sec"><div class="in"><div class="faq"><details open><summary>Can I switch subjects?</summary><p>Yes, any time with one week’s notice.</p></details><details><summary>What if we miss a class?</summary><p>Replacement within 2 weeks, free.</p></details></div></div></section>
<?php include 'includes/footer.php'; ?>
