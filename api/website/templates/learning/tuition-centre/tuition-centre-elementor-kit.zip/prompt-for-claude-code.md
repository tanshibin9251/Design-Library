# Build "BrightPath Tuition" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1e3a8a · Secondary #475569 · Text #111827 · Accent #fde047 · Surface #fffdf5 · Border #e5e1c8

## 2. Global Fonts
Headings: Baloo 2 · Body: Lexend
H1 76px / H2 44px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 80px vertical · Border radius 16px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Programmes (programmes) — html/programmes.html
- Timetable (timetable) — html/timetable.html
- Teachers (teachers) — html/teachers.html
- Results (results) — html/results.html
- Fees (fees) — html/fees.html
- Book a trial class (trial) — html/trial.html
- Contact (contact) — html/contact.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
