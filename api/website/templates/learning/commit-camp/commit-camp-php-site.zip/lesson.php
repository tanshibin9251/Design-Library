<?php $title = 'Lesson player'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="cc-sec"><div class="cc-cm">// web-dev-101 / week-04 / lesson-03</div><div class="cc-split"><div><div class="cc-player"><div class="cc-vid"><span>▶</span><em>03 · Events and listeners — 08:42</em></div><div class="cc-ctl"><span>00:00 ━━━━━━━━━━ 08:42</span><span>1.0× · cc · full</span></div></div>
<h2 style="font:700 24px var(--f-head);margin:22px 0 8px;color:var(--c-primary)">Events and listeners</h2><p style="line-height:1.8;max-width:60ch">A click is just a message. Listen for it, run a function, and update the page. Try the exercise on the right after the video.</p><pre class="cc-term" style="margin-top:18px;padding:18px;font:400 14px/1.8 var(--f-head)">button.addEventListener(<span class="p">"click"</span>, () => {
  count++;
  label.textContent = count;
});</pre></div>
<div><div class="cc-cm">// week 4 · 5 lessons</div><div class="cc-list"><a href="#"><span class="n">01</span><span>Variables recap</span><span class="on">✓</span></a><a href="#"><span class="n">02</span><span>Selecting elements</span><span class="on">✓</span></a><a class="cur" href="#"><span class="n">03</span><span>Events and listeners</span><span>▶</span></a><a href="#"><span class="n">04</span><span>Updating the DOM</span><span></span></a><a href="#"><span class="n">05</span><span>Mini project</span><span></span></a></div><p style="margin-top:16px"><a class="cc-btn" href="playground.php">open in playground</a></p></div></div></section></div>
<?php include 'includes/footer.php'; ?>
