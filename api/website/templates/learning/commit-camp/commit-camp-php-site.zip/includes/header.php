<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Commit Camp';
$dark = true;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Commit Camp</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="commit-camp" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Commit Camp — IDE-chrome coding bootcamp, tokens only */
body{font-feature-settings:"liga" 1}
.cc-shell{display:grid;grid-template-columns:250px minmax(0,1fr);min-height:100vh}
.cc-side{position:sticky;top:0;align-self:start;height:100vh;overflow:auto;border-right:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 82%,#000);display:flex;flex-direction:column}
.cc-dots{display:flex;gap:7px;padding:14px 16px}.cc-dots i{width:11px;height:11px;border-radius:50%;background:var(--c-border)}.cc-dots i:nth-child(1){background:var(--c-accent)}
.cc-logo{display:block;padding:6px 16px 18px;font:700 17px var(--f-head);color:var(--c-primary);text-decoration:none;letter-spacing:0}
.cc-logo span{color:var(--c-accent)}
.cc-tree h4{font:600 11px var(--f-head);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);padding:14px 16px 6px}
.cc-tree a{display:flex;align-items:center;gap:8px;padding:8px 16px 8px 22px;min-height:40px;text-decoration:none;font:400 13px var(--f-head);color:var(--c-text);border-left:2px solid transparent}
.cc-tree a::before{content:"▸";color:var(--c-secondary);font-size:10px}
.cc-tree a:hover{background:color-mix(in srgb,var(--c-primary) 6%,transparent)}
.cc-tree a.on{background:color-mix(in srgb,var(--c-accent) 12%,transparent);border-left-color:var(--c-accent);color:var(--c-primary)}
.cc-side .cta{margin:auto 16px 18px;display:grid;place-items:center;min-height:44px;background:var(--c-accent);color:var(--on-accent);text-decoration:none;font:700 13px var(--f-head);border-radius:6px}
.cc-main{min-width:0;display:flex;flex-direction:column}
.cc-tabs{display:flex;gap:0;border-bottom:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 82%,#000);overflow:auto}
.cc-tabs span{padding:11px 18px;font:400 12px var(--f-head);color:var(--c-secondary);border-right:1px solid var(--c-border);white-space:nowrap}
.cc-tabs span.on{color:var(--c-primary);background:var(--c-surface);box-shadow:inset 0 2px 0 var(--c-accent)}
.cc-body{flex:1;min-width:0}
.cc-m{display:none}
@media(max-width:900px){.cc-shell{grid-template-columns:1fr}.cc-side{display:none}.cc-m{display:block;position:sticky;top:0;z-index:40;background:var(--c-surface);border-bottom:1px solid var(--c-border)}
 .cc-m summary{list-style:none;cursor:pointer;min-height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;font:700 15px var(--f-head);color:var(--c-primary)}
 .cc-m summary::-webkit-details-marker{display:none}.cc-m summary b{font:400 12px var(--f-head);color:var(--c-secondary);border:1px solid var(--c-border);padding:6px 10px;border-radius:6px}
 .cc-m nav{display:grid;padding:4px 16px 16px}.cc-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:400 14px var(--f-head);min-height:44px}}

.cc-sec{padding:clamp(40px,6vw,84px) clamp(18px,4vw,64px)}
.cc-cm{font:400 13px var(--f-head);color:var(--c-secondary);margin-bottom:14px}
.cc-cm b{color:var(--c-accent);font-weight:400}
.cc-h1{font:700 clamp(34px,5.2vw,var(--h1)) var(--f-head);letter-spacing:-.02em;line-height:1.08;color:var(--c-primary)}
.cc-h1 em{font-style:normal;color:var(--c-accent)}
.cc-btn{display:inline-flex;align-items:center;gap:10px;min-height:46px;padding:0 22px;border:1px solid var(--c-accent);background:var(--c-accent);color:var(--on-accent);font:700 14px var(--f-head);text-decoration:none;border-radius:6px;cursor:pointer}
.cc-btn.o{background:transparent;color:var(--c-accent)}
.cc-btn:hover{filter:brightness(1.12)}
.cc-term{border:1px solid var(--c-border);border-radius:10px;background:color-mix(in srgb,var(--c-surface) 70%,#000);overflow:hidden;font:400 14px/1.8 var(--f-head)}
.cc-term .bar{display:flex;gap:7px;padding:10px 14px;border-bottom:1px solid var(--c-border)}.cc-term .bar i{width:10px;height:10px;border-radius:50%;background:var(--c-border)}
.cc-term pre{padding:18px 20px;white-space:pre-wrap;word-break:break-word;color:var(--c-text)}
.cc-term .p{color:var(--c-accent)}.cc-term .d{color:var(--c-secondary)}.cc-term .k{color:var(--c-primary)}
.cc-cur{display:inline-block;width:.6em;height:1.1em;background:var(--c-accent);vertical-align:-.15em;animation:ccb 1s steps(2) infinite}
@keyframes ccb{50%{opacity:0}}
.cc-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.cc-card{border:1px solid var(--c-border);border-radius:10px;background:color-mix(in srgb,var(--c-surface) 70%,#000);padding:22px;display:grid;gap:10px;align-content:start;text-decoration:none;transition:border-color .2s,transform .2s}
.cc-card:hover{border-color:var(--c-accent);transform:translateY(-2px)}
.cc-card .t{font:400 12px var(--f-head);color:var(--c-accent)}
.cc-card h3{font:700 19px var(--f-head);letter-spacing:-.01em;color:var(--c-primary)}
.cc-card p{font:400 14px/1.7 var(--f-body);color:var(--c-text);opacity:.85}
.cc-card .m{display:flex;gap:14px;font:400 12px var(--f-head);color:var(--c-secondary);margin-top:6px}
.cc-bar{height:6px;border-radius:99px;background:var(--c-border);overflow:hidden}.cc-bar i{display:block;height:100%;background:var(--c-accent);width:var(--p)}
@media(max-width:1000px){.cc-grid{grid-template-columns:1fr 1fr}}@media(max-width:640px){.cc-grid{grid-template-columns:1fr}}
.cc-log{font:400 14px/1.9 var(--f-head);display:grid;gap:0}
.cc-log a,.cc-log div{display:grid;grid-template-columns:62px 1fr auto;gap:14px;padding:6px 0;text-decoration:none;align-items:baseline}
.cc-log .g{color:var(--c-accent);white-space:pre}.cc-log .h{color:var(--c-secondary)}
.cc-log .tag{font-size:11px;border:1px solid var(--c-accent);color:var(--c-accent);padding:1px 8px;border-radius:99px}
.cc-log b{font-weight:400;color:var(--c-primary)}
.cc-play{display:grid;grid-template-columns:1fr 1fr;gap:0;border:1px solid var(--c-border);border-radius:10px;overflow:hidden;min-height:440px}
.cc-play textarea{width:100%;height:100%;min-height:440px;border:0;border-radius:0;border-right:1px solid var(--c-border);background:color-mix(in srgb,var(--c-surface) 70%,#000);color:var(--c-text);font:400 14px/1.7 var(--f-head);padding:18px;resize:none;outline:0;box-shadow:none}
.cc-play iframe{width:100%;height:100%;min-height:440px;border:0;background:#fff}
@media(max-width:800px){.cc-play{grid-template-columns:1fr}.cc-play textarea{border-right:0;border-bottom:1px solid var(--c-border);min-height:260px}.cc-play iframe{min-height:300px}}
.cc-player{border:1px solid var(--c-border);border-radius:10px;overflow:hidden;background:color-mix(in srgb,var(--c-surface) 70%,#000)}
.cc-vid{aspect-ratio:16/9;display:grid;place-items:center;background:repeating-linear-gradient(45deg,transparent 0 16px,color-mix(in srgb,var(--c-primary) 5%,transparent) 16px 17px);position:relative}
.cc-vid span{width:68px;height:68px;border-radius:50%;background:var(--c-accent);color:var(--on-accent);display:grid;place-items:center;font-size:22px}
.cc-vid em{position:absolute;left:14px;bottom:10px;font:400 11px var(--f-head);font-style:normal;color:var(--c-secondary)}
.cc-ctl{display:flex;justify-content:space-between;padding:12px 16px;font:400 12px var(--f-head);color:var(--c-secondary);border-top:1px solid var(--c-border)}
.cc-split{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(260px,1fr);gap:clamp(20px,3vw,40px);align-items:start}
@media(max-width:900px){.cc-split{grid-template-columns:1fr}}
.cc-list{display:grid;gap:0;border:1px solid var(--c-border);border-radius:10px;overflow:hidden}
.cc-list a{display:grid;grid-template-columns:30px 1fr auto;gap:10px;padding:13px 16px;border-bottom:1px solid var(--c-border);text-decoration:none;font:400 13px var(--f-head);min-height:44px;align-items:center}
.cc-list a:last-child{border-bottom:0}.cc-list .n{color:var(--c-secondary)}.cc-list .on{color:var(--c-accent)}
.cc-list a.cur{background:color-mix(in srgb,var(--c-accent) 12%,transparent)}
.cc-price{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.cc-price>div{border:1px solid var(--c-border);border-radius:10px;padding:26px;display:grid;gap:12px;align-content:start}
.cc-price>.hl{border-color:var(--c-accent);box-shadow:0 0 0 1px var(--c-accent)}
.cc-price .p{font:700 38px var(--f-head);color:var(--c-primary)}.cc-price .p small{font:400 14px var(--f-head);color:var(--c-secondary)}
.cc-price li{list-style:none;font:400 14px var(--f-body);padding:7px 0;border-top:1px solid var(--c-border)}.cc-price li::before{content:"✓ ";color:var(--c-accent)}
@media(max-width:900px){.cc-price{grid-template-columns:1fr}}
.cc-status{display:flex;gap:18px;flex-wrap:wrap;align-items:center;background:var(--c-accent);color:var(--on-accent);padding:0 16px;min-height:28px;font:400 12px var(--f-head);position:sticky;bottom:0;z-index:10}
.cc-status a{color:inherit;text-decoration:none}
.faq summary{font-family:var(--f-head);font-size:16px}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.cc-cur{animation:none}.cc-card{transition:none}}
</style><details class="cc-m"><summary><span>commit<span style="color:var(--c-accent)">.</span>camp</span><b>menu</b></summary><nav><a href="index.php">index.html</a><a href="courses.php">courses/</a><a href="course.php">web-dev-101.md</a><a href="lesson.php">lesson-03.js</a><a href="roadmap.php">roadmap.log</a><a href="playground.php">playground.html</a><a href="pricing.php">pricing.json</a><a href="mentors.php">mentors.yml</a><a href="faq.php">faq.md</a><a href="privacy.php">privacy.txt</a><a href="404.php">404.err</a></nav></details><div class="cc-shell"><aside class="cc-side"><div class="cc-dots"><i></i><i></i><i></i></div><a class="cc-logo" href="index.php">commit<span>.</span>camp</a><div class="cc-tree"><h4>Learn</h4><a class="" href="index.php">index.html</a><a class="" href="courses.php">courses/</a><a class="" href="course.php">web-dev-101.md</a><a class="" href="lesson.php">lesson-03.js</a><a class="" href="roadmap.php">roadmap.log</a><a class="" href="playground.php">playground.html</a></div><div class="cc-tree"><h4>Camp</h4><a class="" href="pricing.php">pricing.json</a><a class="" href="mentors.php">mentors.yml</a><a class="" href="faq.php">faq.md</a></div><div class="cc-tree"><h4>Utility</h4><a class="" href="privacy.php">privacy.txt</a><a class="" href="404.php">404.err</a></div><a class="cta" href="pricing.php">$ enroll --free-week</a></aside><div class="cc-main"><div class="cc-tabs"><span class="on">commit.camp</span><span>~/learn</span><span>main ✓</span></div><div class="cc-body"><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
