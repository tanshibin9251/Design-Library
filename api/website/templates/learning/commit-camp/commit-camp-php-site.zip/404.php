<?php $title = '404 error'; include 'includes/header.php'; ?>
<div tabindex="-1" data-dl-content><section class="cc-sec"><div class="cc-term" style="max-width:640px"><div class="bar"><i></i><i></i><i></i></div><pre><span class="p">learner@camp</span>:~$ cat page.html
<span class="k">cat: page.html: No such file or directory</span>
<span class="d">404 — this route returned nothing.</span>
<span class="p">learner@camp</span>:~$ cd <span class="cc-cur"></span></pre></div><p style="margin-top:26px"><a class="cc-btn" href="index.php">$ cd ~</a></p></section></div>
<?php include 'includes/footer.php'; ?>
