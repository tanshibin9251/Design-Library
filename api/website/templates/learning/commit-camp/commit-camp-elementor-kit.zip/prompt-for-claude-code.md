# Build "Commit Camp" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #e6edf3 · Secondary #8b949e · Text #c9d1d9 · Accent #3fb950 · Surface #0d1117 · Border #30363d

## 2. Global Fonts
Headings: Geist Mono · Body: Geist
H1 64px / H2 40px / H3 20px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 6px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Courses (courses) — html/courses.html
- Course: Web Dev 101 (course) — html/course.html
- Lesson player (lesson) — html/lesson.html
- Roadmap (roadmap) — html/roadmap.html
- Playground (playground) — html/playground.html
- Pricing (pricing) — html/pricing.html
- Mentors (mentors) — html/mentors.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
