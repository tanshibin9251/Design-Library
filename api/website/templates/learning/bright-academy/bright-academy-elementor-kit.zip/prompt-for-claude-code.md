# Build "Bright Academy" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1f2933 · Secondary #d9f0a0 · Text #1f2933 · Accent #b7e04b · Surface #f7f9f2 · Border #dfe5d2

## 2. Global Fonts
Headings: Space Grotesk · Body: DM Sans
H1 72px / H2 40px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 12px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Courses (services) — html/services.html
- Single Course (service) — html/service.html
- Fees (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Student Work (projects) — html/projects.html
- Single Project (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Blog (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Timetable (schedule) — html/schedule.html
- Free trial (trial) — html/trial.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
