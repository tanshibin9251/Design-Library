# Build "Knack Index" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #2b2d42 · Secondary #8d99ae · Text #2b2d42 · Accent #ff7f6e · Surface #f5f3ee · Border #ddd8cc

## 2. Global Fonts
Headings: Gabarito · Body: Hanken Grotesk
H1 92px / H2 44px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 14px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Topics (topics) — html/topics.html
- A–Z index (atoz) — html/atoz.html
- Guide: Remove a red wine stain (guide) — html/guide.html
- Checklists (checklists) — html/checklists.html
- About (about) — html/about.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
