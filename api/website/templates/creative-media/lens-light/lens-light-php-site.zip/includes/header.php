<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Lens & Light';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Lens &amp; Light</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Lens & Light v2 — proof-sheet photographer portfolio, tokens only */
.ll-head{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:20px;padding:0 clamp(14px,3vw,40px);min-height:64px;background:var(--c-surface);border-bottom:2px solid var(--c-primary);position:sticky;top:0;z-index:50;font-family:var(--f-head)}
.ll-meta{font:500 11px var(--f-head);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary)}
.ll-logo{font:500 17px var(--f-head);letter-spacing:.12em;text-transform:uppercase;color:var(--c-primary);text-decoration:none;text-align:center}
.ll-logo i{font-style:normal;color:var(--c-accent)}
.ll-nav{display:flex;gap:clamp(8px,1.6vw,24px);list-style:none;justify-content:flex-end;align-items:center}
.ll-nav a{display:inline-flex;align-items:center;min-height:44px;font:500 12px var(--f-head);letter-spacing:.14em;text-transform:uppercase;color:var(--c-text);text-decoration:none;padding:0 2px;border-bottom:2px solid transparent}
.ll-nav a:hover{border-bottom-color:var(--c-accent)}
.ll-nav .more{position:relative}
.ll-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:2px solid var(--c-primary);min-width:600px;z-index:60;text-align:left}
.ll-nav .more:hover .dd,.ll-nav .more:focus-within .dd{display:grid}
.ll-nav .dd h4{font:500 11px var(--f-head);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.ll-nav .dd a{display:block;min-height:0;padding:5px 0;border:0;letter-spacing:.04em;text-transform:none;font:400 14px var(--f-body)}
.ll-m{display:none;justify-self:end;position:relative}
.ll-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:2px solid var(--c-primary);padding:0 12px;font:500 12px var(--f-head);letter-spacing:.12em}
.ll-m summary::-webkit-details-marker{display:none}
.ll-m nav{position:absolute;right:0;top:100%;min-width:240px;background:var(--c-surface);border:2px solid var(--c-primary);padding:6px 16px;display:grid;z-index:60}
.ll-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:400 15px var(--f-body);min-height:44px}
@media(max-width:900px){.ll-head{grid-template-columns:1fr auto}.ll-meta,.ll-nav{display:none}.ll-m{display:block}.ll-logo{text-align:left}}
.ll-sec{padding:clamp(34px,5vw,70px) clamp(14px,3vw,40px)}
.ll-ti{display:flex;justify-content:space-between;gap:16px;align-items:end;flex-wrap:wrap;margin-bottom:22px}
.ll-ti h1,.ll-ti h2{font:500 clamp(30px,5vw,var(--h1))/1 var(--f-head);letter-spacing:-.02em;color:var(--c-primary);text-transform:uppercase}
.ll-ti p{font:400 16px/1.7 var(--f-body);max-width:44ch;color:var(--c-text)}
.ll-sheet{background:var(--c-primary);padding:clamp(10px,1.6vw,22px);display:grid;grid-template-columns:repeat(6,1fr);gap:clamp(6px,1vw,12px)}
.ll-fr{position:relative;background:var(--c-primary);border:0;padding:0;cursor:pointer;color:var(--on-primary);text-align:left;font-family:var(--f-head)}
.ll-fr .im{display:block;aspect-ratio:3/2;background:radial-gradient(circle at var(--x,30%) var(--y,40%),var(--c1) 0 22%,transparent 23%),linear-gradient(var(--a,160deg),var(--c2),var(--c3));position:relative;transition:transform .3s,filter .3s;filter:grayscale(1) contrast(1.05)}
.ll-fr:hover .im,.ll-fr:focus-visible .im{filter:none;transform:scale(1.04);z-index:2}
.ll-fr .no{display:flex;justify-content:space-between;font:500 10px var(--f-head);letter-spacing:.14em;padding:6px 4px 0;color:var(--c-secondary)}
.ll-fr.tall{grid-row:span 2}.ll-fr.tall .im{aspect-ratio:3/4.2}
.ll-fr.wide{grid-column:span 2}.ll-fr.wide .im{aspect-ratio:2.4/1}
.ll-fr[aria-pressed=true]{outline:3px solid var(--c-accent);outline-offset:-3px}
.ll-mark{position:absolute;right:8px;top:8px;width:26px;height:26px;border:2px solid var(--c-accent);border-radius:50%;opacity:0;transition:opacity .2s;z-index:3}
.ll-fr[aria-pressed=true] .ll-mark{opacity:1}
@media(max-width:900px){.ll-sheet{grid-template-columns:repeat(3,1fr)}}@media(max-width:520px){.ll-sheet{grid-template-columns:repeat(2,1fr)}.ll-fr.wide{grid-column:span 2}}
.ll-view{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(240px,1fr);gap:clamp(18px,3vw,44px);margin-top:26px;align-items:start}
@media(max-width:860px){.ll-view{grid-template-columns:1fr}}
.ll-big{aspect-ratio:3/2;border:2px solid var(--c-primary);background:radial-gradient(circle at var(--x,30%) var(--y,40%),var(--c1) 0 22%,transparent 23%),linear-gradient(var(--a,160deg),var(--c2),var(--c3));position:relative}
.ll-big::after{content:"缺图";position:absolute;right:10px;bottom:8px;font:500 11px var(--f-head);letter-spacing:.14em;background:var(--c-surface);padding:2px 8px}
.ll-exif{border-top:2px solid var(--c-primary);padding-top:12px;font:500 13px var(--f-head);letter-spacing:.06em}
.ll-exif div{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid var(--c-border)}
.ll-exif b{font-weight:500;color:var(--c-accent)}
.ll-exif h3{font:500 22px var(--f-head);letter-spacing:-.01em;margin-bottom:10px;color:var(--c-primary);text-transform:uppercase}
.ll-btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 24px;border:2px solid var(--c-primary);background:var(--c-primary);color:var(--on-primary);font:500 13px var(--f-head);letter-spacing:.16em;text-transform:uppercase;text-decoration:none;cursor:pointer}
.ll-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.ll-btn.o{background:transparent;color:var(--c-primary)}.ll-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}
.ll-ser{display:grid;grid-template-columns:repeat(3,1fr);border-top:2px solid var(--c-primary)}
.ll-ser a{padding:22px 20px 26px 0;border-right:1px solid var(--c-border);text-decoration:none;color:var(--c-text);display:grid;gap:6px;padding-left:20px}
.ll-ser a:first-child{padding-left:0}.ll-ser a:last-child{border-right:0}
.ll-ser b{font:500 22px var(--f-head);text-transform:uppercase;color:var(--c-primary);letter-spacing:-.01em}
.ll-ser span{font:500 12px var(--f-head);letter-spacing:.14em;color:var(--c-accent)}
.ll-ser a:hover b{color:var(--c-accent)}
@media(max-width:700px){.ll-ser{grid-template-columns:1fr}.ll-ser a{border-right:0;border-bottom:1px solid var(--c-border);padding-left:0}}
.ll-foot{background:var(--c-primary);color:var(--on-primary);margin-top:clamp(30px,5vw,70px);padding:clamp(30px,4vw,56px) clamp(14px,3vw,40px) 22px}
.ll-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.ll-foot .big{font:500 26px var(--f-head);letter-spacing:.1em;text-transform:uppercase}
.ll-foot h4{font:500 11px var(--f-head);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:10px}
.ll-foot ul{list-style:none}.ll-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:400 15px var(--f-body);color:var(--on-primary);min-height:34px}
.ll-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.ll-foot .copy{margin-top:24px;font:500 11px var(--f-head);letter-spacing:.14em;text-transform:uppercase;opacity:.7}
@media(max-width:860px){.ll-foot .top{grid-template-columns:1fr}.ll-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.ll-fr .im{transition:none}}
.ll .pagehead{background:none;border-bottom:3px solid var(--c-primary);padding-bottom:30px}.ll .pagehead h1{max-width:none}.ll .card,.ll .scard,.ll .qcard,.ll .pcard,.ll .person{background:var(--c-surface);border:1px solid var(--c-primary);box-shadow:none}.ll .eyebrow{display:inline-block;border-left:4px solid var(--c-accent);padding-left:10px;letter-spacing:.2em}.ll .pagehead h1{text-transform:uppercase;letter-spacing:-.02em}.ll .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.ll .svc{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:3px solid var(--c-primary)}
.ll .scard{display:block;padding:clamp(22px,3vw,40px);border:0;border-bottom:1px solid var(--c-primary);border-right:1px solid var(--c-primary);border-radius:0;background:none;box-shadow:none;min-height:240px;transition:background .2s}
.ll .scard:nth-child(2n){border-right:0}
.ll .scard .ph{display:none}
.ll .scard h3{font-size:clamp(28px,3.6vw,50px);line-height:1.02;margin-bottom:12px;letter-spacing:-.02em}
.ll .scard p{max-width:34ch;opacity:.85}.ll .scard .m{margin-top:16px;display:flex;gap:14px;font:700 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-accent)}
.ll .scard:hover{background:color-mix(in srgb,var(--c-accent) 14%,var(--c-surface))}
@media(max-width:760px){.ll .svc{grid-template-columns:1fr}.ll .scard{border-right:0;min-height:0}}

.ll .tgrid{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:14px}
.ll .person{flex:0 0 min(240px,70vw);scroll-snap-align:start}

.ll .qgrid{display:block}.ll .qgrid.mt{margin-top:0}
.ll .qcard{max-width:900px;margin:0 auto;padding:clamp(24px,4vw,48px) 0;border:0;border-bottom:1px solid var(--c-border);background:none;box-shadow:none;border-radius:0}
.ll .qcard blockquote{font-size:clamp(22px,3vw,36px);line-height:1.3;margin:10px 0 18px}

.ll .masonry{display:flex!important;gap:12px;overflow-x:auto;scroll-snap-type:x mandatory;columns:auto;padding-bottom:14px}
.ll .masonry .mi{flex:0 0 min(340px,76vw);margin:0;scroll-snap-align:start}.ll .masonry .mi .ph{aspect-ratio:3/4!important}

.ll .articles{display:block!important}
.ll .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.ll .art .ph{display:none}.ll .art .meta{grid-row:1/span 2;align-self:start}.ll .art h3{margin:0}
.ll .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}
.ll .faq summary{font-size:clamp(20px,2.4vw,30px);padding:10px 0}.ll .faq details{padding:14px 0}.ll .faq p{font-size:18px;max-width:60ch}

.ll .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.ll .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.ll .pricing .card.hl h3,.ll .pricing .card.hl .amt{color:var(--c-primary)!important}.ll .pricing .card.hl li::before{color:var(--c-accent)!important}
.ll .split{display:flex;flex-direction:column-reverse;gap:30px}.ll .cinfo{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}@media(max-width:800px){.ll .cinfo{grid-template-columns:1fr 1fr}}
.ll .sec.dark{background:none;color:var(--c-text);border-top:3px solid var(--c-primary);border-bottom:3px solid var(--c-primary)}.ll .sec.dark h2,.ll .sec.dark p{color:var(--c-text)}
.ll .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.ll .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.ll .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.ll .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.ll .tl>div:last-child{border-right:0}
.ll .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.ll .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.ll .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.ll .vals .card:last-child{border-right:0}
@media(max-width:700px){.ll .vals{grid-template-columns:1fr}.ll .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}

.ll-pk{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:2px solid var(--c-primary)}
.ll-pk>div{padding:26px 24px;border-right:2px solid var(--c-primary);display:grid;gap:8px;align-content:start}.ll-pk>div:last-child{border-right:0}
.ll-pk h3{font:500 24px var(--f-head);text-transform:uppercase;color:var(--c-primary)}.ll-pk .p{font:500 18px var(--f-head);color:var(--c-accent)}.ll-pk li{list-style:none;font:400 15px var(--f-body);padding:7px 0;border-top:1px solid var(--c-border)}
@media(max-width:800px){.ll-pk{grid-template-columns:1fr}.ll-pk>div{border-right:0;border-bottom:2px solid var(--c-primary)}}</style><header class="ll-head"><span class="ll-meta">Kuala Lumpur · 3.139° N, 101.687° E</span><a class="ll-logo" href="index.php">Lens <i>&amp;</i> Light</a><ul class="ll-nav"><li><a href="projects.php">Work</a></li><li><a href="services.php">Services</a></li><li><a href="about.php">About</a></li><li><a href="contact.php">Contact</a></li><li class="more"><a href="#" tabindex="0">All</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Prints</a><a href="product.php">Single Print</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Portfolio</a><a href="project.php">Single Gallery</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="booking.php">Book a shoot</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li></ul><details class="ll-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Services</a><a href="service.php">Single Service</a><a href="pricing.php">Packages</a><a href="contact.php">Contact</a><a href="shop.php">Prints</a><a href="product.php">Single Print</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Team</a><a href="projects.php">Portfolio</a><a href="project.php">Single Gallery</a><a href="gallery.php">Gallery</a><a href="blog.php">Journal</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="booking.php">Book a shoot</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="ll">
<main>
