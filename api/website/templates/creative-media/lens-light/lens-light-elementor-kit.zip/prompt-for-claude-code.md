# Build "Lens & Light" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #151413 · Secondary #8c877b · Text #24221f · Accent #d6322a · Surface #f1efe9 · Border #d4d0c5

## 2. Global Fonts
Headings: DM Mono · Body: Albert Sans
H1 88px / H2 44px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 80px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Services (services) — html/services.html
- Single Service (service) — html/service.html
- Packages (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Prints (shop) — html/shop.html
- Single Print (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Portfolio (projects) — html/projects.html
- Single Gallery (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Journal (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Book a shoot (booking) — html/booking.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
