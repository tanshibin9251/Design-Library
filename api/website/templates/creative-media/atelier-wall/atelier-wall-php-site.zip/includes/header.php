<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Atelier Wall';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Atelier Wall</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<style>
/* Atelier Wall — online art school as a gallery, tokens only */
.aw-head{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:0 clamp(16px,3vw,44px);min-height:72px;background:var(--c-surface);border-bottom:1px solid var(--c-border);position:sticky;top:0;z-index:50}
.aw-l,.aw-r{display:flex;gap:clamp(14px,2.2vw,32px);list-style:none;align-items:center}
.aw-r{justify-content:flex-end}
.aw-l a,.aw-r a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;font:500 13px var(--f-body);letter-spacing:.04em;color:var(--c-text)}
.aw-l a:hover,.aw-r a:hover{color:var(--c-accent)}
.aw-logo{font:800 22px var(--f-head);letter-spacing:-.03em;color:var(--c-primary);text-decoration:none;text-align:center}
.aw-logo i{font-style:normal;display:inline-block;width:.55em;height:.55em;background:var(--c-accent);margin-left:2px;vertical-align:baseline}
.aw-r .b{border:1.5px solid var(--c-primary);padding:0 16px}
.aw-more{position:relative}
.aw-more .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);border:1px solid var(--c-primary);min-width:600px;z-index:60}
.aw-more:hover .dd,.aw-more:focus-within .dd{display:grid}
.aw-more .dd h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:6px}
.aw-more .dd a{padding:5px 0;min-height:0;display:block}
.aw-m{display:none}
.aw-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;font:700 12px var(--f-body);letter-spacing:.14em;border:1.5px solid var(--c-primary);padding:0 14px}
.aw-m summary::-webkit-details-marker{display:none}
.aw-m nav{position:absolute;left:0;right:0;top:100%;background:var(--c-surface);border-bottom:1px solid var(--c-primary);padding:6px 18px 16px;display:grid}
.aw-m nav a{padding:12px 0;border-bottom:1px solid var(--c-border);text-decoration:none;font:500 15px var(--f-body);min-height:44px}
@media(max-width:900px){.aw-head{grid-template-columns:auto 1fr}.aw-l,.aw-r{display:none}.aw-m{display:block;justify-self:end}.aw-logo{text-align:left}}

.aw-sec{padding:clamp(48px,7vw,110px) clamp(16px,3vw,44px)}
.aw-hero{padding:clamp(40px,6vw,90px) clamp(16px,3vw,44px) 0}
.aw-hero h1{font:800 clamp(44px,9vw,var(--h1))/.94 var(--f-head);letter-spacing:-.045em;color:var(--c-primary);max-width:14ch}
.aw-hero h1 em{font-style:normal;color:var(--c-accent)}
.aw-lab{font:600 11px var(--f-body);letter-spacing:.18em;text-transform:uppercase;color:var(--c-secondary)}
.aw-btn{display:inline-flex;align-items:center;gap:10px;min-height:50px;padding:0 24px;background:var(--c-primary);color:var(--on-primary);text-decoration:none;font:600 14px var(--f-body);border:1.5px solid var(--c-primary);cursor:pointer}
.aw-btn:hover{background:var(--c-accent);border-color:var(--c-accent);color:var(--on-accent)}
.aw-btn.o{background:transparent;color:var(--c-primary)}.aw-btn.o:hover{background:var(--c-primary);color:var(--on-primary);border-color:var(--c-primary)}

/* hung works */
.aw-wall{display:grid;grid-template-columns:repeat(12,1fr);gap:clamp(24px,3vw,48px) clamp(16px,2vw,32px);align-items:end}
.aw-work{margin:0;grid-column:span 4}
.aw-work.w{grid-column:span 6}.aw-work.s{grid-column:span 3}.aw-work.xl{grid-column:span 8}
.aw-work.hide{display:none}
.aw-pic{position:relative;background:var(--bg,color-mix(in srgb,var(--c-primary) 10%,var(--c-surface)));aspect-ratio:var(--r,4/5);box-shadow:0 20px 30px -22px color-mix(in srgb,var(--c-primary) 55%,transparent);overflow:hidden}
.aw-pic::before{content:"";position:absolute;inset:0;background:radial-gradient(circle at var(--x,30%) var(--y,35%),var(--c1,var(--c-accent)) 0 18%,transparent 19%),radial-gradient(circle at calc(100% - var(--x,30%)) calc(100% - var(--y,35%)),var(--c2,var(--c-primary)) 0 26%,transparent 27%)}
.aw-pic::after{content:attr(data-l);position:absolute;left:10px;bottom:8px;font:600 10px var(--f-body);letter-spacing:.14em;text-transform:uppercase;background:var(--c-surface);padding:2px 7px}
.aw-cap{margin-top:12px;display:grid;gap:2px;font:400 13px/1.5 var(--f-body)}
.aw-cap b{font:700 15px var(--f-body);color:var(--c-primary)}
.aw-cap span{color:var(--c-secondary)}
@media(max-width:900px){.aw-work,.aw-work.w,.aw-work.xl,.aw-work.s{grid-column:span 6}}
@media(max-width:560px){.aw-work,.aw-work.w,.aw-work.xl,.aw-work.s{grid-column:1/-1}}
.aw-chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:30px}
.aw-chips button{min-height:44px;padding:0 18px;border:1.5px solid var(--c-primary);background:transparent;color:var(--c-primary);font:600 13px var(--f-body);cursor:pointer}
.aw-chips button[aria-pressed=true]{background:var(--c-primary);color:var(--on-primary)}

/* studios */
.aw-st{display:grid;grid-template-columns:90px minmax(0,1fr) minmax(0,1fr);gap:clamp(16px,3vw,48px);padding:clamp(24px,3vw,44px) 0;border-top:1.5px solid var(--c-primary);align-items:center;text-decoration:none}
.aw-st:last-child{border-bottom:1.5px solid var(--c-primary)}
.aw-st .n{font:800 clamp(40px,5vw,72px)/1 var(--f-head);letter-spacing:-.05em;color:var(--c-accent)}
.aw-st h3{font:800 clamp(24px,3vw,40px)/1.05 var(--f-head);letter-spacing:-.03em;color:var(--c-primary)}
.aw-st p{font:400 16px/1.7 var(--f-body);margin-top:8px;max-width:42ch}
.aw-st .meta{font:600 12px var(--f-body);letter-spacing:.14em;text-transform:uppercase;color:var(--c-secondary);margin-top:12px;display:flex;gap:18px;flex-wrap:wrap}
.aw-st .aw-pic{aspect-ratio:16/10}
.aw-st:hover h3{color:var(--c-accent)}
@media(max-width:800px){.aw-st{grid-template-columns:50px 1fr}.aw-st .aw-pic{grid-column:1/-1}}

/* before/after */
.aw-ba{position:relative;max-width:760px;aspect-ratio:4/3;overflow:hidden;border:1.5px solid var(--c-primary);--p:50%;touch-action:pan-y}
.aw-ba>div{position:absolute;inset:0}
.aw-ba .a{background:repeating-linear-gradient(45deg,transparent 0 14px,color-mix(in srgb,var(--c-primary) 14%,transparent) 14px 15px),color-mix(in srgb,var(--c-secondary) 25%,var(--c-surface))}
.aw-ba .b{background:radial-gradient(circle at 30% 40%,var(--c-accent) 0 20%,transparent 21%),radial-gradient(circle at 72% 62%,var(--c-primary) 0 28%,transparent 29%),var(--c-surface);clip-path:inset(0 0 0 var(--p))}
.aw-ba span{position:absolute;top:12px;font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;background:var(--c-surface);padding:4px 10px}
.aw-ba .a span{left:12px}.aw-ba .b span{right:12px}
.aw-ba i{position:absolute;top:0;bottom:0;left:var(--p);width:3px;background:var(--c-primary);margin-left:-1px;pointer-events:none}
.aw-ba i::after{content:"↔";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:44px;height:44px;border-radius:50%;background:var(--c-primary);color:var(--on-primary);display:grid;place-items:center;font:700 18px var(--f-body)}
.aw-ba input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:ew-resize;margin:0;padding:0}
.aw-split{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,80px);align-items:start}
@media(max-width:860px){.aw-split{grid-template-columns:1fr}}
.aw-3{display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(18px,2vw,32px)}
@media(max-width:860px){.aw-3{grid-template-columns:1fr}}
.aw-card{border-top:1.5px solid var(--c-primary);padding-top:16px;display:grid;gap:8px;align-content:start}
.aw-card h3{font:800 26px var(--f-head);letter-spacing:-.03em}
.aw-card .p{font:800 44px var(--f-head);letter-spacing:-.04em;color:var(--c-primary)}
.aw-card li{list-style:none;padding:8px 0;border-top:1px solid var(--c-border);font:400 15px var(--f-body)}
.aw-foot{padding:clamp(40px,5vw,70px) clamp(16px,3vw,44px) 20px;border-top:1.5px solid var(--c-primary);margin-top:clamp(40px,6vw,100px)}
.aw-foot .big{font:800 clamp(56px,13vw,200px)/.85 var(--f-head);letter-spacing:-.06em;color:var(--c-primary)}
.aw-foot .big i{font-style:normal;color:var(--c-accent)}
.aw-foot .cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:34px}
.aw-foot h4{font:700 11px var(--f-body);letter-spacing:.16em;text-transform:uppercase;color:var(--c-accent);margin-bottom:8px}
.aw-foot ul{list-style:none}.aw-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:500 14px var(--f-body);min-height:32px}
.aw-foot .copy{margin-top:26px;font:400 12px var(--f-body);color:var(--c-secondary)}
html,body{overflow-x:clip}img,svg{max-width:100%}
</style><header class="aw-head"><ul class="aw-l"><li><a href="studios.php">Studios</a></li><li><a href="wall.php">Student wall</a></li><li><a href="progress.php">Before &amp; after</a></li></ul><a class="aw-logo" href="index.php">atelier wall<i></i></a><ul class="aw-r"><li><a href="faculty.php">Faculty</a></li><li class="aw-more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>School</h4><a href="index.php">Home</a><a href="studios.php">Studios</a><a href="studio.php">Studio: Drawing Foundations</a><a href="wall.php">Student wall</a><a href="progress.php">Before & after</a><a href="faculty.php">Faculty</a></div><div><h4>Join</h4><a href="tuition.php">Tuition</a><a href="faq.php">FAQ</a></div><div><h4>Utility</h4><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></div></div></li><li><a class="b" href="tuition.php">Enrol</a></li></ul><details class="aw-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="studios.php">Studios</a><a href="studio.php">Studio: Drawing Foundations</a><a href="wall.php">Student wall</a><a href="progress.php">Before & after</a><a href="faculty.php">Faculty</a><a href="tuition.php">Tuition</a><a href="faq.php">FAQ</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a></nav></details></header>
<main>
