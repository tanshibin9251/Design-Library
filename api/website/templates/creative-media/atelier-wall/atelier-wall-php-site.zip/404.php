<?php $title = '404 error'; include 'includes/header.php'; ?>
<section class="aw-sec"><div class="aw-lab">Error 404</div><h1 class="aw-hero" style="padding:0;font:800 clamp(60px,14vw,200px)/.9 var(--f-head);letter-spacing:-.05em;margin:18px 0 24px">Blank<br>canvas.</h1><a class="aw-btn" href="index.php">Back to the school</a></section>
<?php include 'includes/footer.php'; ?>
