# Pixel Arena

Exported from Design Library · 25 pages · HTML

## Structure
- assets/css/tokens.css  ← colours, fonts, sizes, content width, section spacing
- assets/css/style.css   ← components and layout (uses the tokens)
- *.html  ← one file per page

## Customise
Open assets/css/tokens.css and change the variables. Pages: Home, About, Arena Cafe, Single Package, Memberships, Contact, Merch Shop, Single Item, Cart, Checkout, Testimonials, Roster, Highlights, Single Highlight, Gallery, News, Single post, FAQ, Events, Book a station, Free first hour, Careers, Privacy policy, 404 error, Coming soon.

All text and images are placeholders — replace them with your own.
