# Build "Pixel Arena" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #3b1a8f · Secondary #7a1fa2 · Text #1a1033 · Accent #c4126f · Surface #f2ecff · Border #1a1033

## 2. Global Fonts
Headings: Orbitron · Body: Archivo
H1 84px / H2 50px / H3 26px / Body 16px

## 3. Layout
Content width 1300px · Section padding 84px vertical · Border radius 20px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Arena Cafe (services) — html/services.html
- Single Package (service) — html/service.html
- Memberships (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Merch Shop (shop) — html/shop.html
- Single Item (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Roster (team) — html/team.html
- Highlights (projects) — html/projects.html
- Single Highlight (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- News (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Events (schedule) — html/schedule.html
- Book a station (booking) — html/booking.html
- Free first hour (trial) — html/trial.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
