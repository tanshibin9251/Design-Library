# Build "Pulse Records" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #1a35d6 · Secondary #ff6f91 · Text #101323 · Accent #ffd23f · Surface #f4efe6 · Border #101323

## 2. Global Fonts
Headings: Rubik Mono One · Body: Chivo
H1 68px / H2 38px / H3 22px / Body 16px

## 3. Layout
Content width 1300px · Section padding 76px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Merch (services) — html/services.html
- Single Merch (service) — html/service.html
- Subscribe (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Releases (shop) — html/shop.html
- Single Release (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Artists (team) — html/team.html
- Artists (projects) — html/projects.html
- Single Artist (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- News (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Shows (schedule) — html/schedule.html
- Submit a demo (booking) — html/booking.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
