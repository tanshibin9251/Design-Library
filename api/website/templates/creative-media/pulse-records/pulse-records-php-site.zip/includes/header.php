<?php
// Usage in a page:  $title = 'About'; include 'includes/header.php';
$title = $title ?? 'Pulse Records';
$dark = false;
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> · Pulse Records</title>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/style.css">
</head><body<?= $dark ? ' class="dk"' : '' ?>>
<span data-dl-template="pulse-records" hidden></span><style>/* Shared, exported template behaviour. Scope additions to enhanced fragments. */
.dl-mobile{display:none}.dl-skip{position:fixed;left:16px;top:-100px;z-index:10000;padding:12px 18px;background:var(--c-surface);color:var(--c-text);border:2px solid var(--c-accent)}.dl-skip:focus{top:12px}
.nav:has(details[open]){overflow:visible!important}.dl-filter-empty{padding:28px;border:1px dashed var(--c-border);border-radius:var(--radius);margin-top:20px}
.products>[hidden],.dl-filter-empty[hidden]{display:none!important}
/* A grid item's default min-content size must not widen its whole page. */
main :where(*){min-width:0}
.more.dl-menu-open>.dd{display:grid!important;opacity:1;visibility:visible;pointer-events:auto}.more:has(>a[aria-expanded=false])>.dd{display:none!important}
[data-pk-panel][hidden]{display:none!important}[data-pk-panel]{padding-block:24px}
.dl-photo-story{padding:clamp(32px,5vw,72px) 0;border-block:1px solid var(--c-border);background:var(--c-surface);color:var(--c-text)}.dl-photo-wrap{max-width:var(--w,1300px);padding-inline:clamp(20px,4vw,40px);margin-inline:auto}.dl-photo-head{display:flex;justify-content:space-between;align-items:start;gap:24px;margin-bottom:28px}.dl-photo-head h2{font-size:clamp(26px,3vw,40px);font-style:normal}.dl-photo-head p{max-width:48ch;font-size:14px;opacity:.75}.dl-photo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:24px}.dl-photo-grid figcaption{font-size:13px;padding-top:10px;opacity:.8}.dl-photo-grid .dl-visual{border-radius:var(--radius)}@media(max-width:700px){.dl-photo-head{display:block}.dl-photo-head p{margin-top:12px}}
[data-dl-footer] .cols{display:grid;grid-template-columns:minmax(220px,1.6fr) repeat(auto-fit,minmax(125px,1fr));gap:28px 36px;padding-bottom:28px}
[data-dl-footer] .cols>div{min-width:0}[data-dl-footer] .cols ul{list-style:none;padding:0;margin:10px 0 0}[data-dl-footer] h4{color:inherit;font-size:13px;letter-spacing:.08em}
[data-dl-footer] .cols li a{display:inline-flex;align-items:center;min-height:44px;text-decoration:none;line-height:1.4}[data-dl-footer] .cols a:hover{text-decoration:underline;text-underline-offset:4px}
[data-dl-footer] .copy{border-top:1px solid currentColor;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;font-size:13px}
.dl-form-note,.dl-feedback{grid-column:1/-1;font-size:14px;line-height:1.6;padding:12px 16px;border:1px solid var(--c-border);border-radius:var(--radius);background:var(--c-surface);color:var(--c-text);max-width:100%}.dl-feedback{border-left:4px solid var(--c-accent);margin-block:12px}.dl-feedback[hidden]{display:none}
.dl-visual{position:relative;isolation:isolate;overflow:hidden;background:var(--c-border)}.dl-visual:before,.dl-visual:after{display:none!important}.dl-visual>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1}.dl-visual>span{position:relative;z-index:1}.dl-photo-failed>img{display:none}.dl-photo-failed:after{display:grid!important;position:absolute;inset:0;place-items:center;content:'Image unavailable · 缺图';padding:16px;background:var(--c-surface);color:var(--c-text);font:500 14px var(--f-body)}
.dl-stock-label{position:absolute;left:10px;bottom:10px;padding:4px 8px;max-width:calc(100% - 20px);background:var(--c-surface);color:var(--c-text);font-size:11px;line-height:1.5;border-radius:4px}.dl-credits{padding:20px 0;font-size:13px}.dl-credits summary{cursor:pointer;min-height:44px;display:flex;align-items:center}.dl-credits li{margin-block:8px}.dl-credits a{overflow-wrap:anywhere}
:where(button,a,input,select,textarea,summary):focus-visible{outline:3px solid var(--c-accent);outline-offset:4px}
@media(max-width:820px){.dl-mobile{display:block;position:relative}.dl-mobile summary{display:flex;align-items:center;justify-content:center;min-width:64px;min-height:44px;padding:8px 12px;border:1px solid var(--c-border);border-radius:var(--radius);cursor:pointer;list-style:none;font:600 14px var(--f-body)}.dl-mobile summary::-webkit-details-marker{display:none}.dl-mobile-links{position:fixed;top:74px;left:12px;right:12px;z-index:9999;max-height:75dvh;overflow:auto;background:var(--c-surface);color:var(--c-text);padding:16px 20px;border:1px solid var(--c-border);border-radius:var(--radius);box-shadow:0 16px 40px #0002}.dl-mobile-links a{display:flex;align-items:center;min-height:44px;text-decoration:none}.dl-mobile-links h4{font-size:12px;margin:18px 0 4px;color:var(--c-secondary)}.burger summary,.bmenu a{min-height:44px}.burger summary{display:flex;align-items:center}.burger:not([open])>.bmenu{display:none}.btn,.chip,.qty button{min-height:44px}.qty button{min-width:44px}[data-dl-footer] .cols{grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}[data-dl-footer] .cols>div:first-child{grid-column:1/-1}.pdp,.split{min-width:0}.pdp>*{min-width:0}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style><a class="dl-skip" href="#dl-content">Skip to content</a><style>
/* Pulse Records v2 — record label shop with a spinning turntable and a scroll crate, tokens only */
.pr-head{display:flex;align-items:center;gap:18px;padding:0 clamp(14px,3vw,40px);min-height:70px;background:var(--c-primary);color:var(--on-primary);position:sticky;top:0;z-index:50;border-bottom:4px solid var(--c-text)}
.pr-logo{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--on-primary);font:400 20px var(--f-head);letter-spacing:.02em}
.pr-logo i{width:34px;height:34px;border-radius:50%;background:radial-gradient(circle,var(--c-accent) 0 18%,var(--c-text) 19% 24%,transparent 25%),repeating-radial-gradient(circle,var(--c-text) 0 2px,#2a2a2a 2px 4px);display:inline-block;animation:prspin 6s linear infinite}
@keyframes prspin{to{transform:rotate(360deg)}}
.pr-nav{display:flex;gap:4px;list-style:none;margin-left:auto;align-items:center}
.pr-nav a{display:inline-flex;align-items:center;min-height:44px;padding:0 14px;text-decoration:none;font:400 12px var(--f-head);letter-spacing:.06em;text-transform:uppercase;color:var(--on-primary);border-radius:4px}
.pr-nav a:hover{background:var(--c-accent);color:var(--on-accent)}
.pr-nav .cart{border:2px solid var(--on-primary)}
.pr-nav .more{position:relative}
.pr-nav .dd{position:absolute;right:0;top:100%;display:none;grid-template-columns:repeat(4,minmax(130px,1fr));gap:16px 26px;padding:22px 26px;background:var(--c-surface);color:var(--c-text);border:4px solid var(--c-text);min-width:620px;z-index:60;text-align:left}
.pr-nav .more:hover .dd,.pr-nav .more:focus-within .dd{display:grid}
.pr-nav .dd h4{font:400 11px var(--f-head);letter-spacing:.1em;text-transform:uppercase;color:var(--c-primary);margin-bottom:6px}
.pr-nav .dd a{display:block;min-height:0;padding:5px 0;color:var(--c-text);text-transform:none;font:700 15px var(--f-body);letter-spacing:0;background:none}
.pr-nav .dd a:hover{background:none;color:var(--c-primary);text-decoration:underline}
.pr-m{display:none;margin-left:auto;position:relative}
.pr-m summary{list-style:none;cursor:pointer;min-height:44px;min-width:44px;display:grid;place-items:center;border:2px solid var(--on-primary);padding:0 14px;font:400 12px var(--f-head);letter-spacing:.08em}
.pr-m summary::-webkit-details-marker{display:none}
.pr-m nav{position:absolute;right:0;top:100%;min-width:250px;background:var(--c-surface);color:var(--c-text);border:4px solid var(--c-text);padding:8px 18px;display:grid;z-index:60}
.pr-m nav a{padding:12px 0;border-bottom:2px solid var(--c-text);text-decoration:none;font:700 15px var(--f-body);min-height:44px}
@media(max-width:900px){.pr-nav{display:none}.pr-m{display:block}}
.pr-tick{background:var(--c-accent);color:var(--on-accent);border-bottom:4px solid var(--c-text);overflow:hidden;white-space:nowrap}
.pr-tick span{display:inline-block;padding:9px 0;font:400 12px var(--f-head);letter-spacing:.1em;text-transform:uppercase;animation:prtk 28s linear infinite}
@keyframes prtk{to{transform:translateX(-50%)}}
.pr-sec{padding:clamp(34px,5vw,76px) clamp(14px,3vw,40px)}
.pr-hero{display:grid;grid-template-columns:1.05fr .95fr;gap:clamp(20px,4vw,56px);align-items:center;padding:clamp(30px,5vw,70px) clamp(14px,3vw,40px)}
@media(max-width:900px){.pr-hero{grid-template-columns:1fr}}
.pr-hero h1{font:400 clamp(30px,5vw,var(--h1))/1.05 var(--f-head);color:var(--c-text);text-transform:uppercase;letter-spacing:-.02em}
.pr-hero h1 span{background:var(--c-accent);padding:0 .12em;box-decoration-break:clone;-webkit-box-decoration-break:clone}
.pr-hero p{font:600 18px/1.7 var(--f-body);margin:18px 0 24px;max-width:38ch}
.pr-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 24px;background:var(--c-primary);color:var(--on-primary);font:400 13px var(--f-head);letter-spacing:.06em;text-transform:uppercase;text-decoration:none;border:3px solid var(--c-text);cursor:pointer;box-shadow:5px 5px 0 var(--c-text);transition:transform .1s,box-shadow .1s}
.pr-btn:hover{transform:translate(3px,3px);box-shadow:2px 2px 0 var(--c-text)}
.pr-btn.y{background:var(--c-accent);color:var(--on-accent)}
.pr-deck{background:var(--c-text);color:var(--c-surface);padding:clamp(18px,2.4vw,30px);border:4px solid var(--c-text);box-shadow:8px 8px 0 var(--c-secondary)}
.pr-plat{position:relative;width:min(100%,360px);aspect-ratio:1;margin:0 auto}
.pr-vinyl{position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle,var(--c-accent) 0 17%,var(--c-text) 17.5% 20%,transparent 20.5%),repeating-radial-gradient(circle,#0b0b0b 0 2px,#222 2px 4px),conic-gradient(from 20deg,transparent 0 20%,rgba(255,255,255,.12) 25%,transparent 30% 70%,rgba(255,255,255,.1) 75%,transparent 80%);background-blend-mode:normal;animation:prspin var(--sp,3s) linear infinite;animation-play-state:paused}
.pr-vinyl.on{animation-play-state:running}
.pr-vinyl::after{content:"";position:absolute;left:50%;top:50%;width:5%;height:5%;border-radius:50%;background:var(--c-surface);transform:translate(-50%,-50%)}
.pr-arm{position:absolute;right:-4%;top:2%;width:46%;height:6px;background:var(--c-surface);border-radius:4px;transform-origin:92% 50%;transform:rotate(26deg);transition:transform .6s}
.pr-arm.on{transform:rotate(44deg)}
.pr-arm::after{content:"";position:absolute;left:-4px;top:-5px;width:16px;height:16px;background:var(--c-accent)}
.pr-now{margin-top:16px;display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;border-top:2px solid color-mix(in srgb,var(--c-surface) 40%,transparent);padding-top:14px}
.pr-now b{font:400 18px var(--f-head);text-transform:uppercase;letter-spacing:.02em;display:block}
.pr-now span{font:600 13px var(--f-body);color:var(--c-secondary)}
.pr-play{min-height:48px;min-width:48px;padding:0 18px;border:0;background:var(--c-accent);color:var(--on-accent);font:400 13px var(--f-head);letter-spacing:.06em;cursor:pointer}
.pr-rpm{min-height:44px;padding:0 12px;border:2px solid var(--c-surface);background:transparent;color:var(--c-surface);font:400 12px var(--f-head);cursor:pointer}
.pr-tl{list-style:none;margin-top:12px}
.pr-tl button{display:grid;grid-template-columns:34px 1fr auto;gap:10px;width:100%;min-height:44px;padding:8px 6px;border:0;border-bottom:1px solid color-mix(in srgb,var(--c-surface) 25%,transparent);background:transparent;color:var(--c-surface);text-align:left;font:600 15px var(--f-body);cursor:pointer;align-items:center}
.pr-tl button b{font:400 12px var(--f-head);color:var(--c-accent)}
.pr-tl button[aria-pressed=true]{background:var(--c-primary)}
.pr-h{display:flex;justify-content:space-between;align-items:baseline;gap:14px;margin-bottom:20px;flex-wrap:wrap}
.pr-h h2{font:400 clamp(22px,3vw,var(--h2)) var(--f-head);text-transform:uppercase;letter-spacing:-.01em}
.pr-h span{font:600 14px var(--f-body);color:var(--c-secondary)}
.pr-crate{display:flex;gap:clamp(12px,1.6vw,20px);overflow-x:auto;scroll-snap-type:x mandatory;padding:6px 6px 22px;margin:0 -6px;-webkit-overflow-scrolling:touch}
.pr-sl{flex:0 0 clamp(190px,22vw,260px);scroll-snap-align:start;text-decoration:none;color:var(--c-text);display:grid;gap:8px}
.pr-sl .cv{aspect-ratio:1;border:3px solid var(--c-text);background:conic-gradient(from var(--a,0deg) at 30% 60%,var(--c1),var(--c2),var(--c3),var(--c1));position:relative;box-shadow:6px 6px 0 var(--c-text);transition:transform .15s}
.pr-sl:hover .cv{transform:translate(-3px,-3px) rotate(-1deg)}
.pr-sl .cv::after{content:"缺图";position:absolute;left:8px;bottom:8px;background:var(--c-surface);font:700 10px var(--f-body);padding:2px 8px;letter-spacing:.12em}
.pr-sl .p{position:absolute;right:-10px;top:-10px;background:var(--c-accent);color:var(--on-accent);border:3px solid var(--c-text);border-radius:50%;width:58px;height:58px;display:grid;place-items:center;font:400 14px var(--f-head);transform:rotate(10deg)}
.pr-sl b{font:400 15px var(--f-head);text-transform:uppercase;letter-spacing:0}
.pr-sl span{font:600 14px var(--f-body);color:var(--c-secondary)}
.pr-rows a{display:grid;grid-template-columns:90px 1.2fr 1.6fr 100px 80px;gap:14px;padding:16px 4px;border-top:3px solid var(--c-text);text-decoration:none;color:var(--c-text);align-items:center;transition:background .12s}
.pr-rows a:last-child{border-bottom:3px solid var(--c-text)}
.pr-rows a:hover{background:var(--c-accent)}
.pr-rows .no{font:400 12px var(--f-head);color:var(--c-primary)}
.pr-rows b{font:400 15px var(--f-head);text-transform:uppercase}
.pr-rows .f{font:700 12px var(--f-body);letter-spacing:.1em;text-transform:uppercase}
.pr-rows .pc{font:400 15px var(--f-head);text-align:right}
@media(max-width:760px){.pr-rows a{grid-template-columns:1fr auto;gap:4px}.pr-rows .no,.pr-rows .f{display:none}}
.pr-foot{background:var(--c-text);color:var(--c-surface);margin-top:clamp(30px,5vw,70px);padding:clamp(34px,5vw,60px) clamp(14px,3vw,40px) 22px}
.pr-foot .top{display:grid;grid-template-columns:1.1fr 2fr;gap:clamp(24px,5vw,80px)}
.pr-foot .big{font:400 30px var(--f-head);text-transform:uppercase;color:var(--c-accent)}
.pr-foot h4{font:400 11px var(--f-head);letter-spacing:.1em;text-transform:uppercase;color:var(--c-secondary);margin-bottom:10px}
.pr-foot ul{list-style:none}.pr-foot li a{display:inline-block;padding:6px 0;text-decoration:none;font:700 15px var(--f-body);color:var(--c-surface);min-height:34px}
.pr-foot .cols{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.pr-foot .copy{margin-top:24px;font:600 12px var(--f-body);opacity:.7}
@media(max-width:860px){.pr-foot .top{grid-template-columns:1fr}.pr-foot .cols{grid-template-columns:1fr 1fr}}
html,body{overflow-x:clip}img,svg{max-width:100%}
@media(prefers-reduced-motion:reduce){.pr-logo i,.pr-tick span{animation:none}.pr-vinyl{animation:none}.pr-arm{transition:none}}
.pr .pagehead{background:var(--c-primary);color:var(--on-primary)}.pr .pagehead h1,.pr .pagehead .lead,.pr .pagehead .crumbs,.pr .pagehead .eyebrow{color:var(--on-primary)}.pr .card,.pr .scard,.pr .qcard,.pr .pcard,.pr .person{background:var(--c-surface);border:3px solid var(--c-primary);box-shadow:5px 5px 0 var(--c-accent)}.pr .eyebrow{display:inline-block;background:var(--c-accent);color:var(--on-accent);padding:4px 12px;border-radius:99px;opacity:1}.pr h1,.pr h2,.pr h3{letter-spacing:-.01em}.pr .alt{background:color-mix(in srgb,var(--c-secondary) 12%,var(--c-surface))}/*presets*/

.pr .svc{display:grid;grid-template-columns:repeat(3,1fr);gap:0;counter-reset:sv}
.pr .scard{display:flex;flex-direction:column;justify-content:space-between;aspect-ratio:1;padding:clamp(18px,2.4vw,32px);border:0;border-radius:0;box-shadow:none;background:color-mix(in srgb,var(--c-primary) 92%,var(--c-surface));color:var(--on-primary);counter-increment:sv}
.pr .scard:nth-child(3n+2){background:var(--c-accent);color:var(--on-accent)}
.pr .scard:nth-child(3n){background:color-mix(in srgb,var(--c-secondary) 55%,var(--c-surface));color:var(--c-text)}
.pr .scard::before{content:counter(sv,decimal-leading-zero);font:700 13px var(--f-body);letter-spacing:.16em;opacity:.8}
.pr .scard .ph{display:none}.pr .scard h3{color:inherit;font-size:clamp(22px,2.4vw,32px)}.pr .scard p{color:inherit;opacity:.85}.pr .scard .m{color:inherit;display:flex;gap:12px;font-size:13px}
@media(max-width:800px){.pr .svc{grid-template-columns:1fr 1fr}.pr .scard{aspect-ratio:auto;min-height:200px}}@media(max-width:520px){.pr .svc{grid-template-columns:1fr}}

.pr .tgrid{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:14px}
.pr .person{flex:0 0 min(240px,70vw);scroll-snap-align:start}

.pr .qgrid{display:block;columns:2 300px;column-gap:20px}.pr .qgrid.mt{margin-top:20px}
.pr .qcard{break-inside:avoid;margin-bottom:20px}

.pr .masonry{display:grid!important;grid-template-columns:repeat(3,1fr);gap:clamp(8px,1.4vw,18px);columns:auto}
.pr .masonry .mi{margin:0}.pr .masonry .mi .ph{aspect-ratio:4/3!important}
@media(max-width:700px){.pr .masonry{grid-template-columns:1fr 1fr}}

.pr .articles{display:block!important}
.pr .art{display:grid;grid-template-columns:110px 1fr;gap:4px 24px;padding:22px 0;border-bottom:1px solid var(--c-border)}
.pr .art .ph{display:none}.pr .art .meta{grid-row:1/span 2;align-self:start}.pr .art h3{margin:0}
.pr .feat{border-bottom:2px solid var(--c-primary);padding-bottom:26px;margin-bottom:6px}

.pr .faq{counter-reset:q;max-width:960px}
.pr .faq details{counter-increment:q;position:relative;padding-left:64px}
.pr .faq details::before{content:counter(q,decimal-leading-zero);position:absolute;left:0;top:18px;font:700 22px var(--f-head);color:var(--c-accent)}

.pr .pricing .card{border:2px solid var(--c-primary);background:var(--c-surface)!important;box-shadow:none;border-radius:0;color:var(--c-text)!important;transform:none!important}
.pr .pricing .card.hl{border-width:4px;background:var(--c-surface)!important}
.pr .pricing .card.hl h3,.pr .pricing .card.hl .amt{color:var(--c-primary)!important}.pr .pricing .card.hl li::before{color:var(--c-accent)!important}
.pr .split{display:flex;flex-direction:column-reverse;gap:30px}.pr .cinfo{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}@media(max-width:800px){.pr .cinfo{grid-template-columns:1fr 1fr}}
.pr .sec.dark{background:var(--c-accent);color:var(--on-accent)}.pr .sec.dark h2,.pr .sec.dark p{color:var(--on-accent)}.pr .sec.dark .btn{background:var(--c-primary);border-color:var(--c-primary);color:var(--on-primary)}
.pr .steps b{font-size:clamp(42px,6vw,84px);line-height:1;color:var(--c-accent);letter-spacing:-.02em;display:block}.pr .steps>div{border-top:0;border-left:1px solid var(--c-border);padding-left:20px}

.pr .tl{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;border-top:3px solid var(--c-primary)}
.pr .tl>div{padding:20px 18px 20px 0;border-right:1px solid var(--c-border)}.pr .tl>div:last-child{border-right:0}
.pr .tl b{display:block;font-size:clamp(36px,5vw,64px);line-height:1;color:var(--c-accent);margin-bottom:8px}

.pr .vals{display:grid;grid-template-columns:repeat(3,1fr);gap:0;border-top:2px solid var(--c-primary)}
.pr .vals .card{border:0;border-right:1px solid var(--c-border);border-radius:0;background:none;box-shadow:none;padding:24px 22px}.pr .vals .card:last-child{border-right:0}
@media(max-width:700px){.pr .vals{grid-template-columns:1fr}.pr .vals .card{border-right:0;border-bottom:1px solid var(--c-border)}}

.pr-ab{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}.pr-ab>div{border:3px solid var(--c-text);padding:18px;background:var(--c-surface);box-shadow:6px 6px 0 var(--c-text)}
.pr-ab b{font:400 34px var(--f-head);color:var(--c-primary);display:block}.pr-ab span{font:700 13px var(--f-body);letter-spacing:.06em;text-transform:uppercase}
@media(max-width:800px){.pr-ab{grid-template-columns:1fr 1fr}}
.pr-sv{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.pr-sv>div{border:3px solid var(--c-text);padding:22px;background:var(--c-accent);box-shadow:6px 6px 0 var(--c-text);display:grid;gap:8px;align-content:start}
.pr-sv>div:nth-child(2){background:var(--c-secondary)}.pr-sv>div:nth-child(3){background:var(--c-primary);color:var(--on-primary)}.pr-sv>div:nth-child(3) h3{color:var(--on-primary)}
.pr-sv h3{font:400 20px var(--f-head);text-transform:uppercase}.pr-sv p{font:600 15px/1.6 var(--f-body)}
@media(max-width:800px){.pr-sv{grid-template-columns:1fr}}</style><header class="pr-head"><a class="pr-logo" href="index.php"><i></i>Pulse Records</a><ul class="pr-nav"><li><a href="shop.php">Shop</a></li><li><a href="projects.php">Artists</a></li><li><a href="schedule.php">Shows</a></li><li><a href="blog.php">Journal</a></li><li class="more"><a href="#" tabindex="0">More</a><div class="dd"><div><h4>Main</h4><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Merch</a><a href="service.php">Single Merch</a><a href="pricing.php">Subscribe</a><a href="contact.php">Contact</a></div><div><h4>Shop</h4><a href="shop.php">Releases</a><a href="product.php">Single Release</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a></div><div><h4>Proof</h4><a href="testimonials.php">Testimonials</a><a href="team.php">Artists</a><a href="projects.php">Artists</a><a href="project.php">Single Artist</a><a href="gallery.php">Gallery</a></div><div><h4>Content</h4><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a></div><div><h4>Special</h4><a href="schedule.php">Shows</a><a href="booking.php">Submit a demo</a></div><div><h4>Utility</h4><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></div></div></li><li><a class="cart" href="cart.php">Crate · 0</a></li></ul><details class="pr-m"><summary>MENU</summary><nav><a href="index.php">Home</a><a href="about.php">About</a><a href="services.php">Merch</a><a href="service.php">Single Merch</a><a href="pricing.php">Subscribe</a><a href="contact.php">Contact</a><a href="shop.php">Releases</a><a href="product.php">Single Release</a><a href="cart.php">Cart</a><a href="checkout.php">Checkout</a><a href="testimonials.php">Testimonials</a><a href="team.php">Artists</a><a href="projects.php">Artists</a><a href="project.php">Single Artist</a><a href="gallery.php">Gallery</a><a href="blog.php">News</a><a href="post.php">Single post</a><a href="faq.php">FAQ</a><a href="schedule.php">Shows</a><a href="booking.php">Submit a demo</a><a href="careers.php">Careers</a><a href="privacy.php">Privacy policy</a><a href="404.php">404 error</a><a href="coming-soon.php">Coming soon</a></nav></details></header><div class="pr-tick" aria-hidden="true"><span>NEW PRESS · LIMITED 300 · FREE POSTER WITH ANY 2 LPS · LOUD NIGHTS EVERY FRIDAY · NEW PRESS · LIMITED 300 · FREE POSTER WITH ANY 2 LPS · LOUD NIGHTS EVERY FRIDAY · NEW PRESS · LIMITED 300 · FREE POSTER WITH ANY 2 LPS · LOUD NIGHTS EVERY FRIDAY · </span></div><div class="pr"><script>/* Runs in previews AND exported files. No requests, credentials or submissions. */
(function(){
 'use strict';
 function start(){
  var root=document.querySelector('[data-dl-template]');if(!root)return;
  document.querySelectorAll('[data-dl-demo-form]').forEach(function(form,index){
   if(form.dataset.dlBound)return;form.dataset.dlBound='1';
   var note=document.createElement('p');note.className='dl-form-note';note.textContent='Interactive demo · Nothing is sent. Use sample details only. No account, booking or payment will be created.';form.prepend(note);
   var result=document.createElement('p');result.className='dl-feedback';result.setAttribute('role','status');result.setAttribute('aria-live','polite');result.hidden=true;form.append(result);
   form.querySelectorAll('input,textarea,select').forEach(function(input,i){
    if(!input.name)input.name='demo-'+index+'-'+i;
    var label=input.closest('label'),text=(label?label.textContent:input.placeholder||'').toLowerCase();
    if(/name|email|message|date|time/.test(text)&&!/optional/.test(text))input.required=true;
    if(input.type==='password')input.autocomplete='new-password';
    if(/card number|cvc|expiry/.test(text)){input.disabled=true;input.placeholder='Disabled in demo';}
   });
   function submit(e){if(e)e.preventDefault();if(!form.reportValidity())return;result.hidden=false;result.textContent='Demo complete. Your entries passed the browser checks. Nothing was sent, charged, booked or stored.';}
   form.addEventListener('submit',submit);
   if(!form.querySelector('[type="submit"],button:not([type])')){var buttons=form.querySelectorAll('button[type="button"]');if(buttons.length===1)buttons[0].addEventListener('click',submit);}
  });
  document.querySelectorAll('.dl-visual img').forEach(function(img){img.addEventListener('error',function(){img.parentElement.classList.add('dl-photo-failed')});if(img.complete&&!img.naturalWidth)img.parentElement.classList.add('dl-photo-failed')});
  document.querySelectorAll('.shoptop').forEach(function(top){
   var grid=top.nextElementSibling;if(!grid||!grid.matches('.products'))return;
   var cards=Array.from(grid.children),chips=Array.from(top.querySelectorAll('.chip')),sort=top.querySelector('select'),category='All';
   var empty=document.createElement('p');empty.className='dl-filter-empty';empty.textContent='No sample items match this category. Choose All to see the collection.';empty.hidden=true;grid.after(empty);
   function update(){var shown=0;cards.forEach(function(card){var tag=card.querySelector('small');card.hidden=category!=='All'&&(!tag||tag.textContent.trim()!==category);if(!card.hidden)shown++});empty.hidden=shown!==0;var count=top.querySelector('.sort span');if(count)count.textContent=shown+' sample items';}
   chips.forEach(function(chip){chip.type='button';chip.setAttribute('aria-pressed',chip.classList.contains('on'));chip.addEventListener('click',function(){category=chip.textContent.trim();chips.forEach(function(c){c.classList.toggle('on',c===chip);c.setAttribute('aria-pressed',c===chip)});update()})});
   if(sort){sort.setAttribute('aria-label','Sort sample items');Array.from(sort.options).forEach(function(o){if(/newest/i.test(o.textContent))o.textContent='Reverse featured'});sort.addEventListener('change',function(){var ordered=cards.slice();if(sort.selectedIndex===1||sort.selectedIndex===2){ordered.sort(function(a,b){function price(c){var p=c.querySelector('.price');return Number((p?p.textContent:'').replace(/[^0-9.]/g,''))||0}return price(a)-price(b)});if(sort.selectedIndex===2)ordered.reverse()}else if(sort.selectedIndex===3)ordered.reverse();ordered.forEach(function(card){grid.append(card)})})}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.burger[open],.dl-mobile[open],.nav details[open]').forEach(function(menu){menu.open=false;var summary=menu.querySelector('summary');if(summary)summary.focus()})});
  document.addEventListener('click',function(e){var a=e.target.closest('.dl-mobile a,.bmenu a');if(a){var menu=a.closest('details');if(menu)menu.open=false;}});
  document.querySelectorAll('.more>a[href="#"]').forEach(function(a){a.setAttribute('role','button');a.setAttribute('aria-expanded','false');function set(open){a.parentElement.classList.toggle('dl-menu-open',open);a.setAttribute('aria-expanded',open)}function toggle(e){e.preventDefault();set(a.getAttribute('aria-expanded')!=='true')}a.addEventListener('click',toggle);a.addEventListener('keydown',function(e){if(e.key===' ')toggle(e)});a.parentElement.addEventListener('mouseenter',function(){set(true)});a.parentElement.addEventListener('mouseleave',function(){if(!a.parentElement.contains(document.activeElement))set(false)})});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href="#"]');if(!a||e.defaultPrevented||a.onclick||a.closest('.more'))return;e.preventDefault();var note=a.parentElement.querySelector(':scope>.dl-missing-link');if(!note){note=document.createElement('p');note.className='dl-feedback dl-missing-link';note.setAttribute('role','status');a.after(note)}note.textContent='Demonstration link. Add the real destination before launching this site.'});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dl-menu-open').forEach(function(menu){menu.classList.remove('dl-menu-open');var a=menu.querySelector(':scope>a');if(a){a.setAttribute('aria-expanded','false');a.focus()}})});
  document.querySelectorAll('.dl-skip').forEach(function(link){link.addEventListener('click',function(e){e.preventDefault();var target=document.querySelector('main.on [data-dl-content],main:not([data-page]) [data-dl-content]');if(target){target.focus();target.scrollIntoView({block:'start'})}})});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script><script>/* Sample commerce only: local item choices, quantities and consistent totals. */
(function(){
 'use strict';
 function start(){
  var marker=document.querySelector('[data-dl-template]');if(!marker||marker.dataset.dlTemplate==='restaurant-warm')return;
  var carts=Array.from(document.querySelectorAll('.cart')).filter(function(x){return x.querySelector('.crow')}),details=Array.from(document.querySelectorAll('.pdp,[data-dl-product]')).filter(function(x){return x.querySelector('.pinfo .price')}),checkouts=Array.from(document.querySelectorAll('aside.side-card')).filter(function(x){return x.querySelector('.kv')&&x.previousElementSibling&&x.previousElementSibling.querySelector('form')});
  if(!carts.length&&!details.length&&!checkouts.length)return;
  var currency='RM ',rows=[],key='dl-sample-cart:'+marker.dataset.dlTemplate;
  function amount(text){return Number(String(text).replace(/[^0-9.]/g,''))||0}
  function money(n){return currency+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function item(name,price,qty){return {name:String(name).slice(0,120),price:Math.max(0,Math.min(10000000,price)),qty:Math.max(1,Math.min(99,qty))}}
  if(carts.length){rows=Array.from(carts[0].querySelectorAll('.crow')).map(function(row){var p=row.querySelector(':scope>b'),h=row.querySelector('h3'),q=row.querySelector('.qty span');if(p){currency=p.textContent.replace(/[0-9.,\s]/g,'')+' '}return item(h?h.textContent:'Sample item',amount(p?p.textContent:0),amount(q?q.textContent:1)||1)})}
  else if(checkouts.length){rows=Array.from(checkouts[0].querySelectorAll('.kv li:not(.tot)')).filter(function(row){return row.querySelector('b')&&amount(row.querySelector('b').textContent)>0&&!/tax|shipping|delivery|subtotal|fee/i.test(row.textContent)}).map(function(row){var p=row.querySelector('b');currency=p.textContent.replace(/[0-9.,\s]/g,'')+' ';return item(row.querySelector('span').textContent,amount(p.textContent),1)})}
  try{var saved=JSON.parse(localStorage.getItem(key));if(saved&&Array.isArray(saved.rows)&&saved.rows.length<=100){rows=saved.rows.filter(function(r){return typeof r.name==='string'&&Number.isFinite(r.price)&&r.price>=0&&Number.isInteger(r.qty)&&r.qty>0&&r.qty<=99}).map(function(r){return item(r.name,r.price,r.qty)});if(typeof saved.currency==='string'&&/^[A-Z$€£¥ ]{1,8}$/.test(saved.currency))currency=saved.currency;}}catch(e){}
  function save(){try{localStorage.setItem(key,JSON.stringify({currency:currency,rows:rows}))}catch(e){}}
  function totals(){var sub=rows.reduce(function(sum,r){return sum+r.price*r.qty},0);return {subtotal:sub,total:sub}}
  function makeLine(label,value,total){var li=document.createElement('li');if(total)li.className='tot';var span=document.createElement('span'),b=document.createElement('b');span.textContent=label;b.textContent=value;li.append(span,b);return li}
  function render(){
   document.querySelectorAll('header a[href]').forEach(function(a){var match=a.textContent.trim().match(/^(Cart|Bag)\s*\(\d+\)$/i);if(match)a.textContent=match[1]+' ('+rows.reduce(function(sum,r){return sum+r.qty},0)+')'});
   carts.forEach(function(cart){cart.querySelectorAll('.crow,.dl-cart-empty').forEach(function(r){r.remove()});rows.forEach(function(row,i){var el=document.createElement('div');el.className='crow';el.dataset.dlCartRow=i;var spacer=document.createElement('div'),info=document.createElement('div'),h=document.createElement('h3'),small=document.createElement('small');h.textContent=row.name;small.textContent=money(row.price)+' each · sample item';info.append(h,small);var qty=document.createElement('div');qty.className='qty';[-1,1].forEach(function(change){var b=document.createElement('button');b.type='button';b.dataset.dlCartChange=change;b.textContent=change<0?'−':'+';b.setAttribute('aria-label',(change<0?'Decrease ':'Increase ')+row.name);if(change>0){var value=document.createElement('span');value.textContent=row.qty;qty.append(value)}qty.append(b)});var price=document.createElement('b');price.textContent=money(row.price*row.qty);var remove=document.createElement('button');remove.type='button';remove.className='btn ghost';remove.dataset.dlCartRemove='';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+row.name);el.append(spacer,info,qty,price,remove);cart.insertBefore(el,cart.querySelector(':scope>a'))});if(!rows.length){var empty=document.createElement('p');empty.className='dl-cart-empty';empty.setAttribute('role','status');empty.textContent='Your sample cart is empty. Browse the collection to add an item.';cart.prepend(empty)}var aside=cart.parentElement.querySelector('aside.side-card');if(aside){var list=aside.querySelector('.kv');if(list){list.replaceChildren(makeLine('Subtotal',money(totals().subtotal)),makeLine('Demo delivery / fees','Not applied'),makeLine('Total',money(totals().total),true))}var note=aside.querySelector('p');if(note)note.textContent='Local sample cart. Real delivery, tax and payment must be configured before launch.'}});
   checkouts.forEach(function(aside){var list=aside.querySelector('.kv');list.replaceChildren();rows.forEach(function(r){list.append(makeLine(r.qty+' × '+r.name,money(r.price*r.qty)))});list.append(makeLine('Total · demo only',money(totals().total),true));var form=aside.parentElement.querySelector('form'),button=form&&form.querySelector('[type=submit]');if(button){button.textContent=rows.length?'Preview checkout · '+money(totals().total):'Add an item before checkout';button.disabled=!rows.length}});
  }
  details.forEach(function(detail){detail.querySelectorAll('.qty button').forEach(function(b){b.type='button';b.setAttribute('aria-label',b.textContent.trim()==='+'?'Increase quantity':'Decrease quantity')});detail.querySelectorAll('.chips .chip').forEach(function(b){b.type='button';b.setAttribute('aria-pressed',b.classList.contains('on'));b.addEventListener('click',function(){b.parentElement.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)})})})});
  document.addEventListener('click',function(e){var row=e.target.closest('[data-dl-cart-row]');if(row){var index=Number(row.dataset.dlCartRow),change=e.target.closest('[data-dl-cart-change]');if(e.target.closest('[data-dl-cart-remove]'))rows.splice(index,1);else if(change&&rows[index])rows[index].qty=Math.max(1,Math.min(99,rows[index].qty+Number(change.dataset.dlCartChange)));save();render();return}
   var detail=e.target.closest('.pdp,[data-dl-product]');if(!detail)return;var button=e.target.closest('.qty button');if(button&&!button.onclick){var span=button.parentElement.querySelector('span');if(span)span.textContent=Math.max(1,Math.min(99,amount(span.textContent)+(button.textContent.trim()==='+'?1:-1)))}
   var link=e.target.closest('.buy a,[data-dl-add]');if(link&&!e.defaultPrevented&&link.getAttribute('aria-disabled')!=='true'&&/cart(?:\.|$)|#\/cart/.test(link.getAttribute('href')||'')){var h=detail.querySelector('.pinfo h1'),price=detail.querySelector('.pinfo .price'),q=detail.querySelector('.qty span');if(h&&price){var chosen=Array.from(detail.querySelectorAll('.pinfo .chip.on,.pinfo .ok-finish [aria-pressed=true]')).map(function(b){return b.getAttribute('aria-label')||b.textContent.trim()}),name=h.textContent+(chosen.length?' · '+chosen.join(' / '):''),quantity=amount(q?q.textContent:1)||1,found=rows.find(function(r){return r.name===name});if(found)found.qty=Math.min(99,found.qty+quantity);else rows.push(item(name,amount(price.textContent),quantity));save();render()}}
  });
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
</script>
<main>
