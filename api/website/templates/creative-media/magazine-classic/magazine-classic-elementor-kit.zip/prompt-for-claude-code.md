# Build "Magazine Classic" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #18181B · Secondary #991B1B · Text #27272A · Accent #DC2626 · Surface #FAFAFA · Border #E5E5E5

## 2. Global Fonts
Headings: Libre Baskerville · Body: Source Serif 4
H1 52px / H2 34px / H3 22px / Body 18px

## 3. Layout
Content width 1300px · Section padding 72px vertical · Border radius 2px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- About (about) — html/about.html
- Subscribe (services) — html/services.html
- Single service (service) — html/service.html
- Subscribe (pricing) — html/pricing.html
- Contact (contact) — html/contact.html
- Shop (shop) — html/shop.html
- Single Product (product) — html/product.html
- Cart (cart) — html/cart.html
- Checkout (checkout) — html/checkout.html
- Testimonials (testimonials) — html/testimonials.html
- Team (team) — html/team.html
- Sections (projects) — html/projects.html
- Single Section (project) — html/project.html
- Gallery (gallery) — html/gallery.html
- Latest (blog) — html/blog.html
- Single post (post) — html/post.html
- FAQ (faq) — html/faq.html
- Section page (archive) — html/archive.html
- Author page (author) — html/author.html
- Newsletter (newsletter) — html/newsletter.html
- Careers (careers) — html/careers.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html
- Coming soon (coming-soon) — html/coming-soon.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
