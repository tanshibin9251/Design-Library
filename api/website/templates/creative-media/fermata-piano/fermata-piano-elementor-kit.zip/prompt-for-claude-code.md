# Build "Fermata Piano" in Elementor

You are working in WordPress with Elementor (Pro) through MCP. Recreate this template.

## 1. Site Settings › Global Colors
Primary #201c17 · Secondary #8a7d68 · Text #2a251f · Accent #0f7b7b · Surface #f5efe0 · Border #d8cdb4

## 2. Global Fonts
Headings: Old Standard TT · Body: Libre Franklin
H1 84px / H2 44px / H3 24px / Body 16px

## 3. Layout
Content width 1300px · Section padding 92px vertical · Border radius 8px

## 4. Pages to create (use the HTML files in /html as the visual reference)
- Home (home) — html/home.html
- Programme (courses) — html/courses.html
- Course: Piano from Zero (course) — html/course.html
- Lesson & metronome (lesson) — html/lesson.html
- Keyboard (keyboard) — html/keyboard.html
- Teachers (teachers) — html/teachers.html
- Tuition (pricing) — html/pricing.html
- FAQ (faq) — html/faq.html
- Privacy policy (privacy) — html/privacy.html
- 404 error (404) — html/404.html

## Rules
- Bind every colour and font to the Global Colors / Fonts above. Never hard-code hex.
- Use native widgets (Heading, Text, Button, Image Box, Icon List, Form). Use the HTML widget only for effects.
- Build the header and footer once as Theme Builder templates; use the Menu widget for navigation.
